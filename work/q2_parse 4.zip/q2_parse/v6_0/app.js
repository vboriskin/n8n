'use strict';
/* ============================================================
   Q2 PLAN ANALYZER — app.js  (v3)
   ============================================================ */

// ============================================================
// CONSTANTS
// ============================================================
const STORAGE_KEY = 'q2_plan_v3';
const SETTINGS_KEY = 'q2_settings_v3';
const LLM_SETTINGS_KEY = 'q2_llm_settings_v1';
const STORAGE_KEYS = [STORAGE_KEY, 'q2_plan_v2', 'q2_plan'];
const SETTINGS_KEYS = [SETTINGS_KEY, 'q2_settings_v2', 'q2_settings'];
const DEFAULT_LLM_SYSTEM_PROMPT = `Ты аналитик внутри СБОФ Планировщик — инструмента планирования спринта Q2. Отвечай на русском языке, опираясь на переданный контекст приложения.

Структура контекста:
- summary: агрегированная статистика (totalRows, done, blockers, risky, inScope и т.д.)
- releaseDistribution: распределение задач по релизам (backlog, 1.20, 1.21, 1.22, overtime)
- riskSummary: счётчики по типам рисков
- teamBreakdown: количество задач, блокеров, рисков по каждой команде
- topBlockers / topRiskyRows: конкретные задачи-блокеры и рискованные строки с деталями
- rows / visibleRows: массив строк реестра с полями: team, epic, tasks, scopeStatus, release120/121/122Types, overtimeTypes, assignee, blockingDependency, riskFlags, isDone, workPeriodStart/End, comment

Релизные окна: 1.20 (20.04–17.05), 1.21 (18.05–14.06), 1.22 (15.06–14.07), Overtime — задачи за пределами окон.
Типы работ: backend, frontend, тестирование, аналитика, бизнес аналитика, внедрение, миграция данных, стабилизация, хотфикс.
Статусы scope: "Да" = в скоупе, "Нет" = вне скоупа, "Требует подтверждения" = на согласовании.

Давай конкретные, actionable ответы. Ссылайся на конкретные команды, эпики, задачи из данных. Если в переданном контексте данных достаточно — отвечай. Если строк нет или контекст пуст — предложи пользователю выбрать режим контекста "Весь реестр" в настройках ассистента (⚙).`.trim();

const RELEASE_WINDOWS = {
  r120:    { label:'Релиз 1.20', short:'1.20', dates:'20.04–17.05', barCls:'gantt-bar-r120',    winCls:'gantt-window-r120',    stageCls:'stage-r120'    },
  r121:    { label:'Релиз 1.21', short:'1.21', dates:'18.05–14.06', barCls:'gantt-bar-r121',    winCls:'gantt-window-r121',    stageCls:'stage-r121'    },
  r122:    { label:'Релиз 1.22', short:'1.22', dates:'15.06–14.07', barCls:'gantt-bar-r122',    winCls:'gantt-window-r122',    stageCls:'stage-r122'    },
  overtime:{ label:'Овертайм',   short:'OT',   dates:'',            barCls:'gantt-bar-overtime', winCls:'gantt-window-overtime', stageCls:'stage-overtime' },
};

const PHASE_ORDER = ['бизнес аналитика','аналитика','backend','frontend','тестирование','внедрение','миграция данных','стабилизация','хотфикс'];
const PHASE_COLORS = {
  'бизнес аналитика':'#7c3aed','аналитика':'#0284c7','backend':'#4f46e5','frontend':'#059669',
  'тестирование':'#d97706','внедрение':'#dc2626','миграция данных':'#db2777',
  'стабилизация':'#65a30d','хотфикс':'#ea580c',
};
const PHASE_SHORT = {
  'бизнес аналитика':'БА',
  'аналитика':'АН',
  'backend':'BE',
  'frontend':'FE',
  'тестирование':'QA',
  'внедрение':'ВН',
  'миграция данных':'МД',
  'стабилизация':'СТ',
  'хотфикс':'HF',
};
const GANTT_RELEASE_WINDOWS = [
  { key:'r120', label:'1.20', start:new Date('2025-04-20'), end:new Date('2025-05-17'), tf:'release120Types' },
  { key:'r121', label:'1.21', start:new Date('2025-05-18'), end:new Date('2025-06-14'), tf:'release121Types' },
  { key:'r122', label:'1.22', start:new Date('2025-06-15'), end:new Date('2025-07-14'), tf:'release122Types' },
  { key:'ot',   label:'OT',   start:null, end:null, tf:'overtimeTypes' },
];
const GANTT_TIMELINE_START = new Date('2025-04-01');
const GANTT_TIMELINE_END   = new Date('2025-09-01');
const GANTT_DAY_PX = 5;
const GANTT_RELEASE_BOUNDS = {
  r120: [new Date(GANTT_RELEASE_WINDOWS[0].start), new Date(GANTT_RELEASE_WINDOWS[0].end)],
  r121: [new Date(GANTT_RELEASE_WINDOWS[1].start), new Date(GANTT_RELEASE_WINDOWS[1].end)],
  r122: [new Date(GANTT_RELEASE_WINDOWS[2].start), new Date(GANTT_RELEASE_WINDOWS[2].end)],
};

const WORK_TYPES = [
  'backend','frontend','тестирование','аналитика',
  'бизнес аналитика','внедрение','миграция данных','стабилизация','хотфикс',
];

const SCOPE_OPTIONS = ['Да','Нет','Требует подтверждения'];

const RISK_FLAGS = {
  CONFIRMATION_IN_RELEASE: 'Подтверждение, но уже в релизе',
  IN_SCOPE_WITHOUT_RELEASE: 'В scope, но без релиза',
  BLOCKING_NEAR_RELEASE:    'Блокер в ближайшем релизе',
};

const LEGACY_WT_MAP = {
  'разработка':'backend','backend':'backend','frontend':'frontend',
  'аналитика':'аналитика','тестирование':'тестирование','внедрение':'внедрение',
  'бизнес аналитика':'бизнес аналитика','миграция данных':'миграция данных',
  'стабилизация':'стабилизация','хотфикс':'хотфикс',
};

const WT_CLS = {
  'backend':'wt-backend','frontend':'wt-frontend',
  'тестирование':'wt-testing','аналитика':'wt-analytics','бизнес аналитика':'wt-analytics',
};

// Registry columns definition — epic FIRST (sticky)
const REGISTRY_COLS = [
  { key:'epic',               label:'Эпик',          type:'text',        visible:true,  width:180 },
  { key:'team',               label:'Команда',       type:'suggest',     visible:true,  width:110 },
  { key:'category',           label:'Категория',     type:'tags',        visible:true,  width:110 },
  { key:'tags',               label:'Теги',          type:'tags',        visible:false, width:150 },
  { key:'tasks',              label:'Задачи',        type:'jira',        visible:true,  width:220 },
  { key:'scopeStatus',        label:'Scope',         type:'scope',       visible:true,  width:130 },
  { key:'release120Types',    label:'1.20',          type:'multiselect', visible:true,  width:160 },
  { key:'release121Types',    label:'1.21',          type:'multiselect', visible:true,  width:160 },
  { key:'release122Types',    label:'1.22',          type:'multiselect', visible:true,  width:160 },
  { key:'overtimeTypes',      label:'Овертайм',      type:'multiselect', visible:true,  width:160 },
  { key:'role',               label:'Роли',          type:'tags',        visible:true,  width:150 },
  { key:'isDone',             label:'Сделано',       type:'checkbox',    visible:true,  width:70  },
  { key:'doneDate',           label:'Дата сделано',  type:'date',        visible:true,  width:120 },
  { key:'blockingDependency', label:'Блокер',        type:'checkbox',    visible:true,  width:60  },
  { key:'blockingDeadline',   label:'Deadline',      type:'date',        visible:true,  width:120 },
  { key:'backend',            label:'BE SP',         type:'number',      visible:false, width:70  },
  { key:'frontend',           label:'FE SP',         type:'number',      visible:false, width:70  },
  { key:'analytics_estimate', label:'Ан. SP',        type:'number',      visible:false, width:70  },
  { key:'testing_estimate',   label:'Тест. SP',      type:'number',      visible:false, width:70  },
  { key:'total_estimate',     label:'Оценка',        type:'number',      visible:false, width:70  },
  { key:'risks',              label:'Риски',         type:'text',        visible:false, width:180 },
  { key:'taskComment',        label:'Коммент.',      type:'text',        visible:false, width:180 },
  { key:'teamDependency',     label:'Зависимость',   type:'text',        visible:false, width:150 },
  { key:'comment',            label:'Комментарий',   type:'text',        visible:false, width:180 },
  { key:'workPeriod',         label:'Период работ',  type:'daterange',   visible:true,  width:190 },
  { key:'workPeriodStart',    label:'Период (нач.)', type:'date',        visible:false, width:120 },
  { key:'workPeriodEnd',      label:'Период (кон.)', type:'date',        visible:false, width:120 },
  { key:'assignee',           label:'Исполнитель',   type:'tags',        visible:true,  width:170 },
  { key:'sourceSheet',        label:'Лист',          type:'readonly',    visible:false, width:100 },
  { key:'priority',           label:'Приоритет',     type:'priority',    visible:true,  width:100 },
  { key:'businessValue',      label:'Ценность',      type:'number',      visible:false, width:80  },
  { key:'riskScore',          label:'Риск',          type:'riskscore',   visible:true,  width:70  },
];
const COL_TYPES = ['text','number','tags','multiselect','scope','checkbox','date','suggest','daterange','readonly','jira'];

// ============================================================
// STATE
// ============================================================
const state = {
  rows: [],
  employees: [],
  filters: {
    search:'', team:'', scope:'', release:'', workType:'', role:'', assignee:'', tag:'',
    onlyBlocking:false, onlyRisky:false, onlyDone:false, preset:null,
  },
  activeSection: 'dashboard',
  diagnostics: {
    sources:[], sheets:[], rowsPerSheet:{}, detectedColumns:{}, missingColumns:{}, warnings:[],
    registryCount:0, csvImportCount:0, localStorageCount:0,
  },
  sort: { col:null, dir:'asc' },
  ganttMode: 'compact',
  ganttEpicsWell: 'none',
  epicDeps: {},
  gantt2Zoom: 1,
  gantt2ShowDeps: true,
  gantt2Team: '',
  lastClickedRowId: null,
  timelineMode: 'summary',
  podlozhkaGroup: 'team',
  podlozhkaMode: 'summary',
  summaryMode: 'brief',
  presetsCollapsed: false,
  theme: 'light',
  colVisibility: {},
  colOrder: REGISTRY_COLS.map(c => c.key),
  colWidths: {},
  colLabels: {},
  pinnedCols: [],
  rowHeight: 36,
  customCols: [],
  colTypes: {},
  sidebarCollapsed: false,
  _idCounter: 1,
  _dataVersion: 0,
  llm: {},
  simMode: false,
  bulkSelected: new Set(),
};
REGISTRY_COLS.forEach(c => { state.colVisibility[c.key] = c.visible; });

function getAllCols() {
  return [...REGISTRY_COLS, ...state.customCols].map(col => ({
    ...col,
    type: state.colTypes[col.key] || col.type || 'text',
  }));
}

function toBool(value, fallback=false) {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  if (typeof value === 'string') {
    const v = value.trim().toLowerCase();
    if (['true','1','yes','on','да'].includes(v)) return true;
    if (['false','0','no','off','нет',''].includes(v)) return false;
  }
  return !!fallback;
}

function syncColumnSettings() {
  // Sanitize custom columns first (old localStorage could contain half-broken objects).
  const seenCustom = new Set();
  state.customCols = (Array.isArray(state.customCols) ? state.customCols : []).map((col, idx) => {
    if (!col || typeof col !== 'object') return null;
    const key = String(col.key || '').trim() || ('custom_' + idx);
    if (seenCustom.has(key)) return null;
    seenCustom.add(key);
    const widthRaw = Number.parseInt(col.width, 10);
    return {
      key,
      label: String(col.label || key).trim() || key,
      type: COL_TYPES.includes(col.type) ? col.type : 'text',
      visible: toBool(col.visible, true),
      width: Math.max(70, Math.min(420, Number.isFinite(widthRaw) ? widthRaw : 150)),
    };
  }).filter(Boolean);

  const all=[...REGISTRY_COLS, ...state.customCols];
  const allSet=new Set(all.map(c=>c.key));

  // Order: keep only existing keys, unique, then append missing.
  const orderRaw=Array.isArray(state.colOrder)?state.colOrder:[];
  const order=[];
  orderRaw.forEach(k=>{ if(allSet.has(k)&&!order.includes(k)) order.push(k); });
  all.forEach(col=>{ if(!order.includes(col.key)) order.push(col.key); });
  state.colOrder=order;

  // Visibility coercion: accept booleans and legacy "true"/"false" strings.
  const vis={};
  all.forEach(col=>{ vis[col.key]=toBool(state.colVisibility?.[col.key], col.visible!==false); });
  state.colVisibility=vis;

  // Widths with sane caps to avoid "everything moved away" UI.
  const widths={};
  all.forEach(col=>{
    const raw=state.colWidths?.[col.key];
    const n=Number.parseInt(raw,10);
    if (Number.isFinite(n)) widths[col.key]=Math.max(70,Math.min(420,n));
  });
  state.colWidths=widths;

  // Labels.
  const labels={};
  all.forEach(col=>{
    const v=state.colLabels?.[col.key];
    if (typeof v==='string' && v.trim()) labels[col.key]=v.trim();
  });
  state.colLabels=labels;

  // Type overrides.
  const types={};
  all.forEach(col=>{
    const t=state.colTypes?.[col.key];
    if (COL_TYPES.includes(t)) types[col.key]=t;
  });
  state.colTypes=types;

  // Pinned columns must exist and be visible.
  state.pinnedCols=[...new Set((Array.isArray(state.pinnedCols)?state.pinnedCols:[]).filter(key=>allSet.has(key)&&state.colVisibility[key]!==false))].slice(0,6);

  // Row height hard clamp.
  const rh=Number.parseInt(state.rowHeight,10);
  state.rowHeight=Math.max(28,Math.min(44,Number.isFinite(rh)?rh:36));

  // Sidebar collapsed flag could be stored as string in older snapshots.
  state.sidebarCollapsed=toBool(state.sidebarCollapsed,false);
  state.presetsCollapsed=toBool(state.presetsCollapsed,false);

  // Epic dependencies cleanup.
  const deps={};
  Object.entries(state.epicDeps||{}).forEach(([a,b])=>{
    const from=String(a||'').trim();
    const to=String(b||'').trim();
    if (!from||!to||from===to) return;
    deps[from]=to;
  });
  state.epicDeps=deps;
}

// ============================================================
// ID / UTILS
// ============================================================
function nextId() { return 'r_' + (state._idCounter++).toString(36) + '_' + Date.now().toString(36); }

const Utils = {
  normalizeHeader(h) {
    if (h == null) return '';
    return String(h).replace(/\r?\n/g,' ').replace(/\u00a0/g,' ')
      .replace(/[\u200b\u200c\u200d\ufeff]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
  },
  mapHeader(n) {
    if (n==='категория') return 'category';
    if (n==='теги') return 'tags';
    if (n==='эпик') return 'epic';
    if (n==='роль'||n==='роли') return 'role';
    if (n==='исполнитель'||n==='исполнители') return 'assignee';
    if (n==='период работ') return 'work_period';
    if (n==='оценка') return 'estimation_legacy';
    if (n==='задачи') return 'tasks';
    if (n==='коммент к задачам') return 'task_comment';
    if (n==='зависимость от команд') return 'team_dependency';
    if (n==='риски') return 'risks';
    if (n.includes('релиз 1.20')) return 'release120';
    if (n.includes('релиз 1.21')) return 'release121';
    if (n.includes('релиз 1.22')) return 'release122';
    if (n.includes('входит в скоуп')) return 'scope';
    if (n==='комментарий') return 'comment';
    return null;
  },
  parseLegacyRelease(raw) {
    if (!raw) return [];
    const s = String(raw).trim();
    if (!s||s==='-'||s.toLowerCase()==='нет'||s==='0') return [];
    const lower = s.toLowerCase();
    const truthy = ['+','да','yes','1','x','✓','✔'];
    if (truthy.includes(lower)) return ['backend'];
    const parts = s.split(/[,;\n\/]+/).map(p=>p.trim().toLowerCase()).filter(Boolean);
    const res = [];
    for (const p of parts) {
      const m = LEGACY_WT_MAP[p];
      if (m) res.push(m);
      else if (truthy.includes(p)) res.push('backend');
    }
    return [...new Set(res.filter(Boolean))];
  },
  parsePipe(raw) {
    if (!raw) return [];
    return String(raw).split('|').map(s=>s.trim()).filter(Boolean);
  },
  parseDateish(raw) {
    if (!raw) return '';
    const s=String(raw).trim();
    const iso=s.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
    const ru=s.match(/\b(\d{1,2})[./](\d{1,2})[./](\d{2,4})\b/);
    if (ru) {
      const y=ru[3].length===2?'20'+ru[3]:ru[3];
      return `${y}-${ru[2].padStart(2,'0')}-${ru[1].padStart(2,'0')}`;
    }
    const d=new Date(s);
    return Number.isNaN(d.getTime())?'':d.toISOString().slice(0,10);
  },
  parseDateRange(raw) {
    if (!raw) return {start:'',end:''};
    const matches=String(raw).match(/\d{4}-\d{2}-\d{2}|\d{1,2}[./]\d{1,2}[./]\d{2,4}/g) || [];
    return { start:Utils.parseDateish(matches[0]||raw), end:Utils.parseDateish(matches[1]||matches[0]||raw) };
  },
  parseDateList(raw) {
    if (!raw) return [];
    const parts=String(raw).split(/[|,;\n]+/).map(s=>s.trim()).filter(Boolean);
    return [...new Set(parts.map(p=>Utils.parseDateish(p)||p).filter(Boolean))];
  },
  toBool(raw, fallback=false) {
    if (typeof raw==='boolean') return raw;
    if (typeof raw==='number') return raw!==0;
    const s=String(raw||'').trim().toLowerCase();
    if (['true','1','yes','on','да','y','ok'].includes(s)) return true;
    if (['false','0','no','off','нет','n',''].includes(s)) return false;
    return !!fallback;
  },
  escapeHtml(v) {
    return String(v==null?'':v)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#39;');
  },
  hexToRgba(hex, alpha=0.14) {
    const h=String(hex||'').trim().replace('#','');
    if (!/^[0-9a-fA-F]{6}$/.test(h)) return '';
    const r=parseInt(h.slice(0,2),16);
    const g=parseInt(h.slice(2,4),16);
    const b=parseInt(h.slice(4,6),16);
    return `rgba(${r},${g},${b},${alpha})`;
  },
  mapEmployeeHeader(n) {
    if (!n) return null;
    if (n==='фио' || n==='сотрудник' || n==='имя') return 'fio';
    if (n==='роль' || n==='роли') return 'roles';
    if (n==='команда' || n==='команды') return 'teams';
    if (n.includes('дни') && n.includes('овер')) return 'overtimeDays';
    if ((n.includes('готов') || n.includes('может')) && n.includes('будн')) return 'weekdayReady';
    if (n.includes('комментар') && n.includes('будн')) return 'weekdayComment';
    return null;
  },
  serializePipe(arr) { return Array.isArray(arr) ? arr.join('|') : ''; },
  scopeFromRaw(raw) {
    if (!raw) return '';
    const s = String(raw).trim().toLowerCase();
    if (s==='да'||s==='yes'||s==='+'||s==='1') return 'Да';
    if (s==='нет'||s==='no'||s==='-'||s==='0') return 'Нет';
    if (s.includes('подтвержд')||s.includes('требует')) return 'Требует подтверждения';
    if (s) return raw.trim().charAt(0).toUpperCase()+raw.trim().slice(1);
    return '';
  },
  escapeCSV(v) {
    if (v==null) return '';
    const s = String(v);
    if (s.includes(',')||s.includes('"')||s.includes('\n')||s.includes('\r')) return '"'+s.replace(/"/g,'""')+'"';
    return s;
  },
  parseCSVLine(line) {
    const r=[]; let cur='', inQ=false;
    for (let i=0;i<line.length;i++) {
      const c=line[i];
      if (inQ) { if (c==='"'&&line[i+1]==='"'){cur+='"';i++;} else if(c==='"'){inQ=false;} else{cur+=c;} }
      else { if(c==='"'){inQ=true;} else if(c===','){r.push(cur);cur='';} else{cur+=c;} }
    }
    r.push(cur); return r;
  },
  parseFullCSV(text) {
    // Splits on newlines while respecting quoted fields (RFC 4180).
    // Preserves raw quote chars so parseCSVLine can handle them correctly.
    const lines=[]; let cur='', inQ=false;
    for (let i=0;i<text.length;i++) {
      const c=text[i];
      if (inQ) {
        if(c==='"'&&text[i+1]==='"'){cur+='""';i++;} // keep escaped pair intact for parseCSVLine
        else if(c==='"'){inQ=false;cur+=c;}
        else{cur+=c;}
      }
      else {
        if(c==='"'){inQ=true;cur+=c;}
        else if(c==='\n'){lines.push(cur);cur='';}
        else if(c==='\r'&&text[i+1]==='\n'){lines.push(cur);cur='';i++;}
        else if(c==='\r'){lines.push(cur);cur='';}
        else{cur+=c;}
      }
    }
    if (cur) lines.push(cur);
    return lines.map(l=>Utils.parseCSVLine(l));
  },
  truncate(s,n) { if(!s)return''; s=String(s); return s.length>n?s.slice(0,n)+'…':s; },
  unique(arr) { return [...new Set(arr.filter(Boolean))].sort(); },
  yieldToBrowser(ms=0) {
    return new Promise(resolve=>setTimeout(resolve,ms));
  },

  // Parse Jira-style URLs or standalone keys from a string
  parseJiraLinks(raw) {
    if (!raw) return [];
    const results = [];
    // Full URL pattern: .../browse/KEY-123
    const urlRe = /https?:\/\/[^\s,;"'<>]+\/browse\/([A-Z][A-Z0-9_]*-\d+)/gi;
    let m;
    while ((m = urlRe.exec(raw)) !== null) {
      results.push({ key: m[1], url: m[0] });
    }
    if (results.length) return results;
    // Standalone keys: KEY-123
    const keyRe = /\b([A-Z][A-Z0-9_]*-\d+)\b/g;
    while ((m = keyRe.exec(raw)) !== null) {
      results.push({ key: m[1], url: null });
    }
    if (results.length) return results;
    // Fallback: treat as plain text
    const trimmed = raw.trim();
    if (trimmed) results.push({ key: trimmed, url: null });
    return results;
  },
};

// ============================================================
// ROW FACTORY
// ============================================================
const RowFactory = {
  create(ov={}) {
    const now = new Date().toISOString();
    const row = {
      id: nextId(), sourceType:'', sourceSheet:'', team:'',
      category:'', epic:'',
      backend:'', frontend:'', analytics_estimate:'', testing_estimate:'', total_estimate:'',
      tasks:'', taskComment:'', teamDependency:'', risks:'',
      release120Raw:'', release121Raw:'', release122Raw:'', overtimeRaw:'',
      release120Types:[], release121Types:[], release122Types:[], overtimeTypes:[],
      hasRelease120:false, hasRelease121:false, hasRelease122:false, hasOvertime:false, isUnassigned:true,
      scopeStatus:'', role:'',
      blockingDependency:false, blockingDeadline:'',
      isDone:false, doneDate:'',
      comment:'', dirty:true, riskFlags:[],
      workPeriodStart:'', workPeriodEnd:'', assignee:'', rowColor:'',
      createdAt:now, updatedAt:now,
    };
    Object.assign(row, ov);
    RowFactory.updateDerived(row);
    return row;
  },
  updateDerived(row) {
    // Keep work period consistent for timeline math.
    if (row.workPeriodStart && row.workPeriodEnd) {
      const s = new Date(row.workPeriodStart);
      const e = new Date(row.workPeriodEnd);
      if (!Number.isNaN(s.getTime()) && !Number.isNaN(e.getTime()) && s > e) {
        const tmp = row.workPeriodStart;
        row.workPeriodStart = row.workPeriodEnd;
        row.workPeriodEnd = tmp;
      }
    }
    row.hasRelease120 = !!(row.release120Types && row.release120Types.length);
    row.hasRelease121 = !!(row.release121Types && row.release121Types.length);
    row.hasRelease122 = !!(row.release122Types && row.release122Types.length);
    row.hasOvertime   = !!(row.overtimeTypes   && row.overtimeTypes.length);
    row.isUnassigned  = !row.hasRelease120 && !row.hasRelease121 && !row.hasRelease122 && !row.hasOvertime;
    row.release120Raw = (row.release120Types||[]).join(', ');
    row.release121Raw = (row.release121Types||[]).join(', ');
    row.release122Raw = (row.release122Types||[]).join(', ');
    row.overtimeRaw   = (row.overtimeTypes||[]).join(', ');
    RiskEngine.computeFlags(row);
    RiskEngine.computeRiskScore(row);
  },
};

const EmployeeFactory = {
  create(ov={}) {
    const now = new Date().toISOString();
    const emp = {
      id: 'emp_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,7),
      fio: '',
      roles: '',
      teams: '',
      overtimeDays: [],
      weekdayReady: false,
      weekdayComment: '',
      sourceType: 'manual',
      createdAt: now,
      updatedAt: now,
    };
    Object.assign(emp, ov);
    EmployeeFactory.normalize(emp);
    return emp;
  },
  normalize(emp) {
    emp.fio = String(emp.fio || '').trim();
    emp.roles = String(emp.roles || '').split(/[|,]/).map(s=>s.trim()).filter(Boolean).join('|');
    emp.teams = String(emp.teams || '').split(/[|,]/).map(s=>s.trim()).filter(Boolean).join('|');
    if (!Array.isArray(emp.overtimeDays)) emp.overtimeDays = Utils.parseDateList(emp.overtimeDays);
    emp.overtimeDays = [...new Set(emp.overtimeDays.map(d=>Utils.parseDateish(d)||d).filter(Boolean))].sort();
    emp.weekdayReady = Utils.toBool(emp.weekdayReady,false);
    emp.weekdayComment = String(emp.weekdayComment || '').split(/[|,]/).map(s=>s.trim()).filter(Boolean).join('|');
    emp.updatedAt = new Date().toISOString();
  },
};

// ============================================================
// RISK ENGINE
// ============================================================
const RiskEngine = {
  computeFlags(row) {
    const flags = [];
    const inAny = row.hasRelease120||row.hasRelease121||row.hasRelease122||row.hasOvertime;
    if (row.scopeStatus==='Требует подтверждения' && inAny) flags.push('CONFIRMATION_IN_RELEASE');
    if (row.scopeStatus==='Да' && row.isUnassigned) flags.push('IN_SCOPE_WITHOUT_RELEASE');
    if (row.blockingDependency && (row.hasRelease120||row.hasRelease121)) flags.push('BLOCKING_NEAR_RELEASE');
    row.riskFlags = flags;
  },
  computeRiskScore(row) {
    let score = 0;
    if (row.blockingDependency) score += 30;
    if ((row.riskFlags||[]).includes('IN_SCOPE_WITHOUT_RELEASE')) score += 25;
    if ((row.riskFlags||[]).includes('CONFIRMATION_IN_RELEASE')) score += 20;
    if (row.hasRelease120) score += 15;
    if (row.scopeStatus === 'Требует подтверждения') score += 10;
    row.riskScore = Math.min(100, score);
    return row.riskScore;
  },
  computeAll() {
    state.rows.forEach(r => {
      RiskEngine.computeFlags(r);
      RiskEngine.computeRiskScore(r);
    });
  },
};

// ============================================================
// PROGRESS & FORECAST
// ============================================================
function computeProgress(rows) {
  const releases = ['120','121','122','ot'];
  const result = {};
  releases.forEach(rel => {
    const key = rel === 'ot' ? 'hasOvertime' : `hasRelease${rel}`;
    const inRel = rows.filter(r => r[key]);
    const done = inRel.filter(r => r.isDone).length;
    result[rel] = { total: inRel.length, done, pct: inRel.length ? Math.round(done/inRel.length*100) : 0 };
  });
  const total = rows.length;
  const done = rows.filter(r => r.isDone).length;
  result.all = { total, done, pct: total ? Math.round(done/total*100) : 0 };
  return result;
}

function computeLoad(rows) {
  const load = {};
  rows.forEach(r => {
    const assignees = String(r.assignee||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
    assignees.forEach(name => {
      if (!load[name]) load[name] = { total:0, r120:0, r121:0, r122:0, ot:0 };
      load[name].total++;
      if (r.hasRelease120) load[name].r120++;
      if (r.hasRelease121) load[name].r121++;
      if (r.hasRelease122) load[name].r122++;
      if (r.hasOvertime)   load[name].ot++;
    });
  });
  return load;
}

// ============================================================
// ACTION LAYER
// ============================================================
function applyBulkAction(rowIds, actionType, payload={}) {
  const ids = new Set(rowIds);
  const targets = state.rows.filter(r => ids.has(r.id));
  if (!targets.length) return;
  HistoryManager.checkpoint(`bulk:${actionType}`);
  targets.forEach(row => {
    switch (actionType) {
      case 'assign_release': {
        const rel = payload.release;
        if (rel === '120') { row.release120Types = payload.types||['backend']; }
        else if (rel === '121') { row.release121Types = payload.types||['backend']; }
        else if (rel === '122') { row.release122Types = payload.types||['backend']; }
        else if (rel === 'ot')  { row.overtimeTypes = payload.types||['backend']; }
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row); RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
      case 'clear_release': {
        row.release120Types=[]; row.release121Types=[]; row.release122Types=[]; row.overtimeTypes=[];
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row); RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
      case 'set_scope': {
        row.scopeStatus = payload.scope||'Да';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row); RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
      case 'set_assignee': {
        if (payload.assignee) { row.assignee = payload.assignee; row.dirty = true; row.updatedAt = new Date().toISOString(); }
        break;
      }
      case 'set_priority': {
        row.priority = payload.priority||'medium';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
      case 'clear_blocker': {
        row.blockingDependency = false; row.blockingDeadline = '';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
      case 'mark_done': {
        row.isDone = payload.done !== false;
        if (row.isDone && !row.doneDate) row.doneDate = new Date().toISOString().slice(0,10);
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
    }
  });
  if (state.simMode) {
    showToast(`[Симуляция] ${actionType} применено к ${targets.length} задачам`, 'info');
  } else {
    Storage.save();
    showToast(`Применено к ${targets.length} задачам`, 'success');
  }
  App.refreshCurrentSection();
}

// ============================================================
// BULK EDIT PANEL
// ============================================================
const BulkEditPanel = {
  show() {
    const panel = document.getElementById('bulk-panel');
    if (panel) { panel.classList.remove('hidden'); BulkEditPanel.update(); }
  },
  hide() {
    const panel = document.getElementById('bulk-panel');
    if (panel) panel.classList.add('hidden');
  },
  update() {
    const panel = document.getElementById('bulk-panel');
    if (!panel) return;
    const count = state.bulkSelected.size;
    const countEl = panel.querySelector('#bulk-count');
    if (countEl) countEl.textContent = `Выбрано: ${count}`;
  },
  toggle(rowId, checked) {
    if (checked) state.bulkSelected.add(rowId);
    else state.bulkSelected.delete(rowId);
    if (state.bulkSelected.size > 0) BulkEditPanel.show();
    else BulkEditPanel.hide();
    BulkEditPanel.update();
  },
  selectAll(rows) {
    rows.forEach(r => state.bulkSelected.add(r.id));
    BulkEditPanel.show(); BulkEditPanel.update();
    document.querySelectorAll('.bulk-row-cb').forEach(cb => { cb.checked = true; });
  },
  clearAll() {
    state.bulkSelected.clear(); BulkEditPanel.hide();
    document.querySelectorAll('.bulk-row-cb').forEach(cb => { cb.checked = false; });
    const selectAll = document.getElementById('bulk-select-all');
    if (selectAll) selectAll.checked = false;
  },
  applyFromPanel(actionType) {
    const ids = [...state.bulkSelected];
    if (!ids.length) return;
    let payload = {};
    if (actionType === 'assign_release') {
      const sel = document.getElementById('bulk-release-select');
      payload.release = sel ? sel.value : '120';
    } else if (actionType === 'set_scope') {
      const sel = document.getElementById('bulk-scope-select');
      payload.scope = sel ? sel.value : 'Да';
    } else if (actionType === 'set_priority') {
      const sel = document.getElementById('bulk-priority-select');
      payload.priority = sel ? sel.value : 'medium';
    } else if (actionType === 'set_assignee') {
      const inp = document.getElementById('bulk-assignee-input');
      payload.assignee = inp ? inp.value.trim() : '';
      if (!payload.assignee) return;
    }
    applyBulkAction(ids, actionType, payload);
    BulkEditPanel.clearAll();
  },
  bindUI() {
    const panel = document.getElementById('bulk-panel');
    if (!panel) return;
    panel.querySelector('#bulk-btn-deselect')?.addEventListener('click', () => BulkEditPanel.clearAll());
    panel.querySelector('#bulk-btn-release')?.addEventListener('click', () => BulkEditPanel.applyFromPanel('assign_release'));
    panel.querySelector('#bulk-btn-scope')?.addEventListener('click', () => BulkEditPanel.applyFromPanel('set_scope'));
    panel.querySelector('#bulk-btn-priority')?.addEventListener('click', () => BulkEditPanel.applyFromPanel('set_priority'));
    panel.querySelector('#bulk-btn-assignee')?.addEventListener('click', () => BulkEditPanel.applyFromPanel('set_assignee'));
    panel.querySelector('#bulk-btn-done')?.addEventListener('click', () => { applyBulkAction([...state.bulkSelected], 'mark_done', {done:true}); BulkEditPanel.clearAll(); });
    panel.querySelector('#bulk-btn-clear-release')?.addEventListener('click', () => { applyBulkAction([...state.bulkSelected], 'clear_release', {}); BulkEditPanel.clearAll(); });
    panel.querySelector('#bulk-btn-clear-blocker')?.addEventListener('click', () => { applyBulkAction([...state.bulkSelected], 'clear_blocker', {}); BulkEditPanel.clearAll(); });
  },
};

// ============================================================
// SIMULATION MODE
// ============================================================
const SimMode = {
  toggle() {
    state.simMode = !state.simMode;
    const btn = document.getElementById('btn-sim-mode');
    if (btn) {
      btn.textContent = state.simMode ? '⚡ Симуляция ON' : '⚡ Симуляция';
      btn.classList.toggle('btn-warning', state.simMode);
      btn.classList.toggle('btn-outline', !state.simMode);
    }
    document.body.classList.toggle('sim-mode-active', state.simMode);
    showToast(state.simMode ? 'Режим симуляции включён — изменения не сохраняются' : 'Режим симуляции выключен', state.simMode ? 'warning' : 'info');
  },
};

// ============================================================
// LLM COMMAND PARSER
// ============================================================
function parseLLMCommand(text) {
  const t = text.toLowerCase().trim();
  const rows = FilterEngine.getFiltered();

  if (/назнач|распредел/.test(t) && /без.*релиз|нераспредел|unassigned/.test(t)) {
    const rel = /1\.21/.test(t) ? '121' : /1\.22/.test(t) ? '122' : '120';
    const targets = rows.filter(r => r.isUnassigned && r.scopeStatus === 'Да');
    return { intent: 'assign_unassigned_to_release', targets, payload: { release: rel }, description: `Назначить ${targets.length} нераспределённых задач в релиз 1.${rel}` };
  }
  if (/убер|удал|сним/.test(t) && /риск|блокер/.test(t)) {
    const targets = rows.filter(r => r.blockingDependency);
    return { intent: 'remove_risks', targets, payload: {}, description: `Снять блокер с ${targets.length} задач` };
  }
  if (/перегруж|нагруз/.test(t)) {
    const load = computeLoad(rows);
    const overloaded = Object.entries(load).filter(([,v]) => v.total >= 6).map(([name]) => name);
    return { intent: 'show_overloaded', targets: [], payload: { overloaded }, description: `Перегруженные исполнители: ${overloaded.join(', ') || 'нет'}` };
  }
  return null;
}

// ============================================================
// XLSX IMPORTER
// ============================================================
const XLSXImporter = {
  import(buffer) {
    if (typeof XLSX==='undefined') { alert('Положите libs/xlsx.full.min.js рядом с index.html'); return; }
    HistoryManager.checkpoint('импорт XLSX');
    const wb = XLSX.read(buffer, {type:'array'});
    const newRows=[], diag={sources:['xlsx'],sheets:wb.SheetNames.slice(),rowsPerSheet:{},detectedColumns:{},missingColumns:{},warnings:[]};
    wb.SheetNames.forEach(sheetName => {
      const ws = wb.Sheets[sheetName];
      const raw = XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:false});
      if (!raw||raw.length<2) { diag.warnings.push(`Лист "${sheetName}": < 2 строк`); diag.rowsPerSheet[sheetName]=0; return; }
      let headerIdx=0;
      for (let i=0;i<Math.min(6,raw.length);i++) {
        if (raw[i].some(h=>Utils.mapHeader(Utils.normalizeHeader(h))!==null)) { headerIdx=i; break; }
      }
      const headerRow=raw[headerIdx], colMap={}, mapped={};
      headerRow.forEach((h,i) => {
        const n=Utils.normalizeHeader(h), f=Utils.mapHeader(n);
        if (f) { colMap[f]=i; mapped[f]={index:i,originalHeader:String(h).trim()}; }
      });
      diag.detectedColumns[sheetName]=mapped;
      const missing=['tasks'].filter(k=>!(k in colMap));
      if (missing.length) { diag.missingColumns[sheetName]=missing; diag.warnings.push(`Лист "${sheetName}": не найдены: ${missing.join(', ')}`); }
      const get=(f,cells)=>{ const i=colMap[f]; return i==null?'':String(cells[i]||'').trim(); };
      let cnt=0;
      for (let ri=headerIdx+1;ri<raw.length;ri++) {
        const cells=raw[ri];
        if (cells.every(c=>!String(c).trim())) continue;
        const r120=get('release120',cells), r121=get('release121',cells), scope=get('scope',cells);
        const period=Utils.parseDateRange(get('work_period',cells));
        const row=RowFactory.create({
          sourceType:'xlsx', sourceSheet:sheetName, team:sheetName,
          category:get('category',cells), tags:get('tags',cells), epic:get('epic',cells),
          total_estimate:get('estimation_legacy',cells),
          tasks:get('tasks',cells), taskComment:get('task_comment',cells),
          teamDependency:get('team_dependency',cells), risks:get('risks',cells),
          release120Raw:r120, release121Raw:r121,
          release120Types:Utils.parseLegacyRelease(r120), release121Types:Utils.parseLegacyRelease(r121),
          release122Types:[], overtimeTypes:[],
          scopeStatus:Utils.scopeFromRaw(scope), role:get('role',cells), assignee:get('assignee',cells),
          workPeriodStart:period.start, workPeriodEnd:period.end,
          comment:get('comment',cells), dirty:false,
        });
        newRows.push(row); cnt++;
      }
      diag.rowsPerSheet[sheetName]=cnt;
    });
    state.rows=newRows;
    state.diagnostics={...state.diagnostics,...diag,registryCount:newRows.length};
    RiskEngine.computeAll(); Storage.save(); App.refreshAll(); App.updateTopbarBadge();
  },
};

// ============================================================
// CSV IMPORT / EXPORT
// ============================================================
const CSV = {
  COLS: [
    'id','sourceType','sourceSheet','team','category','epic',
    'backend','frontend','analytics_estimate','testing_estimate','total_estimate',
    'tasks','taskComment','teamDependency','risks',
    'release120Types','release121Types','release122Types','overtimeTypes',
    'scopeStatus','role','blockingDependency','blockingDeadline',
    'isDone','doneDate','comment','tags','dirty','createdAt','updatedAt',
    'workPeriodStart','workPeriodEnd','assignee','rowColor',
  ],
  SETTINGS_MARKER: '__Q2SETTINGS__',

  async export() {
    const bom='\uFEFF';
    const customKeys=state.customCols.map(c=>c.key);
    const allCols=[...CSV.COLS,...customKeys];
    const header=allCols.join(',');
    const rowToLine=(row)=>allCols.map(col=>{
      let v=row[col];
      if (Array.isArray(v)) v=Utils.serializePipe(v);
      if (typeof v==='boolean') v=v?'true':'false';
      return Utils.escapeCSV(v==null?'':v);
    }).join(',');
    // Append settings
    const settings={
      colOrder:state.colOrder, colWidths:state.colWidths, colVisibility:state.colVisibility,
      pinnedCols:state.pinnedCols, rowHeight:state.rowHeight, colLabels:state.colLabels,
      customCols:state.customCols, colTypes:state.colTypes, epicDeps:state.epicDeps,
      ganttMode:state.ganttMode, ganttEpicsWell:state.ganttEpicsWell,
      podlozhkaMode:state.podlozhkaMode, summaryMode:state.summaryMode, presetsCollapsed:state.presetsCollapsed,
      theme:state.theme,
      gantt2Zoom:state.gantt2Zoom, gantt2ShowDeps:state.gantt2ShowDeps, gantt2Team:state.gantt2Team,
    };
    const settingsRow=CSV.SETTINGS_MARKER+','+Utils.escapeCSV(JSON.stringify(settings));
    const onProgress=(done,total)=>{
      if (total>=2500 && done>0 && done%2000===0) showToast(`Экспорт CSV: ${done}/${total}`, 'success', 900);
    };
    let blob;
    if (window.CSVStreamExporter && typeof window.CSVStreamExporter.buildBlob === 'function') {
      blob=await window.CSVStreamExporter.buildBlob({
        bom,
        header,
        rows: state.rows,
        rowToLine,
        tailLines: [settingsRow],
        batchSize: 700,
        onProgress,
      });
    } else {
      const parts=[bom, header, '\n'];
      for (let i=0;i<state.rows.length;i++) {
        parts.push(rowToLine(state.rows[i]), '\n');
        if ((i+1)%700===0) await Utils.yieldToBrowser();
      }
      parts.push(settingsRow, '\n');
      blob=new Blob(parts,{type:'text/csv;charset=utf-8;'});
    }
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a'); a.href=url; a.download=`q2_plan_${new Date().toISOString().slice(0,10)}.csv`; a.click();
    URL.revokeObjectURL(url);
    if (state.rows.length>=2500) showToast(`CSV экспортирован: ${state.rows.length} строк`);
  },

  import(text) {
    if (text.charCodeAt(0)===0xFEFF) text=text.slice(1);
    const allRows=Utils.parseFullCSV(text);
    if (allRows.length<2) { alert('CSV пустой'); return; }
    HistoryManager.checkpoint('импорт CSV');
    const headers=allRows[0].map(h=>h.trim());
    const newRows=[]; let count=0;
    for (let i=1;i<allRows.length;i++) {
      const cells=allRows[i];
      if (cells.every(c=>!c.trim())) continue;
      if (cells[0]===CSV.SETTINGS_MARKER) {
        try {
          const s=JSON.parse(cells[1]);
          if (s.colOrder) state.colOrder=s.colOrder;
          if (s.colWidths) state.colWidths=s.colWidths;
          if (s.colVisibility) state.colVisibility=s.colVisibility;
          if (s.pinnedCols) state.pinnedCols=s.pinnedCols;
          if (Object.prototype.hasOwnProperty.call(s,'rowHeight')) state.rowHeight=s.rowHeight;
          if (s.colLabels) state.colLabels=s.colLabels;
          if (s.colTypes) state.colTypes=s.colTypes;
          if (s.customCols) state.customCols=s.customCols;
          if (s.epicDeps) state.epicDeps=s.epicDeps;
          if (s.ganttMode) state.ganttMode=s.ganttMode;
          if (s.ganttEpicsWell) state.ganttEpicsWell=s.ganttEpicsWell;
          if (s.podlozhkaMode) state.podlozhkaMode=s.podlozhkaMode;
          if (s.summaryMode) state.summaryMode=s.summaryMode;
          if (Object.prototype.hasOwnProperty.call(s,'presetsCollapsed')) state.presetsCollapsed=s.presetsCollapsed;
          if (s.theme) state.theme=s.theme;
          if (Object.prototype.hasOwnProperty.call(s,'gantt2Zoom')) state.gantt2Zoom=s.gantt2Zoom;
          if (Object.prototype.hasOwnProperty.call(s,'gantt2ShowDeps')) state.gantt2ShowDeps=s.gantt2ShowDeps;
          if (s.gantt2Team) state.gantt2Team=s.gantt2Team;
          syncColumnSettings();
          if (App.applyPresetsCollapsed) App.applyPresetsCollapsed();
          if (ThemeUI.apply) ThemeUI.apply();
        } catch(e) {}
        continue;
      }
      const obj={};
      headers.forEach((h,idx)=>{ obj[h]=cells[idx]!==undefined?cells[idx]:''; });
      ['release120Types','release121Types','release122Types','overtimeTypes'].forEach(f=>{
        obj[f]=Utils.parsePipe(obj[f]);
      });
      obj.blockingDependency=obj.blockingDependency==='true';
      obj.isDone=obj.isDone==='true';
      obj.dirty=obj.dirty==='true';
      const row=RowFactory.create({...obj, id:obj.id||nextId()});
      newRows.push(row); count++;
    }
    state.rows=newRows;
    state.diagnostics.csvImportCount=count; state.diagnostics.sources=['csv'];
    RiskEngine.computeAll(); Storage.save(); App.refreshAll(); App.updateTopbarBadge();
  },

  importUpdate(text) {
    if (text.charCodeAt(0)===0xFEFF) text=text.slice(1);
    const allRows=Utils.parseFullCSV(text);
    if (allRows.length<2) { alert('CSV пустой'); return; }
    const headers=allRows[0].map(h=>h.trim()).filter(Boolean);
    if (!headers.length) { alert('Нет заголовков в CSV'); return; }

    const boolKeys=new Set(['blockingDependency','isDone','dirty']);
    const pipeKeys=new Set(['release120Types','release121Types','release122Types','overtimeTypes']);
    const skipKeys=new Set([CSV.SETTINGS_MARKER]);
    const keyOf=(r)=>[r.team,r.epic,r.tasks].map(v=>String(v||'').trim().toLowerCase()).join('||');

    const byId=new Map(state.rows.map(r=>[String(r.id),r]));
    const byKey=new Map();
    state.rows.forEach(r=>{
      const k=keyOf(r);
      if(!byKey.has(k)) byKey.set(k,[]);
      byKey.get(k).push(r);
    });

    const staged=[];
    let parsed=0, matched=0, changed=0, unchanged=0, notFound=0;

    for (let i=1;i<allRows.length;i++) {
      const cells=allRows[i];
      if (!cells || cells.every(c=>!String(c||'').trim())) continue;
      if (cells[0]===CSV.SETTINGS_MARKER) continue;
      parsed++;

      const obj={};
      headers.forEach((h,idx)=>{ obj[h]=cells[idx]!==undefined?cells[idx]:''; });
      const id=String(obj.id||'').trim();
      let row=id&&byId.has(id)?byId.get(id):null;
      if(!row){
        const k=keyOf(obj);
        const pool=byKey.get(k)||[];
        row=pool.length?pool[0]:null;
      }
      if(!row){ notFound++; continue; }
      matched++;

      const changes={};
      headers.forEach(h=>{
        if (!h || skipKeys.has(h) || h==='id') return;
        if (!Object.prototype.hasOwnProperty.call(row,h)) return;
        let incoming=obj[h];
        let current=row[h];

        if (pipeKeys.has(h)) {
          incoming=Utils.parsePipe(incoming);
          current=Array.isArray(current)?current:Utils.parsePipe(current);
          if (incoming.join('|')!==current.join('|')) changes[h]=incoming;
          return;
        }
        if (boolKeys.has(h)) {
          incoming=Utils.toBool(incoming,false);
          current=Utils.toBool(current,false);
          if (incoming!==current) changes[h]=incoming;
          return;
        }
        incoming=String(incoming==null?'':incoming).trim();
        current=String(current==null?'':current).trim();
        if (incoming!==current) changes[h]=incoming;
      });

      const changeKeys=Object.keys(changes);
      if (!changeKeys.length) { unchanged++; continue; }
      changed++;
      staged.push({ row, changes, changeKeys });
    }

    if (!matched) { alert('Не найдено совпадающих строк для обновления. Нужны id или совпадение team+epic+tasks.'); return; }
    if (!changed) { alert(`Совпадения найдены (${matched}), но изменений нет.`); return; }
    HistoryManager.checkpoint('CSV update');

    const preview = `Найдено строк: ${parsed}\nСовпало: ${matched}\nИз них изменится: ${changed}\nБез изменений: ${unchanged}\nНе найдено: ${notFound}\n\nПрименить обновление только изменённых полей?`;
    if (!confirm(preview)) return;

    staged.forEach(({row,changes})=>{
      Object.entries(changes).forEach(([k,v])=>{ row[k]=v; });
      row.dirty=true;
      row.updatedAt=new Date().toISOString();
      RowFactory.updateDerived(row);
    });
    RiskEngine.computeAll();
    Storage.save();
    App.populateFilterDropdowns();
    App.refreshAll();
    showToast(`CSV update: обновлено ${changed} строк`);
  },
};

// ============================================================
// LOCAL STORAGE
// ============================================================
const Storage = {
  _t: null,
  save() {
    clearTimeout(Storage._t);
    state._dataVersion++;
    Storage._t=setTimeout(()=>{
      syncColumnSettings();
      try {
        localStorage.setItem(STORAGE_KEY,JSON.stringify({rows:state.rows,employees:state.employees,savedAt:new Date().toISOString(),version:3}));
      } catch(e){
        if (e && e.name === 'QuotaExceededError') showToast('Память браузера заполнена — экспортируйте данные в CSV', 'error', 4200);
      }
      try {
        localStorage.setItem(SETTINGS_KEY,JSON.stringify({
          colOrder:state.colOrder,colWidths:state.colWidths,colVisibility:state.colVisibility,
          sidebarCollapsed:state.sidebarCollapsed,pinnedCols:state.pinnedCols,rowHeight:state.rowHeight,
          colLabels:state.colLabels,customCols:state.customCols,colTypes:state.colTypes,
          epicDeps:state.epicDeps,ganttMode:state.ganttMode,ganttEpicsWell:state.ganttEpicsWell,
          podlozhkaMode:state.podlozhkaMode,summaryMode:state.summaryMode,presetsCollapsed:state.presetsCollapsed,
          theme:state.theme,
          gantt2Zoom:state.gantt2Zoom,gantt2ShowDeps:state.gantt2ShowDeps,gantt2Team:state.gantt2Team,
        }));
      } catch(e){
        if (e && e.name === 'QuotaExceededError') showToast('Не удалось сохранить настройки: переполнен localStorage', 'error', 4200);
      }
    },400);
  },
  saveSetting(k,v) { state[k]=v; Storage.save(); },
  load() {
    for (const key of STORAGE_KEYS) {
      try {
        const raw=localStorage.getItem(key);
        if (!raw) continue;
        const parsed=JSON.parse(raw);
        if (parsed && Array.isArray(parsed.rows)) return parsed;
      } catch(e){}
    }
    return null;
  },
  loadSettings() {
    let s=null;
    for (const key of SETTINGS_KEYS) {
      try {
        const raw=localStorage.getItem(key);
        if (!raw) continue;
        s=JSON.parse(raw);
        if (s) break;
      } catch(e){}
    }
    if (!s) return;
    if (s.colOrder) state.colOrder=s.colOrder;
    if (s.colWidths) state.colWidths=s.colWidths;
    if (s.colVisibility) state.colVisibility=s.colVisibility;
    if (Object.prototype.hasOwnProperty.call(s,'sidebarCollapsed')) state.sidebarCollapsed=s.sidebarCollapsed;
    if (s.pinnedCols) state.pinnedCols=s.pinnedCols;
    if (Object.prototype.hasOwnProperty.call(s,'rowHeight')) state.rowHeight=s.rowHeight;
    if (s.colLabels) state.colLabels=s.colLabels;
    if (s.colTypes) state.colTypes=s.colTypes;
    if (s.customCols) state.customCols=s.customCols;
    if (s.epicDeps) state.epicDeps=s.epicDeps;
    if (s.ganttMode) state.ganttMode=s.ganttMode;
    if (s.ganttEpicsWell) state.ganttEpicsWell=s.ganttEpicsWell;
    if (s.podlozhkaMode) state.podlozhkaMode=s.podlozhkaMode;
    if (s.summaryMode) state.summaryMode=s.summaryMode;
    if (Object.prototype.hasOwnProperty.call(s,'presetsCollapsed')) state.presetsCollapsed=s.presetsCollapsed;
    if (s.theme) state.theme=s.theme;
    if (Object.prototype.hasOwnProperty.call(s,'gantt2Zoom')) state.gantt2Zoom=s.gantt2Zoom;
    if (Object.prototype.hasOwnProperty.call(s,'gantt2ShowDeps')) state.gantt2ShowDeps=s.gantt2ShowDeps;
    if (s.gantt2Team) state.gantt2Team=s.gantt2Team;
    syncColumnSettings();
  },
  clear() {
    STORAGE_KEYS.forEach(k=>localStorage.removeItem(k));
    SETTINGS_KEYS.forEach(k=>localStorage.removeItem(k));
  },
  restore(data) {
    state.rows=(data.rows||[]).map(r=>{
      ['release120Types','release121Types','release122Types','overtimeTypes'].forEach(f=>{
        if (!Array.isArray(r[f])) r[f]=Utils.parsePipe(r[f]||'');
      });
      if (typeof r.blockingDependency!=='boolean') r.blockingDependency=r.blockingDependency==='true';
      if (typeof r.isDone!=='boolean') r.isDone=r.isDone==='true';
      if (typeof r.dirty!=='boolean') r.dirty=r.dirty==='true';
      RowFactory.updateDerived(r);
      return r;
    });
    state.employees=(data.employees||[]).map(e=>EmployeeFactory.create(e));
    state.diagnostics.localStorageCount=state.rows.length;
    state.diagnostics.registryCount=state.rows.length;
    state.diagnostics.sources=['localStorage'];
  },
};

// ============================================================
// FILTER ENGINE
// ============================================================
const FilterEngine = {
  _cacheKey: '',
  _cacheRows: [],
  _buildCacheKey() {
    const f = state.filters || {};
    const roleKey = Array.isArray(f.role) ? f.role.join('|') : (f.role || '');
    const assigneeKey = Array.isArray(f.assignee) ? f.assignee.join('|') : (f.assignee || '');
    const tagKey = Array.isArray(f.tag) ? f.tag.join('|') : (f.tag || '');
    return [
      state._dataVersion,
      f.search || '',
      f.team || '',
      f.scope || '',
      f.release || '',
      f.workType || '',
      roleKey,
      assigneeKey,
      tagKey,
      f.onlyBlocking ? 1 : 0,
      f.onlyRisky ? 1 : 0,
      f.onlyDone ? 1 : 0,
    ].join('~');
  },
  invalidate() {
    FilterEngine._cacheKey = '';
    FilterEngine._cacheRows = [];
  },
  getFiltered() {
    const f=state.filters;
    const cacheKey = FilterEngine._buildCacheKey();
    if (cacheKey === FilterEngine._cacheKey) return FilterEngine._cacheRows;
    const rows = state.rows.filter(row=>{
      if (f.search) {
        const q=f.search.toLowerCase();
        if (![row.team,row.category,row.tags,row.epic,row.tasks,row.taskComment,row.comment,row.role,row.assignee].join(' ').toLowerCase().includes(q)) return false;
      }
      if (f.team && row.team!==f.team) return false;
      if (f.scope && row.scopeStatus!==f.scope) return false;
      if (f.release) {
        if (f.release==='1.20'&&!row.hasRelease120) return false;
        if (f.release==='1.21'&&!row.hasRelease121) return false;
        if (f.release==='1.22'&&!row.hasRelease122) return false;
        if (f.release==='overtime'&&!row.hasOvertime) return false;
        if (f.release==='none'&&!row.isUnassigned) return false;
      }
      if (f.workType) {
        const all=[...row.release120Types,...row.release121Types,...row.release122Types,...row.overtimeTypes];
        if (!all.includes(f.workType)) return false;
      }
      if (f.role) {
        const reqRoles=Array.isArray(f.role)?f.role:[f.role];
        const roles=String(row.role||'').split(/[,|]/).map(s=>s.trim()).filter(Boolean);
        if (!reqRoles.some(rr=>roles.includes(rr))) return false;
      }
      if (f.assignee) {
        const reqAssignees=Array.isArray(f.assignee)?f.assignee:[f.assignee];
        const assignees=String(row.assignee||'').split(/[,|]/).map(s=>s.trim()).filter(Boolean);
        if (!reqAssignees.some(ra=>assignees.includes(ra))) return false;
      }
      if (f.onlyBlocking&&!row.blockingDependency) return false;
      if (f.onlyRisky&&(!row.riskFlags||!row.riskFlags.length)) return false;
      if (f.onlyDone&&!row.isDone) return false;
      if (f.tag) {
        const reqTags=Array.isArray(f.tag)?f.tag:[f.tag];
        if (!row.tags||!reqTags.some(rt=>String(row.tags).split('|').map(s=>s.trim()).includes(rt))) return false;
      }
      return true;
    });
    FilterEngine._cacheKey = cacheKey;
    FilterEngine._cacheRows = rows;
    return rows;
  },
  getTeams() { return Utils.unique(state.rows.map(r=>r.team)); },
  getWorkTypes() {
    const all=[];
    state.rows.forEach(r=>all.push(...r.release120Types,...r.release121Types,...r.release122Types,...r.overtimeTypes));
    return Utils.unique(all);
  },
  getRoles() {
    const s=new Set();
    state.rows.forEach(r=>{ if(r.role) String(r.role).split('|').map(x=>x.trim()).filter(Boolean).forEach(v=>s.add(v)); });
    return [...s].sort();
  },
  getAssignees() {
    const s=new Set();
    state.rows.forEach(r=>{ if(r.assignee) String(r.assignee).split('|').map(x=>x.trim()).filter(Boolean).forEach(v=>s.add(v)); });
    state.employees.forEach(e=>{ if(e.fio) s.add(String(e.fio).trim()); });
    return [...s].sort((a,b)=>a.localeCompare(b,'ru'));
  },
};

// ============================================================
// RENDER HELPERS
// ============================================================
const RH = {
  scopeChip(s) {
    if (!s) return '<span class="chip chip-gray">—</span>';
    const m={'Да':'chip chip-green','Нет':'chip chip-gray','Требует подтверждения':'chip chip-yellow'};
    return `<span class="${m[s]||'chip chip-gray'}">${s==='Требует подтверждения'?'Треб.':s}</span>`;
  },
  workTypeChips(types) {
    if (!types||!types.length) return '<span class="text-muted text-sm">—</span>';
    return types.map(t=>`<span class="wt-tag ${WT_CLS[t]||'wt-other'}">${t}</span>`).join('');
  },
  riskBadges(flags) {
    if (!flags||!flags.length) return '';
    return flags.map(f=>{
      const cls=f==='BLOCKING_NEAR_RELEASE'?'risk-badge risk-badge-danger':'risk-badge';
      return `<span class="${cls}" title="${RISK_FLAGS[f]||f}">⚠</span>`;
    }).join('');
  },
  dirtyBadge(d) { return d?'<span class="chip chip-dirty">✎</span>':''; },
  doneBadge(d) { return d?'<span class="chip chip-done">✅</span>':''; },
  jiraTagsHtml(raw) {
    const links=Utils.parseJiraLinks(raw);
    if (!links.length) return `<span class="tasks-cell-raw">${Utils.truncate(raw,40)}</span>`;
    return links.map(l=>{
      if (l.url) return `<a class="jira-tag" href="${l.url}" target="_blank" rel="noopener" title="${l.url}"><span class="jira-tag-icon">🔗</span>${l.key}</a>`;
      return `<span class="jira-tag" title="${l.key}">${l.key}</span>`;
    }).join('');
  },
  releaseChips(row) {
    const out=[];
    if (row.hasRelease120) out.push(`<span class="chip chip-indigo">1.20</span>`);
    if (row.hasRelease121) out.push(`<span class="chip chip-green">1.21</span>`);
    if (row.hasRelease122) out.push(`<span class="chip chip-yellow">1.22</span>`);
    if (row.hasOvertime) out.push(`<span class="chip chip-red">OT</span>`);
    return out.join('') || '<span class="chip chip-gray">—</span>';
  },
};

// ============================================================
// MULTISELECT COMPONENT
// ============================================================
const Multiselect = {
  _open: null,
  // getOptions: optional array or function returning array; falls back to WORK_TYPES
  create(currentValues, onChange, getOptions) {
    const opts = typeof getOptions === 'function' ? getOptions()
                : Array.isArray(getOptions)        ? getOptions
                : WORK_TYPES;
    const container=document.createElement('div'); container.className='ms-container';
    const display=document.createElement('div'); display.className='ms-display';
    const chipsWrap=document.createElement('span'); chipsWrap.className='ms-chips';
    const arrow=document.createElement('span'); arrow.className='ms-arrow'; arrow.textContent='▾';
    function renderChips() {
      chipsWrap.innerHTML='';
      if (!currentValues||!currentValues.length) {
        const ph=document.createElement('span'); ph.className='ms-placeholder'; ph.textContent='Выбрать...'; chipsWrap.appendChild(ph);
      } else {
        currentValues.forEach(v=>{ const c=document.createElement('span'); c.className='ms-chip'; c.textContent=v; chipsWrap.appendChild(c); });
      }
    }
    renderChips();
    display.appendChild(chipsWrap); display.appendChild(arrow);
    const dd=document.createElement('div'); dd.className='ms-dropdown hidden';
    dd.style.cssText='position:fixed;z-index:9999;';
    document.body.appendChild(dd);
    opts.forEach(opt=>{
      const lbl=document.createElement('label'); lbl.className='ms-option';
      const cb=document.createElement('input'); cb.type='checkbox'; cb.value=opt;
      cb.checked=(currentValues||[]).includes(opt);
      cb.addEventListener('change',()=>{
        if(cb.checked){if(!currentValues.includes(opt))currentValues.push(opt);}
        else{const i=currentValues.indexOf(opt);if(i>-1)currentValues.splice(i,1);}
        renderChips(); if(onChange)onChange(currentValues.slice());
      });
      lbl.appendChild(cb); lbl.appendChild(document.createTextNode(' '+opt)); dd.appendChild(lbl);
    });
    function openDrop() {
      if (Multiselect._open&&Multiselect._open!==dd) { Multiselect._open.classList.add('hidden'); if(Multiselect._open._disp)Multiselect._open._disp.classList.remove('open'); }
      const r=display.getBoundingClientRect();
      dd.style.left=r.left+'px'; dd.style.top=(r.bottom+2)+'px'; dd.style.minWidth=r.width+'px';
      dd.classList.remove('hidden'); display.classList.add('open');
      Multiselect._open=dd; dd._disp=display;
    }
    function closeDrop() {
      dd.classList.add('hidden'); display.classList.remove('open');
      if(Multiselect._open===dd)Multiselect._open=null;
    }
    display.addEventListener('click',e=>{ e.stopPropagation(); dd.classList.contains('hidden')?openDrop():closeDrop(); });
    container._cleanup=()=>dd.remove();
    container.appendChild(display);
    return container;
  },
  closeAll() {
    document.querySelectorAll('.ms-dropdown').forEach(d=>d.classList.add('hidden'));
    document.querySelectorAll('.ms-display').forEach(d=>d.classList.remove('open'));
    Multiselect._open=null;
  },
};
document.addEventListener('click',()=>Multiselect.closeAll());

// ============================================================
// TAG INPUT COMPONENT (for roles/tags)
// ============================================================
// Tag color palette
const TAG_PALETTE = ['#4f46e5','#059669','#d97706','#dc2626','#7c3aed','#0284c7','#db2777','#65a30d','#ea580c','#0891b2','#9333ea','#16a34a'];
function tagColor(tag) {
  let h = 0;
  for (let i = 0; i < tag.length; i++) h = ((h << 5) - h) + tag.charCodeAt(i);
  return TAG_PALETTE[Math.abs(h) % TAG_PALETTE.length];
}

function getUniqueTagValues(colKey) {
  const vals=new Set();
  state.rows.forEach(r=>{ const v=r[colKey]; if(!v)return; String(v).split(/[|,]/).map(s=>s.trim()).filter(Boolean).forEach(s=>vals.add(s)); });
  return [...vals].sort();
}
function getUniqueTextValues(colKey) {
  const vals=new Set();
  state.rows.forEach(r=>{ if(r[colKey])vals.add(String(r[colKey]).trim()); });
  return [...vals].sort();
}
function getEmployeeNames() {
  return state.employees.map(e=>String(e.fio||'').trim()).filter(Boolean).sort((a,b)=>a.localeCompare(b,'ru'));
}

function createTagInput(initialTags, onChange, getSuggestions) {
  const wrap=document.createElement('div'); wrap.className='tag-input-wrap';
  let tags=[...(initialTags||[])];
  let suggDrop=null;
  if (getSuggestions) {
    suggDrop=document.createElement('div'); suggDrop.className='tag-suggest-drop hidden';
    suggDrop.style.cssText='position:fixed;z-index:9999;';
    document.body.appendChild(suggDrop);
    wrap._cleanup=()=>suggDrop.remove();
  }
  function renderTags() {
    wrap.innerHTML='';
    tags.forEach((tag,i)=>{
      const item=document.createElement('span'); item.className='tag-item'; item.textContent=tag;
      const c=tagColor(tag); item.style.cssText=`background:${c}20;color:${c};border:1px solid ${c}40`;
      const rm=document.createElement('span'); rm.className='tag-remove'; rm.textContent='×';
      rm.addEventListener('click',e=>{ e.stopPropagation(); tags.splice(i,1); renderTags(); if(onChange)onChange(tags.slice()); });
      item.appendChild(rm); wrap.appendChild(item);
    });
    const inp=document.createElement('input'); inp.className='tag-input-field'; inp.placeholder=tags.length?'':'Тег...'; inp.type='text';
    function addTag(v) {
      v=v.trim().replace(/,$/,'');
      if(v&&!tags.includes(v)){tags.push(v);renderTags();if(onChange)onChange(tags.slice());}
      else inp.value='';
      if(suggDrop)suggDrop.classList.add('hidden');
    }
    if (getSuggestions) {
      inp.addEventListener('input',()=>{
        const q=inp.value.trim().toLowerCase();
        const suggs=getSuggestions().filter(s=>!tags.includes(s)&&(q?s.toLowerCase().includes(q):true)).slice(0,10);
        if(!suggs.length){suggDrop.classList.add('hidden');return;}
        const r=inp.getBoundingClientRect();
        suggDrop.style.left=r.left+'px'; suggDrop.style.top=(r.bottom+2)+'px'; suggDrop.style.minWidth=Math.max(160,r.width)+'px';
        suggDrop.innerHTML=suggs.map(s=>`<div class="tag-suggest-item" data-val="${s.replace(/"/g,'&quot;')}">${s}</div>`).join('');
        suggDrop.querySelectorAll('.tag-suggest-item').forEach(item=>{ item.addEventListener('mousedown',e=>{e.preventDefault();addTag(item.dataset.val);inp.value='';}); });
        suggDrop.classList.remove('hidden');
      });
      inp.addEventListener('focus',()=>inp.dispatchEvent(new Event('input')));
      inp.addEventListener('blur',()=>setTimeout(()=>suggDrop.classList.add('hidden'),150));
    }
    inp.addEventListener('keydown',e=>{
      if((e.key==='Enter'||e.key===',')&&inp.value.trim()){e.preventDefault();addTag(inp.value);}
      if(e.key==='Backspace'&&!inp.value&&tags.length){tags.pop();renderTags();if(onChange)onChange(tags.slice());}
      if(e.key==='Escape'&&suggDrop)suggDrop.classList.add('hidden');
    });
    if(!getSuggestions){inp.addEventListener('blur',()=>{if(inp.value.trim())addTag(inp.value);});}
    wrap.appendChild(inp);
  }
  renderTags();
  return wrap;
}

// ============================================================
// SIDEBAR
// ============================================================
const SidebarUI = {
  init() {
    document.getElementById('sidebar-toggle').addEventListener('click',()=>SidebarUI.toggle());
    if (state.sidebarCollapsed) SidebarUI.apply();
  },
  toggle() {
    state.sidebarCollapsed=!state.sidebarCollapsed;
    SidebarUI.apply();
    Storage.save();
  },
  apply() {
    const sb=document.getElementById('sidebar');
    const bd=document.body;
    if (state.sidebarCollapsed) { sb.classList.add('collapsed'); bd.classList.add('sidebar-collapsed'); }
    else { sb.classList.remove('collapsed'); bd.classList.remove('sidebar-collapsed'); }
  },
};

// ============================================================
// THEME
// ============================================================
const ThemeUI = {
  init() {
    const btn=document.getElementById('btn-theme-toggle');
    if (!btn) return;
    if (!['light','dark'].includes(state.theme)) state.theme='light';
    ThemeUI.apply();
    btn.addEventListener('click',()=>{
      state.theme=state.theme==='dark'?'light':'dark';
      ThemeUI.apply();
      Storage.save();
    });
  },
  apply() {
    const dark=state.theme==='dark';
    document.body.classList.toggle('theme-dark',dark);
    const btn=document.getElementById('btn-theme-toggle');
    if (btn) {
      btn.textContent=dark?'☀️ Светлая':'🌙 Тёмная';
      btn.title=dark?'Переключить на светлую тему':'Переключить на тёмную тему';
    }
  },
};

// ============================================================
// TOAST
// ============================================================
function showToast(msg, type='success', ms=2000) {
  const el=document.getElementById('toast');
  el.textContent=msg; el.className=`toast toast-${type}`;
  el.classList.remove('hidden');
  clearTimeout(showToast._t);
  showToast._t=setTimeout(()=>{
    el.classList.add('toast-out');
    setTimeout(()=>el.classList.add('hidden'),160);
  },ms);
}

function closeModal(el) {
  if (!el || el.classList.contains('hidden')) return;
  el.classList.add('modal-closing');
  setTimeout(() => { el.classList.remove('modal-closing'); el.classList.add('hidden'); }, 140);
}

// ============================================================
// UNDO / REDO
// ============================================================
const HistoryManager = {
  limit: 45,
  undoStack: [],
  redoStack: [],
  _restoring: false,

  _capture() {
    if (window.HistoryModule && typeof window.HistoryModule.buildSnapshot === 'function') {
      return window.HistoryModule.buildSnapshot(state);
    }
    return JSON.parse(JSON.stringify({
      rows: state.rows,
      employees: state.employees,
      customCols: state.customCols,
      colOrder: state.colOrder,
      colWidths: state.colWidths,
      colVisibility: state.colVisibility,
      colLabels: state.colLabels,
      colTypes: state.colTypes,
      pinnedCols: state.pinnedCols,
      rowHeight: state.rowHeight,
      sort: state.sort,
      lastClickedRowId: state.lastClickedRowId,
      epicDeps: state.epicDeps,
      _idCounter: state._idCounter,
      _dataVersion: state._dataVersion,
    }));
  },

  _fingerprint(snapshot) {
    if (window.HistoryModule && typeof window.HistoryModule.fingerprint === 'function') {
      return window.HistoryModule.fingerprint(snapshot);
    }
    const payload = JSON.stringify(snapshot);
    return payload.length + ':' + payload.slice(0, 180);
  },

  checkpoint(label='edit') {
    if (HistoryManager._restoring) return;
    const snapshot = HistoryManager._capture();
    const fp = HistoryManager._fingerprint(snapshot);
    const prev = HistoryManager.undoStack[HistoryManager.undoStack.length - 1];
    if (prev && prev.fp === fp) return;
    HistoryManager.undoStack.push({ label, fp, snapshot });
    if (HistoryManager.undoStack.length > HistoryManager.limit) HistoryManager.undoStack.shift();
    HistoryManager.redoStack = [];
    HistoryManager.syncButtons();
  },

  _apply(snapshot) {
    HistoryManager._restoring = true;
    try {
      if (window.HistoryModule && typeof window.HistoryModule.applySnapshot === 'function') {
        window.HistoryModule.applySnapshot(state, snapshot);
      } else {
        Object.assign(state, JSON.parse(JSON.stringify(snapshot)));
      }
      syncColumnSettings();
      RegistryView.applyRowHeight();
      FilterEngine.invalidate();
      state.rows.forEach(r => RowFactory.updateDerived(r));
      RiskEngine.computeAll();
      Storage.save();
      App.populateFilterDropdowns();
      App.refreshAll();
      App.updateTopbarBadge();
    } finally {
      HistoryManager._restoring = false;
      HistoryManager.syncButtons();
    }
  },

  undo() {
    if (!HistoryManager.undoStack.length) return;
    const current = HistoryManager._capture();
    const prev = HistoryManager.undoStack.pop();
    HistoryManager.redoStack.push({ label: prev.label, fp: HistoryManager._fingerprint(current), snapshot: current });
    HistoryManager._apply(prev.snapshot);
    showToast('Отменено');
  },

  redo() {
    if (!HistoryManager.redoStack.length) return;
    const current = HistoryManager._capture();
    const next = HistoryManager.redoStack.pop();
    HistoryManager.undoStack.push({ label: next.label, fp: HistoryManager._fingerprint(current), snapshot: current });
    HistoryManager._apply(next.snapshot);
    showToast('Повторено');
  },

  clear() {
    HistoryManager.undoStack = [];
    HistoryManager.redoStack = [];
    HistoryManager.syncButtons();
  },

  syncButtons() {
    const undoBtn = document.getElementById('btn-undo');
    const redoBtn = document.getElementById('btn-redo');
    if (undoBtn) {
      undoBtn.disabled = !HistoryManager.undoStack.length;
      undoBtn.title = HistoryManager.undoStack.length ? `Отменить (${HistoryManager.undoStack[HistoryManager.undoStack.length - 1].label})` : 'Отменить';
    }
    if (redoBtn) {
      redoBtn.disabled = !HistoryManager.redoStack.length;
      redoBtn.title = HistoryManager.redoStack.length ? `Повторить (${HistoryManager.redoStack[HistoryManager.redoStack.length - 1].label})` : 'Повторить';
    }
  },
};

// ============================================================
// FORCE SAVE (button handler)
// ============================================================
function forceSave() {
  state.rows.forEach(r=>RowFactory.updateDerived(r));
  RiskEngine.computeAll();
  syncColumnSettings();
  state._dataVersion++;
  clearTimeout(Storage._t);
  try {
    localStorage.setItem(STORAGE_KEY,JSON.stringify({rows:state.rows,employees:state.employees,savedAt:new Date().toISOString(),version:3}));
    localStorage.setItem(SETTINGS_KEY,JSON.stringify({
      colOrder:state.colOrder,colWidths:state.colWidths,colVisibility:state.colVisibility,
      sidebarCollapsed:state.sidebarCollapsed,pinnedCols:state.pinnedCols,rowHeight:state.rowHeight,
      colLabels:state.colLabels,customCols:state.customCols,colTypes:state.colTypes,
      epicDeps:state.epicDeps,ganttMode:state.ganttMode,ganttEpicsWell:state.ganttEpicsWell,
      podlozhkaMode:state.podlozhkaMode,summaryMode:state.summaryMode,presetsCollapsed:state.presetsCollapsed,
      theme:state.theme,
      gantt2Zoom:state.gantt2Zoom,gantt2ShowDeps:state.gantt2ShowDeps,gantt2Team:state.gantt2Team,
    }));
  } catch(e){
    if (e && e.name === 'QuotaExceededError') {
      showToast('Сохранение не выполнено: переполнен localStorage', 'error', 4200);
      return;
    }
  }
  App.populateFilterDropdowns();
  App.refreshAll();
  App.updateTopbarBadge();
  showToast('✓ Сохранено и пересчитано');
}

// ============================================================
// DASHBOARD VIEW
// ============================================================
const DashboardView = {
  render() {
    const rows=FilterEngine.getFiltered();
    DashboardView.renderKPIs(rows);
    DashboardView.renderProgress(rows);
    DashboardView.renderRisksPanel(rows);
    DashboardView.renderBlockingCard(rows);
    DashboardView.renderReleaseBreakdown(rows);
    DashboardView.renderTeamsSummary(rows);
    DashboardView.renderNoReleaseTable(rows);
    DashboardView.renderNeedsConfirmTable(rows);
  },
  renderKPIs(rows) {
    const done=rows.filter(r=>r.isDone).length;
    const kpis=[
      {label:'Всего задач',      value:rows.length,                                       cls:'',          key:'total'},
      {label:'В scope (Да)',      value:rows.filter(r=>r.scopeStatus==='Да').length,       cls:'kpi-green', key:'scope_yes'},
      {label:'Вне scope (Нет)',   value:rows.filter(r=>r.scopeStatus==='Нет').length,      cls:'kpi-gray',  key:'scope_no'},
      {label:'Треб. подтв.',      value:rows.filter(r=>r.scopeStatus==='Требует подтверждения').length, cls:'kpi-yellow', key:'needs_confirm'},
      {label:'В релизе 1.20',     value:rows.filter(r=>r.hasRelease120).length,            cls:'kpi-blue',  key:'r120'},
      {label:'В релизе 1.21',     value:rows.filter(r=>r.hasRelease121).length,            cls:'kpi-blue',  key:'r121'},
      {label:'В релизе 1.22',     value:rows.filter(r=>r.hasRelease122).length,            cls:'kpi-blue',  key:'r122'},
      {label:'В овертайме',       value:rows.filter(r=>r.hasOvertime).length,              cls:'kpi-red',   key:'overtime'},
      {label:'Без релиза',        value:rows.filter(r=>r.isUnassigned).length,             cls:'kpi-yellow',key:'no_release'},
      {label:'Блокирующих зав.',  value:rows.filter(r=>r.blockingDependency).length,       cls:'kpi-red',   key:'blocked'},
      {label:'Строк с рисками',   value:rows.filter(r=>r.riskFlags&&r.riskFlags.length).length, cls:rows.filter(r=>r.riskFlags&&r.riskFlags.length).length>0?'kpi-red':'kpi-gray', key:'risky'},
      {label:'Сделано',           value:done,                                              cls:'kpi-teal',  key:'done'},
    ];
    const el=document.getElementById('dashboard-kpi');
    el.innerHTML=kpis.map(k=>`
      <div class="kpi-card ${k.cls}" style="cursor:pointer" data-kpi="${k.key}"><div class="kpi-label">${k.label}</div><div class="kpi-value">${k.value}</div></div>`).join('');
    // Attach click handlers
    const kpiFilters={
      total:      ()=>rows,
      scope_yes:  ()=>rows.filter(r=>r.scopeStatus==='Да'),
      scope_no:   ()=>rows.filter(r=>r.scopeStatus==='Нет'),
      needs_confirm:()=>rows.filter(r=>r.scopeStatus==='Требует подтверждения'),
      r120:       ()=>rows.filter(r=>r.hasRelease120),
      r121:       ()=>rows.filter(r=>r.hasRelease121),
      r122:       ()=>rows.filter(r=>r.hasRelease122),
      overtime:   ()=>rows.filter(r=>r.hasOvertime),
      no_release: ()=>rows.filter(r=>r.isUnassigned),
      blocked:    ()=>rows.filter(r=>r.blockingDependency),
      risky:      ()=>rows.filter(r=>r.riskFlags&&r.riskFlags.length),
      done:       ()=>rows.filter(r=>r.isDone),
    };
    el.querySelectorAll('[data-kpi]').forEach(card=>{
      card.addEventListener('click',()=>{
        const key=card.dataset.kpi;
        const label=card.querySelector('.kpi-label').textContent;
        const filteredRows=kpiFilters[key]?kpiFilters[key]():[];
        DashboardView.openKpiModal(label, filteredRows);
      });
    });
  },
  renderProgress(rows) {
    const el = document.getElementById('dashboard-progress');
    if (!el) return;
    const p = computeProgress(rows);
    const releases = [
      { key:'120', label:'1.20', color:'#3b82f6' },
      { key:'121', label:'1.21', color:'#8b5cf6' },
      { key:'122', label:'1.22', color:'#10b981' },
      { key:'ot',  label:'OT',   color:'#f97316' },
      { key:'all', label:'Всего',color:'#64748b' },
    ];
    el.innerHTML = releases.map(r => {
      const d = p[r.key] || {total:0,done:0,pct:0};
      const overload = d.total > 30 && r.key !== 'all';
      return `<div class="progress-card">
        <div class="progress-card-header">
          <span class="progress-label">${r.label}</span>
          <span class="progress-counts">${d.done} / ${d.total} задач${overload?' ⚠️':''}</span>
        </div>
        <div class="progress-bar-wrap">
          <div class="progress-bar-fill" style="width:${d.pct}%;background:${r.color}"></div>
        </div>
        <div class="progress-pct">${d.pct}%</div>
      </div>`;
    }).join('');
  },
  openKpiModal(title, rows) {
    document.getElementById('modal-kpi-title').textContent = title;
    const body = document.getElementById('modal-kpi-body');
    if (!rows.length) { body.innerHTML = '<div style="padding:20px;color:var(--text-3)">Нет строк</div>'; }
    else {
      body.innerHTML = `<table class="data-table" style="width:100%">
        <thead><tr><th>Команда</th><th>Эпик</th><th>Задачи</th><th>Scope</th><th>Категория</th><th>Теги</th><th>Релизы</th></tr></thead>
        <tbody>${rows.map(r=>`<tr>
          <td>${r.team||'—'}</td>
          <td>${r.epic||'—'}</td>
          <td style="max-width:200px"><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks)}</div></td>
          <td>${RH.scopeChip(r.scopeStatus)}</td>
          <td>${r.category||'—'}</td>
          <td>${r.tags||'—'}</td>
          <td>${RH.releaseChips(r)}</td>
        </tr>`).join('')}</tbody>
      </table>`;
    }
    document.getElementById('modal-kpi').classList.remove('hidden');
  },
  renderRisksPanel(rows) {
    const byFlag={};
    rows.forEach(r=>(r.riskFlags||[]).forEach(f=>{byFlag[f]=(byFlag[f]||0)+1;}));
    const el=document.getElementById('risks-panel');
    if (!Object.keys(byFlag).length) { el.innerHTML='<div class="risks-panel-title">Риски внимания</div><div class="text-muted text-sm">Нет активных рисков</div>'; return; }
    el.innerHTML=`<div class="risks-panel-title">Риски внимания</div><div class="risks-panel-items">${
      Object.entries(byFlag).map(([f,c])=>`<div class="risk-counter"><div class="risk-counter-value">${c}</div><div class="risk-counter-label">${RISK_FLAGS[f]||f}</div></div>`).join('')
    }</div>`;
  },
  renderBlockingCard(rows) {
    const blocking=rows.filter(r=>r.blockingDependency);
    const el=document.getElementById('blocking-detail-card');
    if (!blocking.length) { el.innerHTML=''; return; }
    const rowsHtml=blocking.slice(0,20).map(r=>`
      <tr>
        <td>${Utils.truncate(r.team,16)}</td>
        <td>${Utils.truncate(r.epic,28)}</td>
        <td><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks)}</div></td>
        <td>${r.blockingDeadline||'—'}</td>
        <td>${RH.releaseChips(r)}</td>
        <td>${RH.scopeChip(r.scopeStatus)}</td>
        <td>${r.category||'—'}</td>
        <td>${r.tags||'—'}</td>
        <td>${Utils.truncate(r.comment,40)||'—'}</td>
      </tr>`).join('');
    el.innerHTML=`<div class="blocking-detail-card">
      <div class="blocking-detail-title">Блокирующие зависимости (${blocking.length})</div>
      <div style="overflow-x:auto"><table class="data-table">
        <thead><tr><th>Команда</th><th>Эпик</th><th>Задачи</th><th>Deadline</th><th>Релизы</th><th>Scope</th><th>Категория</th><th>Теги</th><th>Комментарий</th></tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table></div></div>`;
  },
  renderReleaseBreakdown(rows) {
    const releases=[
      {key:'r120',field:'hasRelease120',tf:'release120Types'},
      {key:'r121',field:'hasRelease121',tf:'release121Types'},
      {key:'r122',field:'hasRelease122',tf:'release122Types'},
      {key:'overtime',field:'hasOvertime',tf:'overtimeTypes'},
    ];
    document.getElementById('release-breakdown').innerHTML=releases.map(rel=>{
      const rw=RELEASE_WINDOWS[rel.key];
      const rr=rows.filter(r=>r[rel.field]);
      const wtMap={};
      rr.forEach(r=>(r[rel.tf]||[]).forEach(t=>{wtMap[t]=(wtMap[t]||0)+1;}));
      const scMap={'Да':0,'Нет':0,'Требует подтверждения':0};
      rr.forEach(r=>{if(r.scopeStatus in scMap)scMap[r.scopeStatus]++;});
      const done=rr.filter(r=>r.isDone).length;
      return `<div class="release-card">
        <div class="release-card-header"><div class="release-card-title">${rw.label}</div><div class="release-card-dates">${rw.dates}</div></div>
        <div class="release-card-count">${rr.length} задач</div>
        <div class="mini-breakdown">
          <div class="mini-breakdown-row"><span class="mini-breakdown-label">В scope (Да)</span><span class="mini-breakdown-val">${scMap['Да']}</span></div>
          <div class="mini-breakdown-row"><span class="mini-breakdown-label">Треб. подтв.</span><span class="mini-breakdown-val">${scMap['Требует подтверждения']}</span></div>
          <div class="mini-breakdown-row"><span class="mini-breakdown-label">Сделано</span><span class="mini-breakdown-val">${done}</span></div>
          ${Object.entries(wtMap).slice(0,3).map(([t,c])=>`<div class="mini-breakdown-row"><span class="mini-breakdown-label">${t}</span><span class="mini-breakdown-val">${c}</span></div>`).join('')}
        </div></div>`;
    }).join('');
  },
  renderTeamsSummary(rows) {
    const teams=Utils.unique(rows.map(r=>r.team));
    if (!teams.length) { document.getElementById('teams-summary-wrap').innerHTML=''; return; }
    document.getElementById('teams-summary-wrap').innerHTML=`<div class="data-table-wrap">
      <div class="data-table-title">📊 Сводка по командам</div>
      <div style="overflow-x:auto"><table class="data-table">
        <thead><tr><th style="text-align:left">Команда</th><th style="text-align:left">Всего</th><th style="text-align:left">Да</th><th style="text-align:left">Нет</th><th style="text-align:left">Треб.</th><th style="text-align:left">1.20</th><th style="text-align:left">1.21</th><th style="text-align:left">1.22</th><th style="text-align:left">OT</th><th style="text-align:left">Без рел.</th><th style="text-align:left">Блокер</th><th style="text-align:left">Риски</th><th style="text-align:left">Сделано</th></tr></thead>
        <tbody>${teams.map(team=>{
          const tr=rows.filter(r=>r.team===team);
          return `<tr><td style="text-align:left"><strong>${team}</strong></td>${[
            tr.length,
            tr.filter(r=>r.scopeStatus==='Да').length,
            tr.filter(r=>r.scopeStatus==='Нет').length,
            tr.filter(r=>r.scopeStatus==='Требует подтверждения').length,
            tr.filter(r=>r.hasRelease120).length,
            tr.filter(r=>r.hasRelease121).length,
            tr.filter(r=>r.hasRelease122).length,
            tr.filter(r=>r.hasOvertime).length,
            tr.filter(r=>r.isUnassigned).length,
            tr.filter(r=>r.blockingDependency).length,
            tr.filter(r=>r.riskFlags&&r.riskFlags.length).length,
            tr.filter(r=>r.isDone).length,
          ].map(c=>`<td style="text-align:left">${c||'—'}</td>`).join('')}</tr>`;
        }).join('')}</tbody>
      </table></div></div>`;
  },
  renderNoReleaseTable(rows) {
    const nr=rows.filter(r=>r.isUnassigned&&!r.isDone);
    const el=document.getElementById('no-release-wrap');
    if (!nr.length) { el.innerHTML=`<div class="data-table-wrap"><div class="data-table-title">📭 Без релиза</div><div style="padding:20px;color:var(--text-3);font-size:12px">Все задачи назначены</div></div>`; return; }
    el.innerHTML=`<div class="data-table-wrap"><div class="data-table-title">📭 Без релиза <span class="count-badge">${nr.length}</span></div>
      <div style="overflow-x:auto;max-height:320px;overflow-y:auto"><table class="data-table"><thead><tr><th>Команда</th><th>Эпик</th><th>Задача</th><th>Scope</th><th>Риски</th></tr></thead>
      <tbody>${nr.slice(0,50).map(r=>`<tr><td>${Utils.truncate(r.team,16)}</td><td>${Utils.truncate(r.epic,24)}</td><td><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks)}</div></td><td>${RH.scopeChip(r.scopeStatus)}</td><td>${RH.riskBadges(r.riskFlags)}</td></tr>`).join('')}</tbody>
      </table></div></div>`;
  },
  renderNeedsConfirmTable(rows) {
    const nc=rows.filter(r=>r.scopeStatus==='Требует подтверждения');
    const el=document.getElementById('needs-confirm-wrap');
    if (!nc.length) { el.innerHTML=`<div class="data-table-wrap"><div class="data-table-title">⚠ Требует подтверждения</div><div style="padding:20px;color:var(--text-3);font-size:12px">Нет задач</div></div>`; return; }
    el.innerHTML=`<div class="data-table-wrap"><div class="data-table-title">⚠ Требует подтверждения <span class="count-badge">${nc.length}</span></div>
      <div style="overflow-x:auto;max-height:320px;overflow-y:auto"><table class="data-table"><thead><tr><th>Команда</th><th>Эпик</th><th>Задача</th><th>Релизы</th><th>Риски</th></tr></thead>
      <tbody>${nc.slice(0,50).map(r=>`<tr><td>${Utils.truncate(r.team,16)}</td><td>${Utils.truncate(r.epic,24)}</td><td><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks)}</div></td><td>${RH.releaseChips(r)}</td><td>${RH.riskBadges(r.riskFlags)}</td></tr>`).join('')}</tbody>
      </table></div></div>`;
  },
};

// ============================================================
// REGISTRY VIEW
// ============================================================
let _dragColKey=null;

const RegistryView = {
  render() {
    const filtered=FilterEngine.getFiltered();
    const sorted=RegistryView.applySorting(filtered);
    const table=document.getElementById('registry-table');
    const empty=document.getElementById('registry-empty');
    const badge=document.getElementById('registry-count-badge');
    badge.textContent=`${sorted.length} / ${state.rows.length}`;
    if (!sorted.length) { table.classList.add('hidden'); empty.classList.remove('hidden'); return; }
    table.classList.remove('hidden'); empty.classList.add('hidden');
    RegistryView.renderHeader(); RegistryView.renderBody(sorted);
  },

  applySorting(rows) {
    const {col,dir}=state.sort; if (!col) return rows;
    return [...rows].sort((a,b)=>{
      let va=a[col],vb=b[col];
      if (va==null)va=''; if (vb==null)vb='';
      if (Array.isArray(va))va=va.join(','); if (Array.isArray(vb))vb=vb.join(',');
      const cmp=String(va).localeCompare(String(vb),'ru',{numeric:true});
      return dir==='asc'?cmp:-cmp;
    });
  },

  getVisibleCols() {
    const all=getAllCols();
    const ordered=state.colOrder
      .map(k=>all.find(c=>c.key===k))
      .filter(c=>c && state.colVisibility[c.key]!==false);
    const pinned=ordered.filter(c=>state.pinnedCols.includes(c.key));
    const rest=ordered.filter(c=>!state.pinnedCols.includes(c.key));
    return [...pinned,...rest];
  },

  _pinnedOffsets(visibleCols) {
    const map={};
    let left=36;
    for (const col of visibleCols) {
      if (!state.pinnedCols.includes(col.key)) break;
      map[col.key]=left;
      left+=(state.colWidths[col.key]||col.width||100);
    }
    return map;
  },

  findRowEl(rowId) {
    return document.querySelector(`#registry-tbody tr[data-row-id="${CSS.escape(String(rowId||''))}"]`);
  },

  updateRowVisual(tr,row) {
    if (!tr || !row) return;
    tr.classList.toggle('row-risky', !!(row.riskFlags && row.riskFlags.length));
    tr.classList.toggle('row-done', !!row.isDone);
    if (row.rowColor) {
      const rowBg = state.theme==='dark' ? Utils.hexToRgba(row.rowColor,0.2) : Utils.hexToRgba(row.rowColor,0.16);
      if (rowBg) {
        tr.classList.add('row-colored');
        tr.style.setProperty('--row-color', rowBg);
      }
    } else {
      tr.classList.remove('row-colored');
      tr.style.removeProperty('--row-color');
    }
  },

  updateRowRiskCell(tr,row) {
    if (!tr || !row) return;
    const tds = tr.querySelectorAll('td');
    const rt = tds[tds.length - 2];
    if (rt) rt.innerHTML = RH.riskBadges(row.riskFlags) + RH.doneBadge(row.isDone);
  },

  renderHeader() {
    const thead=document.getElementById('registry-thead');
    const visibleCols=RegistryView.getVisibleCols();
    const offsets=RegistryView._pinnedOffsets(visibleCols);

    const ths=visibleCols.map((col)=>{
      const w=state.colWidths[col.key]||col.width||100;
      const sortCls=state.sort.col===col.key?(state.sort.dir==='asc'?'sort-asc':'sort-desc'):'';
      const isPinned=state.pinnedCols.includes(col.key);
      const stickyAttr=isPinned?'data-sticky="true"':'';
      const stickyLeft=isPinned?`left:${offsets[col.key]}px;`:'';
      const pinCls=isPinned?'pinned':'';
      const label=state.colLabels[col.key]||col.label;
      return `<th class="${sortCls}" data-sortcol="${col.key}" data-colkey="${col.key}" ${stickyAttr}
        style="min-width:${w}px;width:${w}px;${stickyLeft}" draggable="true">
        ${label}<button class="col-pin-btn ${pinCls}" data-pinkey="${col.key}" title="${isPinned?'Открепить':'Закрепить'} столбец">📌</button><span class="sort-icon"></span>
        <div class="col-resize-handle" data-resizecol="${col.key}"></div>
      </th>`;
    });

    thead.innerHTML=`<tr><th class="th-cb"><input type="checkbox" id="bulk-select-all" title="Выбрать все"></th><th class="th-num">#</th>${ths.join('')}<th style="min-width:60px">Риски</th><th class="th-actions"></th></tr>`;
    const selectAllCb = thead.querySelector('#bulk-select-all');
    if (selectAllCb) {
      selectAllCb.addEventListener('change', () => {
        const tbody = document.getElementById('registry-tbody');
        const rowIds = [...tbody.querySelectorAll('tr[data-row-id]')].map(tr => tr.dataset.rowId);
        if (selectAllCb.checked) {
          rowIds.forEach(id => state.bulkSelected.add(id));
          tbody.querySelectorAll('.bulk-row-cb').forEach(cb => { cb.checked = true; });
          BulkEditPanel.show(); BulkEditPanel.update();
        } else {
          BulkEditPanel.clearAll();
        }
      });
    }

    // Pin toggle
    thead.querySelectorAll('.col-pin-btn').forEach(btn=>{
      btn.addEventListener('click',e=>{
        e.stopPropagation();
        HistoryManager.checkpoint('закрепление столбца');
        const key=btn.dataset.pinkey;
        if (state.pinnedCols.includes(key)) state.pinnedCols=state.pinnedCols.filter(k=>k!==key);
        else state.pinnedCols.push(key);
        Storage.save(); RegistryView.render();
      });
    });

    // Sort click
    thead.querySelectorAll('[data-sortcol]').forEach(th=>{
      th.addEventListener('click',e=>{
        if (e.target.classList.contains('col-resize-handle')) return;
        const col=th.dataset.sortcol;
        state.sort.dir=(state.sort.col===col&&state.sort.dir==='asc')?'desc':'asc';
        state.sort.col=col;
        RegistryView.render();
      });
    });

    // Column DnD reorder
    thead.querySelectorAll('th[data-colkey]').forEach(th=>{
      th.addEventListener('dragstart',e=>{ _dragColKey=th.dataset.colkey; th.classList.add('dragging'); e.dataTransfer.effectAllowed='move'; });
      th.addEventListener('dragend',()=>{ th.classList.remove('dragging'); thead.querySelectorAll('th').forEach(t=>t.classList.remove('drag-over')); });
      th.addEventListener('dragover',e=>{ e.preventDefault(); th.classList.add('drag-over'); });
      th.addEventListener('dragleave',()=>th.classList.remove('drag-over'));
      th.addEventListener('drop',e=>{
        e.preventDefault(); th.classList.remove('drag-over');
        const target=th.dataset.colkey;
        if (!_dragColKey||_dragColKey===target) return;
        HistoryManager.checkpoint('порядок столбцов');
        const from=state.colOrder.indexOf(_dragColKey), to=state.colOrder.indexOf(target);
        if (from<0||to<0) return;
        state.colOrder.splice(from,1); state.colOrder.splice(to,0,_dragColKey);
        Storage.save(); RegistryView.render();
      });
    });

    // Column resize
    thead.querySelectorAll('.col-resize-handle').forEach(handle=>{
      handle.addEventListener('mousedown',e=>{
        e.preventDefault(); e.stopPropagation();
        HistoryManager.checkpoint('ширина столбца');
        const colKey=handle.dataset.resizecol;
        const th=handle.closest('th');
        const startX=e.clientX, startW=th.offsetWidth;
        handle.classList.add('resizing');
        let active=true;
        function onMove(e2) {
          if (!active) return;
          const w=Math.max(50,startW+e2.clientX-startX);
          state.colWidths[colKey]=w;
          th.style.minWidth=w+'px'; th.style.width=w+'px';
          // Update all cells in this column
          document.querySelectorAll(`td[data-col="${colKey}"]`).forEach(td=>{ td.style.minWidth=w+'px'; td.style.maxWidth=w+'px'; });
        }
        function onUp() {
          if (!active) return;
          active=false;
          handle.classList.remove('resizing');
          document.removeEventListener('mousemove',onMove);
          document.removeEventListener('mouseup',onUp);
          window.removeEventListener('blur',onUp);
          Storage.save();
        }
        document.addEventListener('mousemove',onMove); document.addEventListener('mouseup',onUp);
        window.addEventListener('blur',onUp);
      });
    });
  },

  renderBody(rows) {
    const tbody=document.getElementById('registry-tbody');
    tbody.querySelectorAll('.ms-container,[data-cleanup]').forEach(c=>{if(c._cleanup)c._cleanup();});
    // also cleanup tag inputs
    tbody.querySelectorAll('.tag-input-wrap').forEach(c=>{if(c._cleanup)c._cleanup();});
    tbody.innerHTML='';
    tbody.classList.remove('rows-animate');
    // Force reflow so re-adding the class re-triggers animation
    void tbody.offsetHeight;
    tbody.classList.add('rows-animate');
    const visibleCols=RegistryView.getVisibleCols();
    const offsets=RegistryView._pinnedOffsets(visibleCols);

    rows.forEach((row,idx)=>{
      const tr=document.createElement('tr'); tr.dataset.rowId=row.id;
      tr.style.setProperty('--i', Math.min(idx, 30));
      RegistryView.updateRowVisual(tr,row);
      tr.addEventListener('click', (e) => {
        if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') return;
        document.querySelectorAll('#registry-tbody tr.selected-row').forEach(r => r.classList.remove('selected-row'));
        tr.classList.add('selected-row');
        state.lastClickedRowId = row.id;
      });

      const tdCb=document.createElement('td'); tdCb.className='td-cb';
      const cb=document.createElement('input'); cb.type='checkbox'; cb.className='bulk-row-cb';
      cb.checked=state.bulkSelected.has(row.id);
      cb.addEventListener('change',e=>{ e.stopPropagation(); BulkEditPanel.toggle(row.id, cb.checked); });
      tdCb.appendChild(cb); tr.appendChild(tdCb);

      const tdNum=document.createElement('td'); tdNum.className='td-num'; tdNum.textContent=idx+1; tr.appendChild(tdNum);

      visibleCols.forEach((col)=>{
        const td=document.createElement('td');
        td.dataset.col=col.key;
        const w=state.colWidths[col.key]||col.width||100;
        td.style.minWidth=w+'px'; td.style.maxWidth=w+'px';
        if (state.pinnedCols.includes(col.key)) {
          td.setAttribute('data-sticky','true');
          td.style.left=offsets[col.key]+'px';
        }
        RegistryView.renderCell(td,row,col);
        tr.appendChild(td);
      });

      const tdRisk=document.createElement('td');
      tdRisk.innerHTML=RH.riskBadges(row.riskFlags)+RH.doneBadge(row.isDone);
      tr.appendChild(tdRisk);

      const tdAct=document.createElement('td');
      tdAct.className='td-actions';
      const copyBtn=document.createElement('button'); copyBtn.className='row-act-btn row-act-copy'; copyBtn.title='Копировать строку'; copyBtn.innerHTML='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>';
      copyBtn.addEventListener('click',()=>RegistryView.copyRow(row.id));
      tdAct.appendChild(copyBtn);
      const delBtn=document.createElement('button'); delBtn.className='row-act-btn row-act-del'; delBtn.title='Удалить строку'; delBtn.innerHTML='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>';
      delBtn.addEventListener('click',()=>RegistryView.deleteRow(row.id));
      tdAct.appendChild(delBtn); tr.appendChild(tdAct);

      tbody.appendChild(tr);
    });
  },

  renderCell(td,row,col) {
    const val=row[col.key];

    if (col.type==='readonly' || col.type==='riskscore') {
      const score = col.type==='riskscore' ? (row.riskScore||0) : null;
      if (col.type==='riskscore') {
        const color = score>=60?'#ef4444':score>=30?'#f97316':'#22c55e';
        td.innerHTML=`<span class="risk-score-badge" style="background:${color}20;color:${color};border:1px solid ${color}40">${score}</span>`;
      } else {
        td.innerHTML=`<span class="cell-text" style="pointer-events:none">${Utils.truncate(String(val||''),30)}</span>`;
      }
      return;
    }
    if (col.type==='priority') {
      const opts=[['','—'],['high','Высокий'],['medium','Средний'],['low','Низкий']];
      const sel=document.createElement('select'); sel.className='cell-select priority-select';
      opts.forEach(([v,l])=>{ const o=document.createElement('option'); o.value=v; o.textContent=l; if((val||'')===(v))o.selected=true; sel.appendChild(o); });
      sel.addEventListener('change',()=>{
        HistoryManager.checkpoint(`ячейка ${col.key}`);
        row[col.key]=sel.value; row.dirty=true; row.updatedAt=new Date().toISOString();
        Storage.save(); App.refreshDashboardIfActive();
      });
      td.appendChild(sel); return;
    }
    if (col.type==='jira') {
      const wrap=document.createElement('div'); wrap.className='tasks-cell';
      wrap.innerHTML=RH.jiraTagsHtml(val);
      // Edit on double-click
      wrap.title='Двойной клик для редактирования';
      wrap.addEventListener('dblclick',()=>{
        const inp=document.createElement('input'); inp.type='text'; inp.className='cell-input'; inp.value=val||'';
        td.innerHTML=''; td.appendChild(inp); inp.focus();
        function save() {
          const nextVal=inp.value.trim();
          if (String(val||'')===nextVal) { RegistryView.renderCell(td,row,col); return; }
          HistoryManager.checkpoint(`ячейка ${col.key}`);
          row[col.key]=nextVal; row.dirty=true; row.updatedAt=new Date().toISOString();
          Storage.save(); RegistryView.renderCell(td,row,col); App.refreshDashboardIfActive();
        }
        inp.addEventListener('blur',save);
        inp.addEventListener('keydown',e=>{if(e.key==='Enter')inp.blur(); if(e.key==='Escape'){row[col.key]=val;RegistryView.renderCell(td,row,col);}});
      });
      td.appendChild(wrap); return;
    }
    if (col.type==='multiselect') {
      const cv=Array.isArray(val)?val:[];
      const ms=Multiselect.create(cv,(newVals)=>{
        HistoryManager.checkpoint(`ячейка ${col.key}`);
        row[col.key]=newVals; row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row); Storage.save(); App.refreshDashboardIfActive();
        const tr=td.closest('tr');
        if(tr){ RegistryView.updateRowVisual(tr,row); RegistryView.updateRowRiskCell(tr,row); }
      });
      td.appendChild(ms); return;
    }
    if (col.type==='scope') {
      const sel=document.createElement('select'); sel.className='cell-select';
      ['',...SCOPE_OPTIONS].forEach(opt=>{const o=document.createElement('option');o.value=opt;o.textContent=opt||'—';if(val===opt)o.selected=true;sel.appendChild(o);});
      sel.addEventListener('change',()=>{
        HistoryManager.checkpoint(`ячейка ${col.key}`);
        row[col.key]=sel.value; row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row); Storage.save(); App.refreshDashboardIfActive();
        const tr=sel.closest('tr');if(tr){RegistryView.updateRowVisual(tr,row);RegistryView.updateRowRiskCell(tr,row);}
      });
      td.appendChild(sel); return;
    }
    if (col.type==='checkbox') {
      const cb=document.createElement('input'); cb.type='checkbox'; cb.checked=!!val; cb.style.cursor='pointer';
      cb.addEventListener('change',()=>{
        HistoryManager.checkpoint(`чекбокс ${col.key}`);
        row[col.key]=cb.checked; row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row);
        const tr=cb.closest('tr');
        if (tr) {
          RegistryView.updateRowVisual(tr,row);
          RegistryView.updateRowRiskCell(tr,row);
          // Enable/disable associated date
          const assoc=col.key==='isDone'?'doneDate':col.key==='blockingDependency'?'blockingDeadline':null;
          if (assoc) { const dt=tr.querySelector(`[data-col="${assoc}"] input`); if(dt) dt.disabled=!cb.checked; }
        }
        Storage.save(); App.refreshDashboardIfActive();
      });
      td.appendChild(cb); return;
    }
    if (col.type==='date') {
      const inp=document.createElement('input'); inp.type='date'; inp.className='cell-input'; inp.value=val||'';
      const isDoneDate=col.key==='doneDate', isDeadline=col.key==='blockingDeadline';
      if (isDoneDate) inp.disabled=!row.isDone;
      if (isDeadline) inp.disabled=!row.blockingDependency;
      inp.addEventListener('change',()=>{
        if (String(row[col.key]||'')===String(inp.value||'')) return;
        HistoryManager.checkpoint(`дата ${col.key}`);
        row[col.key]=inp.value; row.dirty=true; row.updatedAt=new Date().toISOString(); Storage.save();
      });
      td.appendChild(inp); return;
    }
    if (col.type==='daterange') {
      const wrap=document.createElement('div'); wrap.className='date-range-cell';
      const start=document.createElement('input'); start.type='date'; start.className='cell-input'; start.value=row.workPeriodStart||'';
      const end=document.createElement('input'); end.type='date'; end.className='cell-input'; end.value=row.workPeriodEnd||'';
      const dash=document.createElement('span'); dash.textContent='-'; dash.className='date-range-sep';
      const save=()=>{
        const prevStart=row.workPeriodStart||'';
        const prevEnd=row.workPeriodEnd||'';
        const nextStart=start.value||'';
        const nextEnd=end.value||'';
        if (prevStart===nextStart && prevEnd===nextEnd) return;
        HistoryManager.checkpoint('период работ');
        row.workPeriodStart=start.value;
        row.workPeriodEnd=end.value;
        row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row);
        Storage.save(); App.refreshDashboardIfActive();
      };
      start.addEventListener('change',save); end.addEventListener('change',save);
      wrap.appendChild(start); wrap.appendChild(dash); wrap.appendChild(end); td.appendChild(wrap); return;
    }
    if (col.type==='number') {
      const inp=document.createElement('input'); inp.type='number'; inp.className='cell-input cell-number'; inp.value=val||''; inp.min=0; inp.style.width='100%';
      inp.addEventListener('change',()=>{
        if (String(row[col.key]||'')===String(inp.value||'')) return;
        HistoryManager.checkpoint(`число ${col.key}`);
        row[col.key]=inp.value; row.dirty=true; row.updatedAt=new Date().toISOString(); Storage.save();
      });
      td.appendChild(inp); return;
    }
    if (col.type==='tags') {
      const current=String(val||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
      const suggFn = () => {
        if (col.key==='assignee') return [...new Set([...getUniqueTagValues(col.key), ...getEmployeeNames()])].sort((a,b)=>a.localeCompare(b,'ru'));
        return getUniqueTagValues(col.key);
      };
      const tw=createTagInput(current,(tags)=>{
        const nextVal=tags.join('|');
        if (String(row[col.key]||'')===nextVal) return;
        HistoryManager.checkpoint(`теги ${col.key}`);
        row[col.key]=nextVal; row.dirty=true; row.updatedAt=new Date().toISOString();
        Storage.save(); App.populateFilterDropdowns();
      },suggFn);
      td.appendChild(tw); return;
    }
    if (col.type==='suggest') {
      const inp=document.createElement('input'); inp.type='text'; inp.className='cell-input'; inp.value=val||''; inp.style.width='100%';
      const listId='dl-'+col.key;
      inp.setAttribute('list',listId);
      inp.addEventListener('focus',()=>{
        let dl=document.getElementById(listId);
        if(!dl){dl=document.createElement('datalist');dl.id=listId;document.body.appendChild(dl);}
        dl.innerHTML=getUniqueTextValues(col.key).map(v=>`<option value="${v.replace(/"/g,'&quot;')}">`).join('');
      });
      inp.addEventListener('change',()=>{
        const nextVal=inp.value.trim();
        if (String(row[col.key]||'')===nextVal) return;
        HistoryManager.checkpoint(`текст ${col.key}`);
        row[col.key]=nextVal; row.dirty=true; row.updatedAt=new Date().toISOString(); RowFactory.updateDerived(row); App.populateFilterDropdowns(); Storage.save(); App.refreshDashboardIfActive();
      });
      td.appendChild(inp); return;
    }
    // Default text: long fields are multiline with autosize, short fields stay compact.
    const multilineKeys = new Set(['epic','taskComment','teamDependency','risks','comment']);
    const useMultiline = multilineKeys.has(col.key) || col.key.startsWith('custom_');
    if (useMultiline) {
      const inp=document.createElement('textarea'); inp.className='cell-input cell-textarea'; inp.value=val||''; inp.rows=1;
      const autoresize=()=>{ inp.style.height='auto'; inp.style.height=Math.min(180,Math.max(28,inp.scrollHeight))+'px'; };
      inp.addEventListener('input',autoresize);
      inp.addEventListener('change',()=>{
        const nextVal=inp.value.trim();
        if (String(row[col.key]||'')===nextVal) return;
        HistoryManager.checkpoint(`текст ${col.key}`);
        row[col.key]=nextVal; row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row); App.populateFilterDropdowns(); Storage.save(); App.refreshDashboardIfActive();
      });
      td.appendChild(inp); requestAnimationFrame(autoresize); return;
    }
    const inp=document.createElement('input'); inp.type='text'; inp.className='cell-input'; inp.value=val||''; inp.style.width='100%';
    inp.addEventListener('change',()=>{
      const nextVal=inp.value.trim();
      if (String(row[col.key]||'')===nextVal) return;
      HistoryManager.checkpoint(`текст ${col.key}`);
      row[col.key]=nextVal; row.dirty=true; row.updatedAt=new Date().toISOString();
      RowFactory.updateDerived(row); App.populateFilterDropdowns(); Storage.save(); App.refreshDashboardIfActive();
    });
    td.appendChild(inp);
  },

  deleteRow(id) {
    HistoryManager.checkpoint('удаление строки');
    state.rows=state.rows.filter(r=>r.id!==id);
    Storage.save(); RegistryView.render(); App.updateTopbarBadge(); App.refreshDashboardIfActive();
  },
  addRow() {
    HistoryManager.checkpoint('добавление строки');
    const newRow=RowFactory.create({dirty:true,sourceType:'manual'});
    if (state.lastClickedRowId) {
      const idx=state.rows.findIndex(r=>r.id===state.lastClickedRowId);
      if (idx>=0) { state.rows.splice(idx+1,0,newRow); Storage.save(); RegistryView.render(); App.updateTopbarBadge(); return; }
    }
    state.rows.push(newRow);
    Storage.save(); RegistryView.render(); App.updateTopbarBadge();
  },
  copyRow(id) {
    const idx=state.rows.findIndex(r=>r.id===id);
    if (idx<0) return;
    HistoryManager.checkpoint('копия строки');
    const orig=state.rows[idx];
    const copy=RowFactory.create({
      ...JSON.parse(JSON.stringify(orig)),
      id:nextId(), dirty:true, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString(),
    });
    state.rows.splice(idx+1,0,copy);
    Storage.save(); RegistryView.render(); App.updateTopbarBadge();
  },
  renderColTogglePanel() {
    const panel=document.getElementById('col-toggle-panel');
    panel.innerHTML=getAllCols().map(col=>`
      <label class="col-toggle-item">
        <input type="checkbox" data-col="${col.key}" ${state.colVisibility[col.key]!==false?'checked':''}> ${state.colLabels[col.key]||col.label}
      </label>`).join('');
    panel.querySelectorAll('input[data-col]').forEach(cb=>{
      cb.addEventListener('change',()=>{
        if (!cb.checked) {
          const visibleNow=getAllCols().filter(c=>state.colVisibility[c.key]!==false && c.key!==cb.dataset.col).length;
          if (!visibleNow) {
            cb.checked=true;
            showToast('Нужен минимум один видимый столбец','error',1800);
            return;
          }
        }
        HistoryManager.checkpoint('видимость столбца');
        state.colVisibility[cb.dataset.col]=cb.checked;
        syncColumnSettings();
        Storage.save();
        RegistryView.render();
      });
    });
  },

  applyRowHeight() {
    const rh = state.rowHeight;
    const lines = Math.max(1, Math.floor((rh - 10) / 18));
    document.documentElement.style.setProperty('--row-h', rh + 'px');
    document.documentElement.style.setProperty('--row-lines', String(lines));
  },

  renderSettingsPanel() {
    const panel=document.getElementById('registry-settings-panel');
    const all=getAllCols();
    const allTypes=COL_TYPES;
    const colRows=all.map(col=>{
      const label=state.colLabels[col.key]||col.label;
      const w=state.colWidths[col.key]||col.width||100;
      const isPinned=state.pinnedCols.includes(col.key);
      const isCustom=!!state.customCols.find(c=>c.key===col.key);
      const typeHtml=`<select class="rsp-col-type-input" data-key="${col.key}">${allTypes.map(t=>`<option value="${t}"${(col.type||'text')===t?' selected':''}>${t}</option>`).join('')}</select>`;
      return `<span class="rsp-col-key" title="${col.key}">${col.key}</span>
        <input class="rsp-col-label-input" data-key="${col.key}" value="${label.replace(/"/g,'&quot;')}">
        ${typeHtml}
        <input class="rsp-col-width-input" type="number" data-key="${col.key}" value="${w}" min="40" max="800">
        <button class="rsp-pin-btn ${isPinned?'active':''}" data-key="${col.key}">${isPinned?'📌 Закреплён':'📌 Закрепить'}</button>
        ${isCustom?`<button class="rsp-del-btn" data-key="${col.key}">✕ Удалить</button>`:'<span></span>'}`;
    }).join('');

    panel.innerHTML=`
      <div class="rsp-section">
        <div class="rsp-title">Высота строк</div>
        <div class="rsp-row-height">
          <label>Высота</label>
          <input class="filter-input" type="number" id="rsp-row-h" value="${state.rowHeight}" min="28" max="44" style="width:80px">
          <span style="font-size:12px;color:var(--text-3)">px</span>
          <button class="btn btn-ghost btn-sm" id="rsp-reset-view-btn">Сбросить вид</button>
        </div>
      </div>
      <div class="rsp-section">
        <div class="rsp-title">Столбцы</div>
        <div class="rsp-cols-grid">
          <span class="rsp-col-header">Ключ</span>
          <span class="rsp-col-header">Название</span>
          <span class="rsp-col-header">Тип</span>
          <span class="rsp-col-header">Ширина</span>
          <span class="rsp-col-header">Закреплён</span>
          <span class="rsp-col-header"></span>
          ${colRows}
        </div>
      </div>
      <div class="rsp-section">
        <div class="rsp-title">Добавить столбец</div>
        <div class="rsp-add-col">
          <input id="rsp-new-name" placeholder="Название" style="width:180px">
          <select id="rsp-new-type">
            <option value="text">Текст</option>
            <option value="number">Число</option>
            <option value="checkbox">Чекбокс</option>
            <option value="date">Дата</option>
            <option value="tags">Теги (мультиселект)</option>
          </select>
          <button class="btn btn-primary btn-sm" id="rsp-add-col-btn">+ Добавить</button>
        </div>
      </div>
      <div style="text-align:right;margin-top:8px">
        <button class="btn btn-ghost btn-sm" id="rsp-close-btn">✕ Свернуть настройки</button>
      </div>`;

    panel.querySelector('#rsp-row-h').addEventListener('input', e=>{
      const v=Math.max(28,Math.min(44,parseInt(e.target.value)||36));
      HistoryManager.checkpoint('высота строки');
      state.rowHeight=v; RegistryView.applyRowHeight(); Storage.save();
    });
    panel.querySelector('#rsp-reset-view-btn').addEventListener('click', ()=>{
      if (!confirm('Сбросить вид реестра (ширины, закрепления, видимость, высота)?')) return;
      HistoryManager.checkpoint('сброс вида реестра');
      state.colOrder=[...new Set([...REGISTRY_COLS.map(c=>c.key), ...state.customCols.map(c=>c.key)])];
      state.colWidths={};
      state.pinnedCols=[];
      state.rowHeight=36;
      const vis={};
      getAllCols().forEach(col=>{ vis[col.key]=col.visible!==false; });
      state.colVisibility=vis;
      syncColumnSettings();
      RegistryView.applyRowHeight();
      Storage.save();
      RegistryView.render();
      RegistryView.renderSettingsPanel();
      showToast('Вид реестра сброшен');
    });

    panel.querySelectorAll('.rsp-col-type-input').forEach(sel=>{
      sel.addEventListener('change', e=>{
        HistoryManager.checkpoint('тип столбца');
        const key=e.target.dataset.key;
        state.colTypes[key]=e.target.value;
        Storage.save(); RegistryView.render(); RegistryView.renderSettingsPanel();
      });
    });

    panel.querySelectorAll('.rsp-col-label-input').forEach(inp=>{
      inp.addEventListener('change', e=>{
        HistoryManager.checkpoint('название столбца');
        const key=e.target.dataset.key;
        const v=e.target.value.trim();
        if (v) state.colLabels[key]=v;
        else delete state.colLabels[key];
        Storage.save(); RegistryView.render();
      });
    });

    panel.querySelectorAll('.rsp-col-width-input').forEach(inp=>{
      inp.addEventListener('change', e=>{
        HistoryManager.checkpoint('ширина столбца');
        const v=Math.max(40,parseInt(e.target.value)||100);
        state.colWidths[e.target.dataset.key]=v;
        e.target.value=v;
        Storage.save(); RegistryView.render();
      });
    });

    panel.querySelectorAll('.rsp-pin-btn').forEach(btn=>{
      btn.addEventListener('click', e=>{
        HistoryManager.checkpoint('закрепление столбца');
        const key=btn.dataset.key;
        if (state.pinnedCols.includes(key)) state.pinnedCols=state.pinnedCols.filter(k=>k!==key);
        else state.pinnedCols.push(key);
        Storage.save(); RegistryView.render(); RegistryView.renderSettingsPanel();
      });
    });

    panel.querySelectorAll('.rsp-del-btn').forEach(btn=>{
      btn.addEventListener('click', e=>{
        const key=btn.dataset.key;
        if (!confirm('Удалить столбец «'+key+'»?')) return;
        HistoryManager.checkpoint('удаление столбца');
        state.customCols=state.customCols.filter(c=>c.key!==key);
        state.colOrder=state.colOrder.filter(k=>k!==key);
        state.pinnedCols=state.pinnedCols.filter(k=>k!==key);
        delete state.colVisibility[key]; delete state.colWidths[key]; delete state.colLabels[key]; delete state.colTypes[key];
        state.rows.forEach(r=>delete r[key]);
        Storage.save(); RegistryView.render(); RegistryView.renderSettingsPanel();
      });
    });

    panel.querySelector('#rsp-add-col-btn').addEventListener('click', ()=>{
      const name=panel.querySelector('#rsp-new-name').value.trim();
      if (!name) { panel.querySelector('#rsp-new-name').focus(); return; }
      HistoryManager.checkpoint('добавление столбца');
      const type=panel.querySelector('#rsp-new-type').value;
      const key='custom_'+Date.now().toString(36);
      const col={ key, label:name, type, visible:true, width:150 };
      state.customCols.push(col);
      state.colOrder.push(key);
      state.colVisibility[key]=true;
      panel.querySelector('#rsp-new-name').value='';
      Storage.save(); RegistryView.render(); RegistryView.renderSettingsPanel();
    });

    panel.querySelector('#rsp-close-btn').addEventListener('click',()=>{ panel.classList.add('hidden'); });
  },
};

// ============================================================
// GANTT VIEW
// ============================================================
const GanttView = {
  gf:{ team:'',scope:'',onlyBlocking:false,onlyNoRelease:false,onlyRisky:false },
  _cancelTransientInteractions: null,
  _clearTransientInteractions() {
    if (typeof GanttView._cancelTransientInteractions === 'function') {
      try { GanttView._cancelTransientInteractions(); } catch(_) {}
    }
    GanttView._cancelTransientInteractions = null;
  },
  render() { GanttView.renderFilters(); GanttView.renderChart(); },
  renderFilters() {
    const el=document.getElementById('gantt-filters');
    const teams=FilterEngine.getTeams();
    const f=GanttView.gf;
    el.innerHTML=`
      <div class="filter-group"><label class="filter-label">Команда</label>
        <select id="gf-team" class="filter-select"><option value="">Все</option>${teams.map(t=>`<option value="${t}"${f.team===t?' selected':''}>${t}</option>`).join('')}</select></div>
      <div class="filter-group"><label class="filter-label">Scope</label>
        <select id="gf-scope" class="filter-select"><option value="">Все</option>${SCOPE_OPTIONS.map(s=>`<option value="${s}"${f.scope===s?' selected':''}>${s}</option>`).join('')}</select></div>
      <label class="toggle-chip"><input type="checkbox" id="gf-blocking"${f.onlyBlocking?' checked':''}> Блокеры</label>
      <label class="toggle-chip"><input type="checkbox" id="gf-norel"${f.onlyNoRelease?' checked':''}> Без релиза</label>
      <label class="toggle-chip"><input type="checkbox" id="gf-risky"${f.onlyRisky?' checked':''}> Рисковые</label>`;
    el.querySelector('#gf-team').addEventListener('change',e=>{f.team=e.target.value;GanttView.renderChart();});
    el.querySelector('#gf-scope').addEventListener('change',e=>{f.scope=e.target.value;GanttView.renderChart();});
    el.querySelector('#gf-blocking').addEventListener('change',e=>{f.onlyBlocking=e.target.checked;GanttView.renderChart();});
    el.querySelector('#gf-norel').addEventListener('change',e=>{f.onlyNoRelease=e.target.checked;GanttView.renderChart();});
    el.querySelector('#gf-risky').addEventListener('change',e=>{f.onlyRisky=e.target.checked;GanttView.renderChart();});
  },
  getRows() {
    let rows=FilterEngine.getFiltered(); const f=GanttView.gf;
    if(f.team)rows=rows.filter(r=>r.team===f.team);
    if(f.scope)rows=rows.filter(r=>r.scopeStatus===f.scope);
    if(f.onlyBlocking)rows=rows.filter(r=>r.blockingDependency);
    if(f.onlyNoRelease)rows=rows.filter(r=>r.isUnassigned);
    if(f.onlyRisky)rows=rows.filter(r=>r.riskFlags&&r.riskFlags.length);
    return rows;
  },
  renderChart() {
    GanttView._clearTransientInteractions();
    if (GanttView._docTipListener) {
      document.removeEventListener('mousemove', GanttView._docTipListener);
      GanttView._docTipListener = null;
    }
    document.querySelectorAll('.gep-tooltip,.gtx-tooltip').forEach(t => t.remove());
    if (state.ganttMode==='epics') { GanttView.renderEpics(); return; }
    if (state.ganttMode==='arrows') { GanttView.renderArrows(); return; }
    if (state.ganttMode==='ultra') { GanttView.renderUltra(); return; }
    const wrap=document.getElementById('gantt-wrap');
    const rows=GanttView.getRows();
    if (!rows.length){wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>';return;}
    const cols=[
      {key:'backlog',label:'Бэклог',sub:'',cls:'gantt-window-backlog'},
      {key:'r120',label:'1.20',sub:'20.04–17.05',cls:'gantt-window-r120'},
      {key:'r121',label:'1.21',sub:'18.05–14.06',cls:'gantt-window-r121'},
      {key:'r122',label:'1.22',sub:'15.06–14.07',cls:'gantt-window-r122'},
      {key:'overtime',label:'OT',sub:'Овертайм',cls:'gantt-window-overtime'},
    ];
    const wrapW=Math.max(960,wrap.clientWidth||0);
    const lw=Math.max(220,Math.min(300,Math.round(wrapW*0.18)));
    const minCw=140;
    const cw=Math.max(minCw,Math.floor((wrapW-lw)/cols.length));
    const gt=`${lw}px repeat(${cols.length},${cw}px)`;
    const hasMap={backlog:'isUnassigned',r120:'hasRelease120',r121:'hasRelease121',r122:'hasRelease122',overtime:'hasOvertime'};
    const tfMap={r120:'release120Types',r121:'release121Types',r122:'release122Types',overtime:'overtimeTypes'};
    const header=`<div class="gantt-header" style="display:grid;grid-template-columns:${gt}">
      <div class="gantt-header-label">Команда / Задача</div>
      ${cols.map(c=>`<div class="gantt-header-col">${c.label}<br><span style="font-size:10px;font-weight:400;color:var(--text-4)">${c.sub}</span></div>`).join('')}
    </div>`;

    let body='';
    if (state.ganttMode==='compact') {
      Utils.unique(rows.map(r=>r.team)).forEach(team=>{
        const tr=rows.filter(r=>r.team===team);
        const cells=cols.map(col=>{
          const cnt=tr.filter(r=>r[hasMap[col.key]]).length;
          const barCls=RELEASE_WINDOWS[col.key]?RELEASE_WINDOWS[col.key].barCls:'gantt-bar-backlog';
          return `<div class="gantt-cell ${col.cls}">${cnt?`<div class="gantt-bar ${barCls}">${cnt} задач</div>`:''}</div>`;
        });
        body+=`<div class="gantt-row" style="display:grid;grid-template-columns:${gt}">
          <div class="gantt-row-label"><div class="gantt-row-label-name">${team}</div><div class="gantt-row-label-sub">${tr.length} задач</div></div>
          ${cells.join('')}</div>`;
      });
    } else if (state.ganttMode==='detailedTasks') {
      GanttView.renderDetailedTasks(rows, wrap, cols, gt, hasMap, tfMap);
      return;
    } else {
      // Detailed with team "wells"
      const teams=Utils.unique(rows.map(r=>r.team));
      teams.forEach(team=>{
        const teamRows=rows.filter(r=>r.team===team);
        body+=`<div class="gantt-team-header" style="display:grid;grid-template-columns:${gt}">
          <div class="gantt-team-header-cell">▾ ${team} <span class="team-count">${teamRows.length} задач</span></div>
          ${cols.map(col=>{
            const cnt=teamRows.filter(r=>r[hasMap[col.key]]).length;
            return `<div class="gantt-team-header-cell" style="font-weight:400;color:var(--text-3)">${cnt||''}</div>`;
          }).join('')}
        </div>`;
        teamRows.forEach(row=>{
          const cells=cols.map(col=>{
            const has=row[hasMap[col.key]];
            const barCls=RELEASE_WINDOWS[col.key]?RELEASE_WINDOWS[col.key].barCls:'gantt-bar-backlog';
            const types=(tfMap[col.key]?row[tfMap[col.key]]:[])||[];
            return `<div class="gantt-cell ${col.cls}">${has?`<div class="gantt-bar ${barCls}" title="${types.join(', ')}">${types.slice(0,2).join(',')||'•'}</div>`:''}</div>`;
          });
          body+=`<div class="gantt-row" style="display:grid;grid-template-columns:${gt}">
            <div class="gantt-row-label">
              <div class="gantt-row-label-name">${RH.riskBadges(row.riskFlags)} ${Utils.truncate(row.epic||row.tasks,30)}</div>
            </div>${cells.join('')}</div>`;
        });
      });
    }

    const legend=`<div class="gantt-legend">
      ${[['#6b7280','Бэклог'],['#4f46e5','1.20'],['#059669','1.21'],['#d97706','1.22'],['#dc2626','OT']].map(([c,l])=>`<div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:${c}"></div>${l}</div>`).join('')}
    </div>`;
    wrap.innerHTML=`<div class="gantt-container">${header}<div>${body}</div>${legend}</div>`;
  },
  renderDetailedTasks(rows, wrap, cols, gt, hasMap, tfMap) {
    const esc=Utils.escapeHtml;
    const toTags=v=>String(v||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
    const wtEmoji=(wt)=>{
      const x=String(wt||'').trim().toLowerCase();
      if (!x) return '🧩';
      if (x.includes('бизнес аналит')) return '📈';
      if (x.includes('аналит')) return '📊';
      if (x.includes('backend') || x.includes('бэкенд') || x.includes('разработ')) return '💻';
      if (x.includes('frontend') || x.includes('фронт')) return '🖥️';
      if (x.includes('qa') || x.includes('тест')) return '🧪';
      if (x.includes('внедр')) return '🚀';
      if (x.includes('миграц')) return '🗃️';
      if (x.includes('стабилиз')) return '🧯';
      if (x.includes('хотфикс') || x.includes('hotfix')) return '🚑';
      if (x.includes('интеграц')) return '🔌';
      if (x.includes('документ')) return '📝';
      return '🧩';
    };
    let body='';
    const teams=Utils.unique(rows.map(r=>r.team));
    teams.forEach(team=>{
      const teamRows=rows.filter(r=>r.team===team);
      body+=`<div class="gantt-team-header" style="display:grid;grid-template-columns:${gt}">
        <div class="gantt-team-header-cell">▾ ${esc(team||'—')} <span class="team-count">${teamRows.length} задач</span></div>
        ${cols.map(col=>{
          const cnt=teamRows.filter(r=>r[hasMap[col.key]]).length;
          return `<div class="gantt-team-header-cell" style="font-weight:400;color:var(--text-3)">${cnt||''}</div>`;
        }).join('')}
      </div>`;
      teamRows.forEach(row=>{
        const epicText=Utils.truncate(row.epic||row.tasks||'(без эпика)',42);
        const cats=toTags(row.category);
        const catHtml=cats.length
          ? cats.slice(0,3).map(cat=>`<span class="chip chip-indigo">${esc(Utils.truncate(cat,16))}</span>`).join('')
          : '<span class="text-muted text-xs">без категории</span>';
        const cells=cols.map(col=>{
          const has=row[hasMap[col.key]];
          const barCls=RELEASE_WINDOWS[col.key]?RELEASE_WINDOWS[col.key].barCls:'gantt-bar-backlog';
          const types=(tfMap[col.key]?row[tfMap[col.key]]:[])||[];
          const rendered=types.slice(0,3);
          const more=types.length-rendered.length;
          const pills=rendered.map(t=>`<span class="gantt-type-pill">${wtEmoji(t)} ${esc(Utils.truncate(t,14))}</span>`).join('');
          const barTitle=types.join(' / ');
          const bodyHtml=pills || '<span class="gantt-type-pill">🧩 задача</span>';
          const moreHtml=more>0?`<span class="gantt-type-pill">+${more}</span>`:'';
          return `<div class="gantt-cell ${col.cls}">${has?`<div class="gantt-bar ${barCls} gantt-bar-multi" title="${esc(barTitle)}">${bodyHtml}${moreHtml}</div>`:''}</div>`;
        });
        body+=`<div class="gantt-row" style="display:grid;grid-template-columns:${gt}">
          <div class="gantt-row-label">
            <div class="gantt-row-label-name">${RH.riskBadges(row.riskFlags)} ${esc(epicText)}</div>
            <div class="gantt-row-label-sub">${catHtml}</div>
          </div>${cells.join('')}</div>`;
      });
    });
    const header=`<div class="gantt-header" style="display:grid;grid-template-columns:${gt}">
      <div class="gantt-header-label">Эпик / Категория</div>
      ${cols.map(c=>`<div class="gantt-header-col">${c.label}<br><span style="font-size:10px;font-weight:400;color:var(--text-4)">${c.sub}</span></div>`).join('')}
    </div>`;
    const legend=`<div class="gantt-legend">
      ${[['#6b7280','Бэклог'],['#4f46e5','1.20'],['#059669','1.21'],['#d97706','1.22'],['#dc2626','OT']].map(([c,l])=>`<div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:${c}"></div>${l}</div>`).join('')}
    </div>`;
    wrap.innerHTML=`<div class="gantt-container">${header}<div>${body}</div>${legend}</div>`;
  },
  renderArrows() {
    const wrap=document.getElementById('gantt-wrap');
    const rows=GanttView.getRows();
    if (!rows.length) {
      wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>';
      return;
    }

    if (typeof GanttView._arrowsShowLines !== 'boolean') GanttView._arrowsShowLines=true;
    document.querySelectorAll('.gep-tooltip,.gtx-tooltip').forEach(t=>t.remove());

    const esc=Utils.escapeHtml;
    const toTags=v=>String(v||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
    const toDate=v=>{ if(!v) return null; const d=new Date(v); if(Number.isNaN(d.getTime())) return null; return new Date(d.getFullYear(),d.getMonth(),d.getDate()); };
    const fmtIso=d=>d?d.toISOString().slice(0,10):'';

    const hasEpicData=rows.some(r=>String(r.epic||'').trim());
    const epicMap={};
    rows.forEach(r=>{
      const key=hasEpicData
        ? (String(r.epic||'').trim()||'(без эпика)')
        : (String(r.category||r.tasks||'').trim()||'(без эпика)');
      if(!epicMap[key]) epicMap[key]=[];
      epicMap[key].push(r);
    });

    const epics=Object.keys(epicMap).sort((a,b)=>a.localeCompare(b,'ru'));
    const epicInfo={};
    epics.forEach(name=>{
      const erows=epicMap[name];
      const categories=new Set();
      const assignees=new Set();
      const roles=new Set();
      const phases={};
      let start=null,end=null;
      erows.forEach(r=>{
        toTags(r.category).forEach(x=>categories.add(x));
        toTags(r.assignee).forEach(x=>assignees.add(x));
        toTags(r.role).forEach(x=>roles.add(x));
        const pushPhase=(key,wtList,s,e)=>{
          if(!wtList.length||!s||!e) return;
          if(!phases[key]) phases[key]={types:new Set(),start:s,end:e};
          wtList.forEach(w=>phases[key].types.add(w));
          if (s<phases[key].start) phases[key].start=s;
          if (e>phases[key].end) phases[key].end=e;
          if (!start||s<start) start=s;
          if (!end||e>end) end=e;
        };
        if (r.hasRelease120) pushPhase('r120',Array.isArray(r.release120Types)?r.release120Types:[],new Date(GANTT_RELEASE_BOUNDS.r120[0]),new Date(GANTT_RELEASE_BOUNDS.r120[1]));
        if (r.hasRelease121) pushPhase('r121',Array.isArray(r.release121Types)?r.release121Types:[],new Date(GANTT_RELEASE_BOUNDS.r121[0]),new Date(GANTT_RELEASE_BOUNDS.r121[1]));
        if (r.hasRelease122) pushPhase('r122',Array.isArray(r.release122Types)?r.release122Types:[],new Date(GANTT_RELEASE_BOUNDS.r122[0]),new Date(GANTT_RELEASE_BOUNDS.r122[1]));
        if (r.hasOvertime) {
          const s=toDate(r.workPeriodStart), e=toDate(r.workPeriodEnd);
          pushPhase('ot',Array.isArray(r.overtimeTypes)?r.overtimeTypes:[],s,e);
        }
      });
      epicInfo[name]={
        categories:[...categories].sort((a,b)=>a.localeCompare(b,'ru')),
        assignees:[...assignees].sort((a,b)=>a.localeCompare(b,'ru')),
        roles:[...roles].sort((a,b)=>a.localeCompare(b,'ru')),
        phases,
        start,end,
        count:erows.length,
        blocking:erows.some(r=>!!r.blockingDependency),
      };
    });

    const sorted=[...epics].sort((a,b)=>{
      const ia=epicInfo[a], ib=epicInfo[b];
      if (ia.start && ib.start && ia.start.getTime()!==ib.start.getTime()) return ia.start-ib.start;
      if (ia.start && !ib.start) return -1;
      if (!ia.start && ib.start) return 1;
      return a.localeCompare(b,'ru');
    });

    let minBound=null,maxBound=null;
    sorted.forEach(name=>{
      const i=epicInfo[name];
      if (i.start && (!minBound||i.start<minBound)) minBound=i.start;
      if (i.end && (!maxBound||i.end>maxBound)) maxBound=i.end;
    });
    if (!minBound||!maxBound) { minBound=new Date(GANTT_TIMELINE_START); maxBound=new Date(GANTT_TIMELINE_END); }
    const spanDays=Math.ceil((maxBound.getTime()-minBound.getTime())/86400000);
    if (spanDays>280) {
      minBound=new Date(GANTT_TIMELINE_START);
      maxBound=new Date(GANTT_TIMELINE_END.getFullYear(), GANTT_TIMELINE_END.getMonth()+2, 0);
    }

    const tStartDate=new Date(minBound.getFullYear(),minBound.getMonth(),1);
    const tEndDate=new Date(maxBound.getFullYear(),maxBound.getMonth()+1,1);
    const timelineLastDay=new Date(tEndDate.getTime()-86400000);
    const totalDays=Math.max(1,Math.ceil((tEndDate.getTime()-tStartDate.getTime())/86400000));
    const wrapW=Math.max(1120,wrap.clientWidth||0);
    const LEFT_W=Math.max(320,Math.min(470,Math.round(wrapW*0.34)));
    const fitW=Math.max(860,wrapW-LEFT_W-4);
    const rawW=Math.round(totalDays*6);
    const totalW=Math.max(fitW,Math.min(rawW,5600));
    const dayPx=totalW/totalDays;
    const dayOffset=d=>Math.max(0,Math.round((d.getTime()-tStartDate.getTime())/86400000*dayPx));
    const dayWidth=(a,b)=>Math.max(12,Math.round(((b.getTime()-a.getTime())/86400000+1)*dayPx));

    let monthHeader='';
    for(let d=new Date(tStartDate); d<tEndDate; d=new Date(d.getFullYear(),d.getMonth()+1,1)){
      const next=new Date(d.getFullYear(),d.getMonth()+1,1);
      const x=dayOffset(d), w=Math.max(1,dayOffset(next)-x);
      monthHeader+=`<div class="gtx-month-cell" style="left:${x}px;width:${w}px">${esc(d.toLocaleString('ru',{month:'short',year:'2-digit'}))}</div>`;
    }

    const relDefs=[
      {key:'r120',label:'1.20',color:'rgba(79,70,229,.06)'},
      {key:'r121',label:'1.21',color:'rgba(5,150,105,.06)'},
      {key:'r122',label:'1.22',color:'rgba(217,119,6,.06)'},
    ];
    const relBounds={
      r120:[new Date(GANTT_RELEASE_BOUNDS.r120[0]),new Date(GANTT_RELEASE_BOUNDS.r120[1])],
      r121:[new Date(GANTT_RELEASE_BOUNDS.r121[0]),new Date(GANTT_RELEASE_BOUNDS.r121[1])],
      r122:[new Date(GANTT_RELEASE_BOUNDS.r122[0]),new Date(GANTT_RELEASE_BOUNDS.r122[1])],
    };
    let bands='';
    relDefs.forEach(rd=>{
      const b=relBounds[rd.key];
      const visS=b[0]<tStartDate?tStartDate:b[0];
      const visE=b[1]>timelineLastDay?timelineLastDay:b[1];
      if (visE<visS) return;
      const x=dayOffset(visS), w=dayWidth(visS,visE);
      bands+=`<div class="gtx-band" style="left:${x}px;width:${w}px;background:${rd.color}"></div>`;
      bands+=`<div class="gtx-band-label" style="left:${x+4}px">${rd.label}</div>`;
    });

    const depItems=Object.entries(state.epicDeps||{})
      .map(([to,from])=>({to:String(to||'').trim(),from:String(from||'').trim()}))
      .filter(d=>d.to&&d.from&&d.to!==d.from&&epicInfo[d.to]&&epicInfo[d.from])
      .map(d=>{
        const src=epicInfo[d.from], dst=epicInfo[d.to];
        return {...d,offtrack:!!(src.end&&dst.start&&dst.start<src.end)};
      })
      .sort((a,b)=>a.to.localeCompare(b.to,'ru'));

    const depFromMap={}; const depToCount={};
    depItems.forEach(d=>{ depFromMap[d.to]=d.from; depToCount[d.from]=(depToCount[d.from]||0)+1; });

    const ROW_H=52;
    const geometry={};
    const rowHtml=sorted.map((name,rowIdx)=>{
      const i=epicInfo[name];
      let bars='';
      let startX=Number.POSITIVE_INFINITY;
      let endX=Number.NEGATIVE_INFINITY;
      const addBar=(phaseKey,ph)=>{
        if(!ph||!ph.start||!ph.end) return;
        const visS=ph.start<tStartDate?tStartDate:ph.start;
        const visE=ph.end>timelineLastDay?timelineLastDay:ph.end;
        if (visE<visS) return;
        const bx=dayOffset(visS), bw=dayWidth(visS,visE);
        if (bx<startX) startX=bx;
        if (bx+bw>endX) endX=bx+bw;
        const ordered=PHASE_ORDER.filter(p=>ph.types.has(p));
        const leftovers=[...ph.types].filter(t=>!ordered.includes(t));
        const all=[...ordered,...leftovers];
        const segBase=Math.max(1,Math.floor(bw/Math.max(1,all.length)));
        let segs='',left=0;
        all.forEach((wt,idx)=>{
          const sw=idx===all.length-1?Math.max(1,bw-left):segBase;
          segs+=`<span class="gtx-seg" style="left:${left}px;width:${sw}px;background:${PHASE_COLORS[wt]||'#6b7280'}">${sw>=36?(PHASE_SHORT[wt]||Utils.truncate(wt,10)):''}</span>`;
          left+=sw;
        });
        bars+=`<div class="gtx-bar${i.blocking?' gtx-bar-blocking':''}" style="left:${bx}px;width:${bw}px">${segs}</div>`;
      };
      addBar('r120',i.phases.r120);
      addBar('r121',i.phases.r121);
      addBar('r122',i.phases.r122);
      addBar('ot',i.phases.ot);
      if (!Number.isFinite(startX)) {
        startX=6;
        endX=Math.min(totalW-6,startX+Math.round(10*dayPx));
        bars=`<div class="gtx-bar" style="left:${startX}px;width:${Math.max(14,endX-startX)}px"><span class="gtx-seg" style="left:0;width:100%;background:#94a3b8">BL</span></div>`;
      }

      const y=rowIdx*ROW_H+ROW_H/2;
      geometry[name]={startX,endX,top:rowIdx*ROW_H,midY:y,startDate:i.start,endDate:i.end};
      const inDep=depFromMap[name]||'';
      const depOut=depToCount[name]||0;
      const cats=i.categories.slice(0,2).map(c=>`<span class="chip chip-indigo">${esc(Utils.truncate(c,16))}</span>`).join('');
      const assigneeText=i.assignees.slice(0,2).join(', ')||'—';
      const handleX=Math.max(12,Math.min(totalW-12,endX-10));
      return `<div class="gar-row${i.blocking?' gar-row-blocking':''}" style="height:${ROW_H}px" data-epic="${esc(name)}">
        <div class="gar-left" style="width:${LEFT_W}px">
          <div class="gar-title">${esc(Utils.truncate(name,60))}</div>
          <div class="gar-meta">${cats||'<span class="text-muted text-xs">без категории</span>'}<span class="chip chip-gray">${esc(Utils.truncate(assigneeText,26))}</span>${inDep?`<span class="chip chip-purple">← ${esc(Utils.truncate(inDep,14))}</span>`:''}${depOut?`<span class="chip chip-blue">→ ${depOut}</span>`:''}</div>
        </div>
        <div class="gar-time" style="width:${totalW}px">
          <div class="gar-time-inner" style="width:${totalW}px">
            ${bars}
            <button class="gar-handle" data-epic="${esc(name)}" style="left:${handleX}px" aria-label="Создать связь">◎</button>
          </div>
        </div>
      </div>`;
    }).join('');

    const routePath=(src,dst,idx)=>{
      const sx=LEFT_W+src.endX+2;
      const sy=src.midY;
      const tx=LEFT_W+dst.startX-8;
      const ty=dst.midY;
      const syTop=src.top+8;
      const tyTop=dst.top+8;
      const bendX=Math.max(sx+18,tx+18,LEFT_W+Math.max(src.endX,dst.startX)+24+(idx%4)*10);
      return `M${sx},${sy} L${sx},${syTop} L${bendX},${syTop} L${bendX},${tyTop} L${tx},${tyTop} L${tx},${ty}`;
    };
    const depPaths=depItems.map((d,idx)=>{
      const src=geometry[d.from], dst=geometry[d.to];
      if(!src||!dst) return '';
      const stroke=d.offtrack?'#dc2626':'#6366f1';
      const marker=d.offtrack?'url(#gar-arr-red)':'url(#gar-arr-indigo)';
      return `<path d="${routePath(src,dst,idx)}" stroke="${stroke}" stroke-width="${d.offtrack?2.2:1.8}" stroke-linecap="round" stroke-linejoin="round" fill="none" marker-end="${marker}" opacity=".92"/>`;
    }).join('');

    wrap.innerHTML=`<div class="gar-shell" style="--gar-left:${LEFT_W}px">
      <div class="gar-toolbar">
        <span class="gtx-pill">Эпиков: ${sorted.length}</span>
        <span class="gtx-pill">Связей: ${depItems.length}</span>
        <span class="gtx-pill${depItems.some(x=>x.offtrack)?' gtx-pill-danger':''}">Конфликтов: ${depItems.filter(x=>x.offtrack).length}</span>
        <label class="gtx-lines-toggle"><input type="checkbox" id="gar-show-lines"${GanttView._arrowsShowLines?' checked':''}> Показать стрелки</label>
        <span class="gar-hint">Тяните ◎ с эпика-источника на строку целевого эпика (FS-зависимость).</span>
      </div>
      <div class="gtx-shell">
        <div class="gtx-grid" style="min-width:${LEFT_W+totalW}px">
          <div class="gtx-head">
            <div class="gtx-head-epic" style="width:${LEFT_W}px">Эпик / Категория / Исполнитель</div>
            <div class="gtx-head-time" style="width:${totalW}px"><div class="gtx-month-track" style="width:${totalW}px">${monthHeader}</div></div>
          </div>
          <div class="gtx-body" style="height:${sorted.length*ROW_H}px">
            <div class="gtx-time-bands" style="left:${LEFT_W}px;width:${totalW}px;height:${sorted.length*ROW_H}px">${bands}</div>
            <div class="gar-rows">${rowHtml}</div>
            <svg class="gar-dep-svg" style="width:${LEFT_W+totalW}px;height:${sorted.length*ROW_H}px" viewBox="0 0 ${LEFT_W+totalW} ${sorted.length*ROW_H}">
              <defs>
                <marker id="gar-arr-indigo" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto"><path d="M0,0 L0,7 L7,3.5 z" fill="#4f46e5"/></marker>
                <marker id="gar-arr-red" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto"><path d="M0,0 L0,7 L7,3.5 z" fill="#dc2626"/></marker>
              </defs>
              ${GanttView._arrowsShowLines?depPaths:''}
            </svg>
          </div>
        </div>
      </div>
      <div class="gar-links-list">
        ${depItems.length?depItems.map(d=>`<span class="gar-link-pill${d.offtrack?' offtrack':''}">
          <button class="gar-link-focus" data-from="${esc(d.from)}" data-to="${esc(d.to)}">${esc(Utils.truncate(d.from,18))} → ${esc(Utils.truncate(d.to,18))}</button>
          <button class="gar-link-remove" data-to="${esc(d.to)}" title="Удалить связь">×</button>
        </span>`).join(''):'<span class="text-muted text-sm">Связей пока нет</span>'}
      </div>
    </div>`;

    const refresh=()=>{ Storage.save(); GanttView.renderChart(); };
    const showLines=wrap.querySelector('#gar-show-lines');
    if (showLines) showLines.addEventListener('change',e=>{ GanttView._arrowsShowLines=!!e.target.checked; GanttView.renderChart(); });
    wrap.querySelectorAll('.gar-link-remove').forEach(btn=>btn.addEventListener('click',e=>{
      e.preventDefault(); e.stopPropagation();
      const to=btn.dataset.to||'';
      if (to&&state.epicDeps[to]) { delete state.epicDeps[to]; refresh(); }
    }));
    wrap.querySelectorAll('.gar-link-focus').forEach(btn=>btn.addEventListener('click',e=>{
      e.preventDefault();
      const to=btn.dataset.to||'';
      const row=wrap.querySelector(`.gar-row[data-epic="${CSS.escape(to)}"]`);
      if (row&&row.scrollIntoView) row.scrollIntoView({block:'center',behavior:'smooth'});
      row&&row.classList.add('gar-row-drop');
      setTimeout(()=>row&&row.classList.remove('gar-row-drop'),900);
    }));

    let drag=null,ghostSvg=null,ghostPath=null,dropRow=null;
    const onBlur=()=>clearDrag();
    const clearDrag=()=>{
      ghostSvg&&ghostSvg.remove();
      dropRow&&dropRow.classList.remove('gar-row-drop');
      drag=null; ghostSvg=null; ghostPath=null; dropRow=null;
      document.removeEventListener('mousemove',onMove);
      document.removeEventListener('mouseup',onUp);
      document.removeEventListener('keydown',onKey);
      window.removeEventListener('blur',onBlur);
    };
    GanttView._cancelTransientInteractions=clearDrag;
    const drawGhost=(x1,y1,x2,y2)=>{
      if(!ghostPath) return;
      const bend=Math.max(x1,x2)+28;
      ghostPath.setAttribute('d',`M${x1},${y1} L${bend},${y1} L${bend},${y2} L${x2},${y2}`);
    };
    const rowAt=(x,y)=>{
      const el=document.elementFromPoint(x,y);
      return el&&el.closest?el.closest('#gantt-wrap .gar-row'):null;
    };
    const onMove=(e)=>{
      if(!drag) return;
      drawGhost(drag.x,drag.y,e.clientX,e.clientY);
      const r=rowAt(e.clientX,e.clientY);
      const valid=r&&r.dataset.epic&&r.dataset.epic!==drag.from?r:null;
      if (dropRow&&dropRow!==valid) dropRow.classList.remove('gar-row-drop');
      if (valid&&dropRow!==valid) valid.classList.add('gar-row-drop');
      dropRow=valid;
    };
    const onUp=(e)=>{
      if(!drag) return;
      const r=rowAt(e.clientX,e.clientY);
      const to=r?(r.dataset.epic||''):'';
      const from=drag.from;
      clearDrag();
      if (!to||!from||to===from) return;
      state.epicDeps[to]=from;
      refresh();
      showToast(`Связь создана: ${to} зависит от ${from}`);
    };
    const onKey=e=>{ if(e.key==='Escape') clearDrag(); };

    wrap.querySelectorAll('.gar-handle').forEach(btn=>btn.addEventListener('mousedown',e=>{
      e.preventDefault(); e.stopPropagation();
      clearDrag();
      const row=btn.closest('.gar-row');
      if(!row) return;
      drag={from:row.dataset.epic,x:e.clientX,y:e.clientY};
      const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
      svg.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:9800;';
      const p=document.createElementNS('http://www.w3.org/2000/svg','path');
      p.setAttribute('stroke','#4f46e5');
      p.setAttribute('stroke-width','2');
      p.setAttribute('stroke-dasharray','6 4');
      p.setAttribute('stroke-linecap','round');
      p.setAttribute('stroke-linejoin','round');
      p.setAttribute('fill','none');
      svg.appendChild(p);
      document.body.appendChild(svg);
      ghostSvg=svg; ghostPath=p;
      drawGhost(e.clientX,e.clientY,e.clientX,e.clientY);
      document.addEventListener('mousemove',onMove);
      document.addEventListener('mouseup',onUp);
      document.addEventListener('keydown',onKey);
      window.addEventListener('blur',onBlur);
    }));
  },

  renderUltra() {
    const wrap=document.getElementById('gantt-wrap');
    const rows=GanttView.getRows();
    if (!rows.length) { wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>'; return; }

    const esc=Utils.escapeHtml;
    const toDate=v=>{ if(!v) return null; const d=new Date(v); if(Number.isNaN(d.getTime())) return null; return new Date(d.getFullYear(),d.getMonth(),d.getDate()); };

    let minBound=null,maxBound=null;
    rows.forEach(r=>{
      const dates=[];
      if(r.hasRelease120) dates.push(new Date(GANTT_RELEASE_BOUNDS.r120[0]), new Date(GANTT_RELEASE_BOUNDS.r120[1]));
      if(r.hasRelease121) dates.push(new Date(GANTT_RELEASE_BOUNDS.r121[0]), new Date(GANTT_RELEASE_BOUNDS.r121[1]));
      if(r.hasRelease122) dates.push(new Date(GANTT_RELEASE_BOUNDS.r122[0]), new Date(GANTT_RELEASE_BOUNDS.r122[1]));
      if(r.hasOvertime){
        const s=toDate(r.workPeriodStart), e=toDate(r.workPeriodEnd);
        if(s) dates.push(s);
        if(e) dates.push(e);
      }
      dates.forEach(d=>{
        if(!minBound||d<minBound) minBound=d;
        if(!maxBound||d>maxBound) maxBound=d;
      });
    });
    if (!minBound||!maxBound) { minBound=new Date(GANTT_TIMELINE_START); maxBound=new Date(GANTT_TIMELINE_END); }
    // Guard against outlier dates (for example OT periods far in the future) that make the chart look "shifted away".
    const spanDays=Math.ceil((maxBound.getTime()-minBound.getTime())/86400000);
    if (spanDays>280) {
      minBound=new Date(GANTT_TIMELINE_START);
      maxBound=new Date(GANTT_TIMELINE_END.getFullYear(), GANTT_TIMELINE_END.getMonth()+2, 0);
    }
    const tStartDate=new Date(minBound.getFullYear(),minBound.getMonth(),1);
    const tEndDate=new Date(maxBound.getFullYear(),maxBound.getMonth()+1,1);
    const totalDays=Math.max(1,Math.ceil((tEndDate.getTime()-tStartDate.getTime())/86400000));
    const wrapW=Math.max(1100,wrap.clientWidth||0);
    const LEFT_W=Math.max(360,Math.min(520,Math.round(wrapW*0.34)));
    const fitW=Math.max(840,wrapW-LEFT_W-4);
    const rawW=Math.round(totalDays*GANTT_DAY_PX);
    const totalW=Math.max(fitW,Math.min(rawW,5200));
    const dayPx=totalW/totalDays;
    const dayOffset=d=>Math.max(0,Math.round((d.getTime()-tStartDate.getTime())/86400000*dayPx));
    const dayWidth=(a,b)=>Math.max(10,Math.round(((b.getTime()-a.getTime())/86400000+1)*dayPx));

    let monthHeader='';
    for(let d=new Date(tStartDate); d<tEndDate; d=new Date(d.getFullYear(),d.getMonth()+1,1)){
      const next=new Date(d.getFullYear(),d.getMonth()+1,1);
      const x=dayOffset(d), w=Math.max(1,dayOffset(next)-x);
      monthHeader+=`<div class="gtx-month-cell" style="left:${x}px;width:${w}px">${esc(d.toLocaleString('ru',{month:'short',year:'2-digit'}))}</div>`;
    }

    const sorted=[...rows].sort((a,b)=>{
      const ca=String(a.team||'')+String(a.epic||'')+String(a.tasks||'');
      const cb=String(b.team||'')+String(b.epic||'')+String(b.tasks||'');
      return ca.localeCompare(cb,'ru');
    });

    const relDefs=[
      {key:'r120', label:'1.20', start:new Date(GANTT_RELEASE_BOUNDS.r120[0]), end:new Date(GANTT_RELEASE_BOUNDS.r120[1]), field:'release120Types'},
      {key:'r121', label:'1.21', start:new Date(GANTT_RELEASE_BOUNDS.r121[0]), end:new Date(GANTT_RELEASE_BOUNDS.r121[1]), field:'release121Types'},
      {key:'r122', label:'1.22', start:new Date(GANTT_RELEASE_BOUNDS.r122[0]), end:new Date(GANTT_RELEASE_BOUNDS.r122[1]), field:'release122Types'},
      {key:'ot', label:'OT', start:null, end:null, field:'overtimeTypes'},
    ];
    const relBg={r120:'rgba(79,70,229,.06)',r121:'rgba(5,150,105,.06)',r122:'rgba(217,119,6,.06)',ot:'rgba(220,38,38,.06)'};

    let bands='';
    relDefs.forEach(rd=>{
      if(!rd.start||!rd.end) return;
      const visS=rd.start<tStartDate?tStartDate:rd.start;
      const visE=rd.end>new Date(tEndDate.getTime()-86400000)?new Date(tEndDate.getTime()-86400000):rd.end;
      if(visE<visS) return;
      const x=dayOffset(visS), w=dayWidth(visS,visE);
      bands+=`<div class="gtx-band" style="left:${x}px;width:${w}px;background:${relBg[rd.key]}"></div>`;
      bands+=`<div class="gtx-band-label" style="left:${x+4}px">${rd.label}</div>`;
    });

    const timelineLastDay=new Date(tEndDate.getTime()-86400000);
    const ROW_H=52;
    let firstBarX=Number.POSITIVE_INFINITY;
    const rowHtml=sorted.map(r=>{
      let bars='';
      relDefs.forEach(rd=>{
        const types=Array.isArray(r[rd.field])?r[rd.field]:[];
        if(!types.length) return;
        let s=rd.start,e=rd.end;
        if(rd.key==='ot'){
          s=toDate(r.workPeriodStart); e=toDate(r.workPeriodEnd);
          if(!s||!e) return;
        }
        const visS=s<tStartDate?tStartDate:s;
        const visE=e>timelineLastDay?timelineLastDay:e;
        if (visE<visS) return;
        const bx=dayOffset(visS), bw=dayWidth(visS,visE);
        if (bx<firstBarX) firstBarX=bx;
        const ordered=PHASE_ORDER.filter(p=>types.includes(p));
        const leftovers=types.filter(t=>!ordered.includes(t));
        const phaseList=[...ordered,...leftovers];
        const segBase=Math.max(1,Math.floor(bw/Math.max(1,phaseList.length)));
        let segs='', left=0;
        phaseList.forEach((wt,i)=>{
          const sw=i===phaseList.length-1?Math.max(1,bw-left):segBase;
          segs+=`<span class="gtx-seg" style="left:${left}px;width:${sw}px;background:${PHASE_COLORS[wt]||'#6b7280'}">${sw>=34?(PHASE_SHORT[wt]||Utils.truncate(wt,10)):''}</span>`;
          left+=sw;
        });
        bars+=`<div class="gtx-bar${r.blockingDependency?' gtx-bar-blocking':''}" style="left:${bx}px;width:${bw}px">${segs}</div>`;
      });
      if(!bars && r.isUnassigned){
        const bEnd=new Date(tStartDate.getTime()+Math.min(9,totalDays-1)*86400000);
        bars=`<div class="gtx-bar" style="left:4px;width:${dayWidth(tStartDate,bEnd)}px"><span class="gtx-seg" style="left:0;width:100%;background:#94a3b8">BL</span></div>`;
        firstBarX=Math.min(firstBarX,4);
      }
      const period=r.workPeriodStart&&r.workPeriodEnd?`${r.workPeriodStart} — ${r.workPeriodEnd}`:'—';
      const rowLabel=Utils.truncate(r.epic||r.tasks||'(без эпика)',60);
      return `<div class="gtx-row${r.blockingDependency?' gtx-row-blocking':''}" style="height:${ROW_H}px" title="Исполнитель: ${esc(r.assignee||'—')}&#10;Период: ${esc(period)}">
        <div class="gtx-epic-cell" style="width:${LEFT_W}px">
          <div class="gtx-epic-name">${esc(rowLabel)}</div>
          <div class="gtx-epic-meta">
            <span class="chip chip-gray">${esc(Utils.truncate(r.team||'—',18))}</span>
            ${r.role?`<span class="chip chip-indigo">${esc(Utils.truncate(r.role,20))}</span>`:''}
            ${r.assignee?`<span class="chip chip-blue">${esc(Utils.truncate(r.assignee,22))}</span>`:''}
            ${RH.riskBadges(r.riskFlags)||''}
            ${RH.doneBadge(r.isDone)}
          </div>
        </div>
        <div class="gtx-time-cell" style="width:${totalW}px"><div class="gtx-time-inner" style="width:${totalW}px">${bars}</div></div>
      </div>`;
    }).join('');

    wrap.innerHTML=`<div class="gtx-shell" style="--gtx-left:${LEFT_W}px;--gtx-dep:0px">
      <div class="gtx-grid" style="min-width:${LEFT_W+totalW}px">
        <div class="gtx-head">
          <div class="gtx-head-epic" style="width:${LEFT_W}px">Команда / Эпик / Исполнитель</div>
          <div class="gtx-head-time" style="width:${totalW}px"><div class="gtx-month-track" style="width:${totalW}px">${monthHeader}</div></div>
        </div>
        <div class="gtx-body" style="height:${sorted.length*ROW_H}px">
          <div class="gtx-time-bands" style="left:${LEFT_W}px;width:${totalW}px;height:${sorted.length*ROW_H}px">${bands}</div>
          <div class="gtx-rows">${rowHtml}</div>
        </div>
      </div>
      <div class="gantt-legend">
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#4f46e5"></div>1.20</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#059669"></div>1.21</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#d97706"></div>1.22</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#dc2626"></div>Овертайм</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#dc2626"></div>Толстая рамка = блокер</div>
      </div>
    </div>`;
    const shell=wrap.querySelector('.gtx-shell');
    if (shell && Number.isFinite(firstBarX)) shell.scrollLeft=Math.max(0,firstBarX-60);
  },

  renderEpics() {
    const wrap = document.getElementById('gantt-wrap');
    document.querySelectorAll('.gep-tooltip,.gtx-tooltip').forEach(t => t.remove());
    const rows = GanttView.getRows();
    if (!rows.length) {
      wrap.innerHTML = '<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>';
      return;
    }

    if (typeof GanttView._epicsShowLines !== 'boolean') GanttView._epicsShowLines = true;

    const esc = Utils.escapeHtml;
    const toPipeList = (v) => {
      if (Array.isArray(v)) return v.map(x => String(x).trim()).filter(Boolean);
      return String(v || '').split('|').map(x => x.trim()).filter(Boolean);
    };
    const toDate = (v) => {
      if (!v) return null;
      const d = new Date(v);
      if (Number.isNaN(d.getTime())) return null;
      return new Date(d.getFullYear(), d.getMonth(), d.getDate());
    };
    const addDays = (d, n) => new Date(d.getTime() + n * 86400000);
    const fmtIso = (d) => d ? d.toISOString().slice(0, 10) : '';

    // Build epics from filtered rows.
    const hasEpicData = rows.some(r => String(r.epic || '').trim());
    const epicMap = {};
    rows.forEach(row => {
      const key = hasEpicData ? (String(row.epic || '').trim() || '(без эпика)') : (String(row.category || row.tasks || '').trim() || '(без эпика)');
      if (!epicMap[key]) epicMap[key] = [];
      epicMap[key].push(row);
    });
    const epics = Object.keys(epicMap).sort((a, b) => a.localeCompare(b, 'ru'));

    // Aggregate per epic (phases, bounds, assignees, roles, blockers).
    const epicInfo = {};
    epics.forEach(name => {
      const erows = epicMap[name];
      const phases = {};
      const assignees = new Set();
      const roles = new Set();
      const periodStarts = [];
      const periodEnds = [];

      erows.forEach(r => {
        toPipeList(r.assignee).forEach(v => assignees.add(v));
        toPipeList(r.role).forEach(v => roles.add(v));
        const ws = toDate(r.workPeriodStart);
        const we = toDate(r.workPeriodEnd);
        if (ws) periodStarts.push(ws);
        if (we) periodEnds.push(we);

        GANTT_RELEASE_WINDOWS.forEach(rw => {
          const types = toPipeList(r[rw.tf]);
          if (!types.length) return;
          if (!phases[rw.key]) phases[rw.key] = { types: new Set(), startOverride: null, endOverride: null };
          types.forEach(t => phases[rw.key].types.add(t));
        });
      });

      if (phases.ot) {
        const otStart = periodStarts.length ? new Date(Math.min(...periodStarts.map(d => d.getTime()))) : null;
        const otEnd = periodEnds.length ? new Date(Math.max(...periodEnds.map(d => d.getTime()))) : null;
        if (otStart) phases.ot.startOverride = otStart;
        if (otEnd) phases.ot.endOverride = otEnd;
      }

      const phaseBounds = (rwKey) => {
        const rw = GANTT_RELEASE_WINDOWS.find(x => x.key === rwKey);
        const ph = phases[rwKey];
        if (!rw || !ph) return null;
        const start = rwKey === 'ot' ? ph.startOverride : rw.start;
        const end = rwKey === 'ot' ? ph.endOverride : rw.end;
        if (!start || !end) return null;
        return { start, end };
      };

      let epicStart = null;
      let epicEnd = null;
      GANTT_RELEASE_WINDOWS.forEach(rw => {
        const b = phaseBounds(rw.key);
        if (!b) return;
        if (!epicStart || b.start < epicStart) epicStart = b.start;
        if (!epicEnd || b.end > epicEnd) epicEnd = b.end;
      });

      const periodStart = periodStarts.length ? new Date(Math.min(...periodStarts.map(d => d.getTime()))) : null;
      const periodEnd = periodEnds.length ? new Date(Math.max(...periodEnds.map(d => d.getTime()))) : null;
      const periodText = periodStart && periodEnd ? `${fmtIso(periodStart)} — ${fmtIso(periodEnd)}` : (periodStart ? fmtIso(periodStart) : (periodEnd ? fmtIso(periodEnd) : '—'));

      epicInfo[name] = {
        phases,
        start: epicStart,
        end: epicEnd,
        hasBlocking: erows.some(r => !!r.blockingDependency),
        assignees: [...assignees].sort((a, b) => a.localeCompare(b, 'ru')),
        roles: [...roles].sort((a, b) => a.localeCompare(b, 'ru')),
        periodText,
        count: erows.length,
      };
    });

    // Dependencies: one predecessor per epic (as in current data model), with off-track detection.
    const depItems = Object.entries(state.epicDeps || {})
      .map(([targetEpic, sourceEpic]) => ({ targetEpic: String(targetEpic || '').trim(), sourceEpic: String(sourceEpic || '').trim() }))
      .filter(d => d.targetEpic && d.sourceEpic && d.targetEpic !== d.sourceEpic && epicInfo[d.targetEpic] && epicInfo[d.sourceEpic])
      .map(d => {
        const sourceInfo = epicInfo[d.sourceEpic];
        const targetInfo = epicInfo[d.targetEpic];
        const offTrack = !!(sourceInfo.end && targetInfo.start && targetInfo.start < sourceInfo.end);
        return { ...d, offTrack };
      })
      .sort((a, b) => (a.targetEpic.localeCompare(b.targetEpic, 'ru') || a.sourceEpic.localeCompare(b.sourceEpic, 'ru')));

    const incomingFromMap = {};
    const outgoingToMap = {};
    const incomingOffTrackMap = {};
    depItems.forEach(d => {
      incomingFromMap[d.targetEpic] = d.sourceEpic;
      incomingOffTrackMap[d.targetEpic] = d.offTrack;
      if (!outgoingToMap[d.sourceEpic]) outgoingToMap[d.sourceEpic] = [];
      outgoingToMap[d.sourceEpic].push(d.targetEpic);
    });
    const offTrackCount = depItems.filter(d => d.offTrack).length;

    // Group rows by "wells".
    const groupBy = state.ganttEpicsWell;
    let groups = [];
    if (groupBy === 'role' || groupBy === 'assignee') {
      const groupMap = {};
      epics.forEach(name => {
        const src = groupBy === 'role' ? epicInfo[name].roles : epicInfo[name].assignees;
        const key = src.length ? src.join(', ') : (groupBy === 'role' ? '(без роли)' : '(без исполнителя)');
        if (!groupMap[key]) groupMap[key] = [];
        groupMap[key].push(name);
      });
      groups = Object.entries(groupMap)
        .sort((a, b) => a[0].localeCompare(b[0], 'ru'))
        .map(([label, eps]) => ({ label, epics: eps.sort((a, b) => a.localeCompare(b, 'ru')) }));
    } else {
      groups = [{ label: null, epics }];
    }

    // Timeline sizing and date range.
    let minBound = null;
    let maxBound = null;
    epics.forEach(name => {
      const info = epicInfo[name];
      if (info.start && (!minBound || info.start < minBound)) minBound = info.start;
      if (info.end && (!maxBound || info.end > maxBound)) maxBound = info.end;
    });
    if (!minBound || !maxBound) {
      minBound = new Date(GANTT_TIMELINE_START);
      maxBound = new Date(GANTT_TIMELINE_END);
    }
    const tStartDate = new Date(minBound.getFullYear(), minBound.getMonth(), 1);
    const tEndDate = new Date(maxBound.getFullYear(), maxBound.getMonth() + 1, 1);
    const tStartMs = tStartDate.getTime();
    const tEndMs = tEndDate.getTime();
    const totalDays = Math.max(1, Math.ceil((tEndMs - tStartMs) / 86400000));

    const wrapW = Math.max(1000, wrap.clientWidth || 0);
    const LEFT_W = Math.max(250, Math.min(360, Math.round(wrapW * 0.24)));
    const DEP_W = 84;
    const timelineMinW = Math.round(totalDays * GANTT_DAY_PX);
    const totalW = Math.max(timelineMinW, wrapW - LEFT_W - DEP_W - 6);
    const dayPx = totalW / totalDays;

    const dayOffset = (date) => Math.max(0, Math.min(totalW, Math.round((date.getTime() - tStartMs) / 86400000 * dayPx)));
    const dayWidth = (d1, d2) => {
      const span = Math.max(0, Math.round((d2.getTime() - d1.getTime()) / 86400000));
      return Math.max(10, Math.round((span + 1) * dayPx));
    };

    // Header months.
    let monthHeaderHtml = '';
    for (let d = new Date(tStartDate); d < tEndDate; d = new Date(d.getFullYear(), d.getMonth() + 1, 1)) {
      const next = new Date(d.getFullYear(), d.getMonth() + 1, 1);
      const x = dayOffset(d);
      const w = Math.max(1, dayOffset(next) - x);
      monthHeaderHtml += `<div class="gtx-month-cell" style="left:${x}px;width:${w}px">${esc(d.toLocaleString('ru', { month: 'short', year: '2-digit' }))}</div>`;
    }

    // Build rows and geometry.
    const ROW_H = 42;
    const GROUP_H = 28;
    let rowsHtml = '';
    let topOffset = 0;
    const epicGeometry = {};

    const phaseBounds = (ph, rw) => {
      if (!ph) return null;
      const start = rw.key === 'ot' ? ph.startOverride : rw.start;
      const end = rw.key === 'ot' ? ph.endOverride : rw.end;
      if (!start || !end) return null;
      return { start, end };
    };

    groups.forEach(group => {
      if (group.label !== null) {
        rowsHtml += `<div class="gtx-group-row" style="height:${GROUP_H}px">
          <div class="gtx-group-cell" style="width:${LEFT_W}px">${esc(group.label)}</div>
          <div class="gtx-group-dep" style="width:${DEP_W}px"></div>
          <div class="gtx-group-time" style="width:${totalW}px"></div>
        </div>`;
        topOffset += GROUP_H;
      }

      group.epics.forEach(epicName => {
        const info = epicInfo[epicName];
        const assigneeText = info.assignees.join(', ') || '—';
        const depFrom = incomingFromMap[epicName] || '';
        const depOut = (outgoingToMap[epicName] || []).length;
        const incomingOffTrack = !!incomingOffTrackMap[epicName];

        let barsHtml = '';
        let rowBarLeft = Number.POSITIVE_INFINITY;
        let rowBarRight = Number.NEGATIVE_INFINITY;

        GANTT_RELEASE_WINDOWS.forEach(rw => {
          const ph = info.phases[rw.key];
          const b = phaseBounds(ph, rw);
          if (!b) return;
          const bx = dayOffset(b.start);
          const bw = dayWidth(b.start, b.end);
          rowBarLeft = Math.min(rowBarLeft, bx);
          rowBarRight = Math.max(rowBarRight, bx + bw);

          const ordered = PHASE_ORDER.filter(p => ph.types.has(p));
          const leftovers = [...ph.types].filter(p => !ordered.includes(p));
          const phaseList = [...ordered, ...leftovers];
          if (!phaseList.length) phaseList.push('backend');

          let segLeft = 0;
          const segBase = Math.max(1, Math.floor(bw / phaseList.length));
          let segs = '';
          phaseList.forEach((wt, i) => {
            const sw = i === phaseList.length - 1 ? Math.max(1, bw - segLeft) : segBase;
            const label = sw >= 34 ? (PHASE_SHORT[wt] || Utils.truncate(wt, 9)) : '';
            segs += `<span class="gtx-seg" style="left:${segLeft}px;width:${sw}px;background:${PHASE_COLORS[wt] || '#6b7280'}">${esc(label)}</span>`;
            segLeft += sw;
          });
          barsHtml += `<div class="gtx-bar${info.hasBlocking ? ' gtx-bar-blocking' : ''}" style="left:${bx}px;width:${bw}px">${segs}</div>`;
        });

        if (!Number.isFinite(rowBarLeft)) {
          rowBarLeft = 8;
          rowBarRight = 8;
        }
        const hasBars = rowBarRight > rowBarLeft + 2;
        const handleX = Math.max(10, Math.min(totalW - 10, rowBarLeft + 10));
        const linkHandleHtml = `<button class="gtx-link-handle${hasBars ? '' : ' gtx-link-handle-empty'}" data-epic="${esc(epicName)}" style="left:${handleX}px" title="Протяните ◎ на другую задачу, чтобы создать зависимость">◎</button>`;

        const inChip = depFrom
          ? `<span class="gtx-chip gtx-chip-in${incomingOffTrack ? ' gtx-chip-off' : ''}" title="Зависит от ${esc(depFrom)}">← ${esc(Utils.truncate(depFrom, 14))}<button class="gtx-chip-remove" data-dep-remove="${esc(epicName)}" title="Удалить зависимость">×</button></span>`
          : '';
        const outChip = depOut ? `<span class="gtx-chip gtx-chip-out" title="Исходящих зависимостей: ${depOut}">→ ${depOut}</span>` : '';
        const warnChip = incomingOffTrack ? `<span class="gtx-chip gtx-chip-warn" title="Сроки в конфликте">Конфликт</span>` : '';

        const rowCls = ['gtx-row', info.hasBlocking ? 'gtx-row-blocking' : '', incomingOffTrack ? 'gtx-row-offtrack' : ''].filter(Boolean).join(' ');
        rowsHtml += `<div class="${rowCls}" style="height:${ROW_H}px" data-epic="${esc(epicName)}" title="Исполнитель: ${esc(assigneeText)}&#10;Период: ${esc(info.periodText)}">
          <div class="gtx-epic-cell" style="width:${LEFT_W}px">
            <div class="gtx-epic-name" title="${esc(epicName)}">${esc(epicName)}</div>
            <div class="gtx-epic-meta">${inChip}${outChip}${warnChip}<span class="gtx-count">${info.count}</span></div>
          </div>
          <div class="gtx-dep-cell" style="width:${DEP_W}px"></div>
          <div class="gtx-time-cell" style="width:${totalW}px">
            <div class="gtx-time-inner" style="width:${totalW}px">
              ${barsHtml}
              ${linkHandleHtml}
            </div>
          </div>
        </div>`;

        epicGeometry[epicName] = { y: topOffset + ROW_H / 2 };
        topOffset += ROW_H;
      });
    });

    const containerH = topOffset;
    const lastTimelineDay = addDays(tEndDate, -1);
    const bandColors = {
      r120: 'rgba(79,70,229,.06)',
      r121: 'rgba(5,150,105,.06)',
      r122: 'rgba(217,119,6,.06)',
      ot: 'rgba(220,38,38,.06)',
    };
    let bandsHtml = '';
    GANTT_RELEASE_WINDOWS.forEach(rw => {
      if (!rw.start || !rw.end) return;
      const visStart = rw.start < tStartDate ? tStartDate : rw.start;
      const visEnd = rw.end > lastTimelineDay ? lastTimelineDay : rw.end;
      if (visEnd < visStart) return;
      const x = dayOffset(visStart);
      const w = dayWidth(visStart, visEnd);
      bandsHtml += `<div class="gtx-band" style="left:${x}px;width:${w}px;background:${bandColors[rw.key] || 'transparent'}"></div>`;
      bandsHtml += `<div class="gtx-band-label" style="left:${x + 5}px">${esc(rw.label)}</div>`;
    });

    // Route dependency lines only in the dedicated dependency gutter (never through bars).
    const laneCount = Math.max(2, Math.floor((DEP_W - 18) / 8));
    const depPaths = depItems.map((d, idx) => {
      const src = epicGeometry[d.sourceEpic];
      const dst = epicGeometry[d.targetEpic];
      if (!src || !dst) return '';
      const laneX = LEFT_W + 8 + (idx % laneCount) * 8;
      const xStart = LEFT_W + DEP_W - 5;
      const xEnd = LEFT_W + DEP_W - 12;
      const stroke = d.offTrack ? '#dc2626' : '#6366f1';
      const marker = d.offTrack ? 'url(#gtx-arr-red)' : 'url(#gtx-arr-indigo)';
      return `<path d="M${xStart},${src.y} L${laneX},${src.y} L${laneX},${dst.y} L${xEnd},${dst.y}" stroke="${stroke}" stroke-width="${d.offTrack ? 2.1 : 1.7}" stroke-linecap="round" stroke-linejoin="round" fill="none" marker-end="${marker}" opacity=".9"/>`;
    }).join('');

    const depsListHtml = depItems.length
      ? depItems.map(d => `<div class="gtx-dep-item${d.offTrack ? ' offtrack' : ''}">
          <button class="gtx-dep-focus" data-dep-focus-from="${esc(d.sourceEpic)}" data-dep-focus-to="${esc(d.targetEpic)}">${esc(Utils.truncate(d.sourceEpic, 18))} → ${esc(Utils.truncate(d.targetEpic, 18))}</button>
          ${d.offTrack ? '<span class="gtx-dep-state">конфликт</span>' : ''}
          <button class="gtx-dep-remove" data-dep-remove="${esc(d.targetEpic)}" title="Удалить зависимость">×</button>
        </div>`).join('')
      : '<span class="text-muted text-sm">Пока нет зависимостей. Протяните ◎ с одной задачи на другую.</span>';

    wrap.innerHTML = `<div class="gtx-shell" style="--gtx-left:${LEFT_W}px;--gtx-dep:${DEP_W}px">
      <div class="gtx-deps-panel">
        <div class="gtx-deps-summary">
          <span class="gtx-pill">Связей: ${depItems.length}</span>
          <span class="gtx-pill${offTrackCount ? ' gtx-pill-danger' : ''}">Конфликтов: ${offTrackCount}</span>
        </div>
        <label class="gtx-lines-toggle"><input type="checkbox" id="gtx-show-lines"${GanttView._epicsShowLines ? ' checked' : ''}> Линии связей</label>
        <div class="gtx-deps-hint">Протяните ◎ с задачи на задачу. Сроки задач не меняются автоматически.</div>
        <div class="gtx-deps-list">${depsListHtml}</div>
      </div>

      <div class="gtx-grid" style="min-width:${LEFT_W + DEP_W + totalW}px">
        <div class="gtx-head">
          <div class="gtx-head-epic" style="width:${LEFT_W}px">Эпик</div>
          <div class="gtx-head-dep" style="width:${DEP_W}px">Связи</div>
          <div class="gtx-head-time" style="width:${totalW}px">
            <div class="gtx-month-track" style="width:${totalW}px">${monthHeaderHtml}</div>
          </div>
        </div>
        <div class="gtx-body" style="height:${containerH}px">
          <div class="gtx-time-bands" style="left:${LEFT_W + DEP_W}px;width:${totalW}px;height:${containerH}px">${bandsHtml}</div>
          <div class="gtx-rows">${rowsHtml}</div>
          <svg class="gtx-dep-svg" style="width:${LEFT_W + DEP_W + totalW}px;height:${containerH}px" viewBox="0 0 ${LEFT_W + DEP_W + totalW} ${containerH}">
            <defs>
              <marker id="gtx-arr-indigo" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto"><path d="M0,0 L0,7 L7,3.5 z" fill="#4f46e5"/></marker>
              <marker id="gtx-arr-red" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto"><path d="M0,0 L0,7 L7,3.5 z" fill="#dc2626"/></marker>
            </defs>
            ${GanttView._epicsShowLines ? depPaths : ''}
          </svg>
        </div>
      </div>
    </div>`;

    // Panel interactions.
    const showLinesInput = wrap.querySelector('#gtx-show-lines');
    if (showLinesInput) {
      showLinesInput.addEventListener('change', (e) => {
        GanttView._epicsShowLines = !!e.target.checked;
        GanttView.renderChart();
      });
    }

    wrap.querySelectorAll('[data-dep-remove]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const toEpic = btn.dataset.depRemove || '';
        if (!toEpic || !state.epicDeps[toEpic]) return;
        delete state.epicDeps[toEpic];
        Storage.save();
        GanttView.renderChart();
      });
    });

    wrap.querySelectorAll('[data-dep-focus-from][data-dep-focus-to]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const from = btn.dataset.depFocusFrom || '';
        const to = btn.dataset.depFocusTo || '';
        const allRows = [...wrap.querySelectorAll('.gtx-row')];
        const fromRow = allRows.find(r => r.dataset.epic === from);
        const toRow = allRows.find(r => r.dataset.epic === to);
        allRows.forEach(r => r.classList.remove('gtx-row-focus'));
        if (fromRow) fromRow.classList.add('gtx-row-focus');
        if (toRow) toRow.classList.add('gtx-row-focus');
        if (toRow && toRow.scrollIntoView) toRow.scrollIntoView({ block: 'center', behavior: 'smooth' });
        setTimeout(() => allRows.forEach(r => r.classList.remove('gtx-row-focus')), 1400);
      });
    });

    // Drag-to-link (from ◎ to target row). Creates dependency only, no date changes.
    let depDrag = null;
    let depGhostSvg = null;
    let depGhostPath = null;
    let depDropRow = null;

    const onBlur = () => clearDepDrag();
    const clearDepDrag = () => {
      if (depGhostSvg) depGhostSvg.remove();
      if (depDropRow) depDropRow.classList.remove('gtx-row-drop');
      depDrag = null;
      depGhostSvg = null;
      depGhostPath = null;
      depDropRow = null;
      document.removeEventListener('mousemove', onDepMouseMove);
      document.removeEventListener('mouseup', onDepMouseUp);
      document.removeEventListener('keydown', onDepKeyDown);
      window.removeEventListener('blur', onBlur);
    };
    GanttView._cancelTransientInteractions=clearDepDrag;
    const getRowAtPoint = (x, y) => {
      const el = document.elementFromPoint(x, y);
      if (!el || !el.closest) return null;
      return el.closest('#gantt-wrap .gtx-row');
    };
    const drawGhost = (x1, y1, x2, y2) => {
      if (!depGhostPath) return;
      const elbowX = Math.min(window.innerWidth - 10, Math.max(x1, x2) + 36);
      depGhostPath.setAttribute('d', `M${x1},${y1} L${elbowX},${y1} L${elbowX},${y2} L${x2},${y2}`);
    };
    const onDepMouseMove = (e) => {
      if (!depDrag) return;
      drawGhost(depDrag.x1, depDrag.y1, e.clientX, e.clientY);
      const row = getRowAtPoint(e.clientX, e.clientY);
      const valid = row && row.dataset.epic && row.dataset.epic !== depDrag.fromEpic ? row : null;
      if (depDropRow && depDropRow !== valid) depDropRow.classList.remove('gtx-row-drop');
      if (valid && depDropRow !== valid) valid.classList.add('gtx-row-drop');
      depDropRow = valid;
    };
    const onDepMouseUp = (e) => {
      if (!depDrag) return;
      const row = getRowAtPoint(e.clientX, e.clientY);
      const targetEpic = row ? (row.dataset.epic || '') : '';
      const fromEpic = depDrag.fromEpic;
      clearDepDrag();
      if (!targetEpic || !fromEpic || targetEpic === fromEpic) return;
      state.epicDeps[targetEpic] = fromEpic;
      Storage.save();
      GanttView.renderChart();
      showToast(`Связь: ${targetEpic} зависит от ${fromEpic}`);
    };
    const onDepKeyDown = (e) => {
      if (e.key === 'Escape') clearDepDrag();
    };

    wrap.querySelectorAll('.gtx-link-handle').forEach(handle => {
      handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        clearDepDrag();
        const row = handle.closest('.gtx-row');
        if (!row) return;
        depDrag = { fromEpic: row.dataset.epic, x1: e.clientX, y1: e.clientY };

        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('class', 'gtx-link-ghost');
        svg.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:9800;';
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('stroke', '#4f46e5');
        path.setAttribute('stroke-width', '2');
        path.setAttribute('stroke-linecap', 'round');
        path.setAttribute('stroke-linejoin', 'round');
        path.setAttribute('stroke-dasharray', '6 4');
        path.setAttribute('fill', 'none');
        path.setAttribute('opacity', '0.9');
        svg.appendChild(path);
        document.body.appendChild(svg);
        depGhostSvg = svg;
        depGhostPath = path;
        drawGhost(e.clientX, e.clientY, e.clientX, e.clientY);

        document.addEventListener('mousemove', onDepMouseMove);
        document.addEventListener('mouseup', onDepMouseUp);
        document.addEventListener('keydown', onDepKeyDown);
        window.addEventListener('blur', onBlur);
      });
    });
  },
};

// ============================================================
// KANBAN VIEW  (with drag & drop)
// ============================================================
const KanbanView = {
  _drag: { rowId:null, sourceCol:null },
  render() {
    const filtered=FilterEngine.getFiltered();
    const board=document.getElementById('kanban-board');
    const columns=[
      {key:'backlog',  label:'Без релиза', filter:r=>r.isUnassigned,  tfGet:null,          tfSet:null},
      {key:'r120',     label:'Релиз 1.20', filter:r=>r.hasRelease120, tfGet:'release120Types', tfSet:'release120Types'},
      {key:'r121',     label:'Релиз 1.21', filter:r=>r.hasRelease121, tfGet:'release121Types', tfSet:'release121Types'},
      {key:'r122',     label:'Релиз 1.22', filter:r=>r.hasRelease122, tfGet:'release122Types', tfSet:'release122Types'},
      {key:'overtime', label:'Овертайм',   filter:r=>r.hasOvertime,   tfGet:'overtimeTypes',  tfSet:'overtimeTypes'},
    ];
    const allTFFields=['release120Types','release121Types','release122Types','overtimeTypes'];

    board.innerHTML='';
    columns.forEach(col=>{
      const colRows=filtered.filter(col.filter);
      const colEl=document.createElement('div'); colEl.className='kanban-col'; colEl.dataset.colKey=col.key;

      colEl.innerHTML=`<div class="kanban-col-header"><span>${col.label}</span><span class="kanban-col-header-badge">${colRows.length}</span></div>`;
      const body=document.createElement('div'); body.className='kanban-col-body';

      // Drop target
      body.addEventListener('dragover',e=>{ e.preventDefault(); body.classList.add('drag-over'); colEl.classList.add('drag-target'); });
      body.addEventListener('dragleave',()=>{ body.classList.remove('drag-over'); colEl.classList.remove('drag-target'); });
      body.addEventListener('drop',e=>{
        e.preventDefault(); body.classList.remove('drag-over'); colEl.classList.remove('drag-target');
        const {rowId,sourceCol}=KanbanView._drag;
        if (!rowId||sourceCol===col.key) return;
        const row=state.rows.find(r=>r.id===rowId); if(!row) return;
        if (col.key==='backlog') {
          // Remove from source release only
          if (sourceCol!=='backlog'&&columns.find(c=>c.key===sourceCol)?.tfSet) {
            row[columns.find(c=>c.key===sourceCol).tfSet]=[];
          }
        } else {
          const targetField=col.tfSet;
          if (sourceCol==='backlog') {
            if (!(row[targetField]||[]).length) row[targetField]=['backend'];
          } else {
            const srcField=columns.find(c=>c.key===sourceCol)?.tfSet;
            const srcTypes=(srcField&&row[srcField])||[];
            row[targetField]=srcTypes.length?[...srcTypes]:['backend'];
            if (srcField) row[srcField]=[];
          }
        }
        row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row); Storage.save(); KanbanView.render();
      });

      colRows.slice(0,100).forEach((row,ci)=>{
        let borderCls='';
        if(row.blockingDependency)borderCls='card-blocking';
        else if(row.riskFlags&&row.riskFlags.length)borderCls='card-risky';
        if(row.isDone)borderCls+=' card-done';
        const types=(col.tfGet?row[col.tfGet]:[])||[];

        const card=document.createElement('div');
        card.className=`kanban-card ${borderCls}`;
        card.style.setProperty('--i', ci);
        card.draggable=true;
        card.dataset.rowId=row.id;
        card.innerHTML=`
          <div class="kanban-card-team">${row.team}</div>
          <div class="kanban-card-epic">${Utils.truncate(row.epic,40)}</div>
          <div class="kanban-card-task"><div class="tasks-cell">${RH.jiraTagsHtml(row.tasks)}</div></div>
          <div class="kanban-card-meta">
            ${RH.scopeChip(row.scopeStatus)}
            ${types.length?RH.workTypeChips(types):''}
            ${row.role?`<span class="chip chip-indigo">${Utils.truncate(row.role,20)}</span>`:''}
            ${row.blockingDependency?`<span class="chip chip-red">🚧${row.blockingDeadline?' до '+row.blockingDeadline:''}</span>`:''}
            ${RH.riskBadges(row.riskFlags)}${RH.doneBadge(row.isDone)}
          </div>`;
        card.addEventListener('dragstart',e=>{
          KanbanView._drag={rowId:row.id,sourceCol:col.key};
          card.classList.add('dragging'); e.dataTransfer.effectAllowed='move';
        });
        card.addEventListener('dragend',()=>card.classList.remove('dragging'));
        body.appendChild(card);
      });
      if (colRows.length>100) { const more=document.createElement('div'); more.style.cssText='padding:8px;font-size:11px;color:var(--text-4)'; more.textContent=`...ещё ${colRows.length-100}`; body.appendChild(more); }
      colEl.appendChild(body); board.appendChild(colEl);
    });
  },
};

// ============================================================
// TIMELINE VIEW
// ============================================================
const TimelineView = {
  render() {
    if (state.timelineMode==='detailed') TimelineView.renderDetailed();
    else TimelineView.renderSummary();
  },
  _stages() {
    return [
      {key:'backlog',  label:'Бэклог',    dates:'',            stageCls:'stage-backlog',  filter:r=>r.isUnassigned,  tf:null},
      {key:'r120',     label:'1.20',       dates:'20.04–17.05', stageCls:'stage-r120',     filter:r=>r.hasRelease120, tf:'release120Types'},
      {key:'r121',     label:'1.21',       dates:'18.05–14.06', stageCls:'stage-r121',     filter:r=>r.hasRelease121, tf:'release121Types'},
      {key:'r122',     label:'1.22',       dates:'15.06–14.07', stageCls:'stage-r122',     filter:r=>r.hasRelease122, tf:'release122Types'},
      {key:'overtime', label:'OT',         dates:'Овертайм',    stageCls:'stage-overtime', filter:r=>r.hasOvertime,   tf:'overtimeTypes'},
    ];
  },
  _wtColors:{
    'backend':'#3b82f6','frontend':'#22c55e','тестирование':'#a855f7',
    'аналитика':'#f97316','бизнес аналитика':'#fb923c','внедрение':'#06b6d4',
    'миграция данных':'#84cc16','стабилизация':'#64748b','хотфикс':'#ef4444',
  },
  renderSummary() {
    const filtered=FilterEngine.getFiltered();
    const stages=TimelineView._stages();
    const stageData=stages.map(s=>{
      const rows=filtered.filter(s.filter), count=rows.length;
      const wtMap={},scMap={'Да':0,'Нет':0,'Требует подтверждения':0},doneCount=rows.filter(r=>r.isDone).length;
      rows.forEach(r=>{if(s.tf)(r[s.tf]||[]).forEach(t=>{wtMap[t]=(wtMap[t]||0)+1;});if(r.scopeStatus in scMap)scMap[r.scopeStatus]++;});
      return{...s,count,wtMap,scMap,doneCount};
    });
    const maxC=Math.max(...stageData.map(s=>s.count),1);
    const allWt=Utils.unique(stageData.flatMap(s=>Object.keys(s.wtMap)));
    const wc=TimelineView._wtColors;

    const countSection=`<div class="timeline-section"><div class="timeline-section-title">Количество задач по стадиям</div>
      <div class="timeline-stages">${stageData.map(s=>`
        <div class="timeline-stage">
          <div class="timeline-stage-header ${s.stageCls}">${s.label}<br><span style="font-size:10px;font-weight:400">${s.dates}</span></div>
          <div class="timeline-stage-body">
            <div class="timeline-stat">${s.count}</div>
            <div class="timeline-stat-sub">задач${s.doneCount?` / ${s.doneCount} ✅`:''}</div>
            <div style="height:6px;background:var(--border-light);border-radius:3px;margin-top:8px;overflow:hidden">
              <div class="${s.stageCls}" style="height:100%;width:${s.count/maxC*100}%;background:currentColor;border-radius:3px"></div>
            </div>
          </div></div>`).join('')}</div></div>`;

    const wtSection=allWt.length?`<div class="timeline-section"><div class="timeline-section-title">По типу работ</div>
      ${stageData.map(s=>{const tot=Object.values(s.wtMap).reduce((a,b)=>a+b,0)||1;
        return`<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
          <div style="width:120px;font-size:11px;font-weight:600;color:var(--text-3);text-align:right;flex-shrink:0">${s.label}</div>
          <div class="timeline-bar-wrap" style="flex:1">${allWt.map(wt=>{const c=s.wtMap[wt]||0;if(!c)return'';return`<div class="timeline-bar-seg" title="${wt}:${c}" style="width:${c/tot*100}%;background:${wc[wt]||'#888'}"></div>`;}).join('')}</div>
          <div style="width:30px;font-size:11px;color:var(--text-3)">${s.count}</div></div>`;}).join('')}
      <div class="timeline-legend">${allWt.map(wt=>`<div class="legend-item"><div class="legend-dot" style="background:${wc[wt]||'#888'}"></div>${wt}</div>`).join('')}</div></div>`:'' ;

    const scopeSection=`<div class="timeline-section"><div class="timeline-section-title">По статусу Scope</div>
      ${stageData.map(s=>{const tot=s.count||1;
        return`<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
          <div style="width:120px;font-size:11px;font-weight:600;color:var(--text-3);text-align:right;flex-shrink:0">${s.label}</div>
          <div class="timeline-bar-wrap" style="flex:1">
            ${[['Да','#059669'],['Нет','#9ca3af'],['Требует подтверждения','#d97706']].map(([sc,cl])=>{const c=s.scMap[sc]||0;if(!c)return'';return`<div class="timeline-bar-seg" title="${sc}:${c}" style="width:${c/tot*100}%;background:${cl}"></div>`;}).join('')}
          </div>
          <div style="width:30px;font-size:11px;color:var(--text-3)">${s.count}</div></div>`;}).join('')}
      <div class="timeline-legend"><div class="legend-item"><div class="legend-dot" style="background:#059669"></div>Да</div><div class="legend-item"><div class="legend-dot" style="background:#9ca3af"></div>Нет</div><div class="legend-item"><div class="legend-dot" style="background:#d97706"></div>Треб.</div></div></div>`;

    document.getElementById('timeline-wrap').innerHTML=countSection+wtSection+scopeSection;
  },
  renderDetailed() {
    const filtered=FilterEngine.getFiltered();
    const stages=TimelineView._stages();
    const teams=Utils.unique(filtered.map(r=>r.team));
    const wc=TimelineView._wtColors;
    if (!teams.length) { document.getElementById('timeline-wrap').innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>'; return; }

    const html=stages.map(stage=>{
      const stageRows=filtered.filter(stage.filter);
      const maxTeamCount=Math.max(...teams.map(t=>stageRows.filter(r=>r.team===t).length),1);
      const teamRows=teams.map(team=>{
        const tr=stageRows.filter(r=>r.team===team), cnt=tr.length;
        if(!cnt)return`<div class="timeline-team-row"><div class="timeline-team-label">${Utils.truncate(team,18)}</div><div class="timeline-team-bars"><div class="timeline-team-bar-cell"><div class="timeline-team-bar-inner"><div style="width:100%;background:var(--border-light);height:100%"></div></div></div></div><div class="timeline-team-count">—</div></div>`;
        // Work type breakdown
        const wtMap={}; if(stage.tf)tr.forEach(r=>(r[stage.tf]||[]).forEach(t=>{wtMap[t]=(wtMap[t]||0)+1;}));
        const tot=Object.values(wtMap).reduce((a,b)=>a+b,0)||1;
        const segs=Object.entries(wtMap).map(([wt,c])=>`<div class="timeline-bar-seg" title="${wt}:${c}" style="width:${c/tot*100}%;background:${wc[wt]||'#888'}"></div>`).join('');
        const done=tr.filter(r=>r.isDone).length;
        const barW=cnt/maxTeamCount*100;
        return`<div class="timeline-team-row">
          <div class="timeline-team-label">${Utils.truncate(team,18)}</div>
          <div class="timeline-team-bars"><div class="timeline-team-bar-cell" style="position:relative">
            <div style="width:${barW}%;min-width:${cnt?'4px':'0'}">
              <div class="timeline-team-bar-inner">${segs||`<div style="width:100%;background:#d1d5db;height:100%"></div>`}</div>
            </div>
          </div></div>
          <div class="timeline-team-count">${cnt}${done?` / ${done}✅`:''}</div></div>`;
      }).join('');
      return`<div class="timeline-section"><div class="timeline-section-title" style="display:flex;gap:8px;align-items:center">
        <span class="chip ${stage.stageCls}" style="font-size:13px;padding:4px 10px">${stage.label}</span>
        ${stage.dates} — ${stageRows.length} задач
      </div>${teamRows||'<div style="color:var(--text-3);font-size:12px">Нет задач в этой стадии</div>'}</div>`;
    }).join('');
    document.getElementById('timeline-wrap').innerHTML=html;
  },
};

// ============================================================
// PODLOZHKA VIEW (read-only)
// ============================================================
const PodlozhkaView = {
  render() {
    const filtered=FilterEngine.getFiltered();
    const groupBy=state.podlozhkaGroup;
    const badge=document.getElementById('podlozhka-badge');
    badge.textContent=`${filtered.length} задач`;
    const wrap=document.getElementById('podlozhka-wrap');
    if (!filtered.length) { wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📂</div><div class="empty-title">Нет данных</div></div>'; return; }

    // Group rows
    let groups={};
    if (groupBy==='none') { groups={'Все задачи':filtered}; }
    else {
      filtered.forEach(r=>{
        const key=groupBy==='team'?r.team:groupBy==='epic'?r.epic:groupBy==='scope'?r.scopeStatus||'—':'—';
        if (!groups[key||'—']) groups[key||'—']=[];
        groups[key||'—'].push(r);
      });
    }

    const tableHtml=(rows)=>{
      if (state.podlozhkaMode==='detailed') {
        const cols=RegistryView.getVisibleCols();
        const headers=cols.map(c=>state.colLabels[c.key]||c.label);
        const format=(r,c)=>{
          const v=r[c.key];
          if (c.key==='tasks') return `<div class="pod-tasks">${RH.jiraTagsHtml(v||'')}</div>`;
          if (Array.isArray(v)) return v.length?v.join(', '):'—';
          if (typeof v==='boolean') return v?'Да':'Нет';
          if (c.type==='scope') return RH.scopeChip(v);
          if (c.type==='multiselect') return RH.workTypeChips(v||[]);
          if (c.key==='isDone') return r.isDone?`<span class="chip chip-done">✅${r.doneDate?' '+r.doneDate:''}</span>`:'—';
          if (c.key==='blockingDependency') return r.blockingDependency?`<span class="chip chip-red">🚧${r.blockingDeadline?' '+r.blockingDeadline:''}</span>`:'—';
          return Utils.escapeHtml(String(v==null||v===''?'—':v));
        };
        return `<div style="overflow-x:auto"><table class="podlozhka-table">
          <thead><tr>${headers.map(h=>`<th>${Utils.escapeHtml(h)}</th>`).join('')}<th>Риски</th></tr></thead>
          <tbody>${rows.map(r=>{
            const riskCls=r.riskFlags&&r.riskFlags.length?' pod-risky':'';
            const doneCls=r.isDone?' pod-done':'';
            return `<tr class="${riskCls}${doneCls}">${cols.map(c=>`<td>${format(r,c)}</td>`).join('')}<td>${RH.riskBadges(r.riskFlags)||'—'}</td></tr>`;
          }).join('')}</tbody>
        </table></div>`;
      }
      return `<div style="overflow-x:auto"><table class="podlozhka-table">
        <thead><tr><th>Эпик</th><th>Задачи</th><th>Scope</th><th>Релизы</th><th>Тип работ</th><th>Роль</th><th>Риски</th><th>Блокер</th><th>Сделано</th><th>Комментарий</th></tr></thead>
        <tbody>${rows.map(r=>{
          const allTypes=[...r.release120Types,...r.release121Types,...r.release122Types,...r.overtimeTypes];
          const riskCls=r.riskFlags&&r.riskFlags.length?' pod-risky':'';
          const doneCls=r.isDone?' pod-done':'';
          return`<tr class="${riskCls}${doneCls}">
            <td style="font-weight:600;min-width:140px">${r.epic||'—'}</td>
            <td style="min-width:200px"><div class="pod-tasks">${RH.jiraTagsHtml(r.tasks)}</div></td>
            <td>${RH.scopeChip(r.scopeStatus)}</td>
            <td><div class="pod-release-chips">${RH.releaseChips(r)}</div></td>
            <td>${allTypes.length?RH.workTypeChips(allTypes):'—'}</td>
            <td>${r.role?`<span class="chip chip-indigo">${Utils.truncate(r.role,20)}</span>`:'—'}</td>
            <td>${RH.riskBadges(r.riskFlags)||'—'}</td>
            <td>${r.blockingDependency?`<span class="chip chip-red">🚧${r.blockingDeadline?' '+r.blockingDeadline:''}</span>`:'—'}</td>
            <td>${r.isDone?`<span class="chip chip-done">✅${r.doneDate?' '+r.doneDate:''}</span>`:'—'}</td>
            <td style="max-width:200px;color:var(--text-3)">${Utils.truncate(r.comment,60)||'—'}</td>
          </tr>`;
        }).join('')}</tbody>
      </table></div>`;
    };

    wrap.innerHTML=Object.entries(groups).map(([groupKey,rows])=>{
      const doneCount=rows.filter(r=>r.isDone).length;
      const blockers=rows.filter(r=>r.blockingDependency).length;
      const risky=rows.filter(r=>r.riskFlags&&r.riskFlags.length).length;
      return`<div class="podlozhka-group">
        <div class="podlozhka-group-header">
          <div class="podlozhka-group-title">${groupKey}</div>
          <div class="podlozhka-group-meta">
            <span>${rows.length} задач</span>
            ${doneCount?`<span>✅ ${doneCount}</span>`:''}
            ${blockers?`<span>🚧 ${blockers}</span>`:''}
            ${risky?`<span>⚠ ${risky}</span>`:''}
          </div>
        </div>
        ${tableHtml(rows)}</div>`;
    }).join('');
  },
};

// ============================================================
// EMPLOYEES VIEW
// ============================================================
const EmployeesView = {
  _expanded: {},
  _cleanups: [],
  cleanup() {
    EmployeesView._cleanups.forEach(fn=>{ try{ fn(); } catch(e){} });
    EmployeesView._cleanups=[];
  },
  _splitTags(raw) {
    return String(raw||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
  },
  getTasksForEmployee(fio) {
    const name=String(fio||'').trim();
    if (!name) return [];
    return state.rows.filter(row=>{
      const assignees=EmployeesView._splitTags(row.assignee);
      return assignees.includes(name);
    });
  },
  render() {
    EmployeesView.cleanup();
    const list=[...state.employees].sort((a,b)=>String(a.fio||'').localeCompare(String(b.fio||''),'ru'));
    const badge=document.getElementById('employees-count-badge');
    badge.textContent=`${list.length} сотрудников`;

    const taskLinks=list.reduce((acc,emp)=>acc+EmployeesView.getTasksForEmployee(emp.fio).length,0);
    const weekdayReady=list.filter(e=>e.weekdayReady).length;
    const withOtDays=list.filter(e=>Array.isArray(e.overtimeDays)&&e.overtimeDays.length).length;
    document.getElementById('employees-summary-cards').innerHTML=`
      <div class="kpi-card"><div class="kpi-label">Сотрудников</div><div class="kpi-value">${list.length}</div></div>
      <div class="kpi-card kpi-green"><div class="kpi-label">Готовы в будни</div><div class="kpi-value">${weekdayReady}</div></div>
      <div class="kpi-card kpi-red"><div class="kpi-label">С OT днями</div><div class="kpi-value">${withOtDays}</div></div>
      <div class="kpi-card kpi-blue"><div class="kpi-label">Связанных задач</div><div class="kpi-value">${taskLinks}</div></div>
    `;

    const wrap=document.getElementById('employees-table-wrap');
    if (!list.length) {
      wrap.innerHTML='<div class="empty-state"><div class="empty-icon">👥</div><div class="empty-title">Список сотрудников пуст</div><div class="empty-hint">Добавьте вручную или загрузите CSV/XLSX</div></div>';
      return;
    }

    const table=document.createElement('table');
    const load = computeLoad(state.rows);
    table.className='employees-table';
    table.innerHTML='<thead><tr><th>ФИО</th><th>Роль</th><th>Команда</th><th>Дни OT</th><th>Будни OT</th><th>Комментарий к будням</th><th>Нагрузка</th><th></th></tr></thead>';
    const tbody=document.createElement('tbody');

    list.forEach(emp=>{
      const tr=document.createElement('tr');

      // ФИО
      const fioTd=document.createElement('td');
      const fioInput=document.createElement('input');
      fioInput.className='cell-input';
      fioInput.type='text';
      fioInput.value=emp.fio||'';
      fioInput.placeholder='ФИО';
      fioInput.addEventListener('change',()=>{
        emp.fio=fioInput.value.trim();
        EmployeeFactory.normalize(emp);
        Storage.save();
        App.populateFilterDropdowns();
        EmployeesView.render();
      });
      fioTd.appendChild(fioInput);
      tr.appendChild(fioTd);

      // Роль (теги)
      const rolesTd=document.createElement('td');
      const rolesInput=createTagInput(EmployeesView._splitTags(emp.roles),(tags)=>{
        emp.roles=tags.join('|');
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      },()=>FilterEngine.getRoles());
      if (rolesInput._cleanup) EmployeesView._cleanups.push(()=>rolesInput._cleanup());
      rolesTd.appendChild(rolesInput);
      tr.appendChild(rolesTd);

      // Команда (теги)
      const teamsTd=document.createElement('td');
      const teamsInput=createTagInput(EmployeesView._splitTags(emp.teams),(tags)=>{
        emp.teams=tags.join('|');
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      },()=>FilterEngine.getTeams());
      if (teamsInput._cleanup) EmployeesView._cleanups.push(()=>teamsInput._cleanup());
      teamsTd.appendChild(teamsInput);
      tr.appendChild(teamsTd);

      // Дни OT (дата + мульти)
      const daysTd=document.createElement('td');
      const daysWrap=document.createElement('div');
      daysWrap.className='employee-date-wrap';
      const listWrap=document.createElement('div');
      listWrap.className='employee-date-list';
      (emp.overtimeDays||[]).forEach(d=>{
        const chip=document.createElement('span');
        chip.className='employee-date-chip';
        chip.innerHTML=`${Utils.escapeHtml(d)} <button type="button">×</button>`;
        chip.querySelector('button').addEventListener('click',()=>{
          emp.overtimeDays=(emp.overtimeDays||[]).filter(x=>x!==d);
          EmployeeFactory.normalize(emp);
          Storage.save();
          EmployeesView.render();
        });
        listWrap.appendChild(chip);
      });
      const addWrap=document.createElement('div');
      addWrap.className='employee-date-add';
      const dayInput=document.createElement('input');
      dayInput.type='date';
      dayInput.className='cell-input';
      dayInput.style.maxWidth='150px';
      const addBtn=document.createElement('button');
      addBtn.className='employee-act-btn';
      addBtn.textContent='+';
      addBtn.addEventListener('click',()=>{
        if (!dayInput.value) return;
        emp.overtimeDays=[...(emp.overtimeDays||[]),dayInput.value];
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      });
      addWrap.appendChild(dayInput);
      addWrap.appendChild(addBtn);
      daysWrap.appendChild(listWrap);
      daysWrap.appendChild(addWrap);
      daysTd.appendChild(daysWrap);
      tr.appendChild(daysTd);

      // Будни OT (checkbox)
      const wdTd=document.createElement('td');
      const wdCb=document.createElement('input');
      wdCb.type='checkbox';
      wdCb.checked=!!emp.weekdayReady;
      wdCb.addEventListener('change',()=>{
        emp.weekdayReady=wdCb.checked;
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      });
      wdTd.appendChild(wdCb);
      tr.appendChild(wdTd);

      // Комментарий к будням
      const wdCommentTd=document.createElement('td');
      const commentInput=createTagInput(EmployeesView._splitTags(emp.weekdayComment),(tags)=>{
        emp.weekdayComment=tags.join('|');
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      });
      if (commentInput._cleanup) EmployeesView._cleanups.push(()=>commentInput._cleanup());
      wdCommentTd.appendChild(commentInput);
      tr.appendChild(wdCommentTd);

      // Нагрузка (load per release + drilldown)
      const tasksTd=document.createElement('td');
      const empLoad = load[emp.fio] || { total:0, r120:0, r121:0, r122:0, ot:0 };
      const empTasks=EmployeesView.getTasksForEmployee(emp.fio);
      const isOverloaded = empLoad.total >= 6;
      const loadHtml = `
        <div class="emp-load-wrap ${isOverloaded?'emp-overloaded':''}">
          <span class="emp-load-total" title="Всего задач">${empLoad.total}${isOverloaded?' ⚠️':''}</span>
          <div class="emp-load-breakdown">
            ${empLoad.r120?`<span class="emp-load-chip r120">1.20:${empLoad.r120}</span>`:''}
            ${empLoad.r121?`<span class="emp-load-chip r121">1.21:${empLoad.r121}</span>`:''}
            ${empLoad.r122?`<span class="emp-load-chip r122">1.22:${empLoad.r122}</span>`:''}
            ${empLoad.ot?`<span class="emp-load-chip ot">OT:${empLoad.ot}</span>`:''}
          </div>
        </div>`;
      const drillBtn=document.createElement('button');
      drillBtn.className='employee-act-btn';
      drillBtn.innerHTML=loadHtml+`<span style="font-size:10px;opacity:.7;margin-left:4px">▼ ${empTasks.length}</span>`;
      drillBtn.addEventListener('click',()=>{
        EmployeesView._expanded[emp.id]=!EmployeesView._expanded[emp.id];
        EmployeesView.render();
      });
      tasksTd.appendChild(drillBtn);
      tr.appendChild(tasksTd);

      // Actions
      const actTd=document.createElement('td');
      const delBtn=document.createElement('button');
      delBtn.className='employee-act-btn';
      delBtn.textContent='✕';
      delBtn.title='Удалить сотрудника';
      delBtn.addEventListener('click',()=>{
        if (!confirm(`Удалить сотрудника "${emp.fio||'без имени'}"?`)) return;
        state.employees=state.employees.filter(e=>e.id!==emp.id);
        Storage.save();
        App.populateFilterDropdowns();
        EmployeesView.render();
      });
      actTd.appendChild(delBtn);
      tr.appendChild(actTd);

      tbody.appendChild(tr);

      if (EmployeesView._expanded[emp.id]) {
        const detailTr=document.createElement('tr');
        const td=document.createElement('td');
        td.colSpan=8;
        if (!empTasks.length) {
          td.innerHTML='<div class="text-muted text-sm" style="padding:10px 4px">В реестре нет задач с этим исполнителем.</div>';
        } else {
          td.innerHTML=`<div style="overflow:auto;padding:6px 0">
            <table class="data-table" style="width:100%">
              <thead><tr><th>Команда</th><th>Эпик</th><th>Задача</th><th>Релизы</th><th>Овертайм</th></tr></thead>
              <tbody>
                ${empTasks.map(r=>`<tr>
                  <td>${Utils.escapeHtml(r.team||'—')}</td>
                  <td>${Utils.escapeHtml(r.epic||'—')}</td>
                  <td><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks||'')}</div></td>
                  <td>${RH.releaseChips(r)}</td>
                  <td>${r.hasOvertime?'<span class="chip chip-red">OT</span>':'<span class="chip chip-gray">Нет</span>'}</td>
                </tr>`).join('')}
              </tbody>
            </table>
          </div>`;
        }
        detailTr.appendChild(td);
        tbody.appendChild(detailTr);
      }
    });

    table.appendChild(tbody);
    wrap.innerHTML='';
    wrap.appendChild(table);
  },
  parseImportedRows(headers, matrixRows, sourceType) {
    const headerMap={};
    headers.forEach((h,idx)=>{
      const field=Utils.mapEmployeeHeader(Utils.normalizeHeader(h));
      if (field) headerMap[field]=idx;
    });
    if (headerMap.fio==null) return [];
    const get=(cells,key)=>{
      const idx=headerMap[key];
      return idx==null?'':String(cells[idx]||'').trim();
    };
    const imported=[];
    matrixRows.forEach(cells=>{
      if (!cells || cells.every(c=>!String(c||'').trim())) return;
      const fio=get(cells,'fio');
      if (!fio) return;
      imported.push(EmployeeFactory.create({
        fio,
        roles:get(cells,'roles'),
        teams:get(cells,'teams'),
        overtimeDays:Utils.parseDateList(get(cells,'overtimeDays')),
        weekdayReady:Utils.toBool(get(cells,'weekdayReady'),false),
        weekdayComment:get(cells,'weekdayComment'),
        sourceType,
      }));
    });
    return imported;
  },
  mergeImported(imported, sourceLabel) {
    if (!imported.length) { alert('Не найдено валидных строк сотрудников (нужна колонка ФИО).'); return; }
    const existingByFio=new Map();
    state.employees.forEach(emp=>{
      const key=String(emp.fio||'').trim().toLowerCase();
      if (key) existingByFio.set(key,emp);
    });
    let addCount=0, updateCount=0;
    imported.forEach(emp=>{
      const key=String(emp.fio||'').trim().toLowerCase();
      if (!key) return;
      const existing=existingByFio.get(key);
      if (existing) {
        existing.roles=emp.roles;
        existing.teams=emp.teams;
        existing.overtimeDays=emp.overtimeDays;
        existing.weekdayReady=emp.weekdayReady;
        existing.weekdayComment=emp.weekdayComment;
        existing.sourceType=emp.sourceType;
        EmployeeFactory.normalize(existing);
        updateCount++;
      } else {
        state.employees.push(emp);
        existingByFio.set(key,emp);
        addCount++;
      }
    });
    if (!addCount && !updateCount) { alert('Изменений по сотрудникам не найдено.'); return; }
    const ask=confirm(`${sourceLabel}: добавить ${addCount}, обновить ${updateCount}. Применить?`);
    if (!ask) return;
    Storage.save();
    App.populateFilterDropdowns();
    if (state.activeSection==='employees') EmployeesView.render();
    showToast(`Сотрудники: +${addCount}, обновлено ${updateCount}`);
  },
  importCSV(text) {
    if (text.charCodeAt(0)===0xFEFF) text=text.slice(1);
    const rows=Utils.parseFullCSV(text);
    if (rows.length<2) { alert('CSV пустой'); return; }
    const headers=rows[0].map(h=>String(h||'').trim());
    const imported=EmployeesView.parseImportedRows(headers, rows.slice(1), 'csv');
    EmployeesView.mergeImported(imported, 'CSV');
  },
  importXLSX(buffer) {
    if (typeof XLSX==='undefined') { alert('Положите libs/xlsx.full.min.js рядом с index.html'); return; }
    const wb=XLSX.read(buffer,{type:'array'});
    const imported=[];
    wb.SheetNames.forEach(sheetName=>{
      const ws=wb.Sheets[sheetName];
      const raw=XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:false});
      if (!raw || raw.length<2) return;
      let headerIdx=0;
      for (let i=0;i<Math.min(6,raw.length);i++) {
        const mapped=raw[i].map(h=>Utils.mapEmployeeHeader(Utils.normalizeHeader(h)));
        if (mapped.includes('fio')) { headerIdx=i; break; }
      }
      const headers=(raw[headerIdx]||[]).map(h=>String(h||'').trim());
      const rows=raw.slice(headerIdx+1);
      imported.push(...EmployeesView.parseImportedRows(headers,rows,'xlsx:'+sheetName));
    });
    EmployeesView.mergeImported(imported, 'XLSX');
  },
};

// ============================================================
// SUMMARY VIEW (CEO)
// ============================================================
const SummaryView = {
  splitTags(v) { return String(v||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean); },
  render() {
    const rows=FilterEngine.getFiltered();
    const wrap=document.getElementById('summary-wrap');
    if (!rows.length) {
      wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📈</div><div class="empty-title">Нет данных для сводной</div></div>';
      return;
    }
    if (state.summaryMode==='superBeautiful') SummaryView.renderSuperBeautiful(rows,wrap);
    else SummaryView.renderBrief(rows,wrap);
  },
  renderBrief(rows,wrap) {
    const done=rows.filter(r=>r.isDone).length;
    const blockers=rows.filter(r=>r.blockingDependency).length;
    const risky=rows.filter(r=>r.riskFlags&&r.riskFlags.length).length;
    const noRelease=rows.filter(r=>r.isUnassigned).length;
    const ot=rows.filter(r=>r.hasOvertime).length;
    const inScope=rows.filter(r=>r.scopeStatus==='Да').length;
    const progress=rows.length?Math.round(done/rows.length*100):0;

    const relRows=[
      {k:'1.20', total:rows.filter(r=>r.hasRelease120).length, done:rows.filter(r=>r.hasRelease120&&r.isDone).length},
      {k:'1.21', total:rows.filter(r=>r.hasRelease121).length, done:rows.filter(r=>r.hasRelease121&&r.isDone).length},
      {k:'1.22', total:rows.filter(r=>r.hasRelease122).length, done:rows.filter(r=>r.hasRelease122&&r.isDone).length},
      {k:'OT', total:rows.filter(r=>r.hasOvertime).length, done:rows.filter(r=>r.hasOvertime&&r.isDone).length},
    ];

    wrap.innerHTML=`
      <div class="summary-grid" style="margin-bottom:12px">
        <div class="summary-card"><h4>Всего задач</h4><div class="summary-big">${rows.length}</div><div class="summary-sub">В работе: ${rows.length-done}</div></div>
        <div class="summary-card"><h4>Общий прогресс</h4><div class="summary-big">${progress}%</div><div class="mini-progress"><span style="width:${progress}%"></span></div></div>
        <div class="summary-card"><h4>В scope</h4><div class="summary-big">${inScope}</div><div class="summary-sub">из ${rows.length}</div></div>
        <div class="summary-card"><h4>Блокеры / Риски</h4><div class="summary-big">${blockers} / ${risky}</div><div class="summary-sub">Критичный фокус</div></div>
        <div class="summary-card"><h4>Без релиза</h4><div class="summary-big">${noRelease}</div><div class="summary-sub">Нужно назначение</div></div>
        <div class="summary-card"><h4>Овертайм</h4><div class="summary-big">${ot}</div><div class="summary-sub">Нагрузка после релиза</div></div>
      </div>
      <div class="data-table-wrap" style="margin-bottom:12px">
        <div class="data-table-title">Релизы: объём и выполнение</div>
        <table class="data-table" style="width:100%">
          <thead><tr><th>Релиз</th><th>Задач</th><th>Сделано</th><th>Прогресс</th></tr></thead>
          <tbody>
            ${relRows.map(r=>{
              const p=r.total?Math.round(r.done/r.total*100):0;
              return `<tr><td>${r.k}</td><td>${r.total}</td><td>${r.done}</td><td><div class="mini-progress"><span style="width:${p}%"></span></div></td></tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
      <div class="insight-list">
        <div class="insight-item"><span>Критические блокеры в ближайших релизах</span><span class="insight-badge high">${rows.filter(r=>r.blockingDependency&&(r.hasRelease120||r.hasRelease121)).length}</span></div>
        <div class="insight-item"><span>В scope, но без релиза</span><span class="insight-badge high">${rows.filter(r=>r.scopeStatus==='Да'&&r.isUnassigned).length}</span></div>
        <div class="insight-item"><span>Сделано без даты</span><span class="insight-badge medium">${rows.filter(r=>r.isDone&&!r.doneDate).length}</span></div>
      </div>
    `;
  },
  renderDetailed(rows,wrap) {
    const teams=Utils.unique(rows.map(r=>r.team));
    const byTeamRows=teams.map(team=>{
      const tr=rows.filter(r=>r.team===team);
      const done=tr.filter(r=>r.isDone).length;
      const blockers=tr.filter(r=>r.blockingDependency).length;
      const risky=tr.filter(r=>r.riskFlags&&r.riskFlags.length).length;
      const progress=tr.length?Math.round(done/tr.length*100):0;
      return {team,total:tr.length,done,blockers,risky,progress};
    }).sort((a,b)=>b.total-a.total);

    const assigneeMap={};
    rows.forEach(r=>{
      SummaryView.splitTags(r.assignee).forEach(name=>{
        if(!assigneeMap[name]) assigneeMap[name]={total:0,ot:0,done:0};
        assigneeMap[name].total++;
        if (r.hasOvertime) assigneeMap[name].ot++;
        if (r.isDone) assigneeMap[name].done++;
      });
    });
    const assigneeRows=Object.entries(assigneeMap)
      .map(([name,v])=>({name,...v,progress:v.total?Math.round(v.done/v.total*100):0}))
      .sort((a,b)=>b.total-a.total);

    const roleMap={};
    rows.forEach(r=>{
      SummaryView.splitTags(r.role).forEach(role=>{
        if(!roleMap[role]) roleMap[role]=0;
        roleMap[role]++;
      });
    });
    const roleRows=Object.entries(roleMap).sort((a,b)=>b[1]-a[1]);

    wrap.innerHTML=`
      <div class="data-table-wrap" style="margin-bottom:12px">
        <div class="data-table-title">Команды: объём, прогресс, риски</div>
        <div style="overflow:auto">
          <table class="data-table" style="width:100%">
            <thead><tr><th>Команда</th><th>Задач</th><th>Сделано</th><th>Блокеры</th><th>Риски</th><th>Прогресс</th></tr></thead>
            <tbody>
              ${byTeamRows.map(r=>`<tr>
                <td>${Utils.escapeHtml(r.team||'—')}</td><td>${r.total}</td><td>${r.done}</td><td>${r.blockers}</td><td>${r.risky}</td>
                <td><div class="mini-progress"><span style="width:${r.progress}%"></span></div></td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
      <div class="summary-grid" style="margin-bottom:12px">
        <div class="summary-card">
          <h4>Роли (топ)</h4>
          ${roleRows.slice(0,12).map(([role,count])=>`<div class="insight-item"><span>${Utils.escapeHtml(role)}</span><span>${count}</span></div>`).join('')||'<div class="text-muted text-sm">Нет данных</div>'}
        </div>
        <div class="summary-card">
          <h4>Исполнители (топ)</h4>
          ${assigneeRows.slice(0,12).map(a=>`<div class="insight-item"><span>${Utils.escapeHtml(a.name)}<span class="text-muted"> • OT:${a.ot}</span></span><span>${a.total}</span></div>`).join('')||'<div class="text-muted text-sm">Нет данных</div>'}
        </div>
      </div>
      <div class="data-table-wrap">
        <div class="data-table-title">Исполнители: нагрузка и выполнение</div>
        <div style="overflow:auto">
          <table class="data-table" style="width:100%">
            <thead><tr><th>Исполнитель</th><th>Задач</th><th>OT</th><th>Сделано</th><th>Прогресс</th></tr></thead>
            <tbody>
              ${assigneeRows.map(a=>`<tr><td>${Utils.escapeHtml(a.name)}</td><td>${a.total}</td><td>${a.ot}</td><td>${a.done}</td><td><div class="mini-progress"><span style="width:${a.progress}%"></span></div></td></tr>`).join('')||'<tr><td colspan="5">Нет данных</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },
  renderBeautiful(rows,wrap) {
    const done=rows.filter(r=>r.isDone).length;
    const progress=rows.length?Math.round(done/rows.length*100):0;
    const blockers=rows.filter(r=>r.blockingDependency).length;
    const risky=rows.filter(r=>r.riskFlags&&r.riskFlags.length).length;
    const noRelease=rows.filter(r=>r.isUnassigned).length;
    const inScope=rows.filter(r=>r.scopeStatus==='Да').length;
    const relStats=[
      {label:'1.20',color:'#4f46e5',count:rows.filter(r=>r.hasRelease120).length},
      {label:'1.21',color:'#059669',count:rows.filter(r=>r.hasRelease121).length},
      {label:'1.22',color:'#d97706',count:rows.filter(r=>r.hasRelease122).length},
      {label:'OT',color:'#dc2626',count:rows.filter(r=>r.hasOvertime).length},
      {label:'Без релиза',color:'#64748b',count:noRelease},
    ];
    const relTotal=relStats.reduce((a,b)=>a+b.count,0)||1;
    let cum=0;
    const pieStops=relStats.map(item=>{
      const start=(cum/relTotal*360).toFixed(2);
      cum+=item.count;
      const end=(cum/relTotal*360).toFixed(2);
      return `${item.color} ${start}deg ${end}deg`;
    }).join(', ');

    const byTeam=Utils.unique(rows.map(r=>r.team)).map(team=>{
      const tr=rows.filter(r=>r.team===team);
      const td=tr.filter(r=>r.isDone).length;
      return {team,total:tr.length,done:td,p:tr.length?Math.round(td/tr.length*100):0};
    }).sort((a,b)=>b.total-a.total).slice(0,8);

    wrap.innerHTML=`
      <div class="summary-beautiful">
        <div class="summary-hero">
          <div class="summary-hero-title">CEO Control Room</div>
          <div class="summary-hero-sub">Ключевая картина релизов, рисков и выполнения в одном экране</div>
          <div class="summary-hero-grid">
            <div class="summary-hero-kpi"><div class="k">Всего задач</div><div class="v">${rows.length}</div></div>
            <div class="summary-hero-kpi"><div class="k">Выполнено</div><div class="v">${done}</div></div>
            <div class="summary-hero-kpi"><div class="k">Общий прогресс</div><div class="v">${progress}%</div></div>
            <div class="summary-hero-kpi"><div class="k">Блокеры</div><div class="v">${blockers}</div></div>
            <div class="summary-hero-kpi"><div class="k">Риски</div><div class="v">${risky}</div></div>
            <div class="summary-hero-kpi"><div class="k">В scope</div><div class="v">${inScope}</div></div>
          </div>
        </div>
        <div class="beaut-grid">
          <div class="beaut-card">
            <div class="beaut-title">Прогресс по ключевым командам</div>
            <div class="beaut-bars">
              ${byTeam.map(t=>`<div class="beaut-bar-row">
                <div>${Utils.escapeHtml(Utils.truncate(t.team||'—',16))}</div>
                <div class="beaut-bar-track"><span class="beaut-bar-fill" style="width:${t.p}%;background:${t.p>=75?'#059669':t.p>=45?'#d97706':'#dc2626'}"></span></div>
                <div>${t.p}%</div>
              </div>`).join('')}
            </div>
          </div>
          <div class="beaut-card">
            <div class="beaut-title">Распределение объёма по релизам</div>
            <div class="beaut-pie" style="background:conic-gradient(${pieStops})"></div>
            <div class="beaut-legend">
              ${relStats.map(i=>`<span class="beaut-pill"><span class="beaut-dot" style="background:${i.color}"></span>${i.label}: ${i.count}</span>`).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  },
  renderSuperBeautiful(rows,wrap) {
    const done=rows.filter(r=>r.isDone).length;
    const total=rows.length;
    const progress=total?Math.round(done/total*100):0;
    const blockers=rows.filter(r=>r.blockingDependency).length;
    const risky=rows.filter(r=>r.riskFlags&&r.riskFlags.length).length;
    const ot=rows.filter(r=>r.hasOvertime).length;
    const noRelease=rows.filter(r=>r.isUnassigned).length;
    const inScope=rows.filter(r=>r.scopeStatus==='Да').length;

    const relStats=[
      {label:'1.20',key:'hasRelease120',color:'#6366f1'},
      {label:'1.21',key:'hasRelease121',color:'#14b8a6'},
      {label:'1.22',key:'hasRelease122',color:'#f59e0b'},
      {label:'OT',key:'hasOvertime',color:'#ef4444'},
      {label:'Без релиза',key:'isUnassigned',color:'#64748b'},
    ].map(x=>({...x,count:rows.filter(r=>!!r[x.key]).length}));
    const relTotal=Math.max(1,relStats.reduce((sum,x)=>sum+x.count,0));
    let acc=0;
    const pieStops=relStats.map(item=>{
      const a=(acc/relTotal*360).toFixed(2);
      acc+=item.count;
      const b=(acc/relTotal*360).toFixed(2);
      return `${item.color} ${a}deg ${b}deg`;
    }).join(', ');

    const teams=Utils.unique(rows.map(r=>r.team)).map(team=>{
      const tr=rows.filter(r=>r.team===team);
      const doneCount=tr.filter(r=>r.isDone).length;
      const p=tr.length?Math.round(doneCount/tr.length*100):0;
      return {team,total:tr.length,p};
    }).sort((a,b)=>b.total-a.total).slice(0,10);

    const topAssignees={};
    rows.forEach(r=>{
      SummaryView.splitTags(r.assignee).forEach(name=>{
        if(!topAssignees[name]) topAssignees[name]={name,total:0,done:0};
        topAssignees[name].total++;
        if(r.isDone) topAssignees[name].done++;
      });
    });
    const leaders=Object.values(topAssignees)
      .map(a=>({...a,p:a.total?Math.round(a.done/a.total*100):0}))
      .sort((a,b)=>b.total-a.total)
      .slice(0,8);

    wrap.innerHTML=`
      <div class="summary-super">
        <div class="summary-super-hero">
          <div class="summary-super-glow summary-super-glow-a"></div>
          <div class="summary-super-glow summary-super-glow-b"></div>
          <div class="summary-super-title">СБОФ Executive Pulse</div>
          <div class="summary-super-sub">Моментальный снимок статуса релизов, рисков и загрузки команд</div>
          <div class="summary-super-kpis">
            <div class="summary-super-kpi"><span>Всего задач</span><strong>${total}</strong></div>
            <div class="summary-super-kpi"><span>Выполнено</span><strong>${done}</strong></div>
            <div class="summary-super-kpi"><span>Прогресс</span><strong>${progress}%</strong></div>
            <div class="summary-super-kpi"><span>Блокеры</span><strong>${blockers}</strong></div>
            <div class="summary-super-kpi"><span>Риски</span><strong>${risky}</strong></div>
            <div class="summary-super-kpi"><span>Овертайм</span><strong>${ot}</strong></div>
          </div>
        </div>

        <div class="summary-super-grid">
          <div class="summary-super-card">
            <div class="summary-super-card-title">Прогресс по командам</div>
            <div class="summary-super-bars">
              ${teams.map((t,i)=>`<div class="summary-super-bar-row">
                <div class="summary-super-bar-label">${Utils.escapeHtml(Utils.truncate(t.team||'—',20))}</div>
                <div class="summary-super-bar-track"><span class="summary-super-bar-fill" style="--p:${t.p};--d:${i*70}ms"></span></div>
                <div class="summary-super-bar-value">${t.p}%</div>
              </div>`).join('')}
            </div>
          </div>

          <div class="summary-super-card">
            <div class="summary-super-card-title">Распределение объема</div>
            <div class="summary-super-pie-wrap">
              <div class="summary-super-pie" style="background:conic-gradient(${pieStops})"></div>
            </div>
            <div class="summary-super-legend">
              ${relStats.map(i=>`<span class="summary-super-pill"><i style="background:${i.color}"></i>${i.label}: ${i.count}</span>`).join('')}
            </div>
          </div>
        </div>

        <div class="summary-super-grid">
          <div class="summary-super-card">
            <div class="summary-super-card-title">Критичный фокус</div>
            <div class="summary-super-metrics">
              <div class="summary-super-metric"><span>В scope без релиза</span><strong>${rows.filter(r=>r.scopeStatus==='Да'&&r.isUnassigned).length}</strong></div>
              <div class="summary-super-metric"><span>Сделано без даты</span><strong>${rows.filter(r=>r.isDone&&!r.doneDate).length}</strong></div>
              <div class="summary-super-metric"><span>Овертайм без периода</span><strong>${rows.filter(r=>r.hasOvertime&&(!r.workPeriodStart||!r.workPeriodEnd)).length}</strong></div>
              <div class="summary-super-metric"><span>В scope</span><strong>${inScope}</strong></div>
              <div class="summary-super-metric"><span>Без релиза</span><strong>${noRelease}</strong></div>
            </div>
          </div>

          <div class="summary-super-card">
            <div class="summary-super-card-title">Лидеры загрузки</div>
            <div class="summary-super-people">
              ${leaders.length?leaders.map((a,i)=>`<div class="summary-super-person" style="--d:${i*70}ms">
                <div class="summary-super-person-name">${Utils.escapeHtml(Utils.truncate(a.name,24))}</div>
                <div class="summary-super-person-meta">${a.total} задач • ${a.p}% done</div>
              </div>`).join(''):'<div class="text-muted text-sm">Нет данных по исполнителям</div>'}
            </div>
          </div>
        </div>
      </div>
    `;
  },
};

// ============================================================
// METRICS VIEW
// ============================================================
const MetricsView = {
  splitTags(v) { return String(v||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean); },
  render() {
    const rows=FilterEngine.getFiltered();
    const wrap=document.getElementById('metrics-wrap');
    if (!wrap) return;
    if (!rows.length) {
      wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📉</div><div class="empty-title">Нет данных для метрик</div></div>';
      return;
    }

    const done=rows.filter(r=>r.isDone).length;
    const blockers=rows.filter(r=>r.blockingDependency).length;
    const risky=rows.filter(r=>r.riskFlags&&r.riskFlags.length).length;
    const overtime=rows.filter(r=>r.hasOvertime).length;
    const inScope=rows.filter(r=>r.scopeStatus==='Да').length;
    const progress=rows.length?Math.round(done/rows.length*100):0;

    const releases=[
      {k:'1.20', has:'hasRelease120', c:'#6366f1'},
      {k:'1.21', has:'hasRelease121', c:'#14b8a6'},
      {k:'1.22', has:'hasRelease122', c:'#f59e0b'},
      {k:'OT', has:'hasOvertime', c:'#ef4444'},
      {k:'Без релиза', has:'isUnassigned', c:'#64748b'},
    ].map(x=>{
      const rr=rows.filter(r=>!!r[x.has]);
      const doneCount=rr.filter(r=>r.isDone).length;
      const riskyCount=rr.filter(r=>r.riskFlags&&r.riskFlags.length).length;
      const p=rr.length?Math.round(doneCount/rr.length*100):0;
      return {...x,total:rr.length,done:doneCount,risky:riskyCount,p};
    });

    const relTotal=Math.max(1,releases.reduce((s,r)=>s+r.total,0));
    let acc=0;
    const pieStops=releases.map(r=>{
      const s=(acc/relTotal*360).toFixed(2);
      acc+=r.total;
      const e=(acc/relTotal*360).toFixed(2);
      return `${r.c} ${s}deg ${e}deg`;
    }).join(', ');

    const teams=Utils.unique(rows.map(r=>r.team)).map(team=>{
      const tr=rows.filter(r=>r.team===team);
      const td=tr.filter(r=>r.isDone).length;
      const rb=tr.filter(r=>r.blockingDependency).length;
      const rs=tr.filter(r=>r.riskFlags&&r.riskFlags.length).length;
      return {team,total:tr.length,done:td,blockers:rb,risky:rs,p:tr.length?Math.round(td/tr.length*100):0};
    }).sort((a,b)=>b.total-a.total).slice(0,10);

    const rolesMap={};
    rows.forEach(r=>MetricsView.splitTags(r.role).forEach(role=>{
      if(!rolesMap[role]) rolesMap[role]={total:0,done:0};
      rolesMap[role].total++;
      if(r.isDone) rolesMap[role].done++;
    }));
    const roles=Object.entries(rolesMap).map(([role,v])=>({
      role,total:v.total,done:v.done,p:v.total?Math.round(v.done/v.total*100):0,
    })).sort((a,b)=>b.total-a.total).slice(0,8);

    const assigneeMap={};
    rows.forEach(r=>MetricsView.splitTags(r.assignee).forEach(name=>{
      if(!assigneeMap[name]) assigneeMap[name]={total:0,done:0,ot:0,risky:0};
      assigneeMap[name].total++;
      if(r.isDone) assigneeMap[name].done++;
      if(r.hasOvertime) assigneeMap[name].ot++;
      if(r.riskFlags&&r.riskFlags.length) assigneeMap[name].risky++;
    }));
    const assignees=Object.entries(assigneeMap).map(([name,v])=>({
      name,...v,p:v.total?Math.round(v.done/v.total*100):0,
    })).sort((a,b)=>b.total-a.total).slice(0,12);

    const parseDate=(v)=>{ if(!v) return null; const d=new Date(v); return Number.isNaN(d.getTime())?null:d; };
    const releaseEnd=(row)=>{
      if(row.hasRelease120) return new Date(GANTT_RELEASE_BOUNDS.r120[1]);
      if(row.hasRelease121) return new Date(GANTT_RELEASE_BOUNDS.r121[1]);
      if(row.hasRelease122) return new Date(GANTT_RELEASE_BOUNDS.r122[1]);
      return null;
    };
    const plannedDate=(r)=>parseDate(r.workPeriodEnd)||releaseEnd(r)||parseDate(r.workPeriodStart);
    const doneWithPlan=rows.filter(r=>r.isDone&&parseDate(r.doneDate)&&plannedDate(r));
    const onTimeDone=doneWithPlan.filter(r=>parseDate(r.doneDate)<=plannedDate(r)).length;
    const lateDone=Math.max(0,doneWithPlan.length-onTimeDone);
    const doneNoDate=rows.filter(r=>r.isDone&&!r.doneDate).length;
    const slaPct=doneWithPlan.length?Math.round(onTimeDone/doneWithPlan.length*100):0;

    const scopeMix=[
      {k:'Да',c:'#22c55e',n:rows.filter(r=>r.scopeStatus==='Да').length},
      {k:'Нет',c:'#94a3b8',n:rows.filter(r=>r.scopeStatus==='Нет').length},
      {k:'Треб. подтв.',c:'#f59e0b',n:rows.filter(r=>r.scopeStatus==='Требует подтверждения').length},
    ];
    const scopeTotal=Math.max(1,scopeMix.reduce((s,x)=>s+x.n,0));

    const qualitySignals=[
      {label:'Done без даты', value:doneNoDate, severity:doneNoDate>0?'high':'low'},
      {label:'OT без периода', value:rows.filter(r=>r.hasOvertime&&(!r.workPeriodStart||!r.workPeriodEnd)).length, severity:'high'},
      {label:'Без исполнителя', value:rows.filter(r=>!MetricsView.splitTags(r.assignee).length).length, severity:'medium'},
      {label:'Без категории', value:rows.filter(r=>!MetricsView.splitTags(r.category).length).length, severity:'medium'},
      {label:'В scope без релиза', value:rows.filter(r=>r.scopeStatus==='Да'&&r.isUnassigned).length, severity:'high'},
    ];

    const depByTeam=teams.map(t=>({
      ...t,
      pressure:t.total?Math.round((t.blockers+t.risky)/t.total*100):0,
    })).sort((a,b)=>b.pressure-a.pressure).slice(0,8);

    const typeMap={};
    const gather=(arr)=>arr.forEach(w=>{
      const key=String(w||'').trim();
      if(!key) return;
      if(!typeMap[key]) typeMap[key]=0;
      typeMap[key]+=1;
    });
    rows.forEach(r=>{
      gather(Array.isArray(r.release120Types)?r.release120Types:[]);
      gather(Array.isArray(r.release121Types)?r.release121Types:[]);
      gather(Array.isArray(r.release122Types)?r.release122Types:[]);
      gather(Array.isArray(r.overtimeTypes)?r.overtimeTypes:[]);
    });
    const wtEmoji=(wt)=>{
      const x=String(wt||'').trim().toLowerCase();
      if (x.includes('бизнес аналит')) return '📈';
      if (x.includes('аналит')) return '📊';
      if (x.includes('backend') || x.includes('бэкенд') || x.includes('разработ')) return '💻';
      if (x.includes('frontend') || x.includes('фронт')) return '🖥️';
      if (x.includes('qa') || x.includes('тест')) return '🧪';
      if (x.includes('внедр')) return '🚀';
      if (x.includes('миграц')) return '🗃️';
      if (x.includes('стабилиз')) return '🧯';
      if (x.includes('хотфикс') || x.includes('hotfix')) return '🚑';
      if (x.includes('интеграц')) return '🔌';
      if (x.includes('документ')) return '📝';
      return '🧩';
    };
    const typeTotal=Math.max(1,Object.values(typeMap).reduce((s,x)=>s+x,0));
    const typePortfolio=Object.entries(typeMap).map(([type,count])=>({
      type,count,p:Math.round(count/typeTotal*100),
    })).sort((a,b)=>b.count-a.count).slice(0,8);

    const loadTotals=assignees.map(a=>a.total);
    const topLoad=loadTotals.length?Math.max(...loadTotals):0;
    const loadConcentration=rows.length?Math.round(topLoad/rows.length*100):0;
    const evenness=loadTotals.length>1
      ? Math.round((1-(Math.max(...loadTotals)-Math.min(...loadTotals))/Math.max(1,Math.max(...loadTotals)))*100)
      : 100;
    const riskLoad=rows.length?Math.round(risky/rows.length*100):0;
    const blockerLoad=rows.length?Math.round(blockers/rows.length*100):0;

    const releaseHealth=releases.map(r=>{
      const riskPct=r.total?Math.round(r.risky/r.total*100):0;
      const score=Math.max(0,Math.min(100,Math.round(r.p*0.7 + (100-riskPct)*0.3)));
      return {...r,riskPct,score};
    }).sort((a,b)=>b.score-a.score);

    const last14=[];
    const now=new Date();
    const dayKey=(d)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    for(let i=13;i>=0;i--){
      const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()-i);
      last14.push({k:dayKey(d),label:`${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}`,v:0});
    }
    const idxMap={}; last14.forEach((x,i)=>{ idxMap[x.k]=i; });
    rows.forEach(r=>{
      if(!r.isDone||!r.doneDate) return;
      const d=parseDate(r.doneDate);
      if(!d) return;
      const k=dayKey(new Date(d.getFullYear(),d.getMonth(),d.getDate()));
      if (Object.prototype.hasOwnProperty.call(idxMap,k)) last14[idxMap[k]].v += 1;
    });
    const sparkW=440,sparkH=120,sparkPad=16;
    const sparkMax=Math.max(1,...last14.map(x=>x.v));
    const sx=i=>sparkPad + ((sparkW-sparkPad*2)*(last14.length===1?0:i/(last14.length-1)));
    const sy=v=>sparkH-sparkPad-((sparkH-sparkPad*2)*(v/sparkMax));
    const sparkPath=last14.map((p,i)=>`${i?'L':'M'}${sx(i).toFixed(1)},${sy(p.v).toFixed(1)}`).join(' ');
    const sparkArea=`${sparkPath} L${sx(last14.length-1).toFixed(1)},${sparkH-sparkPad} L${sx(0).toFixed(1)},${sparkH-sparkPad} Z`;

    const opsSignals=[
      {label:'В scope без релиза', value:rows.filter(r=>r.scopeStatus==='Да'&&r.isUnassigned).length, severity:'high'},
      {label:'Сделано без даты', value:rows.filter(r=>r.isDone&&!r.doneDate).length, severity:'medium'},
      {label:'Овертайм без периода', value:rows.filter(r=>r.hasOvertime&&(!r.workPeriodStart||!r.workPeriodEnd)).length, severity:'high'},
      {label:'Задач без исполнителя', value:rows.filter(r=>!MetricsView.splitTags(r.assignee).length).length, severity:'medium'},
      {label:'Блокеров в ближайших релизах', value:rows.filter(r=>r.blockingDependency&&(r.hasRelease120||r.hasRelease121)).length, severity:'high'},
      {label:'Покрытие done', value:`${progress}%`, severity:'low'},
    ];

    wrap.innerHTML=`
      <div class="metrics-room">
        <div class="metrics-hero">
          <div class="summary-super-glow summary-super-glow-a"></div>
          <div class="summary-super-glow summary-super-glow-b"></div>
          <div class="metrics-hero-title">Metrics Command Center</div>
          <div class="metrics-hero-sub">Комплексная панель исполнения, рисков, прогресса и нагрузки</div>
          <div class="metrics-kpis">
            <div class="metrics-kpi"><span>Всего задач</span><strong>${rows.length}</strong></div>
            <div class="metrics-kpi"><span>Сделано</span><strong>${done}</strong></div>
            <div class="metrics-kpi"><span>Прогресс</span><strong>${progress}%</strong></div>
            <div class="metrics-kpi"><span>Блокеры</span><strong>${blockers}</strong></div>
            <div class="metrics-kpi"><span>Риски</span><strong>${risky}</strong></div>
            <div class="metrics-kpi"><span>Овертайм</span><strong>${overtime}</strong></div>
            <div class="metrics-kpi"><span>В scope</span><strong>${inScope}</strong></div>
          </div>
        </div>

        <div class="metrics-grid metrics-grid-2">
          <div class="metrics-card">
            <div class="metrics-card-title">Распределение объёма</div>
            <div class="summary-super-pie-wrap">
              <div class="summary-super-pie" style="background:conic-gradient(${pieStops})"></div>
            </div>
            <div class="summary-super-legend">
              ${releases.map(r=>`<span class="summary-super-pill"><i style="background:${r.c}"></i>${r.k}: ${r.total}</span>`).join('')}
            </div>
          </div>

          <div class="metrics-card">
            <div class="metrics-card-title">SLA сроков: done вовремя</div>
            <div class="metrics-sla">
              <div class="metrics-sla-main">${slaPct}%</div>
              <div class="mini-progress"><span style="width:${slaPct}%"></span></div>
              <div class="metrics-sla-meta">Вовремя: ${onTimeDone} · С опозданием: ${lateDone} · Без даты done: ${doneNoDate}</div>
            </div>
          </div>
        </div>

        <div class="metrics-grid metrics-grid-3">
          <div class="metrics-card">
            <div class="metrics-card-title">Команды: прогресс и риски</div>
            <div class="metrics-rows">
              ${teams.map((t,i)=>`<div class="metrics-row">
                <div class="metrics-row-label">${Utils.escapeHtml(Utils.truncate(t.team||'—',18))}</div>
                <div class="metrics-row-track"><span class="metrics-row-fill" style="--p:${t.p};--d:${i*55}ms"></span></div>
                <div class="metrics-row-meta">${t.p}% · ${t.blockers}/${t.risky}</div>
              </div>`).join('')}
            </div>
          </div>

          <div class="metrics-card">
            <div class="metrics-card-title">Роли: загрузка</div>
            <div class="metrics-rows">
              ${roles.length?roles.map((r,i)=>`<div class="metrics-row">
                <div class="metrics-row-label">${Utils.escapeHtml(Utils.truncate(r.role,18))}</div>
                <div class="metrics-row-track"><span class="metrics-row-fill role" style="--p:${Math.max(8,Math.round(r.total/rows.length*100))};--d:${i*55}ms"></span></div>
                <div class="metrics-row-meta">${r.total}</div>
              </div>`).join(''):'<div class="text-muted text-sm">Нет данных</div>'}
            </div>
          </div>

          <div class="metrics-card">
            <div class="metrics-card-title">Операционные сигналы</div>
            <div class="metrics-signals">
              ${opsSignals.map(s=>`<div class="metrics-signal ${s.severity}">
                <span>${Utils.escapeHtml(s.label)}</span>
                <strong>${s.value}</strong>
              </div>`).join('')}
            </div>
          </div>
        </div>

        <div class="metrics-grid metrics-grid-3">
          <div class="metrics-card">
            <div class="metrics-card-title">Scope mix</div>
            <div class="metrics-stack">
              <div class="metrics-stack-track">
                ${scopeMix.map(s=>`<span class="metrics-stack-seg" style="width:${Math.round(s.n/scopeTotal*100)}%;background:${s.c}" title="${Utils.escapeHtml(s.k)}: ${s.n}"></span>`).join('')}
              </div>
              <div class="summary-super-legend">
                ${scopeMix.map(s=>`<span class="summary-super-pill"><i style="background:${s.c}"></i>${s.k}: ${s.n}</span>`).join('')}
              </div>
            </div>
          </div>

          <div class="metrics-card">
            <div class="metrics-card-title">Нагрузка по типам работ</div>
            <div class="metrics-rows">
              ${typePortfolio.length?typePortfolio.map((t,i)=>`<div class="metrics-row">
                <div class="metrics-row-label">${wtEmoji(t.type)} ${Utils.escapeHtml(Utils.truncate(t.type,18))}</div>
                <div class="metrics-row-track"><span class="metrics-row-fill role" style="--p:${Math.max(8,t.p)};--d:${i*45}ms"></span></div>
                <div class="metrics-row-meta">${t.count}</div>
              </div>`).join(''):'<div class="text-muted text-sm">Нет данных по типам работ</div>'}
            </div>
          </div>

          <div class="metrics-card">
            <div class="metrics-card-title">Dependency pressure по командам</div>
            <div class="metrics-rows">
              ${depByTeam.length?depByTeam.map((t,i)=>`<div class="metrics-row">
                <div class="metrics-row-label">${Utils.escapeHtml(Utils.truncate(t.team||'—',18))}</div>
                <div class="metrics-row-track"><span class="metrics-row-fill" style="--p:${Math.max(6,t.pressure)};--d:${i*45}ms"></span></div>
                <div class="metrics-row-meta">${t.pressure}%</div>
              </div>`).join(''):'<div class="text-muted text-sm">Нет данных по командам</div>'}
            </div>
          </div>
        </div>

        <div class="metrics-grid metrics-grid-2">
          <div class="metrics-card">
            <div class="metrics-card-title">Исполнители: загрузка / done / overtime</div>
            <div class="metrics-people">
              ${assignees.length?assignees.map((a,i)=>`<div class="metrics-person" style="--d:${i*35}ms">
                <div class="metrics-person-name">${Utils.escapeHtml(Utils.truncate(a.name,24))}</div>
                <div class="metrics-person-meta">${a.total} задач · done ${a.p}% · OT ${a.ot} · риск ${a.risky}</div>
              </div>`).join(''):'<div class="text-muted text-sm">Нет данных по исполнителям</div>'}
            </div>
          </div>

          <div class="metrics-card">
            <div class="metrics-card-title">Баланс нагрузки команды</div>
            <div class="metrics-signals">
              <div class="metrics-signal ${loadConcentration>=25?'high':loadConcentration>=18?'medium':'low'}">
                <span>Концентрация нагрузки (топ-исполнитель)</span>
                <strong>${loadConcentration}%</strong>
              </div>
              <div class="metrics-signal ${evenness<55?'high':evenness<75?'medium':'low'}">
                <span>Равномерность распределения</span>
                <strong>${evenness}%</strong>
              </div>
              ${qualitySignals.map(s=>`<div class="metrics-signal ${s.severity}">
                <span>${Utils.escapeHtml(s.label)}</span>
                <strong>${s.value}</strong>
              </div>`).join('')}
            </div>
          </div>
        </div>

        <div class="metrics-grid metrics-grid-3">
          <div class="metrics-card">
            <div class="metrics-card-title">Индекс здоровья релизов</div>
            <div class="metrics-rows">
              ${releaseHealth.map((r,i)=>`<div class="metrics-row">
                <div class="metrics-row-label">${Utils.escapeHtml(r.k)}</div>
                <div class="metrics-row-track"><span class="metrics-row-fill" style="--p:${Math.max(6,r.score)};--d:${i*40}ms"></span></div>
                <div class="metrics-row-meta">${r.score}</div>
              </div>`).join('')}
            </div>
          </div>

          <div class="metrics-card">
            <div class="metrics-card-title">Control ring</div>
            <div class="metrics-control-ring-wrap">
              <div class="metrics-control-ring" style="background:conic-gradient(#6366f1 0 ${progress}%, #ef4444 ${progress}% ${Math.min(100,progress+riskLoad)}%, #f59e0b ${Math.min(100,progress+riskLoad)}% ${Math.min(100,progress+riskLoad+blockerLoad)}%, #1f2a44 ${Math.min(100,progress+riskLoad+blockerLoad)}% 100%)">
                <div class="metrics-control-ring-inner">
                  <strong>${Math.max(0,100-riskLoad-blockerLoad)}%</strong>
                  <span>операц. запас</span>
                </div>
              </div>
            </div>
            <div class="summary-super-legend">
              <span class="summary-super-pill"><i style="background:#6366f1"></i>Прогресс ${progress}%</span>
              <span class="summary-super-pill"><i style="background:#ef4444"></i>Риски ${riskLoad}%</span>
              <span class="summary-super-pill"><i style="background:#f59e0b"></i>Блокеры ${blockerLoad}%</span>
            </div>
          </div>

          <div class="metrics-card">
            <div class="metrics-card-title">Тренд done за 14 дней</div>
            <div class="metrics-spark-wrap">
              <svg viewBox="0 0 ${sparkW} ${sparkH}" class="metrics-spark-svg">
                <path d="${sparkArea}" fill="rgba(99,102,241,.14)"></path>
                <path d="${sparkPath}" fill="none" stroke="#818cf8" stroke-width="2.8" stroke-linecap="round"></path>
                ${last14.map((p,i)=>`<circle cx="${sx(i).toFixed(1)}" cy="${sy(p.v).toFixed(1)}" r="2.6" fill="#a5b4fc"></circle>`).join('')}
              </svg>
              <div class="metrics-spark-foot">
                <span>${last14[0].label}</span>
                <strong>${last14.reduce((s,x)=>s+x.v,0)} done</strong>
                <span>${last14[last14.length-1].label}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  },
};

// ============================================================
// INSIGHTS VIEW
// ============================================================
const InsightsView = {
  split(v) { return String(v||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean); },
  render() {
    const rows=FilterEngine.getFiltered();
    const wrap=document.getElementById('insights-wrap');
    if (!rows.length) {
      wrap.innerHTML='<div class="empty-state"><div class="empty-icon">💡</div><div class="empty-title">Недостаточно данных для инсайтов</div></div>';
      return;
    }

    const bySeverity={high:[],medium:[],low:[]};
    const push=(severity,text,value)=>bySeverity[severity].push({text,value});

    const blockersNear=rows.filter(r=>r.blockingDependency&&(r.hasRelease120||r.hasRelease121)).length;
    push('high','Блокеры в ближайших релизах',blockersNear);
    push('high','В scope без релиза',rows.filter(r=>r.scopeStatus==='Да'&&r.isUnassigned).length);
    push('high','Задачи OT без периода работ',rows.filter(r=>r.hasOvertime&&(!r.workPeriodStart||!r.workPeriodEnd)).length);

    const noAssignee=rows.filter(r=>!InsightsView.split(r.assignee).length).length;
    push('medium','Задачи без исполнителя',noAssignee);
    push('medium','Сделанные без даты',rows.filter(r=>r.isDone&&!r.doneDate).length);
    push('medium','Требуют подтверждения и уже в релизе',rows.filter(r=>r.scopeStatus==='Требует подтверждения'&&(r.hasRelease120||r.hasRelease121||r.hasRelease122||r.hasOvertime)).length);

    const assigneeLoad={};
    rows.forEach(r=>InsightsView.split(r.assignee).forEach(name=>{ assigneeLoad[name]=(assigneeLoad[name]||0)+1; }));
    const overloaded=Object.entries(assigneeLoad).filter(([,n])=>n>=6).sort((a,b)=>b[1]-a[1]).slice(0,8);
    push('low','Исполнители с высокой нагрузкой (>=6 задач)',overloaded.length);

    const teamRisk=Utils.unique(rows.map(r=>r.team)).map(team=>{
      const tr=rows.filter(r=>r.team===team);
      const risky=tr.filter(r=>r.riskFlags&&r.riskFlags.length).length;
      return {team,total:tr.length,risky,ratio:tr.length?risky/tr.length:0};
    }).sort((a,b)=>b.ratio-a.ratio);

    const inScopeNoRelease = rows.filter(r=>r.scopeStatus==='Да'&&r.isUnassigned);
    const confirmInRelease = rows.filter(r=>r.scopeStatus==='Требует подтверждения'&&(r.hasRelease120||r.hasRelease121||r.hasRelease122||r.hasOvertime));
    const blockerNear = rows.filter(r=>r.blockingDependency&&(r.hasRelease120||r.hasRelease121));

    const renderActionBtn=(label,cls,onclick)=>`<button class="btn btn-sm ${cls} insight-action-btn" data-action="${onclick}" style="margin-left:auto">${label}</button>`;

    const renderList=(title,sev,extra='',actionBtn='')=>`
      <div class="insight-list">
        <div class="data-table-title" style="margin-bottom:6px;display:flex;align-items:center;gap:8px">${title}${actionBtn}</div>
        ${bySeverity[sev].map(i=>`<div class="insight-item"><span>${i.text}</span><span class="insight-badge ${sev}">${i.value}</span></div>`).join('')}
        ${extra}
      </div>`;

    const overloadBlock=overloaded.length?`<div style="margin-top:8px">${overloaded.map(([name,count])=>`<div class="insight-item"><span>${Utils.escapeHtml(name)}</span><span>${count}</span></div>`).join('')}</div>`:'<div class="text-muted text-sm">Нет перегруженных исполнителей</div>';
    const teamsBlock=teamRisk.slice(0,8).map(t=>`<div class="insight-item"><span>${Utils.escapeHtml(t.team||'—')}</span><span>${Math.round(t.ratio*100)}%</span></div>`).join('')||'<div class="text-muted text-sm">Нет данных</div>';

    const highActionBtn = inScopeNoRelease.length
      ? renderActionBtn('Назначить в 1.20 →','btn-primary','assign_120')
      : '';
    const medActionBtn = confirmInRelease.length
      ? renderActionBtn('Перевести в "Да" →','btn-outline','confirm_scope')
      : '';
    const blockerActionBtn = blockerNear.length
      ? renderActionBtn('Снять блокеры →','btn-danger','clear_blockers')
      : '';

    wrap.innerHTML=`
      <div class="summary-grid" style="margin-bottom:12px">
        ${renderList('Критические сигналы','high','',highActionBtn+blockerActionBtn)}
        ${renderList('Сигналы внимания','medium','',medActionBtn)}
        ${renderList('Операционные наблюдения','low',overloadBlock)}
      </div>
      <div class="summary-grid">
        <div class="insight-list">
          <div class="data-table-title" style="margin-bottom:6px">Команды с наибольшей долей рисков</div>
          ${teamsBlock}
        </div>
        <div class="insight-list">
          <div class="data-table-title" style="margin-bottom:6px">Ключевые проблемы данных</div>
          <div class="insight-item"><span>Строки без категории</span><span class="insight-badge medium">${rows.filter(r=>!String(r.category||'').trim()).length}</span></div>
          <div class="insight-item"><span>Строки без роли</span><span class="insight-badge medium">${rows.filter(r=>!String(r.role||'').trim()).length}</span></div>
          <div class="insight-item"><span>Строки без эпика</span><span class="insight-badge low">${rows.filter(r=>!String(r.epic||'').trim()).length}</span></div>
          <div class="insight-item"><span>Риски в закрытых задачах</span><span class="insight-badge low">${rows.filter(r=>r.isDone&&r.riskFlags&&r.riskFlags.length).length}</span></div>
        </div>
      </div>
    `;
  },
};

// ============================================================
// DIAGNOSTICS VIEW
// ============================================================
const DiagnosticsView = {
  render() {
    const d=state.diagnostics;
    const wrap=document.getElementById('diagnostics-wrap');
    const g=[['Источник данных',(d.sources||[]).join(', ')||'—'],['Всего строк',d.registryCount||0],['Из CSV',d.csvImportCount||0],['Из localStorage',d.localStorageCount||0]];
    const sheetsCard=d.sheets&&d.sheets.length?`<div class="diag-card"><div class="diag-card-header">Листы XLSX</div><div class="diag-card-body">${d.sheets.map(s=>`<div class="diag-row"><span class="diag-key">${s}</span><span class="diag-val">${(d.rowsPerSheet||{})[s]??'—'} строк</span></div>`).join('')}</div></div>`:'';
    const colCards=d.sheets&&d.sheets.length?d.sheets.map(s=>{
      const det=d.detectedColumns?d.detectedColumns[s]:{}, miss=d.missingColumns?d.missingColumns[s]:[];
      return`<div class="diag-card"><div class="diag-card-header">Колонки: ${s}</div><div class="diag-card-body">
        <div class="diag-col-list">${Object.entries(det||{}).map(([f,i])=>`<span class="diag-col-item" title="${i.originalHeader}">${f}[${i.index}]</span>`).join('')||'—'}</div>
        ${miss&&miss.length?`<div style="margin-top:8px"><div class="diag-col-list">${miss.map(f=>`<span class="diag-col-item diag-col-missing">${f}</span>`).join('')}</div></div>`:''}
      </div></div>`;
    }).join(''):'';
    const warns=d.warnings&&d.warnings.length?`<div class="diag-card"><div class="diag-card-header">Предупреждения</div><div class="diag-card-body">${d.warnings.map(w=>`<div class="diag-warning">${w}</div>`).join('')}</div></div>`:'';
    wrap.innerHTML=`<div class="diag-card"><div class="diag-card-header">Общая информация</div><div class="diag-card-body">${g.map(([k,v])=>`<div class="diag-row"><span class="diag-key">${k}</span><span class="diag-val">${v}</span></div>`).join('')}</div></div>${sheetsCard}${colCards}${warns}`;
  },
};

// ============================================================
// FILTERS UI
// ============================================================
const FiltersUI = {
  init() {
    const bind=(id,key,bool)=>{
      const el=document.getElementById(id);
      if (!el) return;
      el.addEventListener('change',e=>{ state.filters[key]=bool?e.target.checked:e.target.value; App.refreshCurrentSection(); });
    };
    bind('filter-search','search'); bind('filter-team','team'); bind('filter-scope','scope');
    bind('filter-release','release'); bind('filter-worktype','workType'); bind('filter-role','role'); bind('filter-assignee','assignee');
    bind('filter-blocking','onlyBlocking',true);
    bind('filter-risky','onlyRisky',true); bind('filter-done','onlyDone',true);
    if (FiltersUI._searchTimer) clearTimeout(FiltersUI._searchTimer);
    document.getElementById('filter-search').addEventListener('input',e=>{
      const next = e.target.value.trim();
      clearTimeout(FiltersUI._searchTimer);
      FiltersUI._searchTimer = setTimeout(()=>{
        state.filters.search=next;
        App.refreshCurrentSection();
      }, 140);
    });
    document.getElementById('btn-reset-filters').addEventListener('click',()=>FiltersUI.reset());
    document.querySelectorAll('.preset-btn[data-preset]').forEach(btn=>btn.addEventListener('click',()=>FiltersUI.applyPreset(btn.dataset.preset)));
  },
  applyPreset(preset) {
    document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('active'));
    if (preset==='reset') { state.filters.preset=null; state.filters.onlyBlocking=state.filters.onlyRisky=state.filters.onlyDone=false; state.filters.scope=state.filters.release=''; FiltersUI.syncUI(); App.refreshCurrentSection(); return; }
    state.filters.preset=preset;
    const btn=document.querySelector(`.preset-btn[data-preset="${preset}"]`);
    if (btn) btn.classList.add('active');
    state.filters.onlyBlocking=state.filters.onlyRisky=state.filters.onlyDone=false; state.filters.scope=state.filters.release='';
    if (preset==='critical') state.filters.onlyRisky=true;
    else if (preset==='no-release') state.filters.release='none';
    else if (preset==='needs-confirm') state.filters.scope='Требует подтверждения';
    else if (preset==='has-blocker') state.filters.onlyBlocking=true;
    else if (preset==='overtime') state.filters.release='overtime';
    else if (preset==='done') state.filters.onlyDone=true;
    FiltersUI.syncUI(); App.refreshCurrentSection();
  },
  syncUI() {
    document.getElementById('filter-scope').value=state.filters.scope||'';
    document.getElementById('filter-release').value=state.filters.release||'';
    ['blocking','risky','done'].forEach(k=>{
      const fk='only'+k.charAt(0).toUpperCase()+k.slice(1);
      const cb=document.getElementById(`filter-${k}`);
      if (cb) cb.checked=state.filters[fk];
      const tg=document.getElementById(`toggle-${k}`);
      if (tg) tg.classList.toggle('active',state.filters[fk]);
    });
    const roleSel=document.getElementById('filter-role'); if(roleSel) roleSel.value=Array.isArray(state.filters.role)?'':(state.filters.role||'');
    const assigneeSel=document.getElementById('filter-assignee'); if(assigneeSel) assigneeSel.value=Array.isArray(state.filters.assignee)?'':(state.filters.assignee||'');
  },
  reset() {
    state.filters={search:'',team:'',scope:'',release:'',workType:'',role:'',assignee:'',tag:'',onlyBlocking:false,onlyRisky:false,onlyDone:false,preset:null};
    document.getElementById('filter-search').value=''; document.getElementById('filter-team').value='';
    document.getElementById('filter-scope').value=''; document.getElementById('filter-release').value='';
    document.getElementById('filter-worktype').value=''; document.getElementById('filter-role').value='';
    const assigneeSel=document.getElementById('filter-assignee'); if (assigneeSel) assigneeSel.value='';
    document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('active'));
    FiltersUI.syncUI(); FiltersUI.populateDropdowns(); App.refreshCurrentSection();
  },
  populateDropdowns() {
    const teamSel=document.getElementById('filter-team'), cur1=teamSel.value;
    teamSel.innerHTML='<option value="">Все</option>'+FilterEngine.getTeams().map(t=>`<option value="${t}"${cur1===t?' selected':''}>${t}</option>`).join('');
    const wtSel=document.getElementById('filter-worktype'), cur2=wtSel.value;
    wtSel.innerHTML='<option value="">Все</option>'+FilterEngine.getWorkTypes().map(t=>`<option value="${t}"${cur2===t?' selected':''}>${t}</option>`).join('');
    const roleSel=document.getElementById('filter-role'), cur3=Array.isArray(state.filters.role)?'':roleSel.value;
    roleSel.innerHTML='<option value="">Все</option>'+FilterEngine.getRoles().map(r=>`<option value="${r}"${cur3===r?' selected':''}>${r}</option>`).join('');
    const asSel=document.getElementById('filter-assignee');
    if (asSel) {
      const curA=Array.isArray(state.filters.assignee)?'':asSel.value;
      asSel.innerHTML='<option value="">Все</option>'+FilterEngine.getAssignees().map(a=>`<option value="${a}"${curA===a?' selected':''}>${a}</option>`).join('');
    }
    const rpw=document.getElementById('preset-roles-wrap');
    if(rpw){
      const roles=FilterEngine.getRoles();
      const current=Array.isArray(state.filters.role)?state.filters.role:(state.filters.role?[state.filters.role]:[]);
      rpw.innerHTML='';
      const ms=Multiselect.create(current,(vals)=>{
        state.filters.role=vals.length?vals:'';
        document.getElementById('filter-role').value='';
        App.refreshCurrentSection();
      },()=>roles);
      ms.classList.add('preset-ms');
      rpw.appendChild(ms);
    }
    const paw=document.getElementById('preset-assignees-wrap');
    if (paw) {
      const assignees=FilterEngine.getAssignees();
      const current=Array.isArray(state.filters.assignee)?state.filters.assignee:(state.filters.assignee?[state.filters.assignee]:[]);
      paw.innerHTML='';
      const ms=Multiselect.create(current,(vals)=>{
        state.filters.assignee=vals.length?vals:'';
        const baseSel=document.getElementById('filter-assignee'); if (baseSel) baseSel.value='';
        App.refreshCurrentSection();
      },()=>assignees);
      ms.classList.add('preset-ms');
      paw.appendChild(ms);
    }
    const ptw=document.getElementById('preset-tags-wrap');
    if(ptw){
      const tags=[...new Set(state.rows.flatMap(r=>r.tags?String(r.tags).split('|').map(s=>s.trim()).filter(Boolean):[]))].sort();
      const current=Array.isArray(state.filters.tag)?state.filters.tag:(state.filters.tag?[state.filters.tag]:[]);
      ptw.innerHTML='';
      const ms=Multiselect.create(current,(vals)=>{
        state.filters.tag=vals.length?vals:'';
        App.refreshCurrentSection();
      },()=>tags);
      ms.classList.add('preset-ms');
      ptw.appendChild(ms);
    }
  },
};

// ============================================================
// LLM ASSISTANT + CONTEXT BUILDERS
// ============================================================
function getLLMDefaultSettings() {
  const defaultProxy = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:')
    ? 'http://127.0.0.1:8080'
    : '';
  return {
    apiMode: 'direct',
    apiBaseUrl: 'http://localhost:3000/v1',
    proxyUrl: defaultProxy,
    model: 'GigaChat-2',
    token: '',
    temperature: 0.2,
    maxTokens: 2000,
    systemPrompt: DEFAULT_LLM_SYSTEM_PROMPT,
    contextMode: 'currentView',
    rowLimit: 150,
    payloadLimitBytes: 250000,
    saveToLocal: true,
    tokenSessionOnly: true,
    customPayload: '',
  };
}

function safeJSONParse(raw, fallback) {
  try { return JSON.parse(raw); } catch (_) { return fallback; }
}

function buildSummaryContextPayload() {
  const rows = state.rows || [];
  const visibleRows = FilterEngine.getFiltered();
  const summary = {
    totalRows: rows.length,
    visibleRows: visibleRows.length,
    done: rows.filter(r => r.isDone).length,
    blockers: rows.filter(r => r.blockingDependency).length,
    risky: rows.filter(r => (r.riskFlags || []).length > 0).length,
    inScope: rows.filter(r => r.scopeStatus === 'Да').length,
    outScope: rows.filter(r => r.scopeStatus === 'Нет').length,
    needsConfirm: rows.filter(r => r.scopeStatus === 'Требует подтверждения').length,
    noRelease: rows.filter(r => r.isUnassigned).length,
    overtime: rows.filter(r => r.hasOvertime).length,
  };
  const riskCounter = {};
  rows.forEach(r => (r.riskFlags || []).forEach(flag => { riskCounter[flag] = (riskCounter[flag] || 0) + 1; }));
  const releaseDistribution = {
    backlog: rows.filter(r => r.isUnassigned).length,
    '1.20': rows.filter(r => r.hasRelease120).length,
    '1.21': rows.filter(r => r.hasRelease121).length,
    '1.22': rows.filter(r => r.hasRelease122).length,
    overtime: rows.filter(r => r.hasOvertime).length,
  };

  // Team breakdown: count tasks, blockers, risky per team
  const teamMap = {};
  rows.forEach(r => {
    const t = r.team || '(без команды)';
    if (!teamMap[t]) teamMap[t] = { team: t, total: 0, done: 0, blockers: 0, risky: 0, inScope: 0, noRelease: 0 };
    teamMap[t].total++;
    if (r.isDone) teamMap[t].done++;
    if (r.blockingDependency) teamMap[t].blockers++;
    if ((r.riskFlags || []).length > 0) teamMap[t].risky++;
    if (r.scopeStatus === 'Да') teamMap[t].inScope++;
    if (r.isUnassigned) teamMap[t].noRelease++;
  });
  const teamBreakdown = Object.values(teamMap).sort((a, b) => b.total - a.total);

  const pickRowFields = r => ({
    team: r.team,
    epic: r.epic,
    tasks: r.tasks,
    scopeStatus: r.scopeStatus,
    assignee: r.assignee,
    release120Types: r.release120Types,
    release121Types: r.release121Types,
    release122Types: r.release122Types,
    blockingDeadline: r.blockingDeadline,
    riskFlags: r.riskFlags,
    workPeriodStart: r.workPeriodStart,
    workPeriodEnd: r.workPeriodEnd,
    comment: r.comment,
  });

  const topBlockers = rows
    .filter(r => r.blockingDependency && !r.isDone)
    .slice(0, 20)
    .map(pickRowFields);

  const topRiskyRows = rows
    .filter(r => (r.riskFlags || []).length > 0 && !r.isDone)
    .slice(0, 20)
    .map(pickRowFields);

  return {
    app: 'SBOF Planner',
    activeTab: state.activeSection,
    filters: { ...state.filters },
    selectedPreset: state.filters.preset || null,
    summary,
    riskSummary: riskCounter,
    releaseDistribution,
    teamBreakdown,
    topBlockers,
    topRiskyRows,
    timestamp: new Date().toISOString(),
  };
}

function buildVisibleContextPayload() {
  const base = buildSummaryContextPayload();
  const rows = FilterEngine.getFiltered().map(r => ({
    id: r.id,
    team: r.team,
    epic: r.epic,
    category: r.category,
    tags: r.tags,
    tasks: r.tasks,
    scopeStatus: r.scopeStatus,
    release120Types: r.release120Types,
    release121Types: r.release121Types,
    release122Types: r.release122Types,
    overtimeTypes: r.overtimeTypes,
    role: r.role,
    assignee: r.assignee,
    isDone: r.isDone,
    blockingDependency: r.blockingDependency,
    riskFlags: r.riskFlags || [],
    workPeriodStart: r.workPeriodStart,
    workPeriodEnd: r.workPeriodEnd,
    comment: r.comment,
  }));
  return { ...base, visibleRows: rows };
}

function buildAppContextPayload() {
  const base = buildSummaryContextPayload();
  const rows = state.rows.map(r => ({
    id: r.id,
    team: r.team,
    epic: r.epic,
    category: r.category,
    tags: r.tags,
    tasks: r.tasks,
    scopeStatus: r.scopeStatus,
    release120Types: r.release120Types,
    release121Types: r.release121Types,
    release122Types: r.release122Types,
    overtimeTypes: r.overtimeTypes,
    role: r.role,
    assignee: r.assignee,
    isDone: r.isDone,
    blockingDependency: r.blockingDependency,
    riskFlags: r.riskFlags || [],
    workPeriodStart: r.workPeriodStart,
    workPeriodEnd: r.workPeriodEnd,
    comment: r.comment,
  }));
  return { ...base, rows };
}

function buildCustomContextPayload() {
  const customRaw = String(state.llm?.settings?.customPayload || '').trim();
  if (!customRaw) return { customPayload: null };
  const parsed = safeJSONParse(customRaw, null);
  return parsed ? { customPayload: parsed } : { customPayloadText: customRaw };
}

function truncateForLLM(payload, limits) {
  const rowLimit = Math.max(1, Number(limits?.rowLimit) || 50);
  const payloadLimitBytes = Math.max(1024, Number(limits?.payloadLimitBytes) || 120000);
  const out = safeJSONParse(JSON.stringify(payload || {}), {});

  const trimRows = (key) => {
    if (!Array.isArray(out[key])) return;
    if (out[key].length > rowLimit) out[key] = out[key].slice(0, rowLimit);
  };
  trimRows('rows');
  trimRows('visibleRows');

  const serialized = JSON.stringify(out);
  if (serialized.length <= payloadLimitBytes) return out;

  const minimize = (row) => ({
    id: row.id,
    team: row.team,
    epic: row.epic,
    tasks: row.tasks,
    scopeStatus: row.scopeStatus,
    release120Types: row.release120Types,
    release121Types: row.release121Types,
    release122Types: row.release122Types,
    overtimeTypes: row.overtimeTypes,
    blockingDependency: row.blockingDependency,
    riskFlags: row.riskFlags,
    assignee: row.assignee,
  });
  if (Array.isArray(out.rows)) out.rows = out.rows.map(minimize).slice(0, Math.max(10, Math.floor(rowLimit * 0.65)));
  if (Array.isArray(out.visibleRows)) out.visibleRows = out.visibleRows.map(minimize).slice(0, Math.max(10, Math.floor(rowLimit * 0.65)));

  const second = JSON.stringify(out);
  if (second.length <= payloadLimitBytes) return out;

  out.rows = Array.isArray(out.rows) ? out.rows.slice(0, 12) : out.rows;
  out.visibleRows = Array.isArray(out.visibleRows) ? out.visibleRows.slice(0, 12) : out.visibleRows;
  out._truncated = true;
  out._payloadBytes = second.length;
  out._payloadLimitBytes = payloadLimitBytes;
  return out;
}

function buildLLMMessages(userMessage, contextOverride) {
  const settings = LLMAssistant.getSettings();
  const contextMode = contextOverride || settings.contextMode || 'currentView';
  let payload;
  if (contextMode === 'none') payload = { contextDisabled: true };
  else if (contextMode === 'summary') payload = buildSummaryContextPayload();
  else if (contextMode === 'currentView') payload = buildVisibleContextPayload();
  else if (contextMode === 'fullRegistry') payload = buildAppContextPayload();
  else payload = buildCustomContextPayload();

  payload = truncateForLLM(payload, {
    rowLimit: settings.rowLimit,
    payloadLimitBytes: settings.payloadLimitBytes,
  });

  const systemPrompt = settings.systemPrompt || DEFAULT_LLM_SYSTEM_PROMPT;
  const userBlock = [
    `Вопрос пользователя: ${userMessage}`,
    '',
    `Режим контекста: ${contextMode}`,
    'Контекст приложения (JSON):',
    JSON.stringify(payload, null, 2),
  ].join('\n');
  return [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userBlock },
  ];
}

// Maintains conversation history by keeping first user message (has embedded context)
// and trimming old turns when conversation grows too long.
function trimApiHistory(apiHistory, maxMessages) {
  if (!Array.isArray(apiHistory) || apiHistory.length <= maxMessages) return apiHistory;
  const first = apiHistory[0]; // first user msg carries the context JSON — always keep
  const rest = apiHistory.slice(1);
  const trimmed = rest.slice(-(maxMessages - 1));
  return [first, ...trimmed];
}

// Builds the messages array to send to the LLM API.
// First call: includes full context JSON in the user message.
// Subsequent calls: appends raw user question to existing conversation history.
function buildApiCallMessages(userMessage, contextOverride) {
  const settings = LLMAssistant.getSettings();
  const systemPrompt = settings.systemPrompt || DEFAULT_LLM_SYSTEM_PROMPT;
  const apiHistory = state.llm?.apiHistory || [];
  const hasHistory = apiHistory.some(m => m.role === 'user');

  if (!hasHistory) {
    // First message in this session — include full context payload
    return buildLLMMessages(userMessage, contextOverride);
  }

  // Subsequent messages: use apiHistory + current question (no re-send of context)
  const MAX_HISTORY = 20; // last 20 messages (~10 turns)
  const trimmed = trimApiHistory(apiHistory, MAX_HISTORY);
  return [
    { role: 'system', content: systemPrompt },
    ...trimmed,
    { role: 'user', content: userMessage },
  ];
}

function extractDeltaFromChunk(obj) {
  if (!obj) return '';
  if (typeof obj === 'string') return obj;
  const c = obj.choices?.[0];
  const v =
    c?.delta?.content ??
    c?.message?.content ??
    c?.text ??
    obj.delta ??
    obj.content ??
    obj.output_text ??
    obj.result?.choices?.[0]?.delta?.content ??
    obj.result?.choices?.[0]?.message?.content ??
    '';
  if (Array.isArray(v)) return v.map(x => (typeof x === 'string' ? x : (x?.text || ''))).join('');
  return typeof v === 'string' ? v : '';
}

async function parseStreamResponse(response, onDelta, abortSignal) {
  const contentType = (response.headers.get('content-type') || '').toLowerCase();
  if (!response.ok) {
    const errTxt = await response.text().catch(() => '');
    throw new Error(errTxt || `HTTP ${response.status}`);
  }
  if (!response.body) {
    const data = await response.json().catch(() => ({}));
    const full = extractDeltaFromChunk(data) || data?.choices?.[0]?.message?.content || '';
    if (full) onDelta(full);
    return;
  }

  // Fallback for non-streaming JSON payloads.
  if (contentType.includes('application/json')) {
    const data = await response.json().catch(() => ({}));
    const full = extractDeltaFromChunk(data) || data?.choices?.[0]?.message?.content || '';
    if (full) onDelta(full);
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  while (true) {
    if (abortSignal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, idx).trim();
      buffer = buffer.slice(idx + 1);
      if (!line) continue;
      let dataLine = line;
      if (line.startsWith('data:')) dataLine = line.slice(5).trim();
      if (!dataLine || dataLine === '[DONE]') continue;
      const parsed = safeJSONParse(dataLine, null);
      if (parsed) {
        const chunk = extractDeltaFromChunk(parsed);
        if (chunk) onDelta(chunk);
        continue;
      }
      // Non-JSON chunked fallback.
      onDelta(dataLine);
    }
  }
  const tail = buffer.trim();
  if (tail && tail !== '[DONE]') {
    const parsed = safeJSONParse(tail.startsWith('data:') ? tail.slice(5).trim() : tail, null);
    if (parsed) {
      const chunk = extractDeltaFromChunk(parsed);
      if (chunk) onDelta(chunk);
    } else {
      onDelta(tail.replace(/^data:\s*/,''));
    }
  }
}

function buildOpenAIChatEndpoint(baseUrlRaw) {
  const baseUrl = String(baseUrlRaw || '').trim().replace(/\/+$/, '');
  if (!baseUrl) return '/v1/chat/completions';
  if (baseUrl.endsWith('/chat/completions')) return baseUrl;
  if (baseUrl.endsWith('/v1')) return `${baseUrl}/chat/completions`;
  return `${baseUrl}/chat/completions`;
}

function buildProxyEndpoint(settings) {
  const customProxyOrigin = String(settings.proxyUrl || '').trim().replace(/\/+$/, '');
  if (customProxyOrigin) return `${customProxyOrigin}/api/llm/chat`;
  if (window.location.protocol === 'file:') {
    throw new Error('Режим file:// не поддерживает /api/llm/chat. Запусти node server.js и открой приложение по http://127.0.0.1:8080 или укажи Node proxy URL.');
  }
  return '/api/llm/chat';
}

async function callGigaChatStream(messages, settings, onDelta, abortSignal) {
  const mode = settings.apiMode || 'proxy';
  const baseUrl = String(settings.apiBaseUrl || '').replace(/\/+$/, '');
  const token = LLMAssistant.getToken();
  const payload = {
    model: settings.model || 'GigaChat-2',
    temperature: Number(settings.temperature),
    max_tokens: Math.max(64, Number(settings.maxTokens) || 900),
    stream: true,
    messages,
  };

  if (mode === 'direct') {
    const endpoint = buildOpenAIChatEndpoint(baseUrl || 'http://localhost:3000/v1');
    const endpointUrl = new URL(endpoint, window.location.origin);
    const sameOrigin = endpointUrl.origin === window.location.origin;
    if (sameOrigin) {
      const res = await fetch(endpointUrl.toString(), {
        method: 'POST',
        signal: abortSignal,
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(payload),
      });
      return parseStreamResponse(res, onDelta, abortSignal);
    }
    // CORS-safe fallback for cross-origin "direct" endpoints.
    const proxyEndpoint = buildProxyEndpoint(settings);
    const res = await fetch(proxyEndpoint, {
      method: 'POST',
      signal: abortSignal,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        apiBaseUrl: `${endpointUrl.origin}${endpointUrl.pathname.replace(/\/chat\/completions$/, '')}`,
        model: payload.model,
        temperature: payload.temperature,
        max_tokens: payload.max_tokens,
        stream: true,
        messages: payload.messages,
        token,
      }),
    });
    return parseStreamResponse(res, onDelta, abortSignal);
  }

  const proxyEndpoint = buildProxyEndpoint(settings);

  const res = await fetch(proxyEndpoint, {
    method: 'POST',
    signal: abortSignal,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      apiBaseUrl: baseUrl,
      model: payload.model,
      temperature: payload.temperature,
      max_tokens: payload.max_tokens,
      stream: true,
      messages: payload.messages,
      token,
      // Optional future OAuth fields:
      clientId: settings.clientId || '',
      clientSecret: settings.clientSecret || '',
    }),
  });
  return parseStreamResponse(res, onDelta, abortSignal);
}

function renderMarkdownLite(raw) {
  const text = String(raw || '').trim();
  if (!text) return '';

  // Inline formatting applied to already-escaped text.
  function applyInline(s) {
    return s
      .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/__(.+?)__/g, '<strong>$1</strong>')
      .replace(/\*([^*\n]+)\*/g, '<em>$1</em>')
      .replace(/_([^_\n]+)_/g, '<em>$1</em>')
      .replace(/`([^`\n]+)`/g, '<code>$1</code>');
  }

  // Process a plain-text segment (no code blocks) into HTML.
  function processSegment(seg) {
    const lines = Utils.escapeHtml(seg).split('\n');
    const out = [];
    let inUl = false, inOl = false;

    const closeList = () => {
      if (inUl) { out.push('</ul>'); inUl = false; }
      if (inOl) { out.push('</ol>'); inOl = false; }
    };

    for (const line of lines) {
      if (/^###\s/.test(line)) {
        closeList();
        out.push(`<h4 class="md-h">${applyInline(line.replace(/^###\s+/, ''))}</h4>`);
      } else if (/^##\s/.test(line)) {
        closeList();
        out.push(`<h3 class="md-h">${applyInline(line.replace(/^##\s+/, ''))}</h3>`);
      } else if (/^#\s/.test(line)) {
        closeList();
        out.push(`<h3 class="md-h">${applyInline(line.replace(/^#\s+/, ''))}</h3>`);
      } else if (/^\s*[-*]\s/.test(line)) {
        if (!inUl) { closeList(); out.push('<ul>'); inUl = true; }
        out.push(`<li>${applyInline(line.replace(/^\s*[-*]\s+/, ''))}</li>`);
      } else if (/^\s*\d+[.)]\s/.test(line)) {
        if (!inOl) { closeList(); out.push('<ol>'); inOl = true; }
        out.push(`<li>${applyInline(line.replace(/^\s*\d+[.)]\s+/, ''))}</li>`);
      } else if (line.trim() === '') {
        closeList();
        if (out.length && out[out.length - 1] !== '<br>') out.push('<br>');
      } else {
        closeList();
        out.push(applyInline(line) + '<br>');
      }
    }
    closeList();
    return out.join('');
  }

  // Split on fenced code blocks; odd-indexed segments are code.
  const segments = text.split(/(```[\w]*\n?[\s\S]*?```)/g);
  const parts = [];
  for (let i = 0; i < segments.length; i++) {
    if (i % 2 === 1) {
      const code = segments[i].replace(/^```[\w]*\n?/, '').replace(/```$/, '').trimEnd();
      parts.push(`<pre><code>${Utils.escapeHtml(code)}</code></pre>`);
    } else {
      parts.push(processSegment(segments[i]));
    }
  }

  let result = parts.join('');
  result = result.replace(/(<br>){3,}/g, '<br><br>');
  result = result.replace(/^<br>+/, '').replace(/<br>+$/, '');
  return result;
}

const LLMAssistant = {
  CONV_KEY: 'q2_llm_conv_v1',
  init() {
    const defaults = getLLMDefaultSettings();
    const saved = safeJSONParse(localStorage.getItem(LLM_SETTINGS_KEY) || 'null', null);
    const settings = {
      ...defaults,
      ...(saved && typeof saved === 'object' ? saved : {}),
    };
    if (String(settings.apiBaseUrl || '').includes('gigachat.devices.sberbank.ru')) {
      settings.apiBaseUrl = 'http://localhost:3000/v1';
      if (!saved || saved.apiMode === 'proxy') settings.apiMode = 'direct';
    }
    state.llm = {
      settings,
      history: [],
      apiHistory: [],
      panelOpen: false,
      panelMinimized: false,
      isStreaming: false,
      abortController: null,
      sessionToken: '',
      lastUserText: '', // for retry
    };
    LLMAssistant.loadConversation();
    LLMAssistant.bindUI();
    LLMAssistant.syncSettingsUI();
    LLMAssistant.updateContextModeIndicator();
    LLMAssistant.updateQuickPrompts();
    LLMAssistant.renderMessages();
  },
  // Save/load conversation to localStorage for persistence across reloads.
  saveConversation() {
    try {
      const s = LLMAssistant.getSettings();
      if (!s.saveToLocal) { localStorage.removeItem(LLMAssistant.CONV_KEY); return; }
      const data = {
        history: state.llm.history.filter(m => !m.streaming && !m.thinking),
        apiHistory: state.llm.apiHistory,
        savedAt: Date.now(),
      };
      localStorage.setItem(LLMAssistant.CONV_KEY, JSON.stringify(data));
    } catch(_) {}
  },
  loadConversation() {
    try {
      const raw = localStorage.getItem(LLMAssistant.CONV_KEY);
      if (!raw) return;
      const data = safeJSONParse(raw, null);
      if (!data || !Array.isArray(data.history)) return;
      // Discard if older than 24h
      if (Date.now() - (data.savedAt || 0) > 86400000) {
        localStorage.removeItem(LLMAssistant.CONV_KEY);
        return;
      }
      state.llm.history = data.history;
      state.llm.apiHistory = Array.isArray(data.apiHistory) ? data.apiHistory : [];
    } catch(_) {}
  },
  getSettings() {
    return state.llm.settings || getLLMDefaultSettings();
  },
  getToken() {
    const settings = LLMAssistant.getSettings();
    if (settings.tokenSessionOnly) return state.llm.sessionToken || '';
    return settings.token || '';
  },
  saveSettingsFromUI() {
    const s = LLMAssistant.getSettings();
    s.apiMode = document.getElementById('llm-api-mode').value || 'proxy';
    s.apiBaseUrl = (document.getElementById('llm-api-base').value || '').trim();
    s.proxyUrl = (document.getElementById('llm-proxy-url').value || '').trim();
    s.model = (document.getElementById('llm-model').value || '').trim() || 'GigaChat-2';
    s.temperature = Math.max(0, Math.min(2, Number(document.getElementById('llm-temperature').value) || 0.2));
    s.maxTokens = Math.max(64, Number(document.getElementById('llm-max-tokens').value) || 900);
    s.systemPrompt = (document.getElementById('llm-system-prompt').value || '').trim() || DEFAULT_LLM_SYSTEM_PROMPT;
    s.contextMode = document.getElementById('llm-context-mode').value || 'summary';
    s.rowLimit = Math.max(1, Number(document.getElementById('llm-row-limit').value) || 80);
    s.payloadLimitBytes = Math.max(1024, Number(document.getElementById('llm-payload-limit').value) || 120000);
    s.customPayload = document.getElementById('llm-custom-payload').value || '';
    s.saveToLocal = !!document.getElementById('llm-save-local').checked;
    s.tokenSessionOnly = !!document.getElementById('llm-token-session-only').checked;

    const inputToken = (document.getElementById('llm-token').value || '').trim();
    if (s.tokenSessionOnly) {
      state.llm.sessionToken = inputToken;
      s.token = '';
    } else {
      s.token = inputToken;
      state.llm.sessionToken = '';
    }
    if (s.saveToLocal) {
      const persist = { ...s };
      if (persist.tokenSessionOnly) persist.token = '';
      localStorage.setItem(LLM_SETTINGS_KEY, JSON.stringify(persist));
    } else {
      localStorage.removeItem(LLM_SETTINGS_KEY);
    }
    LLMAssistant.updateContextModeIndicator();
    showToast('LLM settings сохранены');
  },
  clearSavedSettings() {
    localStorage.removeItem(LLM_SETTINGS_KEY);
    state.llm.settings = getLLMDefaultSettings();
    state.llm.sessionToken = '';
    LLMAssistant.syncSettingsUI();
    LLMAssistant.updateContextModeIndicator();
    showToast('LLM settings очищены');
  },
  syncSettingsUI() {
    const s = LLMAssistant.getSettings();
    const setVal = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.value = val;
    };
    setVal('llm-api-mode', s.apiMode);
    setVal('llm-api-base', s.apiBaseUrl);
    setVal('llm-proxy-url', s.proxyUrl || '');
    setVal('llm-model', s.model);
    setVal('llm-temperature', s.temperature);
    setVal('llm-max-tokens', s.maxTokens);
    setVal('llm-system-prompt', s.systemPrompt || DEFAULT_LLM_SYSTEM_PROMPT);
    setVal('llm-context-mode', s.contextMode);
    setVal('llm-row-limit', s.rowLimit);
    setVal('llm-payload-limit', s.payloadLimitBytes);
    setVal('llm-custom-payload', s.customPayload || '');
    const tokenInput = document.getElementById('llm-token');
    if (tokenInput) tokenInput.value = s.tokenSessionOnly ? (state.llm.sessionToken || '') : (s.token || '');
    const saveLocal = document.getElementById('llm-save-local');
    const sessionOnly = document.getElementById('llm-token-session-only');
    if (saveLocal) saveLocal.checked = !!s.saveToLocal;
    if (sessionOnly) sessionOnly.checked = !!s.tokenSessionOnly;
  },
  updateContextModeIndicator() {
    const map = {
      none: 'none',
      summary: 'summary only',
      currentView: 'current view',
      fullRegistry: 'full registry limited',
      custom: 'custom payload',
    };
    const el = document.getElementById('assistant-context-mode-label');
    if (el) el.textContent = `Контекст: ${map[LLMAssistant.getSettings().contextMode] || 'summary only'}`;
  },
  bindUI() {
    const fab = document.getElementById('assistant-fab');
    const panel = document.getElementById('assistant-panel');
    const settingsModal = document.getElementById('llm-settings-modal');
    const input = document.getElementById('assistant-input');
    const sendBtn = document.getElementById('assistant-btn-send');
    const stopBtn = document.getElementById('assistant-btn-stop');
    const errorEl = document.getElementById('assistant-error');

    const openSettingsModal = () => { LLMAssistant.syncSettingsUI(); settingsModal.classList.remove('hidden'); };

    // FAB toggle
    if (fab) fab.addEventListener('click', () => {
      const willOpen = panel.classList.contains('hidden');
      state.llm.panelOpen = willOpen;
      if (willOpen) {
        state.llm.panelMinimized = false;
        panel.classList.remove('hidden', 'minimized');
        fab.classList.add('hidden');
        input.focus();
      } else {
        panel.classList.add('hidden');
        fab.classList.remove('hidden');
        errorEl.classList.add('hidden');
      }
    });

    document.getElementById('assistant-btn-close').addEventListener('click', () => {
      state.llm.panelOpen = false;
      panel.classList.add('hidden');
      if (fab) fab.classList.remove('hidden');
      errorEl.classList.add('hidden');
    });
    document.getElementById('assistant-btn-minimize').addEventListener('click', () => {
      state.llm.panelMinimized = !state.llm.panelMinimized;
      panel.classList.toggle('minimized', state.llm.panelMinimized);
    });

    // New: settings button inside panel
    const panelSettingsBtn = document.getElementById('assistant-btn-settings');
    if (panelSettingsBtn) panelSettingsBtn.addEventListener('click', openSettingsModal);

    // New: clear / new conversation button
    const clearBtn = document.getElementById('assistant-btn-clear');
    if (clearBtn) clearBtn.addEventListener('click', () => LLMAssistant.clearConversation());

    // Topbar LLM settings button
    const tobarSettingsBtn = document.getElementById('btn-llm-settings');
    if (tobarSettingsBtn) tobarSettingsBtn.addEventListener('click', openSettingsModal);

    document.getElementById('llm-settings-close').addEventListener('click', () => closeModal(settingsModal));
    settingsModal.addEventListener('click', (e) => { if (e.target === settingsModal) closeModal(settingsModal); });
    document.getElementById('llm-save-settings').addEventListener('click', () => {
      LLMAssistant.saveSettingsFromUI();
      closeModal(settingsModal);
    });
    document.getElementById('llm-clear-saved').addEventListener('click', () => LLMAssistant.clearSavedSettings());

    // Send / stop
    sendBtn.addEventListener('click', () => LLMAssistant.sendFromInput());
    stopBtn.addEventListener('click', () => LLMAssistant.stopGeneration());

    // Enter = send, Shift+Enter = newline
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        LLMAssistant.sendFromInput();
      }
    });

    // Auto-resize textarea as user types
    input.addEventListener('input', () => {
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 180) + 'px';
    });

    // Esc closes panel
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && state.llm?.panelOpen && !settingsModal.classList.contains('hidden')) {
        closeModal(settingsModal);
      } else if (e.key === 'Escape' && state.llm?.panelOpen) {
        state.llm.panelOpen = false;
        panel.classList.add('hidden');
        if (fab) fab.classList.remove('hidden');
        errorEl.classList.add('hidden');
      }
    });

    // Messages list — delegated: retry + copy
    const messagesWrap = document.getElementById('assistant-messages');
    if (messagesWrap) {
      messagesWrap.addEventListener('click', (e) => {
        // Retry failed request
        if (e.target.closest('[data-retry]') && state.llm.lastUserText && !state.llm.isStreaming) {
          const lastMsg = state.llm.history[state.llm.history.length - 1];
          if (lastMsg?.isError) state.llm.history.pop();
          const prevMsg = state.llm.history[state.llm.history.length - 1];
          if (prevMsg?.role === 'user' && prevMsg.content === state.llm.lastUserText) {
            state.llm.history.pop();
          }
          input.value = state.llm.lastUserText;
          input.dispatchEvent(new Event('input'));
          LLMAssistant.sendFromInput();
          return;
        }
        // Copy message content
        const copyBtn = e.target.closest('.msg-copy-btn');
        if (!copyBtn) return;
        const idx = parseInt(copyBtn.dataset.index ?? '-1', 10);
        const msg = state.llm.history[idx];
        if (!msg) return;
        navigator.clipboard.writeText(msg.content || '').then(
          () => showToast('Скопировано'),
          () => {
            const ta = document.createElement('textarea');
            ta.value = msg.content || '';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            showToast('Скопировано');
          }
        );
      });
    }

    // Context mode label — click to cycle through modes
    const contextLabel = document.getElementById('assistant-context-mode-label');
    if (contextLabel) {
      contextLabel.addEventListener('click', () => {
        const modes = ['currentView', 'fullRegistry', 'summary', 'none'];
        const s = LLMAssistant.getSettings();
        const next = modes[(modes.indexOf(s.contextMode) + 1) % modes.length];
        s.contextMode = next;
        if (s.saveToLocal) {
          const persist = { ...s };
          if (persist.tokenSessionOnly) persist.token = '';
          localStorage.setItem(LLM_SETTINGS_KEY, JSON.stringify(persist));
        }
        LLMAssistant.updateContextModeIndicator();
        showToast(`Режим контекста: ${next}`);
      });
    }

    // Payload preview
    document.getElementById('assistant-btn-preview').addEventListener('click', () => {
      const s = LLMAssistant.getSettings();
      const payload = LLMAssistant.buildContextPayloadByMode(s.contextMode);
      const clipped = truncateForLLM(payload, { rowLimit: s.rowLimit, payloadLimitBytes: s.payloadLimitBytes });
      const bytes = JSON.stringify(clipped).length;
      const modal = document.getElementById('modal-kpi');
      document.getElementById('modal-kpi-title').textContent = `LLM payload preview (~${Math.round(bytes/1024)}KB)`;
      document.getElementById('modal-kpi-body').innerHTML = `<pre style="white-space:pre-wrap;word-break:break-word">${Utils.escapeHtml(JSON.stringify(clipped, null, 2))}</pre>`;
      modal.classList.remove('hidden');
    });

    // Insert context into textarea
    document.getElementById('assistant-btn-insert-context').addEventListener('click', () => {
      const s = LLMAssistant.getSettings();
      const payload = LLMAssistant.buildContextPayloadByMode(s.contextMode);
      const clipped = truncateForLLM(payload, { rowLimit: s.rowLimit, payloadLimitBytes: s.payloadLimitBytes });
      const txt = JSON.stringify(clipped, null, 2);
      input.value = input.value ? `${input.value}\n\n${txt}` : txt;
      input.dispatchEvent(new Event('input')); // trigger auto-resize
      input.focus();
    });

    // Quick prompts
    const quickWrap = document.getElementById('assistant-quick-prompts');
    if (quickWrap) {
      quickWrap.addEventListener('click', (e) => {
        const btn = e.target.closest('.assistant-quick-btn');
        if (!btn) return;
        const prompt = btn.dataset.prompt || '';
        if (!prompt) return;
        const contextOverride = btn.dataset.context || null;
        input.value = prompt;
        input.dispatchEvent(new Event('input'));
        input.focus();
        LLMAssistant.sendFromInput(contextOverride);
      });
    }

  },
  getQuickPrompts() {
    // Each entry: { prompt, context } — context is optional contextMode override
    const base = [
      { prompt: 'Сделай короткую сводку статуса по текущим данным.', context: 'summary' },
      { prompt: 'Какие 5 главных рисков сейчас и почему?', context: 'currentView' },
      { prompt: 'Где у нас блокеры и как снять их быстрее всего?', context: 'currentView' },
    ];
    const bySection = {
      registry: [
        { prompt: 'Проверь данные реестра: где дубли/пустые критичные поля?', context: 'currentView' },
        { prompt: 'Какие строки самые рискованные в реестре?', context: 'currentView' },
        { prompt: 'Что поправить в реестре в первую очередь?', context: 'currentView' },
      ],
      gantt: [
        { prompt: 'Покажи критический путь по текущим данным.', context: 'currentView' },
        { prompt: 'Какие зависимости выглядят конфликтными по срокам?', context: 'currentView' },
        { prompt: 'Где самая плотная нагрузка по релизным окнам?', context: 'summary' },
      ],
      kanban: [
        { prompt: 'Какие карточки застряли и почему?', context: 'currentView' },
        { prompt: 'Какие команды сейчас перегружены по канбану?', context: 'summary' },
      ],
      timeline: [
        { prompt: 'Какие релизы выглядят самыми рискованными?', context: 'summary' },
        { prompt: 'Дай прогноз узких мест по таймлайну.', context: 'summary' },
      ],
      employees: [
        { prompt: 'У кого максимальная загрузка и риски?', context: 'currentView' },
        { prompt: 'Кого можно подключить в овертайм в первую очередь?', context: 'currentView' },
      ],
      summary: [
        { prompt: 'Сделай CEO-update на 6 пунктов.', context: 'summary' },
        { prompt: 'Дай три сценария: оптимистичный, базовый, рисковый.', context: 'summary' },
      ],
      metrics: [
        { prompt: 'Какие метрики сейчас самые тревожные?', context: 'summary' },
        { prompt: 'Что улучшить за 2 недели, чтобы заметно поднять картину?', context: 'summary' },
      ],
      insights: [
        { prompt: 'Сформируй топ инсайтов по приоритету действий.', context: 'currentView' },
        { prompt: 'Какие сигналы могут перейти в инцидент?', context: 'currentView' },
      ],
    };
    return [...base, ...(bySection[state.activeSection] || [])].slice(0, 8);
  },
  updateQuickPrompts() {
    const wrap = document.getElementById('assistant-quick-prompts');
    if (!wrap) return;
    const prompts = LLMAssistant.getQuickPrompts();
    wrap.innerHTML = prompts.map((p, i) => {
      const ctx = p.context ? ` data-context="${Utils.escapeHtml(p.context)}"` : '';
      return `<button class="assistant-quick-btn" data-prompt="${Utils.escapeHtml(p.prompt)}"${ctx} style="--i:${i}">${Utils.escapeHtml(Utils.truncate(p.prompt, 62))}</button>`;
    }).join('');
  },
  buildContextPayloadByMode(mode) {
    if (mode === 'none') return { contextDisabled: true };
    if (mode === 'summary') return buildSummaryContextPayload();
    if (mode === 'currentView') return buildVisibleContextPayload();
    if (mode === 'fullRegistry') return buildAppContextPayload();
    return buildCustomContextPayload();
  },
  renderMessages(streamingUpdate) {
    const wrap = document.getElementById('assistant-messages');
    if (!wrap) return;

    if (!state.llm.history.length) {
      wrap.innerHTML = `<div class="assistant-msg assistant-msg-assistant">Готов помочь с анализом данных. Выберите типовой вопрос выше или задайте свой.</div>`;
      return;
    }

    // Incremental update during streaming: only refresh last message DOM node.
    if (streamingUpdate) {
      const lastMsg = state.llm.history[state.llm.history.length - 1];
      const msgEls = wrap.querySelectorAll('.assistant-msg');
      const lastEl = msgEls[msgEls.length - 1];
      if (lastEl && lastMsg && msgEls.length === state.llm.history.length) {
        lastEl.classList.toggle('assistant-msg-streaming', !!lastMsg.streaming);
        const bodyEl = lastEl.querySelector('.msg-body');
        if (bodyEl) {
          bodyEl.innerHTML = lastMsg.thinking
            ? '<span class="msg-thinking"><span></span><span></span><span></span></span>'
            : renderMarkdownLite(lastMsg.content || '');
        }
        wrap.scrollTop = wrap.scrollHeight;
        return;
      }
    }

    // Full re-render.
    wrap.innerHTML = state.llm.history.map((msg, idx) => {
      const isUser = msg.role === 'user';
      const cls = isUser ? 'assistant-msg assistant-msg-user' : 'assistant-msg assistant-msg-assistant';
      const streamingCls = msg.streaming ? ' assistant-msg-streaming' : '';
      let bodyHtml;
      if (msg.thinking) {
        bodyHtml = '<span class="msg-thinking"><span></span><span></span><span></span></span>';
      } else if (msg.isError) {
        const retryBtn = state.llm.lastUserText
          ? `<br><button class="msg-retry-btn" data-retry="1">↺ Повторить запрос</button>`
          : '';
        bodyHtml = renderMarkdownLite(msg.content || '') + retryBtn;
      } else {
        bodyHtml = renderMarkdownLite(msg.content || '');
      }
      const copyBtn = !isUser && !msg.thinking
        ? `<button class="msg-copy-btn" title="Копировать" data-index="${idx}">⧉</button>`
        : '';
      return `<div class="${cls}${streamingCls}" data-index="${idx}"><div class="msg-body">${bodyHtml}</div>${copyBtn}</div>`;
    }).join('');
    wrap.scrollTop = wrap.scrollHeight;
  },
  setError(message) {
    const el = document.getElementById('assistant-error');
    if (!el) return;
    if (!message) { el.classList.add('hidden'); el.textContent = ''; return; }
    el.textContent = message;
    el.classList.remove('hidden');
  },
  clearConversation() {
    if (state.llm.isStreaming) return;
    state.llm.history = [];
    state.llm.apiHistory = [];
    state.llm.lastUserText = '';
    localStorage.removeItem(LLMAssistant.CONV_KEY);
    LLMAssistant.renderMessages();
    LLMAssistant.setPayloadStatus('');
  },
  setPayloadStatus(text) {
    const el = document.getElementById('assistant-payload-status');
    if (el) { el.textContent = text; el.classList.toggle('hidden', !text); }
  },
  async sendFromInput(contextOverride) {
    const input = document.getElementById('assistant-input');
    const sendBtn = document.getElementById('assistant-btn-send');
    const stopBtn = document.getElementById('assistant-btn-stop');
    const text = String(input.value || '').trim();
    if (!text || state.llm.isStreaming) return;

    LLMAssistant.setError('');
    LLMAssistant.setPayloadStatus('');
    state.llm.lastUserText = text;
    state.llm.history.push({ role: 'user', content: text });
    const assistantMsg = { role: 'assistant', content: '', streaming: true, thinking: true };
    state.llm.history.push(assistantMsg);
    input.value = '';
    // Reset textarea height after clearing
    input.style.height = 'auto';
    state.llm.isStreaming = true;
    sendBtn.disabled = true;
    stopBtn.classList.remove('hidden');
    LLMAssistant.renderMessages();

    const abortController = new AbortController();
    state.llm.abortController = abortController;
    try {
      // Use multi-turn messages builder (includes history for follow-up turns).
      const messages = buildApiCallMessages(text, contextOverride || null);
      // The user content actually sent to the API (may include context JSON on first turn).
      const sentUserContent = messages[messages.length - 1].content;

      // Show payload size hint.
      const payloadBytes = JSON.stringify(messages).length;
      const isTruncated = (state.llm.history.filter(m => m.role === 'user').length === 1)
        && sentUserContent.includes('_truncated');
      LLMAssistant.setPayloadStatus(
        `payload: ~${Math.round(payloadBytes / 1024)}KB` +
        (isTruncated ? ' (усечён — увеличь лимиты в настройках)' : '')
      );

      await callGigaChatStream(messages, LLMAssistant.getSettings(), (delta) => {
        if (assistantMsg.thinking) { assistantMsg.thinking = false; }
        assistantMsg.content += delta;
        LLMAssistant.renderMessages(true); // incremental update
      }, abortController.signal);

      assistantMsg.streaming = false;
      assistantMsg.thinking = false;
      if (!assistantMsg.content.trim()) {
        assistantMsg.content = 'Ответ пустой. Проверь модель/токен и режим контекста.';
      } else {
        // Persist this exchange to apiHistory for multi-turn context.
        state.llm.apiHistory.push({ role: 'user', content: sentUserContent });
        state.llm.apiHistory.push({ role: 'assistant', content: assistantMsg.content });
        LLMAssistant.saveConversation();
      }
    } catch (err) {
      assistantMsg.streaming = false;
      assistantMsg.thinking = false;
      if (err && err.name === 'AbortError') {
        assistantMsg.content = assistantMsg.content || 'Генерация остановлена.';
      } else {
        assistantMsg.isError = true;
        assistantMsg.content = assistantMsg.content || 'Не удалось получить ответ от LLM.';
        const errStr = String(err?.message || err || 'Ошибка LLM');
        const hint = errStr.includes('token') || errStr.includes('401')
          ? ' — проверь API-токен в настройках ⚙'
          : errStr.includes('fetch') || errStr.includes('network') || errStr.includes('Failed')
            ? ' — сервер недоступен, проверь URL и запущен ли node server.js'
            : '';
        LLMAssistant.setError(errStr + hint);
      }
    } finally {
      state.llm.isStreaming = false;
      state.llm.abortController = null;
      sendBtn.disabled = false;
      stopBtn.classList.add('hidden');
      LLMAssistant.renderMessages();
    }
  },
  stopGeneration() {
    if (state.llm.abortController) {
      state.llm.abortController.abort();
    }
  },
};

// ============================================================
// GANTT V2 — Epic timeline (ported from claude, isolated section)
// ============================================================
function g2ISOWeek(d) {
  const dt=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  dt.setUTCDate(dt.getUTCDate()+4-(dt.getUTCDay()||7));
  const y=new Date(Date.UTC(dt.getUTCFullYear(),0,1));
  return Math.ceil((((dt-y)/86400000)+1)/7);
}

const GanttV2 = {
  _cancelDrag: null,
  render() {
    GanttV2.syncControls();
    GanttV2.renderChart();
  },
  getZoom() { return Math.max(0.3,Math.min(4,Number.isFinite(state.gantt2Zoom)?state.gantt2Zoom:1)); },
  setZoom(z) {
    state.gantt2Zoom=Math.max(0.3,Math.min(4,z));
    const lbl=document.getElementById('gantt2-zoom-label');
    if(lbl) lbl.textContent=Math.round(GanttV2.getZoom()*100)+'%';
    Storage.save();
    GanttV2.renderChart();
  },
  syncControls() {
    const lbl=document.getElementById('gantt2-zoom-label');
    if(lbl) lbl.textContent=Math.round(GanttV2.getZoom()*100)+'%';
    const sd=document.getElementById('gantt2-show-deps');
    if(sd) sd.checked=state.gantt2ShowDeps!==false;
    const ts=document.getElementById('gantt2-team-filter');
    if(ts){
      const teams=FilterEngine.getTeams();
      const cur=state.gantt2Team||'';
      ts.innerHTML='<option value="">Все команды</option>'+teams.map(t=>`<option value="${Utils.escapeHtml(t)}"${cur===t?' selected':''}>${Utils.escapeHtml(t)}</option>`).join('');
    }
  },
  getRows() {
    let rows=FilterEngine.getFiltered();
    if(state.gantt2Team) rows=rows.filter(r=>r.team===state.gantt2Team);
    return rows;
  },
  buildEpics(rows) {
    const toDate=v=>{
      if(!v) return null;
      const d=new Date(v);
      return Number.isNaN(d.getTime())?null:new Date(d.getFullYear(),d.getMonth(),d.getDate());
    };
    const map={};
    rows.forEach(r=>{
      const key=String(r.epic||r.category||r.tasks||'').trim()||'(без эпика)';
      if(!map[key]) map[key]={rows:[],teams:new Set()};
      map[key].rows.push(r);
      if(r.team) map[key].teams.add(r.team);
    });
    const result=[];
    Object.entries(map).forEach(([name,data])=>{
      const ers=data.rows;
      const phases={};
      let minS=null,maxE=null;
      const assignees=new Set(),roles=new Set(),cats=new Set();
      ers.forEach(r=>{
        if(r.assignee) String(r.assignee).split(/[|,]/).forEach(s=>{s=s.trim();if(s)assignees.add(s);});
        if(r.role) String(r.role).split(/[|,]/).forEach(s=>{s=s.trim();if(s)roles.add(s);});
        if(r.category) String(r.category).split(/[|,]/).forEach(s=>{s=s.trim();if(s)cats.add(s);});
        const addP=(key,types,s,e)=>{
          if(!types||!types.length||!s||!e) return;
          if(!phases[key]) phases[key]={types:new Set(),start:s,end:e};
          types.forEach(t=>phases[key].types.add(t));
          if(s<phases[key].start) phases[key].start=s;
          if(e>phases[key].end) phases[key].end=e;
          if(!minS||s<minS) minS=s;
          if(!maxE||e>maxE) maxE=e;
        };
        if (r.hasRelease120) addP('r120', r.release120Types||[], new Date(GANTT_RELEASE_BOUNDS.r120[0]), new Date(GANTT_RELEASE_BOUNDS.r120[1]));
        if (r.hasRelease121) addP('r121', r.release121Types||[], new Date(GANTT_RELEASE_BOUNDS.r121[0]), new Date(GANTT_RELEASE_BOUNDS.r121[1]));
        if (r.hasRelease122) addP('r122', r.release122Types||[], new Date(GANTT_RELEASE_BOUNDS.r122[0]), new Date(GANTT_RELEASE_BOUNDS.r122[1]));
        if (r.hasOvertime) {
          const s=toDate(r.workPeriodStart),e=toDate(r.workPeriodEnd);
          addP('ot',r.overtimeTypes||[],s,e);
        }
      });
      result.push({
        name,rows:ers,phases,start:minS,end:maxE,
        teams:[...data.teams],team:[...data.teams][0]||'',
        assignees:[...assignees],roles:[...roles],cats:[...cats],
        blocking:ers.some(r=>!!r.blockingDependency),
        done:ers.length>0&&ers.every(r=>r.isDone),
        riskCount:ers.filter(r=>r.riskFlags&&r.riskFlags.length).length,
        count:ers.length,
      });
    });
    return result;
  },
  renderChart() {
    if (typeof GanttV2._cancelDrag === 'function') {
      try { GanttV2._cancelDrag(); } catch(_) {}
      GanttV2._cancelDrag = null;
    }
    const wrap=document.getElementById('gantt2-wrap');
    if(!wrap) return;

    const rows=GanttV2.getRows();
    if(!rows.length){
      wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div><div class="empty-hint">Загрузите файл XLSX или CSV</div></div>';
      return;
    }

    const esc=Utils.escapeHtml;
    const zoom=GanttV2.getZoom();
    const epics=GanttV2.buildEpics(rows);
    const showDeps=state.gantt2ShowDeps!==false;

    let minB=null,maxB=null;
    epics.forEach(e=>{
      if(e.start&&(!minB||e.start<minB)) minB=e.start;
      if(e.end&&(!maxB||e.end>maxB)) maxB=e.end;
    });
    if(!minB||!maxB){minB=new Date(GANTT_TIMELINE_START);maxB=new Date(GANTT_TIMELINE_END);}
    if((maxB-minB)/86400000>400){minB=new Date(GANTT_TIMELINE_START);maxB=new Date(GANTT_TIMELINE_END.getFullYear(),GANTT_TIMELINE_END.getMonth()+2,0);}

    const tS=new Date(minB.getFullYear(),minB.getMonth(),1);
    const tE=new Date(maxB.getFullYear(),maxB.getMonth()+1,1);
    const totalDays=Math.max(1,Math.ceil((tE-tS)/86400000));
    const wrapW=Math.max(900,wrap.getBoundingClientRect().width||wrap.clientWidth||900);
    const LEFT_W=Math.max(240,Math.min(380,Math.round(wrapW*0.27)));
    const viewW=Math.max(500,wrapW-LEFT_W-2);
    const baseDayPx=viewW/totalDays;
    const dayPx=Math.max(1.5,baseDayPx*zoom);
    const totalW=Math.ceil(totalDays*dayPx);
    const dayOff=d=>Math.max(0,Math.round((d-tS)/86400000*dayPx));
    const dayW=(a,b)=>Math.max(16,Math.round(((b-a)/86400000+1)*dayPx));

    const today=new Date();today.setHours(0,0,0,0);
    const todayX=(today>=tS&&today<=tE)?dayOff(today):null;

    let monthHtml='';
    for(let d=new Date(tS);d<tE;d=new Date(d.getFullYear(),d.getMonth()+1,1)){
      const nx=new Date(d.getFullYear(),d.getMonth()+1,1);
      const x=dayOff(d),w=Math.max(1,dayOff(nx)-x);
      monthHtml+=`<div class="g2-month" style="left:${x}px;width:${w}px">${esc(d.toLocaleString('ru',{month:'short',year:'2-digit'}))}</div>`;
    }
    let weekHtml='';
    if(dayPx>=3){
      let wd=new Date(tS);
      while(wd.getDay()!==1&&wd<tE) wd=new Date(wd.getTime()+86400000);
      for(;wd<tE;wd=new Date(wd.getTime()+7*86400000)){
        const x=dayOff(wd);
        weekHtml+=`<div class="g2-week-mark" style="left:${x}px">W${g2ISOWeek(wd)}</div>`;
      }
    }
    const HEAD_H=weekHtml?52:30;

    const relBands=[
      {s:new Date(GANTT_RELEASE_BOUNDS.r120[0]),e:new Date(GANTT_RELEASE_BOUNDS.r120[1]),l:'1.20',c:'rgba(79,70,229,.06)'},
      {s:new Date(GANTT_RELEASE_BOUNDS.r121[0]),e:new Date(GANTT_RELEASE_BOUNDS.r121[1]),l:'1.21',c:'rgba(5,150,105,.06)'},
      {s:new Date(GANTT_RELEASE_BOUNDS.r122[0]),e:new Date(GANTT_RELEASE_BOUNDS.r122[1]),l:'1.22',c:'rgba(217,119,6,.06)'},
    ];
    let bandsHtml='';
    relBands.forEach(b=>{
      const vs=b.s<tS?tS:b.s,ve=b.e>tE?tE:b.e;
      if(ve<vs) return;
      const x=dayOff(vs),w=dayW(vs,ve);
      bandsHtml+=`<div class="g2-band" style="left:${x}px;width:${w}px;background:${b.c}"><span class="g2-band-lbl">${b.l}</span></div>`;
    });

    const TPAL=['#6366f1','#0ea5e9','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899','#14b8a6','#f97316','#84cc16'];
    const allTeams=[...new Set(epics.map(e=>e.team||'(без команды)'))].sort((a,b)=>a.localeCompare(b,'ru'));
    const tColor=t=>TPAL[allTeams.indexOf(t)%TPAL.length]||'#6366f1';
    const byTeam={};
    epics.forEach(e=>{
      const t=e.team||'(без команды)';
      if(!byTeam[t]) byTeam[t]=[];
      byTeam[t].push(e);
    });
    allTeams.forEach(t=>{ if(byTeam[t]) byTeam[t].sort((a,b)=>a.name.localeCompare(b.name,'ru')); });

    const ROW_H=62,TEAM_H=36;
    const geometry={};
    let leftHtml='',rightHtml='',y=0,animIdx=0;
    const deps=state.epicDeps||{};
    const depSrcSet=new Set(Object.values(deps));

    allTeams.forEach((team,ti)=>{
      const tes=byTeam[team]||[];
      const tc=tColor(team);
      const tbg=Utils.hexToRgba(tc.replace('#',''),0.05);
      leftHtml+=`<div class="g2-team-hdr g2-lc" style="top:${y}px;height:${TEAM_H}px;border-left:4px solid ${tc}">
        <span class="g2-team-name">${esc(team)}</span><span class="g2-team-cnt">${tes.length}</span></div>`;
      rightHtml+=`<div class="g2-team-hdr g2-rc" style="top:${y}px;height:${TEAM_H}px;width:${totalW}px;background:${tbg}"></div>`;
      y+=TEAM_H;

      tes.forEach((epic,ei)=>{
        const top=y; y+=ROW_H; animIdx++;
        let bars='',bsx=Infinity,bex=-Infinity;
        const addBar=(ph)=>{
          if(!ph||!ph.start||!ph.end) return;
          const vs=ph.start<tS?tS:ph.start;
          const ve=ph.end>tE?tE:ph.end;
          if(ve<vs) return;
          const bx=dayOff(vs),bw=dayW(vs,ve);
          if(bx<bsx) bsx=bx;
          if(bx+bw>bex) bex=bx+bw;
          const ord=PHASE_ORDER.filter(p=>ph.types.has(p));
          const oth=[...ph.types].filter(t=>!PHASE_ORDER.includes(t));
          const all=[...ord,...oth];
          if(!all.length) return;
          const sw=Math.max(1,Math.floor(bw/all.length));
          let segs='',sl=0;
          all.forEach((wt,si)=>{
            const w2=si===all.length-1?Math.max(1,bw-sl):sw;
            const col=PHASE_COLORS[wt]||'#6b7280';
            const sh=w2>=26?(PHASE_SHORT[wt]||''):'';
            segs+=`<span class="g2-seg" style="left:${sl}px;width:${w2}px;background:${col}">${esc(sh)}</span>`;
            sl+=w2;
          });
          const ad=((ti*8+ei)*35);
          bars+=`<div class="g2-bar${epic.blocking?' g2-bar-blocking':''}" style="left:${bx}px;width:${bw}px;animation-delay:${ad}ms">${segs}</div>`;
        };
        addBar(epic.phases.r120); addBar(epic.phases.r121); addBar(epic.phases.r122); addBar(epic.phases.ot);
        if(!Number.isFinite(bsx)){
          bsx=4; bex=Math.max(32,Math.round(8*dayPx));
          bars=`<div class="g2-bar g2-bar-backlog" style="left:4px;width:${bex}px"><span class="g2-seg" style="left:0;width:100%;background:#94a3b8">BL</span></div>`;
        }
        geometry[epic.name]={startX:bsx,endX:bex,top,midY:top+ROW_H/2,startDate:epic.start,endDate:epic.end};
        const depIn=deps[epic.name]||'';
        const depOut=depSrcSet.has(epic.name);
        const hx=Math.max(8,Math.min(totalW-28,bex+4));
        const catsHtml=epic.cats.slice(0,2).map(c=>`<span class="chip chip-indigo chip-xs">${esc(Utils.truncate(c,12))}</span>`).join('');
        const assignTxt=epic.assignees.slice(0,2).join(', ');
        const ad2=animIdx*22;
        const doneCls=epic.done?' g2-row-done':'';
        const blkCls=epic.blocking?' g2-row-blk':'';
        leftHtml+=`<div class="g2-epic-lc g2-lc${doneCls}${blkCls}" style="top:${top}px;height:${ROW_H}px;border-left:3px solid ${tc};animation-delay:${ad2}ms" data-epic="${esc(epic.name)}">
          <div class="g2-epic-title">${esc(Utils.truncate(epic.name,46))}</div>
          <div class="g2-epic-meta">${catsHtml}${assignTxt?`<span class="chip chip-gray chip-xs">${esc(Utils.truncate(assignTxt,18))}</span>`:''}${epic.riskCount?`<span class="g2-risk">⚠${epic.riskCount}</span>`:''}${depIn?`<span class="g2-dep-in" title="${esc('← '+depIn)}">←dep</span>`:''}${depOut?`<span class="g2-dep-out">dep→</span>`:''}<span class="g2-cnt">${epic.count}</span></div>
        </div>`;
        rightHtml+=`<div class="g2-epic-rc g2-rc${doneCls}${blkCls}" style="top:${top}px;height:${ROW_H}px;width:${totalW}px;animation-delay:${ad2}ms" data-epic="${esc(epic.name)}">
          ${bars}
          <button class="g2-handle" data-epic="${esc(epic.name)}" style="left:${hx}px" title="Тяни → создать зависимость (Finish-to-Start)">⊕</button>
        </div>`;
      });
    });

    const totalH=y;
    const todayHtml=todayX!==null?`<div class="g2-today" style="left:${todayX}px;height:${totalH}px"><div class="g2-today-pip"></div><div class="g2-today-lbl">Сегодня</div></div>`:'';
    const svgHtml=showDeps?GanttV2.buildSVG(deps,geometry,totalW,totalH):'';
    let gridLines='';
    for(let d=new Date(tS);d<tE;d=new Date(d.getFullYear(),d.getMonth()+1,1)){
      const x=dayOff(d);
      gridLines+=`<div class="g2-vline" style="left:${x}px;height:${totalH}px"></div>`;
    }

    wrap.innerHTML=`<div class="g2-shell">
      <div class="g2-scroller">
        <div class="g2-grid" style="min-width:${LEFT_W+totalW+2}px">
          <div class="g2-head" style="height:${HEAD_H}px;min-width:${LEFT_W+totalW+2}px">
            <div class="g2-head-l" style="width:${LEFT_W}px;min-width:${LEFT_W}px">Эпик / Команда</div>
            <div class="g2-head-r" style="width:${totalW}px">
              <div class="g2-months" style="width:${totalW}px">${monthHtml}</div>
              ${weekHtml?`<div class="g2-weeks" style="width:${totalW}px">${weekHtml}</div>`:''}
            </div>
          </div>
          <div class="g2-body" style="min-width:${LEFT_W+totalW+2}px">
            <div class="g2-col-l" style="width:${LEFT_W}px;min-width:${LEFT_W}px;height:${totalH}px">${leftHtml}</div>
            <div class="g2-col-r" style="width:${totalW}px;height:${totalH}px">
              <div class="g2-bands">${bandsHtml}</div>
              ${gridLines}
              ${rightHtml}
              ${todayHtml}
              ${svgHtml}
            </div>
          </div>
        </div>
      </div>
      <div class="g2-dep-list">${GanttV2.buildDepList(deps,geometry)}</div>
    </div>`;

    GanttV2.bindArrowDrag(wrap);
    GanttV2.bindArrowClick(wrap);
    const scroller=wrap.querySelector('.g2-scroller');
    if(scroller){
      let target=0;
      if(todayX!==null) target=Math.max(0,todayX-180);
      else if(Object.keys(geometry).length){
        const firstX=Math.min(...Object.values(geometry).map(g=>g.startX).filter(Number.isFinite));
        if(Number.isFinite(firstX)) target=Math.max(0,firstX-60);
      }
      scroller.scrollLeft=target;
    }
  },
  buildSVG(deps,geometry,totalW,totalH) {
    if(!deps||!Object.keys(deps).length) return '';
    const esc=Utils.escapeHtml;
    const paths=[];
    Object.entries(deps).forEach(([target,source],i)=>{
      const src=geometry[source],dst=geometry[target];
      if(!src||!dst) return;
      const sx=src.endX+8, sy=src.midY;
      const tx=Math.max(src.endX+30,dst.startX-8), ty=dst.midY;
      const conflict=!!(src.endDate&&dst.startDate&&dst.startDate<src.endDate);
      const stroke=conflict?'#dc2626':'#6366f1';
      const mid=conflict?'g2m-red':'g2m-ind';
      const dx=Math.abs(tx-sx);
      const tension=Math.max(60,dx*0.5);
      const d=`M${sx},${sy} C${sx+tension},${sy} ${tx-tension},${ty} ${tx},${ty}`;
      const len=Math.hypot(tx-sx,ty-sy)*1.4+100;
      paths.push({d,stroke,mid,conflict,len,source,target,i});
    });
    if(!paths.length) return '';
    return `<svg class="g2-dep-svg" style="position:absolute;top:0;left:0;width:${totalW}px;height:${totalH}px;overflow:visible;pointer-events:none" viewBox="0 0 ${totalW} ${totalH}">
      <defs>
        <marker id="g2m-ind" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto"><path d="M0,1 L9,4.5 L0,8 z" fill="#6366f1"/></marker>
        <marker id="g2m-red" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto"><path d="M0,1 L9,4.5 L0,8 z" fill="#dc2626"/></marker>
      </defs>
      ${paths.map(p=>`<path class="g2-dep-path${p.conflict?' g2-dep-conflict':''}" d="${p.d}" stroke="${p.stroke}" stroke-width="${p.conflict?2.4:1.9}" stroke-linecap="round" fill="none" marker-end="url(#${p.mid})" opacity="${p.conflict?0.9:0.72}" data-source="${esc(p.source)}" data-target="${esc(p.target)}" style="pointer-events:stroke;stroke-dasharray:${p.len};stroke-dashoffset:${p.len};animation:g2DrawArrow ${0.55+p.i*0.07}s ${0.05+p.i*0.03}s ease-out forwards"><title>${esc(p.source)} → ${esc(p.target)}${p.conflict?'\n⚠ Конфликт: цель начинается до конца источника':''}</title></path>`).join('')}
    </svg>`;
  },
  buildDepList(deps,geometry) {
    const esc=Utils.escapeHtml;
    const items=Object.entries(deps).filter(([t,s])=>geometry[t]&&geometry[s]);
    if(!items.length) return '<span class="g2-dep-empty">Зависимостей нет — тяните ⊕ для создания</span>';
    return items.map(([t,s])=>{
      const conflict=!!(geometry[s]&&geometry[t]&&geometry[s].endDate&&geometry[t].startDate&&geometry[t].startDate<geometry[s].endDate);
      return `<span class="g2-dep-pill${conflict?' g2-dep-conflict-pill':''}">
        <span class="g2-dep-src">${esc(Utils.truncate(s,16))}</span><span class="g2-dep-arr">→</span><span class="g2-dep-tgt">${esc(Utils.truncate(t,16))}</span>${conflict?'<span class="g2-dep-warn">⚠</span>':''}
        <button class="g2-dep-del" data-target="${esc(t)}" title="Удалить">×</button></span>`;
    }).join('');
  },
  bindArrowClick(wrap) {
    wrap.querySelectorAll('.g2-dep-path').forEach(path=>{
      path.style.pointerEvents='stroke';
      path.addEventListener('dblclick',e=>{
        e.preventDefault();
        const target=path.dataset.target;
        if(!target) return;
        delete state.epicDeps[target];
        Storage.save();
        GanttV2.renderChart();
      });
      path.addEventListener('mouseenter',()=>path.style.filter='drop-shadow(0 0 4px '+path.getAttribute('stroke')+')');
      path.addEventListener('mouseleave',()=>path.style.filter='');
    });
    wrap.querySelectorAll('.g2-dep-del').forEach(btn=>{
      btn.addEventListener('click',e=>{
        e.preventDefault();
        const target=btn.dataset.target;
        if(!target) return;
        delete state.epicDeps[target];
        Storage.save();
        GanttV2.renderChart();
      });
    });
  },
  bindArrowDrag(wrap) {
    let drag=null,ghostSvg=null,ghostPath=null,dropEl=null;
    const clear=()=>{
      if(ghostSvg) ghostSvg.remove();
      if(dropEl) dropEl.classList.remove('g2-drop-target');
      drag=null;ghostSvg=null;ghostPath=null;dropEl=null;
      document.removeEventListener('mousemove',onMove);
      document.removeEventListener('mouseup',onUp);
      document.removeEventListener('keydown',onKey);
      window.removeEventListener('blur', onBlur);
    };
    const onBlur = () => clear();
    GanttV2._cancelDrag = clear;
    const drawGhost=(sx,sy,tx,ty)=>{
      if(!ghostPath) return;
      const tension=Math.max(60,Math.abs(tx-sx)*0.5);
      ghostPath.setAttribute('d',`M${sx},${sy} C${sx+tension},${sy} ${tx-tension},${ty} ${tx},${ty}`);
    };
    const epicAt=(x,y)=>{
      const el=document.elementFromPoint(x,y);
      return el&&el.closest?el.closest('.g2-epic-rc')||el.closest('.g2-epic-lc'):null;
    };
    const onMove=e=>{
      if(!drag) return;
      drawGhost(drag.sx,drag.sy,e.clientX,e.clientY);
      const r=epicAt(e.clientX,e.clientY);
      const valid=r&&r.dataset.epic&&r.dataset.epic!==drag.epic?r:null;
      if(dropEl&&dropEl!==valid) dropEl.classList.remove('g2-drop-target');
      if(valid&&dropEl!==valid) valid.classList.add('g2-drop-target');
      dropEl=valid;
    };
    const onUp=e=>{
      if(!drag) return;
      const r=epicAt(e.clientX,e.clientY);
      const target=r?r.dataset.epic||'':'';
      const source=drag.epic;
      clear();
      if(!target||!source||target===source) return;
      state.epicDeps[target]=source;
      Storage.save();
      GanttV2.renderChart();
    };
    const onKey=e=>{if(e.key==='Escape') clear();};
    wrap.querySelectorAll('.g2-handle').forEach(btn=>{
      btn.addEventListener('mousedown',e=>{
        e.preventDefault();
        e.stopPropagation();
        clear();
        const row=btn.closest('.g2-epic-rc');
        if(!row) return;
        const epicName=row.dataset.epic||btn.dataset.epic||'';
        if(!epicName) return;
        drag={epic:epicName,sx:e.clientX,sy:e.clientY};
        const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
        svg.style.cssText='position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:9950;overflow:visible';
        const defs=document.createElementNS('http://www.w3.org/2000/svg','defs');
        defs.innerHTML='<marker id="g2ga" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto"><path d="M0,1 L9,4.5 L0,8 z" fill="#6366f1" opacity=".85"/></marker>';
        svg.appendChild(defs);
        const p=document.createElementNS('http://www.w3.org/2000/svg','path');
        p.setAttribute('stroke','#6366f1'); p.setAttribute('stroke-width','2.2');
        p.setAttribute('stroke-dasharray','8 5'); p.setAttribute('stroke-linecap','round');
        p.setAttribute('fill','none'); p.setAttribute('marker-end','url(#g2ga)');
        svg.appendChild(p);
        document.body.appendChild(svg);
        ghostSvg=svg; ghostPath=p;
        drawGhost(e.clientX,e.clientY,e.clientX,e.clientY);
        document.addEventListener('mousemove',onMove);
        document.addEventListener('mouseup',onUp);
        document.addEventListener('keydown',onKey);
        window.addEventListener('blur', onBlur);
      });
    });
  },
};

// ============================================================
// NAV
// ============================================================
const Nav = {
  init() {
    document.querySelectorAll('.nav-item[data-section]').forEach(btn=>{
      btn.addEventListener('click',()=>Nav.goTo(btn.dataset.section));
    });
  },
  goTo(section) {
    state.activeSection=section;
    document.querySelectorAll('.nav-item').forEach(b=>b.classList.remove('active'));
    const ab=document.querySelector(`.nav-item[data-section="${section}"]`); if(ab)ab.classList.add('active');
    document.querySelectorAll('.app-section').forEach(s=>s.classList.add('hidden'));
    const el=document.getElementById(`section-${section}`);
    if(el){
      el.classList.remove('hidden');
      el.classList.remove('section-enter');
      void el.offsetWidth;
      el.classList.add('section-enter');
      clearTimeout(Nav._sectionAnimT);
      Nav._sectionAnimT=setTimeout(()=>el.classList.remove('section-enter'),280);
    }
    App.renderSection(section);
  },
};

// ============================================================
// APP
// ============================================================
const App = {
  init() {
    Storage.loadSettings();
    syncColumnSettings();
    App.applyPresetsCollapsed();
    RegistryView.applyRowHeight();
    SidebarUI.init();
    ThemeUI.init();
    Nav.init();
    FiltersUI.init();
    App.bindImports();
    App.bindExport();
    App.bindClear();
    App.bindSave();
    App.bindAddRow();
    App.bindUndoRedo();
    App.bindColToggle();
    App.bindRegistrySettings();
    App.bindGanttModes();
    App.bindTimelineModes();
    App.bindPodlozhkaModes();
    App.bindSummaryModes();
    App.bindColOrderReset();
    App.bindPodlozhkaGroup();
    App.bindFullscreenRegistry();
    App.bindFilterToggle();
    App.bindPresetsCollapse();
    App.bindEmployees();
    App.bindGantt2Controls();
    App.bindCrossTabStorageSync();
    App.bindFilesDropdown();
    AppSettings.init();
    Onboarding.init();
    LLMAssistant.init();
    BulkEditPanel.bindUI();
    App.bindSimMode();
    App.bindInsightActions();
    JiraPulse.init();
    document.getElementById('modal-kpi-close').addEventListener('click', () => closeModal(document.getElementById('modal-kpi')));
    document.getElementById('modal-kpi').addEventListener('click', e => { if(e.target===document.getElementById('modal-kpi')) closeModal(document.getElementById('modal-kpi')); });

    const saved=Storage.load();
    if (saved&&saved.rows&&saved.rows.length>0) {
      const meta=document.getElementById('modal-restore-meta');
      meta.textContent=`Сохранено ${saved.rows.length} строк от ${new Date(saved.savedAt).toLocaleString('ru')}.`;
      document.getElementById('modal-restore').classList.remove('hidden');
      document.getElementById('btn-restore-yes').onclick=()=>{
        Storage.restore(saved); RiskEngine.computeAll();
        HistoryManager.clear();
        RegistryView.applyRowHeight();
        closeModal(document.getElementById('modal-restore'));
        App.populateFilterDropdowns(); App.renderSection('dashboard'); App.updateTopbarBadge();
      };
      document.getElementById('btn-restore-no').onclick=()=>{ Storage.clear(); HistoryManager.clear(); closeModal(document.getElementById('modal-restore')); App.renderSection('dashboard'); };
    } else { App.renderSection('dashboard'); }
    App.populateFilterDropdowns();
    App.updateTopbarBadge();
  },
  bindImports() {
    document.getElementById('input-xlsx').addEventListener('change',e=>{
      const f=e.target.files[0]; if(!f)return;
      const r=new FileReader(); r.onload=ev=>{ XLSXImporter.import(new Uint8Array(ev.target.result)); App.populateFilterDropdowns(); e.target.value=''; }; r.readAsArrayBuffer(f);
    });
    document.getElementById('input-csv').addEventListener('change',e=>{
      const f=e.target.files[0]; if(!f)return;
      const r=new FileReader(); r.onload=ev=>{ CSV.import(ev.target.result); App.populateFilterDropdowns(); e.target.value=''; }; r.readAsText(f,'utf-8');
    });
    const csvUpdate=document.getElementById('input-csv-update');
    if (csvUpdate) {
      csvUpdate.addEventListener('change',e=>{
        const f=e.target.files[0]; if(!f)return;
        const r=new FileReader();
        r.onload=ev=>{ CSV.importUpdate(ev.target.result); App.populateFilterDropdowns(); e.target.value=''; };
        r.readAsText(f,'utf-8');
      });
    }
  },
  bindExport() {
    document.getElementById('btn-export-csv').addEventListener('click',async ()=>{
      if(!state.rows.length){alert('Нет данных');return;}
      try { await CSV.export(); }
      catch(e){ console.error(e); showToast('Не удалось экспортировать CSV','error',2600); }
    });
  },
  bindClear() {
    document.getElementById('btn-clear-storage').addEventListener('click',()=>{
      if (confirm('Очистить все данные и настройки?')) {
        HistoryManager.checkpoint('очистка данных');
        Storage.clear(); state.rows=[]; state.diagnostics={sources:[],sheets:[],rowsPerSheet:{},detectedColumns:{},missingColumns:{},warnings:[],registryCount:0,csvImportCount:0,localStorageCount:0};
        state.employees=[];
        App.populateFilterDropdowns(); App.refreshAll(); App.updateTopbarBadge();
      }
    });
  },
  bindSave() { document.getElementById('btn-save').addEventListener('click',()=>forceSave()); },
  bindAddRow() { document.getElementById('btn-add-row').addEventListener('click',()=>RegistryView.addRow()); },
  bindUndoRedo() {
    const undoBtn=document.getElementById('btn-undo');
    const redoBtn=document.getElementById('btn-redo');
    if (undoBtn) undoBtn.addEventListener('click',()=>HistoryManager.undo());
    if (redoBtn) redoBtn.addEventListener('click',()=>HistoryManager.redo());
    document.addEventListener('keydown',e=>{
      const target=e.target;
      const mod=e.ctrlKey || e.metaKey;
      if (!mod) return;
      const registrySection=document.getElementById('section-registry');
      if (state.activeSection!=='registry' && !(registrySection && target instanceof Node && registrySection.contains(target))) return;
      if (e.key.toLowerCase()==='z' && !e.shiftKey) { e.preventDefault(); HistoryManager.undo(); return; }
      if ((e.key.toLowerCase()==='z' && e.shiftKey) || e.key.toLowerCase()==='y') { e.preventDefault(); HistoryManager.redo(); }
    });
    HistoryManager.syncButtons();
  },
  bindColToggle() {
    document.getElementById('btn-toggle-cols').addEventListener('click',()=>{
      const p=document.getElementById('col-toggle-panel'); p.classList.toggle('hidden'); if(!p.classList.contains('hidden'))RegistryView.renderColTogglePanel();
    });
  },
  bindRegistrySettings() {
    document.getElementById('btn-registry-settings').addEventListener('click',()=>{
      const p=document.getElementById('registry-settings-panel');
      p.classList.toggle('hidden');
      if (!p.classList.contains('hidden')) RegistryView.renderSettingsPanel();
    });
  },
  bindColOrderReset() {
    document.getElementById('btn-reset-col-order').addEventListener('click',()=>{
      HistoryManager.checkpoint('сброс порядка столбцов');
      state.colOrder=REGISTRY_COLS.map(c=>c.key);
      state.colWidths={};
      syncColumnSettings();
      Storage.save();
      RegistryView.render();
    });
  },
  bindGanttModes() {
    const group=document.querySelector('#section-gantt .btn-group');
    const epicsCtrl=document.getElementById('gantt-epics-controls');
    if (!group || !epicsCtrl) return;

    // Guard: if standalone HTML came from an older template, inject the missing button.
    if (!document.getElementById('gantt-mode-epics')) {
      const b=document.createElement('button');
      b.className='btn btn-sm btn-outline';
      b.id='gantt-mode-epics';
      b.dataset.mode='epics';
      b.textContent='По задачам';
      group.appendChild(b);
    }
    if (!document.getElementById('gantt-mode-ultra')) {
      const b=document.createElement('button');
      b.className='btn btn-sm btn-outline';
      b.id='gantt-mode-ultra';
      b.dataset.mode='ultra';
      b.textContent='Максимальная детализация';
      group.appendChild(b);
    }
    if (!document.getElementById('gantt-mode-detailed-tasks')) {
      const b=document.createElement('button');
      b.className='btn btn-sm btn-outline';
      b.id='gantt-mode-detailed-tasks';
      b.dataset.mode='detailedTasks';
      b.textContent='Детальный по задачам';
      group.appendChild(b);
    }
    if (!document.getElementById('gantt-mode-arrows')) {
      const b=document.createElement('button');
      b.className='btn btn-sm btn-outline';
      b.id='gantt-mode-arrows';
      b.dataset.mode='arrows';
      b.textContent='Со стрелками';
      group.appendChild(b);
    }

    const modes=new Set(['compact','detailed','detailedTasks','epics','arrows','ultra']);
    if (!modes.has(state.ganttMode)) state.ganttMode='compact';
    if (!['none','role','assignee'].includes(state.ganttEpicsWell)) state.ganttEpicsWell='none';

    const applyModeUi=()=>{
      const compactBtn=document.getElementById('gantt-mode-compact');
      const detailedBtn=document.getElementById('gantt-mode-detailed');
      const detailedTasksBtn=document.getElementById('gantt-mode-detailed-tasks');
      const epicsBtn=document.getElementById('gantt-mode-epics');
      const arrowsBtn=document.getElementById('gantt-mode-arrows');
      const ultraBtn=document.getElementById('gantt-mode-ultra');
      [compactBtn,detailedBtn,detailedTasksBtn,epicsBtn,arrowsBtn,ultraBtn].forEach(btn=>{
        if (!btn) return;
        btn.classList.toggle('active',btn.dataset.mode===state.ganttMode);
      });
      epicsCtrl.classList.toggle('hidden',state.ganttMode!=='epics');
      document.querySelectorAll('[data-well]').forEach(b=>b.classList.toggle('active',b.dataset.well===state.ganttEpicsWell));
    };
    App.syncGanttModeUi=applyModeUi;
    applyModeUi();

    document.getElementById('gantt-mode-compact').addEventListener('click',()=>{
      state.ganttMode='compact';
      applyModeUi();
      Storage.save();
      GanttView.renderChart();
    });
    document.getElementById('gantt-mode-detailed').addEventListener('click',()=>{
      state.ganttMode='detailed';
      applyModeUi();
      Storage.save();
      GanttView.renderChart();
    });
    document.getElementById('gantt-mode-epics').addEventListener('click',()=>{
      state.ganttMode='epics';
      applyModeUi();
      Storage.save();
      GanttView.renderChart();
    });
    document.getElementById('gantt-mode-detailed-tasks').addEventListener('click',()=>{
      state.ganttMode='detailedTasks';
      applyModeUi();
      Storage.save();
      GanttView.renderChart();
    });
    document.getElementById('gantt-mode-arrows').addEventListener('click',()=>{
      state.ganttMode='arrows';
      applyModeUi();
      Storage.save();
      GanttView.renderChart();
    });
    document.getElementById('gantt-mode-ultra').addEventListener('click',()=>{
      state.ganttMode='ultra';
      applyModeUi();
      Storage.save();
      GanttView.renderChart();
    });
    document.querySelectorAll('[data-well]').forEach(btn=>{
      btn.addEventListener('click',()=>{
        state.ganttEpicsWell=btn.dataset.well;
        applyModeUi();
        Storage.save();
        GanttView.renderChart();
      });
    });
  },
  bindTimelineModes() {
    const summaryBtn=document.getElementById('timeline-mode-summary');
    const detailedBtn=document.getElementById('timeline-mode-detailed');
    if (!summaryBtn || !detailedBtn) return;
    const sync=()=>{
      summaryBtn.classList.toggle('active',state.timelineMode!=='detailed');
      detailedBtn.classList.toggle('active',state.timelineMode==='detailed');
    };
    summaryBtn.addEventListener('click',()=>{ state.timelineMode='summary'; sync(); if(state.activeSection==='timeline')TimelineView.render(); });
    detailedBtn.addEventListener('click',()=>{ state.timelineMode='detailed'; sync(); if(state.activeSection==='timeline')TimelineView.render(); });
    sync();
  },
  bindSummaryModes() {
    const brief=document.getElementById('summary-mode-brief');
    const superBeautiful=document.getElementById('summary-mode-super-beautiful');
    if (!brief || !superBeautiful) return;
    const sync=()=>{
      brief.classList.toggle('active',state.summaryMode==='brief');
      superBeautiful.classList.toggle('active',state.summaryMode==='superBeautiful');
    };
    brief.addEventListener('click',()=>{
      state.summaryMode='brief';
      Storage.save();
      sync();
      if (state.activeSection==='summary') SummaryView.render();
    });
    superBeautiful.addEventListener('click',()=>{
      state.summaryMode='superBeautiful';
      Storage.save();
      sync();
      if (state.activeSection==='summary') SummaryView.render();
    });
    if (!['brief','superBeautiful'].includes(state.summaryMode)) state.summaryMode='brief';
    sync();
  },
  bindPodlozhkaModes() {
    const summary=document.getElementById('podlozhka-mode-summary');
    const detailed=document.getElementById('podlozhka-mode-detailed');
    if (!summary || !detailed) return;
    const sync=()=>{
      summary.classList.toggle('active',state.podlozhkaMode!=='detailed');
      detailed.classList.toggle('active',state.podlozhkaMode==='detailed');
    };
    summary.addEventListener('click',()=>{
      state.podlozhkaMode='summary';
      Storage.save();
      sync();
      if (state.activeSection==='podlozhka') PodlozhkaView.render();
    });
    detailed.addEventListener('click',()=>{
      state.podlozhkaMode='detailed';
      Storage.save();
      sync();
      if (state.activeSection==='podlozhka') PodlozhkaView.render();
    });
    sync();
  },
  bindPodlozhkaGroup() {
    const sel=document.getElementById('podlozhka-group');
    if (!sel) return;
    sel.value=state.podlozhkaGroup||'team';
    sel.addEventListener('change',e=>{ state.podlozhkaGroup=e.target.value; if(state.activeSection==='podlozhka')PodlozhkaView.render(); });
  },
  bindFullscreenRegistry() {
    const btn=document.getElementById('btn-fullscreen-registry');
    btn.addEventListener('click',()=>{
      document.body.classList.toggle('registry-fullscreen');
      btn.textContent=document.body.classList.contains('registry-fullscreen')?'✕ Выйти':'⛶';
      btn.title=document.body.classList.contains('registry-fullscreen')?'Выйти из полного экрана':'Полный экран';
    });
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('registry-fullscreen')){document.body.classList.remove('registry-fullscreen');btn.textContent='⛶';}});
  },
  bindFilterToggle() {
    const btn=document.getElementById('btn-toggle-filters');
    btn.addEventListener('click',()=>{
      document.body.classList.toggle('filters-hidden');
      btn.textContent=document.body.classList.contains('filters-hidden')?'▼ Фильтры':'▲ Фильтры';
    });
  },
  bindPresetsCollapse() {
    const btn=document.getElementById('btn-toggle-presets');
    if (!btn) return;
    btn.addEventListener('click',()=>{
      state.presetsCollapsed=!state.presetsCollapsed;
      App.applyPresetsCollapsed();
      Storage.save();
    });
  },
  applyPresetsCollapsed() {
    document.body.classList.toggle('presets-collapsed',!!state.presetsCollapsed);
  },
  bindEmployees() {
    const addBtn=document.getElementById('btn-add-employee');
    if (addBtn) addBtn.addEventListener('click',()=>{
      state.employees.push(EmployeeFactory.create({sourceType:'manual'}));
      Storage.save();
      App.populateFilterDropdowns();
      if (state.activeSection==='employees') EmployeesView.render();
      showToast('Сотрудник добавлен');
    });
    const importCsv=document.getElementById('input-employees-csv');
    if (importCsv) {
      importCsv.addEventListener('change',e=>{
        const f=e.target.files[0]; if(!f)return;
        const r=new FileReader();
        r.onload=ev=>{ EmployeesView.importCSV(ev.target.result); e.target.value=''; };
        r.readAsText(f,'utf-8');
      });
    }
    const importXlsx=document.getElementById('input-employees-xlsx');
    if (importXlsx) {
      importXlsx.addEventListener('change',e=>{
        const f=e.target.files[0]; if(!f)return;
        const r=new FileReader();
        r.onload=ev=>{ EmployeesView.importXLSX(new Uint8Array(ev.target.result)); e.target.value=''; };
        r.readAsArrayBuffer(f);
      });
    }
  },
  bindCrossTabStorageSync() {
    if (App._storageSyncBound) return;
    App._storageSyncBound = true;
    window.addEventListener('storage', (e) => {
      if (!e || (e.key !== STORAGE_KEY && e.key !== SETTINGS_KEY)) return;
      showToast('Данные были изменены в другой вкладке. Обновите страницу, чтобы синхронизироваться.', 'error', 3800);
    });
  },
  bindGantt2Controls() {
    const zoomIn=document.getElementById('gantt2-zoom-in');
    const zoomOut=document.getElementById('gantt2-zoom-out');
    const todayBtn=document.getElementById('gantt2-today-btn');
    const teamSel=document.getElementById('gantt2-team-filter');
    const showDeps=document.getElementById('gantt2-show-deps');
    if(zoomIn) zoomIn.addEventListener('click',()=>{ GanttV2.setZoom(GanttV2.getZoom()*1.35); });
    if(zoomOut) zoomOut.addEventListener('click',()=>{ GanttV2.setZoom(GanttV2.getZoom()/1.35); });
    if(todayBtn) todayBtn.addEventListener('click',()=>{
      const scroller=document.querySelector('#gantt2-wrap .g2-scroller');
      const todayLine=scroller&&scroller.querySelector('.g2-today');
      if(scroller&&todayLine){
        const left=parseInt(todayLine.style.left,10)||0;
        scroller.scrollTo({left:Math.max(0,left-200),behavior:'smooth'});
      }
    });
    if(teamSel) teamSel.addEventListener('change',e=>{
      state.gantt2Team=e.target.value;
      Storage.save();
      if(state.activeSection==='gantt2') GanttV2.render();
    });
    if(showDeps) showDeps.addEventListener('change',e=>{
      state.gantt2ShowDeps=e.target.checked;
      Storage.save();
      if(state.activeSection==='gantt2') GanttV2.renderChart();
    });
  },
  renderLegend(targetId, items) {
    const el=document.getElementById(targetId);
    if (!el) return;
    if (!items || !items.length) { el.innerHTML=''; return; }
    el.innerHTML=items.map(item=>{
      if (item.color) {
        return `<span class="legend-item-inline"><span class="legend-dot" style="background:${item.color}"></span>${Utils.escapeHtml(item.label)}</span>`;
      }
      return `<span class="legend-item-inline">${Utils.escapeHtml(item.label)}</span>`;
    }).join('');
  },
  renderSectionLegends(section) {
    const legendsBySection={
      dashboard:[
        {color:'#4f46e5',label:'Релизы: 1.20 / 1.21 / 1.22'},
        {color:'#dc2626',label:'Красный: блокеры и овертайм'},
        {color:'#f59e0b',label:'Жёлтый: требует подтверждения'},
        {color:'#059669',label:'Зелёный: в scope / сделано'},
      ],
      registry:[],
      gantt:[
        {color:'#4f46e5',label:'Линии зависимостей'},
        {color:'#dc2626',label:'Конфликт зависимости по срокам'},
        {label:'◎ Перетяните с задачи на задачу для связи'},
      ],
      gantt2:[
        {color:'#6366f1',label:'Плавные bezier-стрелки зависимостей'},
        {color:'#dc2626',label:'Красная стрелка: конфликт сроков'},
        {label:'⊕ Тяните с правого края эпика для связи'},
        {label:'Двойной клик по стрелке — удалить связь'},
      ],
      kanban:[
        {color:'#dc2626',label:'Красная рамка: блокер'},
        {color:'#f59e0b',label:'Жёлтая рамка: риск'},
        {color:'#9ca3af',label:'Полупрозрачность: сделано'},
      ],
      timeline:[
        {color:'#4f46e5',label:'Стадии релизов'},
        {color:'#059669',label:'Распределение работ'},
        {color:'#d97706',label:'Статусы scope'},
      ],
      podlozhka:[
        {color:'#dc2626',label:'Рисковые строки'},
        {color:'#059669',label:'Сделанные строки'},
        {label:'Режим «Детализированное» показывает видимые столбцы реестра'},
      ],
      employees:[
        {color:'#4f46e5',label:'Роли и команды как теги'},
        {color:'#dc2626',label:'OT: задачи сотрудника в овертайме'},
        {label:'Кнопка «Задачи» раскрывает связанный список из реестра'},
      ],
      summary:[
        {color:'#4f46e5',label:'Ключевые KPI для CEO'},
        {color:'#059669',label:'Прогресс выполнения'},
        {color:'#dc2626',label:'Точки риска и блокировки'},
      ],
      metrics:[
        {color:'#4f46e5',label:'SLA сроков и зависимостное давление'},
        {color:'#14b8a6',label:'Scope mix и портфель типов работ'},
        {color:'#ef4444',label:'Операционные и качественные сигналы'},
      ],
      insights:[
        {color:'#dc2626',label:'High: критический сигнал'},
        {color:'#f59e0b',label:'Medium: требует внимания'},
        {color:'#22c55e',label:'Low: наблюдение'},
      ],
      diagnostics:[
        {label:'Показывает источник данных и качество импорта'},
      ],
    };
    const targetMap={
      dashboard:'dashboard-legend',
      registry:'registry-legend',
      gantt:'gantt-legend-extra',
      gantt2:'gantt2-legend',
      kanban:'kanban-legend',
      timeline:'timeline-legend-extra',
      podlozhka:'podlozhka-legend',
      employees:'employees-legend',
      summary:'summary-legend',
      metrics:'metrics-legend',
      insights:'insights-legend',
      diagnostics:'diagnostics-legend',
    };
    Object.entries(targetMap).forEach(([key,id])=>App.renderLegend(id,key===section?legendsBySection[key]:[]));
  },
  populateFilterDropdowns() { FiltersUI.populateDropdowns(); },
  renderSection(s) {
    if (App.syncGanttModeUi) App.syncGanttModeUi();
    if(s==='dashboard')DashboardView.render();
    else if(s==='registry')RegistryView.render();
    else if(s==='gantt')GanttView.render();
    else if(s==='gantt2')GanttV2.render();
    else if(s==='kanban')KanbanView.render();
    else if(s==='timeline')TimelineView.render();
    else if(s==='podlozhka')PodlozhkaView.render();
    else if(s==='employees')EmployeesView.render();
    else if(s==='summary')SummaryView.render();
    else if(s==='metrics')MetricsView.render();
    else if(s==='insights')InsightsView.render();
    else if(s==='diagnostics')DiagnosticsView.render();
    else if(s==='jira-pulse')JiraPulse.render();
    App.renderSectionLegends(s);
    if (typeof LLMAssistant !== 'undefined' && LLMAssistant.updateQuickPrompts) {
      LLMAssistant.updateQuickPrompts();
    }
    HistoryManager.syncButtons();
    App.animateSection(s);
  },
  animateSection(section) {
    const root=document.getElementById(`section-${section}`);
    if (!root) return;
    const now=Date.now();
    if (App._lastAnimAt && (now-App._lastAnimAt)<260) return;
    App._lastAnimAt=now;
    const targets=[...root.querySelectorAll('.kpi-card, .summary-card, .data-table-wrap, .insight-item, .kanban-card, .gantt-row, .gar-row, .timeline-section, .diag-card, .employee-card, .metrics-card, .metrics-person, .metrics-signal, .view-legend .legend-item-inline, .preset-btn, .preset-role-btn')].slice(0,48);
    const bars=[...root.querySelectorAll('.mini-progress > span')].slice(0,32);
    targets.forEach((el,idx)=>{
      el.classList.remove('ui-animate-item');
      el.style.animationDelay=`${Math.min(idx*10,150)}ms`;
    });
    bars.forEach((bar,idx)=>{
      bar.classList.remove('progress-animated');
      bar.style.animationDelay=`${Math.min(idx*14,170)}ms`;
    });
    requestAnimationFrame(()=>{
      targets.forEach(el=>el.classList.add('ui-animate-item'));
      bars.forEach(bar=>bar.classList.add('progress-animated'));
    });
    clearTimeout(App._animCleanupT);
    App._animCleanupT=setTimeout(()=>{
      targets.forEach(el=>{ el.classList.remove('ui-animate-item'); el.style.animationDelay=''; });
      bars.forEach(el=>{ el.classList.remove('progress-animated'); el.style.animationDelay=''; });
    },760);
  },
  refreshAll() { App.renderSection(state.activeSection); HistoryManager.syncButtons(); },
  refreshCurrentSection() { App.renderSection(state.activeSection); },
  refreshDashboardIfActive() { if(state.activeSection==='dashboard')DashboardView.render(); },
  updateTopbarBadge() {
    const b=document.getElementById('topbar-row-count');
    if(state.rows.length){b.textContent=state.rows.length+' задач';b.classList.remove('hidden');}else b.classList.add('hidden');
  },
  bindFilesDropdown() {
    const wrap = document.getElementById('files-dropdown-wrap');
    const btn  = document.getElementById('btn-files-dropdown');
    const menu = document.getElementById('files-dropdown-menu');
    if (!btn || !menu) return;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('hidden');
      btn.classList.toggle('active', !menu.classList.contains('hidden'));
    });
    // Close on outside click or file input change
    document.addEventListener('click', (e) => {
      if (!wrap.contains(e.target)) {
        menu.classList.add('hidden');
        btn.classList.remove('active');
      }
    });
    menu.querySelectorAll('input[type=file]').forEach(inp => {
      inp.addEventListener('change', () => {
        menu.classList.add('hidden');
        btn.classList.remove('active');
      });
    });
    document.getElementById('btn-export-csv')?.addEventListener('click', () => {
      menu.classList.add('hidden'); btn.classList.remove('active');
    });
    document.getElementById('btn-clear-storage')?.addEventListener('click', () => {
      menu.classList.add('hidden'); btn.classList.remove('active');
    });
  },

  bindSimMode() {
    const btn = document.getElementById('btn-sim-mode');
    if (btn) btn.addEventListener('click', () => SimMode.toggle());
  },

  bindInsightActions() {
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('.insight-action-btn');
      if (!btn) return;
      const action = btn.dataset.action;
      const rows = FilterEngine.getFiltered();
      if (action === 'assign_120') {
        const targets = rows.filter(r => r.isUnassigned && r.scopeStatus === 'Да');
        applyBulkAction(targets.map(r=>r.id), 'assign_release', { release:'120' });
      } else if (action === 'confirm_scope') {
        const targets = rows.filter(r => r.scopeStatus==='Требует подтверждения' && (r.hasRelease120||r.hasRelease121||r.hasRelease122||r.hasOvertime));
        applyBulkAction(targets.map(r=>r.id), 'set_scope', { scope:'Да' });
      } else if (action === 'clear_blockers') {
        const targets = rows.filter(r => r.blockingDependency && (r.hasRelease120||r.hasRelease121));
        applyBulkAction(targets.map(r=>r.id), 'clear_blocker', {});
      }
    });
  },
};

// ============================================================
// APP SETTINGS
// ============================================================
const NAV_SECTIONS = [
  { key:'dashboard',   label:'Дашборд' },
  { key:'registry',    label:'Реестр' },
  { key:'gantt',       label:'Гант' },
  { key:'gantt2',      label:'Гант 2.0' },
  { key:'kanban',      label:'Канбан' },
  { key:'timeline',    label:'Таймлайн' },
  { key:'podlozhka',   label:'Подложка' },
  { key:'employees',   label:'Сотрудники' },
  { key:'summary',     label:'Сводная' },
  { key:'metrics',     label:'Метрики' },
  { key:'insights',    label:'Инсайты' },
  { key:'diagnostics', label:'Диагностика' },
  { key:'jira-pulse',  label:'Jira Pulse' },
];
const APP_SETTINGS_KEY = 'sbof_app_settings_v1';

const AppSettings = {
  defaults() {
    return { hiddenSections: [] };
  },
  load() {
    try { return { ...AppSettings.defaults(), ...JSON.parse(localStorage.getItem(APP_SETTINGS_KEY) || '{}') }; }
    catch(_) { return AppSettings.defaults(); }
  },
  save(cfg) { localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(cfg)); },
  apply(cfg) {
    NAV_SECTIONS.forEach(s => {
      const hidden = cfg.hiddenSections.includes(s.key);
      const navBtn = document.querySelector(`.nav-item[data-section="${s.key}"]`);
      if (navBtn) navBtn.classList.toggle('nav-item-hidden', hidden);
    });
  },
  init() {
    const cfg = AppSettings.load();
    AppSettings.apply(cfg);

    const openBtn = document.getElementById('btn-app-settings');
    const modal   = document.getElementById('app-settings-modal');
    const closeBtn = document.getElementById('app-settings-close');
    const saveBtn  = document.getElementById('app-settings-save');
    const resetBtn = document.getElementById('app-settings-reset');
    const togglesWrap = document.getElementById('app-settings-nav-toggles');
    if (!openBtn || !modal) return;

    openBtn.addEventListener('click', () => {
      AppSettings.renderToggles(togglesWrap, AppSettings.load());
      modal.classList.remove('hidden');
    });
    closeBtn?.addEventListener('click', () => closeModal(modal));
    modal.addEventListener('click', e => { if (e.target === modal) closeModal(modal); });

    saveBtn?.addEventListener('click', () => {
      const hidden = [];
      togglesWrap.querySelectorAll('input[type=checkbox]').forEach(cb => {
        if (!cb.checked) hidden.push(cb.dataset.section);
      });
      const newCfg = { hiddenSections: hidden };
      AppSettings.save(newCfg);
      AppSettings.apply(newCfg);
      closeModal(modal);
      showToast('Настройки сохранены');
    });

    resetBtn?.addEventListener('click', () => {
      localStorage.removeItem(APP_SETTINGS_KEY);
      AppSettings.apply(AppSettings.defaults());
      AppSettings.renderToggles(togglesWrap, AppSettings.defaults());
      showToast('Настройки сброшены');
    });
  },
  renderToggles(wrap, cfg) {
    if (!wrap) return;
    wrap.innerHTML = NAV_SECTIONS.map(s => `
      <label class="app-settings-toggle-row">
        <input type="checkbox" data-section="${s.key}" ${cfg.hiddenSections.includes(s.key) ? '' : 'checked'}>
        <span>${s.label}</span>
      </label>`).join('');
  },
};

// ============================================================
// ONBOARDING
// ============================================================
const Onboarding = {
  _step: 0,
  // section: which nav section to switch to before highlighting
  // selector: what element to highlight (null = highlight the nav button itself)
  _steps: [
    { section: null,         navKey: null,          selector: '#topbar',             title: 'Шапка и сохранение',        text: 'Кнопка «Сохранить» пересчитывает риски и сохраняет всё в браузере. «Файлы» — импорт и экспорт данных. Иконки справа — настройки и обучение.' },
    { section: null,         navKey: null,          selector: '#btn-files-dropdown', title: 'Импорт и экспорт — «Файлы»', text: 'Импортируйте план из XLSX или CSV. «CSV update» обновляет только изменённые строки. Экспортируйте текущий план в CSV.' },
    { section: null,         navKey: null,          selector: '#global-filters-bar', title: 'Фильтры и пресеты',          text: 'Фильтруйте задачи по команде, scope, релизу, исполнителю. Пресеты сохраняют типовые наборы фильтров для быстрого доступа.' },
    { section: 'dashboard',  navKey: 'dashboard',   selector: '#section-dashboard',  title: 'Дашборд',                   text: 'Главный экран: KPI, риски, прогресс по релизам, задачи без релиза и требующие подтверждения. Обновляется автоматически при изменении данных.' },
    { section: 'registry',   navKey: 'registry',    selector: '#section-registry',   title: 'Реестр — основа данных',     text: 'Таблица всех задач. Редактируйте поля прямо в ячейках. Колонка «Действия» справа — копирование и удаление строк. Столбцы можно закрепить, перетащить, скрыть.' },
    { section: 'insights',   navKey: 'insights',    selector: '#section-insights',   title: 'Инсайты и риски',            text: 'Автоматический анализ проблем: задачи без релиза, блокеры, задачи «Требует подтверждения», перегрузка релизов. Обновляется при каждом сохранении.' },
    { section: 'gantt',      navKey: 'gantt',       selector: '#section-gantt',      title: 'Гант по релизам',            text: 'Временная шкала задач по релизам. Несколько режимов: компактный, детальный, по задачам, со стрелками зависимостей.' },
    { section: 'gantt2',     navKey: 'gantt2',      selector: '#section-gantt2',     title: 'Гант 2.0 — Эпики',           text: 'Расширенный гант с зависимостями между эпиками. Масштаб, фильтр по команде, кнопка «Сегодня» для быстрой навигации.' },
    { section: 'kanban',     navKey: 'kanban',      selector: '#section-kanban',     title: 'Канбан по релизам',          text: 'Карточки задач сгруппированы по релизам. Перетаскивайте карточку для смены релиза. Цветовые метки: блокеры, риски, готово.' },
    { section: 'summary',    navKey: 'summary',     selector: '#section-summary',    title: 'Сводная для CEO',            text: 'Агрегированный отчёт: прогресс по командам и релизам, ключевые риски. Режим «Совсем красиво» — презентационный вид.' },
    { section: 'dashboard',  navKey: null,          selector: '#assistant-fab',      title: 'СБОФ Планировщик (AI)',      text: 'Кнопка в правом нижнем углу открывает AI-помощника. Задавайте вопросы по данным на русском: риски, статус, рекомендации.' },
  ],
  init() {
    const btn = document.getElementById('btn-onboarding');
    if (btn) btn.addEventListener('click', () => Onboarding.start());
    document.getElementById('onboarding-next')?.addEventListener('click', () => Onboarding.next());
    document.getElementById('onboarding-prev')?.addEventListener('click', () => Onboarding.prev());
    document.getElementById('onboarding-skip')?.addEventListener('click', () => Onboarding.end());
    document.querySelector('.onboarding-backdrop')?.addEventListener('click', () => Onboarding.end());
  },
  start() {
    Onboarding._step = 0;
    document.getElementById('onboarding-overlay')?.classList.remove('hidden');
    Onboarding.show(0);
  },
  show(idx) {
    const steps = Onboarding._steps;
    if (idx < 0 || idx >= steps.length) { Onboarding.end(); return; }
    Onboarding._step = idx;
    const step = steps[idx];

    // Update text first
    document.getElementById('onboarding-title').textContent = step.title;
    document.getElementById('onboarding-text').textContent  = step.text;
    document.getElementById('onboarding-step-badge').textContent = `${idx + 1} / ${steps.length}`;
    document.getElementById('onboarding-prev').disabled = idx === 0;
    document.getElementById('onboarding-next').textContent = idx === steps.length - 1 ? 'Завершить' : 'Далее →';

    // Switch section if needed, then measure after layout settles
    const doHighlight = () => {
      const target = document.querySelector(step.selector);
      if (!target) return;
      target.scrollIntoView({ block: 'center', behavior: 'instant' });
      // Double rAF: first frame commits scroll, second measures
      requestAnimationFrame(() => requestAnimationFrame(() => {
        Onboarding._positionHighlight(target);
      }));
    };

    if (step.section) {
      Nav.go(step.section);
      // Wait for section render (one tick) then measure
      setTimeout(doHighlight, 60);
    } else {
      doHighlight();
    }
  },
  _positionHighlight(target) {
    const highlight = document.getElementById('onboarding-highlight');
    const tooltip   = document.getElementById('onboarding-tooltip');
    if (!highlight || !tooltip) return;

    const r = target.getBoundingClientRect();
    const pad = 8;
    const hl = {
      left:   r.left   - pad,
      top:    r.top    - pad,
      width:  r.width  + pad * 2,
      height: r.height + pad * 2,
    };
    highlight.style.left   = `${hl.left}px`;
    highlight.style.top    = `${hl.top}px`;
    highlight.style.width  = `${hl.width}px`;
    highlight.style.height = `${hl.height}px`;

    // Place tooltip: prefer below, fall back to above, clamp horizontally
    const tipW = 320; const tipH = 200; const gap = 14;
    let tipTop  = hl.top + hl.height + gap;
    if (tipTop + tipH > window.innerHeight - 12) tipTop = hl.top - tipH - gap;
    tipTop = Math.max(12, tipTop);
    const tipLeft = Math.max(12, Math.min(hl.left, window.innerWidth - tipW - 12));
    tooltip.style.left = `${tipLeft}px`;
    tooltip.style.top  = `${tipTop}px`;
  },
  next() {
    if (Onboarding._step >= Onboarding._steps.length - 1) { Onboarding.end(); return; }
    Onboarding.show(Onboarding._step + 1);
  },
  prev() { Onboarding.show(Onboarding._step - 1); },
  end() {
    document.getElementById('onboarding-overlay')?.classList.add('hidden');
    const hl = document.getElementById('onboarding-highlight');
    if (hl) { hl.style.left = ''; hl.style.top = ''; hl.style.width = ''; hl.style.height = ''; }
  },
};

// ============================================================
// JIRA PULSE MODULE
// ============================================================
const JiraPulse = {
  // ---- State ----
  _report: null,
  _config: null,
  _loading: false,
  _activeTab: 'people',
  _activeArea: '__all__',    // '__all__' or projectKey
  _sprintArea: null,
  _backlogTab: 'summary',
  _backlogArea: '__all__',

  // ---- Utils ----
  _esc(s) { if(s==null)return''; return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); },
  _fmtDt(iso) { if(!iso)return''; return new Date(iso).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}); },
  _fmtDate(iso) { if(!iso)return''; return new Date(iso).toLocaleDateString('ru-RU',{day:'2-digit',month:'2-digit'}); },
  _fmtTime(iso) { if(!iso)return''; return new Date(iso).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}); },
  _daysSince(iso) { if(!iso)return null; return Math.floor((Date.now()-new Date(iso).getTime())/86400000); },
  _hrs(sec) { if(!sec)return''; const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60); return h&&m?`${h}ч ${m}м`:h?`${h}ч`:`${m}м`; },
  _inRange(iso, range) {
    if(!iso||!range)return false;
    const t=new Date(iso).getTime();
    return t>=new Date(range.from).getTime()&&t<new Date(range.to).getTime();
  },
  _colorFor(s) {
    let h=0; for(let i=0;i<(s||'').length;i++) h=(h*31+s.charCodeAt(i))>>>0;
    return `hsl(${h%360} 55% 42%)`;
  },
  _initials(name) {
    if(!name)return'?';
    const p=String(name).trim().split(/\s+/);
    return((p[0]?.[0]||'')+(p[1]?.[0]||'')).toUpperCase()||'?';
  },
  _issueUrl(key) {
    const base=(JiraPulse._config?.jiraBaseUrl||'').replace(/\/+$/,'');
    return base?`${base}/browse/${key}`:'#';
  },

  // ---- Status semantics ----
  _TERMINAL: ['done','closed','resolved','completed','cancel','rejected','uat','готово','закрыт','выполн','отмен','отклон'],
  _INITIAL:  ['open','to do','todo','backlog','created','new','draft','к выполнению','открыт','новая'],
  _isTerm(name) { if(!name)return false; const n=name.toLowerCase(); return JiraPulse._TERMINAL.some(h=>n.includes(h)); },
  _isInit(name) { if(!name)return true; const n=name.toLowerCase(); return JiraPulse._INITIAL.some(h=>n.includes(h)); },
  _statusCat(issue) { return issue.fields?.status?.statusCategory?.key||'new'; },
  _statusName(issue) { return issue.fields?.status?.name||''; },
  _isWip(issue) {
    const c=JiraPulse._statusCat(issue);
    if(c==='done')return false;
    if(c==='indeterminate')return true;
    const hist=issue.changelog?.histories||[];
    if(hist.some(h=>(h.items||[]).some(i=>i.field==='status')))return true;
    if((issue.fields?.worklog?.worklogs||[]).length)return true;
    if((issue.fields?.comment?.comments||[]).length)return true;
    return false;
  },
  _lastMov(issue) {
    const d=[];
    if(issue.fields?.updated)d.push(issue.fields.updated);
    for(const h of issue.changelog?.histories||[]) if(h.created)d.push(h.created);
    for(const w of issue.fields?.worklog?.worklogs||[]) if(w.started)d.push(w.started);
    for(const c of issue.fields?.comment?.comments||[]) if(c.created)d.push(c.created);
    return d.length?d.sort().at(-1):null;
  },
  _assignee(issue) {
    const a=issue.fields?.assignee; if(!a)return null;
    return { key:a.name||a.accountId||a.displayName, name:a.displayName||a.name||'—', login:a.name||a.accountId||'', email:a.emailAddress||'' };
  },
  _parentKey(issue) { return issue.fields?.parent?.key||null; },
  _isSubtask(issue) { return !!issue.fields?.issuetype?.subtask||/sub.?task|подзадача/i.test(issue.fields?.issuetype?.name||''); },
  _typeBucket(issue) {
    const t=(issue.fields?.issuetype?.name||'').toLowerCase();
    if(JiraPulse._isSubtask(issue))return'sub-task';
    if(/story|история/.test(t))return'story';
    if(/bug|баг|дефект/.test(t))return'bug';
    return'task';
  },
  _typeIcon(t) { return{story:'📗',task:'✅',bug:'🐞','sub-task':'↳'}[t]||'•'; },
  _typeLabel(t) { return{story:'Истории',task:'Задачи',bug:'Баги','sub-task':'Подзадачи'}[t]||t; },
  _matchUser(person, login, email, name) {
    if(!person)return false;
    const nm=s=>(s||'').toLowerCase().replace(/^[^\\]+\\/,'');
    const lo=nm(login), em=(email||'').toLowerCase(), na=(name||'').toLowerCase();
    const pl=nm(person.login), pe=(person.email||'').toLowerCase(), pn=(person.name||'').toLowerCase();
    if(lo&&pl&&lo===pl)return true;
    if(em&&pe&&em===pe)return true;
    if(na&&pn&&na===pn)return true;
    if(em&&pl){const u=em.split('@')[0];if(u&&u===pl)return true;}
    return false;
  },

  // ---- Chips ----
  _statusChip(issue) {
    const c=JiraPulse._statusCat(issue), nm=JiraPulse._statusName(issue);
    const cls=c==='done'?'jp-chip-done':c==='indeterminate'?'jp-chip-wip':'jp-chip-todo';
    return`<span class="jp-chip ${cls}">${JiraPulse._esc(nm)}</span>`;
  },
  _prioChip(issue) {
    const p=issue.fields?.priority?.name; if(!p)return'';
    const cls={'Highest':'jp-prio-highest','High':'jp-prio-high','Medium':'jp-prio-medium','Low':'jp-prio-low','Lowest':'jp-prio-lowest'}[p]||'';
    return`<span class="jp-chip ${cls}">${JiraPulse._esc(p)}</span>`;
  },
  _areaChip(area) {
    if(!area)return'';
    return`<span class="jp-area-chip">${JiraPulse._esc(area.projectKey)}</span>`;
  },

  // ---- Extract activity ----
  _extractActivity(issue, range) {
    const out={transitions:[],worklogs:[],commits:[],prs:[],updatesByUser:{},comments:[]};
    for(const h of issue.changelog?.histories||[]) {
      if(!JiraPulse._inRange(h.created,range))continue;
      const user=h.author?.name||h.author?.displayName||'—';
      out.updatesByUser[user]=(out.updatesByUser[user]||0)+1;
      for(const it of h.items||[]) {
        if(it.field==='status') out.transitions.push({from:it.fromString,to:it.toString,at:h.created,by:user,byName:h.author?.displayName||user});
      }
    }
    for(const w of issue.fields?.worklog?.worklogs||[]) {
      if(!JiraPulse._inRange(w.started,range))continue;
      out.worklogs.push({authorLogin:w.author?.name||'',authorName:w.author?.displayName||w.author?.name||'—',timeSpentSeconds:w.timeSpentSeconds||0,started:w.started,comment:typeof w.comment==='string'?w.comment:''});
    }
    for(const c of issue.fields?.comment?.comments||[]) {
      if(!JiraPulse._inRange(c.created,range))continue;
      out.comments.push({authorLogin:c.author?.name||'',authorName:c.author?.displayName||c.author?.name||'—',at:c.created,body:typeof c.body==='string'?c.body:''});
    }
    return out;
  },

  // ---- Aggregate people ----
  _aggregatePeople(areas) {
    const report=JiraPulse._report;
    const ranges={yesterday:report.yesterdayRange,dayBefore:report.dayBeforeYesterdayRange,last48h:report.last48hRange};
    const people=new Map();
    const ensure=(a,areaInfo)=>{
      const key=a?a.key:'__unassigned__', name=a?a.name:'Без исполнителя', login=a?a.login:'', email=a?a.email:'';
      if(!people.has(key)) people.set(key,{key,name,login,email,areas:new Set(),inProgress:[],doneYesterday:[],doneDayBefore:[],yesterdayItems:[],dayBeforeItems:[],comments48h:[],stale:[],stats:{workSecYesterday:0,workSec48h:0,commits48h:0,prs48h:0}});
      const p=people.get(key);
      if(areaInfo) p.areas.add(areaInfo.projectKey+'|'+areaInfo.name);
      return p;
    };
    for(const area of areas) {
      const ai={name:area.name,projectKey:area.projectKey};
      for(const issue of area.issues||[]) {
        const a=JiraPulse._assignee(issue), p=ensure(a,ai);
        if(JiraPulse._isWip(issue)) p.inProgress.push({issue,area:ai});
        const yA=JiraPulse._extractActivity(issue,ranges.yesterday);
        const dA=JiraPulse._extractActivity(issue,ranges.dayBefore);
        const lA=JiraPulse._extractActivity(issue,ranges.last48h);
        const doneTrans=acts=>acts.transitions.filter(t=>JiraPulse._isTerm(t.to));
        const yDone=doneTrans(yA), dDone=doneTrans(dA);
        if(yDone.length) p.doneYesterday.push({issue,area:ai,toStatus:yDone.at(-1).to});
        if(dDone.length) p.doneDayBefore.push({issue,area:ai,toStatus:dDone.at(-1).to});
        const hasYAct=yA.transitions.length||yA.worklogs.length||Object.keys(yA.updatesByUser).length;
        const hasDAct=dA.transitions.length||dA.worklogs.length||Object.keys(dA.updatesByUser).length;
        if(hasYAct) p.yesterdayItems.push({issue,area:ai,ya:yA});
        if(hasDAct) p.dayBeforeItems.push({issue,area:ai,ya:dA});
        p.stats.workSecYesterday+=yA.worklogs.reduce((s,w)=>s+(w.timeSpentSeconds||0),0);
        p.stats.workSec48h+=lA.worklogs.reduce((s,w)=>s+(w.timeSpentSeconds||0),0);
        if(JiraPulse._isWip(issue)) {
          const mv=JiraPulse._lastMov(issue)||issue.fields?.updated;
          if(mv){ const d=JiraPulse._daysSince(mv); if(d!=null&&d>=report.staleDays) p.stale.push({issue,area:ai,daysIdle:d}); }
        }
      }
    }
    const un=people.get('__unassigned__');
    if(un&&!un.inProgress.length&&!un.yesterdayItems.length&&!un.doneYesterday.length) people.delete('__unassigned__');
    const arr=Array.from(people.values()).filter(p=>p.key!=='__unassigned__');
    arr.sort((a,b)=>(b.yesterdayItems.length+b.doneYesterday.length)-(a.yesterdayItems.length+a.doneYesterday.length)||(a.name||'').localeCompare(b.name||'','ru'));
    return{people:arr,unassigned:people.get('__unassigned__')||null};
  },

  // ---- Selected areas ----
  _selectedAreas(key) {
    const areas=JiraPulse._report?.areas||[];
    if(!key||key==='__all__')return areas;
    return areas.filter(a=>a.projectKey===key);
  },

  // ---- Issue line ----
  _issueLine(issue, area, extra={}) {
    const key=issue.key, summary=issue.fields?.summary||'';
    const right=[];
    if(area) right.push(JiraPulse._areaChip(area));
    right.push(JiraPulse._statusChip(issue));
    const pr=JiraPulse._prioChip(issue); if(pr)right.push(pr);
    if(extra.daysIdle!=null) right.push(`<span class="jp-chip jp-chip-stale">${extra.daysIdle} дн</span>`);
    if(extra.toStatus) right.push(`<span class="jp-chip jp-chip-done">→ ${JiraPulse._esc(extra.toStatus)}</span>`);
    const pk=JiraPulse._parentKey(issue);
    return`<div class="jp-issue">
      <a class="jp-issue-key" href="${JiraPulse._issueUrl(key)}" target="_blank" rel="noreferrer">${JiraPulse._esc(key)}</a>
      <div class="jp-issue-title">
        ${pk&&JiraPulse._isSubtask(issue)?`<span class="jp-parent">↳ ${JiraPulse._esc(pk)}</span>`:''}
        <span>${JiraPulse._esc(summary)}</span>
      </div>
      <div class="jp-issue-meta">${right.join(' ')}</div>
    </div>`;
  },

  // ---- Type groups ----
  _renderTypeGroups(issues, mapFn) {
    if(!issues.length)return'<div class="jp-empty">Нет задач.</div>';
    const order=['story','task','bug','sub-task'], byType=new Map();
    for(const it of issues){const t=JiraPulse._typeBucket(it);if(!byType.has(t))byType.set(t,[]);byType.get(t).push(it);}
    return order.filter(t=>byType.has(t)).map(t=>`
      <div class="jp-type-group">
        <div class="jp-type-header">${JiraPulse._typeIcon(t)} ${JiraPulse._typeLabel(t)} <span class="jp-count">${byType.get(t).length}</span></div>
        ${byType.get(t).map(mapFn).join('')}
      </div>`).join('');
  },

  // ---- Widgets ----
  _widgetBars(title, data, kind='') {
    if(!data.length)return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div class="jp-empty">Нет данных.</div></div>`;
    const max=Math.max(1,...data.map(d=>d.val));
    return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div>
      ${data.map(d=>`<div class="jp-hbar-row">
        <div class="jp-hbar-label" title="${JiraPulse._esc(d.name)}">${JiraPulse._esc(d.name)}</div>
        <div class="jp-hbar ${kind}"><span style="width:${(d.val/max*100).toFixed(1)}%"></span></div>
        <div class="jp-hbar-val">${d.val}</div>
      </div>`).join('')}
    </div>`;
  },
  _widgetHist(title, values, bins) {
    if(!values.length)return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div class="jp-empty">Нет данных.</div></div>`;
    const buckets=[];
    for(let i=0;i<bins.length;i++){
      const lo=bins[i],hi=i+1<bins.length?bins[i+1]:Infinity;
      const label=hi===Infinity?`${lo}+`:`${lo}–${hi-1}`;
      buckets.push({name:label+' дн',val:values.filter(v=>v>=lo&&v<hi).length});
    }
    return JiraPulse._widgetBars(title,buckets,'warn');
  },
  _widgetDonut(title, segments) {
    const total=segments.reduce((s,x)=>s+x.value,0);
    if(!total)return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div class="jp-empty">Нет данных.</div></div>`;
    const r=38,c=2*Math.PI*r;
    let acc=0;
    const rings=segments.map(s=>{
      const len=(s.value/total)*c, dasharray=`${len} ${c-len}`, rotate=(acc/total)*360-90;
      acc+=s.value;
      return`<circle cx="50" cy="50" r="${r}" fill="none" stroke="${s.color}" stroke-width="14" stroke-dasharray="${dasharray}" transform="rotate(${rotate} 50 50)"/>`;
    }).join('');
    const legend=segments.filter(s=>s.value>0).map(s=>`<div class="jp-donut-leg-item"><span style="background:${s.color}"></span>${JiraPulse._esc(s.label)} — ${s.value} (${Math.round(s.value/total*100)}%)</div>`).join('');
    return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div>
      <div class="jp-donut-wrap">
        <svg viewBox="0 0 100 100" width="110" height="110">
          <circle cx="50" cy="50" r="${r}" fill="none" stroke="var(--border-light)" stroke-width="14"/>
          ${rings}
          <text x="50" y="54" text-anchor="middle" font-size="13" fill="var(--text-1)">${total}</text>
        </svg>
        <div class="jp-donut-legend">${legend}</div>
      </div>
    </div>`;
  },
  _widgetTwo(title, left, right) {
    const cell=(x)=>`<div style="flex:1;text-align:center"><div class="jp-big" style="color:${x.kind==='good'?'#22c55e':x.kind==='bad'?'#ef4444':'var(--accent)'}">${x.value}</div><div class="jp-sub">${JiraPulse._esc(x.label)}</div></div>`;
    return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div style="display:flex;gap:18px;padding-top:8px">${cell(left)}${cell(right)}</div></div>`;
  },
  _insightCard(ins) {
    return`<div class="jp-insight jp-sev-${ins.sev}">
      <div class="jp-insight-icon">${ins.icon}</div>
      <div class="jp-insight-body">
        <div class="jp-insight-title">${JiraPulse._esc(ins.title)}</div>
        <div class="jp-insight-desc">${ins.desc||''}</div>
      </div>
      <div class="jp-insight-tag">${JiraPulse._esc(ins.tag||'')}</div>
    </div>`;
  },

  // ---- Stat cards ----
  _statCards(cards) {
    return`<div class="jp-stat-row">${cards.map(c=>`<div class="jp-stat-card jp-stat-${c.kind||''}">
      <div class="jp-stat-label">${JiraPulse._esc(c.label)}</div>
      <div class="jp-stat-value">${c.value}</div>
      ${c.sub?`<div class="jp-stat-sub">${JiraPulse._esc(c.sub)}</div>`:''}
    </div>`).join('')}</div>`;
  },

  // ---- Type breakdown bar ----
  _typeBreakdown(issues) {
    const types=['story','task','bug','sub-task'], total={done:0,wip:0,todo:0}, byType={};
    for(const t of types) byType[t]={done:0,wip:0,todo:0};
    for(const it of issues){
      const t=JiraPulse._typeBucket(it), cat=JiraPulse._statusCat(it), wip=JiraPulse._isWip(it);
      const b=cat==='done'?'done':wip?'wip':'todo';
      byType[t][b]++; total[b]++;
    }
    const rows=types.filter(t=>byType[t].done+byType[t].wip+byType[t].todo>0).map(t=>{
      const s=byType[t], sum=s.done+s.wip+s.todo||1, pct=n=>Math.round(n/sum*100);
      return`<div class="jp-type-row">
        <div class="jp-type-label">${JiraPulse._typeIcon(t)} ${JiraPulse._typeLabel(t)}</div>
        <div class="jp-seg-bar">
          <span class="jp-seg-done" style="width:${pct(s.done)}%" title="Готово: ${s.done}"></span>
          <span class="jp-seg-wip"  style="width:${pct(s.wip)}%"  title="В работе: ${s.wip}"></span>
          <span class="jp-seg-todo" style="width:${pct(s.todo)}%" title="Не взято: ${s.todo}"></span>
        </div>
        <div class="jp-type-counts">✅ ${s.done} · ▶ ${s.wip} · ☐ ${s.todo}</div>
      </div>`;
    }).join('');
    const legend=`<div class="jp-seg-legend"><span><span class="jp-dot jp-seg-done"></span>Готово</span><span><span class="jp-dot jp-seg-wip"></span>В работе</span><span><span class="jp-dot jp-seg-todo"></span>Не приступали</span></div>`;
    return legend+(rows||'<div class="jp-empty">Нет данных.</div>');
  },

  // ============ RENDER: PEOPLE ============
  renderPeople() {
    const areas=JiraPulse._selectedAreas(JiraPulse._activeArea);
    const {people,unassigned}=JiraPulse._aggregatePeople(areas);
    const sorted=[...people].sort((a,b)=>(a.name||'').localeCompare(b.name||'','ru'));
    const cards=sorted.map(p=>JiraPulse._personCard(p)).join('');
    const unCard=unassigned?JiraPulse._personCard(unassigned,true):'';
    return`<div class="jp-people-list">${cards||'<div class="jp-empty-card">Нет участников с активностью.</div>'}${unCard}</div>`;
  },
  _personCard(p, isUnassigned=false) {
    const report=JiraPulse._report;
    const badges=[];
    badges.push(`<span class="jp-badge jp-badge-info">в работе: ${p.inProgress.length}</span>`);
    if(p.doneYesterday.length) badges.push(`<span class="jp-badge jp-badge-good">✅ закрыто: ${p.doneYesterday.length}</span>`);
    if(p.stats.workSec48h) badges.push(`<span class="jp-badge">⏱ ${JiraPulse._hrs(p.stats.workSec48h)}</span>`);
    if(p.stale.length) badges.push(`<span class="jp-badge jp-badge-bad">🐌 висит: ${p.stale.length}</span>`);
    const areaList=Array.from(p.areas||[]).map(s=>{const[k,n]=s.split('|');return`<span class="jp-area-chip">${JiraPulse._esc(k)}</span>`;}).join(' ');

    const buildActList=(items)=>{
      if(!items.length)return'<div class="jp-empty">Без изменений.</div>';
      return JiraPulse._renderTypeGroups(items.map(x=>x.issue),(it)=>{
        const x=items.find(y=>y.issue.key===it.key), a=x?.ya, lines=[];
        for(const t of a?.transitions||[]) {
          const cls=JiraPulse._isTerm(t.to)?'jp-chip-done':'jp-chip-wip';
          lines.push(`<li>→ <span class="jp-chip ${cls}">${JiraPulse._esc(t.to)}</span> <span class="jp-muted">${JiraPulse._fmtTime(t.at)}</span></li>`);
        }
        for(const w of a?.worklogs||[]) lines.push(`<li>⏱ ${JiraPulse._hrs(w.timeSpentSeconds)}${w.comment?' — '+JiraPulse._esc(w.comment.slice(0,100)):''}</li>`);
        if(!lines.length&&Object.keys(a?.updatesByUser||{}).length) lines.push('<li>✎ правки полей</li>');
        return`<div class="jp-issue">
          <a class="jp-issue-key" href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>
          <div class="jp-issue-title"><span>${JiraPulse._esc(it.fields?.summary||'')}</span>${lines.length?`<ul class="jp-act-list">${lines.join('')}</ul>`:''}</div>
          <div class="jp-issue-meta">${x?.area?JiraPulse._areaChip(x.area):''} ${JiraPulse._statusChip(it)}</div>
        </div>`;
      });
    };

    const inProgressBody=JiraPulse._renderTypeGroups(p.inProgress.map(x=>x.issue),(it)=>{
      const x=p.inProgress.find(y=>y.issue.key===it.key);
      const mv=JiraPulse._lastMov(it)||it.fields?.updated, d=JiraPulse._daysSince(mv);
      return JiraPulse._issueLine(it,x?.area,d!=null&&d>=report.staleDays?{daysIdle:d}:{});
    });

    return`<details class="jp-person-card${isUnassigned?' jp-unassigned':''}">
      <summary class="jp-person-head">
        <div class="jp-avatar" style="background:${JiraPulse._colorFor(p.key||p.name)}">${JiraPulse._esc(JiraPulse._initials(p.name))}</div>
        <div class="jp-person-id">
          <div class="jp-person-name">${JiraPulse._esc(p.name)} ${areaList}</div>
          <div class="jp-person-login">${JiraPulse._esc(p.login||'')}</div>
        </div>
        <div class="jp-person-stats">${badges.join('')}</div>
      </summary>
      <details class="jp-section"><summary>В работе сейчас <span class="jp-count">${p.inProgress.length}</span></summary><div class="jp-section-body">${inProgressBody}</div></details>
      <details class="jp-section"><summary>Делал вчера <span class="jp-count">${p.yesterdayItems.length+p.doneYesterday.length}</span></summary><div class="jp-section-body">${buildActList(p.yesterdayItems)}</div></details>
      <details class="jp-section"><summary>Делал позавчера <span class="jp-count">${p.dayBeforeItems.length+p.doneDayBefore.length}</span></summary><div class="jp-section-body">${buildActList(p.dayBeforeItems)}</div></details>
      ${p.stale.length?`<details class="jp-section" open><summary>Висят > ${report.staleDays} дн <span class="jp-count">${p.stale.length}</span></summary><div class="jp-section-body">${p.stale.map(s=>JiraPulse._issueLine(s.issue,s.area,{daysIdle:s.daysIdle})).join('')}</div></details>`:''}
    </details>`;
  },

  // ============ RENDER: SUMMARY ============
  renderSummary() {
    const areas=JiraPulse._selectedAreas(JiraPulse._activeArea);
    if(!areas.length)return'<div class="jp-empty">Нет пространств.</div>';
    const allIssues=areas.flatMap(a=>a.issues||[]);
    const sprintSet=new Set(areas.flatMap(a=>a.sprintKeys||[]));
    const wip=allIssues.filter(JiraPulse._isWip).length;
    const {people}=JiraPulse._aggregatePeople(areas);
    const stale=people.reduce((s,p)=>s+p.stale.length,0);
    const doneY=people.reduce((s,p)=>s+p.doneYesterday.length,0);
    const statC=JiraPulse._statCards([
      {label:'В активных спринтах',value:[...sprintSet].length,kind:'info',sub:'задач'},
      {label:'В работе сейчас',value:wip,kind:''},
      {label:'Висят > N дней',value:stale,kind:'warn',sub:`порог ${JiraPulse._report.staleDays} дн`},
      {label:'Закрыто вчера',value:doneY,kind:'good'},
    ]);

    // Yesterday list
    const yRows=people.filter(p=>p.yesterdayItems.length||p.doneYesterday.length).slice(0,40).map(p=>{
      const bits=[]; if(p.doneYesterday.length)bits.push(`<span class="jp-chip jp-chip-done">✅ ${p.doneYesterday.length}</span>`);
      if(p.stats.workSecYesterday)bits.push(`<span class="jp-chip">⏱ ${JiraPulse._hrs(p.stats.workSecYesterday)}</span>`);
      const seen=new Set(), uniq=[]; for(const x of [...p.doneYesterday,...p.yesterdayItems]){if(seen.has(x.issue.key))continue;seen.add(x.issue.key);uniq.push(x);if(uniq.length>=6)break;}
      return`<div class="jp-issue"><div class="jp-issue-key">${JiraPulse._esc(p.name)}</div><div class="jp-issue-title">${uniq.map(x=>`<a class="jp-issue-key" href="${JiraPulse._issueUrl(x.issue.key)}" target="_blank">${JiraPulse._esc(x.issue.key)}</a>`).join(' ')}</div><div class="jp-issue-meta">${bits.join(' ')}</div></div>`;
    }).join('');
    const todayRows=people.filter(p=>p.inProgress.length).slice(0,30).map(p=>{
      const links=p.inProgress.slice(0,8).map(x=>`<a class="jp-issue-key" href="${JiraPulse._issueUrl(x.issue.key)}" target="_blank">${JiraPulse._esc(x.issue.key)}</a>`).join(' ');
      return`<div class="jp-issue"><div class="jp-issue-key">${JiraPulse._esc(p.name)}</div><div class="jp-issue-title">${links}</div><div class="jp-issue-meta"><span class="jp-chip">${p.inProgress.length}</span></div></div>`;
    }).join('');

    // Area cards (only if multiple areas)
    const areaCards=JiraPulse._activeArea==='__all__'?`<div class="jp-panel"><div class="jp-panel-title">Пространства</div><div class="jp-area-grid">${(JiraPulse._report?.areas||[]).map(a=>{
      const iss=a.issues||[], w=iss.filter(JiraPulse._isWip).length, bl=(a.backlogKeys||[]).length;
      const {people:ap}=JiraPulse._aggregatePeople([a]);
      const st=ap.reduce((s,p)=>s+p.stale.length,0), dy=ap.reduce((s,p)=>s+p.doneYesterday.length,0);
      const max=Math.max(w,st,dy,bl,1);
      return`<div class="jp-area-card"><div class="jp-area-card-title">${JiraPulse._esc(a.name)} <span class="jp-area-chip">${JiraPulse._esc(a.projectKey)}</span></div>
        <div class="jp-hbar-row"><div class="jp-hbar-label">В работе</div><div class="jp-hbar good"><span style="width:${w/max*100}%"></span></div><div class="jp-hbar-val">${w}</div></div>
        <div class="jp-hbar-row"><div class="jp-hbar-label">Висят</div><div class="jp-hbar warn"><span style="width:${st/max*100}%"></span></div><div class="jp-hbar-val">${st}</div></div>
        <div class="jp-hbar-row"><div class="jp-hbar-label">Закрыто вчера</div><div class="jp-hbar good"><span style="width:${dy/max*100}%"></span></div><div class="jp-hbar-val">${dy}</div></div>
        <div class="jp-hbar-row"><div class="jp-hbar-label">Бэклог</div><div class="jp-hbar"><span style="width:${bl/max*100}%"></span></div><div class="jp-hbar-val">${bl}</div></div>
      </div>`;
    }).join('')}</div></div>`:'';

    return`${statC}
      <div class="jp-panel"><div class="jp-panel-title">Разбивка по типам</div>${JiraPulse._typeBreakdown(allIssues.filter(it=>sprintSet.has(it.key)))}</div>
      ${areaCards}
      <div class="jp-two-col">
        <div class="jp-panel"><div class="jp-panel-title">Что делали вчера</div><div>${yRows||'<div class="jp-empty">Вчера тишина.</div>'}</div></div>
        <div class="jp-panel"><div class="jp-panel-title">План на сегодня</div><div>${todayRows||'<div class="jp-empty">Нет задач в работе.</div>'}</div></div>
      </div>`;
  },

  // ============ RENDER: SPRINTS ============
  renderSprints() {
    const areas=JiraPulse._report?.areas||[];
    if(!areas.length)return'<div class="jp-empty">Нет пространств.</div>';
    const sub=JiraPulse._sprintArea||areas[0]?.projectKey;
    JiraPulse._sprintArea=sub;
    const a=areas.find(x=>x.projectKey===sub)||areas[0];
    if(a?.error)return`<div class="jp-error">${JiraPulse._esc(a.error)}</div>`;
    const sprintIssues=(a.issues||[]).filter(it=>(a.sprintKeys||[]).includes(it.key));
    if(!sprintIssues.length)return`<div class="jp-empty-card"><p>В «${JiraPulse._esc(a.name)}» активный спринт не найден.</p></div>`;
    const total=sprintIssues.length, done=sprintIssues.filter(it=>JiraPulse._statusCat(it)==='done').length;
    const wip=sprintIssues.filter(JiraPulse._isWip).length, todo=total-done-wip;
    const pct=Math.round(done/total*100);
    const insights=JiraPulse._sprintInsights(a,sprintIssues);
    return`${JiraPulse._statCards([
      {label:'Всего',value:total,kind:'info',sub:'в активном спринте'},
      {label:'Готово',value:done,kind:'good',sub:`${pct}% спринта`},
      {label:'В работе',value:wip,kind:''},
      {label:'Не приступали',value:todo,kind:'warn'},
    ])}
    <div class="jp-panel"><div class="jp-panel-title">Типы задач — ${JiraPulse._esc(a.name)}</div>${JiraPulse._typeBreakdown(sprintIssues)}</div>
    <div class="jp-panel"><div class="jp-panel-title">Инсайты по спринту</div><div class="jp-insights-list">${insights.length?insights.map(JiraPulse._insightCard).join(''):'<div class="jp-empty">Сигналов нет.</div>'}</div></div>`;
  },
  _sprintInsights(a, si) {
    const ins=[], total=si.length;
    const done=si.filter(it=>JiraPulse._statusCat(it)==='done').length;
    const wip=si.filter(JiraPulse._isWip).length, todo=total-done-wip;
    if(todo/total>0.5) ins.push({sev:'warn',icon:'⏳',title:`${Math.round(todo/total*100)}% спринта не взято в работу`,desc:'Пора брать или резать scope.',tag:'scope'});
    if(wip/Math.max(1,total-done)>0.5) ins.push({sev:'warn',icon:'🪢',title:`WIP ${wip} из ${total-done} оставшихся (>50%)`,desc:'Слишком много задач в работе.',tag:'wip'});
    const counts=new Map(); for(const it of si){const ass=JiraPulse._assignee(it);const k=ass?ass.name:'—';counts.set(k,(counts.get(k)||0)+1);}
    const top=[...counts.entries()].sort((a,b)=>b[1]-a[1])[0];
    if(top&&top[1]/total>0.4&&top[0]!=='—') ins.push({sev:'warn',icon:'🧍',title:`Bus factor: ${JiraPulse._esc(top[0])} — ${top[1]} из ${total}`,desc:'',tag:'риск'});
    const bugs=si.filter(it=>JiraPulse._typeBucket(it)==='bug');
    if(bugs.length/total>0.3) ins.push({sev:'info',icon:'🐞',title:`Доля багов — ${Math.round(bugs.length/total*100)}%`,desc:'',tag:'quality'});
    const inWeek=si.filter(it=>{const d=it.fields?.duedate;if(!d||JiraPulse._statusCat(it)==='done')return false;const t=new Date(d).getTime();return t>Date.now()&&t<Date.now()+7*86400000;});
    if(inWeek.length) ins.push({sev:'warn',icon:'📅',title:`Срок ≤7 дней: ${inWeek.length}`,desc:inWeek.slice(0,6).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', '),tag:'deadline'});
    return ins;
  },

  // ============ RENDER: INSIGHTS ============
  renderInsights() {
    const areas=JiraPulse._selectedAreas(JiraPulse._activeArea);
    const list=JiraPulse._computeInsights(areas);
    return`<div class="jp-insights-list">${list.map(JiraPulse._insightCard).join('')||'<div class="jp-empty-card">🎉 Явных сигналов нет.</div>'}</div>`;
  },
  _computeInsights(areas) {
    const report=JiraPulse._report, ins=[];
    const {people}=JiraPulse._aggregatePeople(areas);
    const allIssues=areas.flatMap(a=>a.issues||[]);
    const sprintSet=new Set(areas.flatMap(a=>a.sprintKeys||[]));
    const wipIssues=allIssues.filter(JiraPulse._isWip);

    for(const a of areas) if(a.error) ins.push({sev:'bad',icon:'⛔',tag:'error',title:`Ошибка ${a.name}`,desc:JiraPulse._esc(a.error)});

    const staleAll=[]; for(const p of people) for(const s of p.stale) staleAll.push({...s,person:p});
    if(staleAll.length) ins.push({sev:'bad',icon:'🐌',tag:'стагнация',title:`Висит > ${report.staleDays} дн: ${staleAll.length}`,desc:staleAll.slice(0,8).map(s=>`<a href="${JiraPulse._issueUrl(s.issue.key)}" target="_blank">${JiraPulse._esc(s.issue.key)}</a> · ${s.daysIdle}дн · ${JiraPulse._esc(s.person.name)}`).join('<br>')});

    const silent=people.filter(p=>p.inProgress.length&&!p.yesterdayItems.length&&!p.doneYesterday.length);
    if(silent.length) ins.push({sev:'warn',icon:'🤫',tag:'тишина',title:`Без активности вчера: ${silent.length} чел.`,desc:silent.slice(0,10).map(p=>JiraPulse._esc(p.name)).join(' · ')});

    const overload=people.filter(p=>p.inProgress.length>3);
    if(overload.length) ins.push({sev:'warn',icon:'🧨',tag:'перегруз',title:`WIP > 3 у ${overload.length} чел.`,desc:overload.map(p=>`${JiraPulse._esc(p.name)} — ${p.inProgress.length}`).join(' · ')});

    const noAssignee=allIssues.filter(it=>!it.fields?.assignee&&sprintSet.has(it.key));
    if(noAssignee.length) ins.push({sev:'warn',icon:'👻',tag:'owner',title:`В спринте без исполнителя: ${noAssignee.length}`,desc:noAssignee.slice(0,8).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', ')});

    const today=new Date(); today.setHours(0,0,0,0);
    const overdue=allIssues.filter(it=>{const d=it.fields?.duedate;if(!d||JiraPulse._statusCat(it)==='done')return false;return new Date(d).getTime()<today.getTime();});
    if(overdue.length) ins.push({sev:'bad',icon:'⏰',tag:'срок',title:`Просрочены: ${overdue.length}`,desc:overdue.slice(0,8).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a> (до ${JiraPulse._fmtDate(it.fields.duedate)})`).join('<br>')});

    const hiTodo=allIssues.filter(it=>{const p=(it.fields?.priority?.name||'').toLowerCase();return['highest','high','blocker','critical'].includes(p)&&JiraPulse._statusCat(it)==='new'&&sprintSet.has(it.key);});
    if(hiTodo.length) ins.push({sev:'warn',icon:'🔥',tag:'prio',title:`Высокий приоритет не взят: ${hiTodo.length}`,desc:hiTodo.slice(0,8).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', ')});

    const doneTotal=people.reduce((s,p)=>s+p.doneYesterday.length,0);
    if(doneTotal){const top=people.filter(p=>p.doneYesterday.length).sort((a,b)=>b.doneYesterday.length-a.doneYesterday.length).slice(0,5);ins.push({sev:'good',icon:'✅',tag:'win',title:`Закрыто вчера: ${doneTotal}`,desc:top.map(p=>`${JiraPulse._esc(p.name)} — ${p.doneYesterday.length}`).join(' · ')});}

    const pp=allIssues.filter(it=>(it.changelog?.histories||[]).filter(h=>JiraPulse._inRange(h.created,report.yesterdayRange)&&(h.items||[]).some(i=>i.field==='status')).length>=3);
    if(pp.length) ins.push({sev:'warn',icon:'🏓',tag:'pingpong',title:`Скакали по статусам вчера: ${pp.length}`,desc:pp.slice(0,6).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', ')});

    const blockers=allIssues.filter(it=>{const p=(it.fields?.priority?.name||'').toLowerCase();if(!['blocker','highest','critical'].includes(p)||JiraPulse._statusCat(it)==='done')return false;const mv=JiraPulse._lastMov(it)||it.fields?.updated;return mv&&JiraPulse._daysSince(mv)>=1;});
    if(blockers.length) ins.push({sev:'bad',icon:'🛑',tag:'blocker',title:`Блокеры без апдейта ≥1 дня: ${blockers.length}`,desc:blockers.slice(0,6).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', ')});

    const orphanOpen=allIssues.filter(p=>JiraPulse._statusCat(p)==='done'&&(p.fields?.subtasks||[]).some(s=>s.fields?.status?.statusCategory?.key!=='done'));
    if(orphanOpen.length) ins.push({sev:'bad',icon:'🪤',tag:'sync',title:`Done, но открытые подзадачи: ${orphanOpen.length}`,desc:orphanOpen.slice(0,6).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', ')});

    if(!wipIssues.length) ins.push({sev:'info',icon:'📭',tag:'empty',title:'В работе нет задач',desc:'Никто ничего не двигает.'});
    return ins;
  },

  // ============ RENDER: METRICS ============
  renderMetrics() {
    const areas=JiraPulse._selectedAreas(JiraPulse._activeArea);
    const report=JiraPulse._report;
    const {people}=JiraPulse._aggregatePeople(areas);
    const allIssues=areas.flatMap(a=>a.issues||[]);
    const sprintSet=new Set(areas.flatMap(a=>a.sprintKeys||[]));
    const widgets=[];

    widgets.push(JiraPulse._widgetBars('WIP по людям',people.map(p=>({name:p.name,val:p.inProgress.length})).filter(x=>x.val>0).sort((a,b)=>b.val-a.val).slice(0,12)));
    widgets.push(JiraPulse._widgetBars('Logtime вчера, ч',people.map(p=>({name:p.name,val:Math.round(p.stats.workSecYesterday/360)/10})).filter(x=>x.val>0).sort((a,b)=>b.val-a.val).slice(0,12),'good'));

    const ages=allIssues.filter(JiraPulse._isWip).map(it=>JiraPulse._daysSince(JiraPulse._lastMov(it)||it.fields?.updated)).filter(x=>x!=null);
    widgets.push(JiraPulse._widgetHist('Возраст задач в работе (дн)',ages,[0,1,3,7,14,30]));

    const cats={'To Do':0,'In Progress':0,'Done':0};
    for(const it of allIssues.filter(x=>sprintSet.has(x.key))){const c=JiraPulse._statusCat(it);if(c==='done')cats['Done']++;else if(c==='indeterminate')cats['In Progress']++;else cats['To Do']++;}
    widgets.push(JiraPulse._widgetDonut('Спринт: статусы',[{label:'Done',value:cats['Done'],color:'#22c55e'},{label:'In Progress',value:cats['In Progress'],color:'var(--accent)'},{label:'To Do',value:cats['To Do'],color:'var(--text-3)'}]));

    const prio=new Map(); for(const it of allIssues){const p=it.fields?.priority?.name||'—';prio.set(p,(prio.get(p)||0)+1);}
    const prioColors={'Highest':'#ef4444','High':'#f97316','Medium':'#f59e0b','Low':'#94a3b8','Lowest':'#64748b'};
    widgets.push(JiraPulse._widgetDonut('Приоритеты',[...prio.entries()].map(([k,v])=>({label:k,value:v,color:prioColors[k]||'var(--accent)'}))));

    if(areas.length>1) {
      const segs=areas.map(a=>({label:a.name,value:(a.issues||[]).length,color:`hsl(${[...a.projectKey].reduce((h,c)=>(h*31+c.charCodeAt(0))>>>0,0)%360} 60% 50%)`}));
      widgets.push(JiraPulse._widgetDonut('Задачи по пространствам',segs));
    }

    const closedY=allIssues.filter(it=>(it.changelog?.histories||[]).some(h=>JiraPulse._inRange(h.created,report.yesterdayRange)&&(h.items||[]).some(i=>i.field==='status'&&JiraPulse._isTerm(i.toString)))).length;
    const openedY=allIssues.filter(it=>JiraPulse._inRange(it.fields?.created,report.yesterdayRange)).length;
    widgets.push(JiraPulse._widgetTwo('Поток вчера',{label:'Закрыто',value:closedY,kind:'good'},{label:'Открыто',value:openedY,kind:'info'}));

    if(areas.length>1) widgets.push(JiraPulse._widgetBars('WIP по пространствам',areas.map(a=>({name:a.name,val:(a.issues||[]).filter(JiraPulse._isWip).length})).sort((a,b)=>b.val-a.val)));

    return`<div class="jp-metrics-grid">${widgets.join('')}</div>`;
  },

  // ============ RENDER: BACKLOG ============
  renderBacklog() {
    const areas=(JiraPulse._backlogArea==='__all__'?JiraPulse._report?.areas||[]:( JiraPulse._report?.areas||[]).filter(a=>a.projectKey===JiraPulse._backlogArea));
    const items=areas.flatMap(a=>(a.issues||[]).filter(it=>(a.backlogKeys||[]).includes(it.key)).map(it=>({issue:it,area:{name:a.name,projectKey:a.projectKey}})));
    if(!items.length)return'<div class="jp-empty-card"><p>В бэклоге нет задач. 👌</p></div>';

    const tabs=['summary','metrics','dashboards','insights'].map(t=>`<button class="jp-subtab${JiraPulse._backlogTab===t?' active':''}" data-bltab="${t}">${{summary:'Сводка',metrics:'Метрики',dashboards:'Дашборды',insights:'Инсайты'}[t]}</button>`).join('');

    const allAreas=JiraPulse._report?.areas||[];
    const areaSel=`<select id="jp-bl-area" class="jp-select"><option value="__all__">Все пространства</option>${allAreas.map(a=>`<option value="${JiraPulse._esc(a.projectKey)}"${JiraPulse._backlogArea===a.projectKey?' selected':''}>${JiraPulse._esc(a.name)} [${JiraPulse._esc(a.projectKey)}]</option>`).join('')}</select>`;

    let body='';
    if(JiraPulse._backlogTab==='summary') {
      const total=items.length, noPrio=items.filter(x=>!x.issue.fields?.priority?.name).length;
      const noAss=items.filter(x=>!x.issue.fields?.assignee).length;
      const oldest=items.map(x=>JiraPulse._daysSince(x.issue.fields?.created)).filter(d=>d!=null).sort((a,b)=>b-a)[0]||0;
      const byArea=new Map(); for(const x of items){const k=x.area.projectKey;if(!byArea.has(k))byArea.set(k,{area:x.area,count:0});byArea.get(k).count++;}
      const areaRows=[...byArea.values()].sort((a,b)=>b.count-a.count);
      body=`${JiraPulse._statCards([{label:'Всего в бэклоге',value:total,kind:'info'},{label:'Без приоритета',value:noPrio,kind:'warn'},{label:'Без исполнителя',value:noAss,kind:'warn'},{label:'Самая старая',value:oldest,kind:'bad',sub:'дней с создания'}])}
        <div class="jp-panel"><div class="jp-panel-title">По пространствам</div>${areaRows.map(r=>`<div class="jp-hbar-row"><div class="jp-hbar-label">${JiraPulse._esc(r.area.name)} <span class="jp-area-chip">${JiraPulse._esc(r.area.projectKey)}</span></div><div class="jp-hbar"><span style="width:${(r.count/total*100).toFixed(1)}%"></span></div><div class="jp-hbar-val">${r.count}</div></div>`).join('')}</div>
        <div class="jp-panel"><div class="jp-panel-title">Список (топ-100, по возрасту)</div>${[...items].sort((a,b)=>(JiraPulse._daysSince(b.issue.fields?.created)||0)-(JiraPulse._daysSince(a.issue.fields?.created)||0)).slice(0,100).map(x=>JiraPulse._issueLine(x.issue,x.area,{daysIdle:JiraPulse._daysSince(x.issue.fields?.created)})).join('')}</div>`;
    } else if(JiraPulse._backlogTab==='metrics') {
      const ages=items.map(x=>JiraPulse._daysSince(x.issue.fields?.created)).filter(d=>d!=null);
      const types=['story','task','bug','sub-task'].map(t=>({label:JiraPulse._typeLabel(t),value:items.filter(x=>JiraPulse._typeBucket(x.issue)===t).length,color:'var(--accent)'})).filter(x=>x.value);
      const prio=new Map(); for(const x of items){const p=x.issue.fields?.priority?.name||'Без приоритета';prio.set(p,(prio.get(p)||0)+1);}
      const prioColors={'Highest':'#ef4444','High':'#f97316','Medium':'#f59e0b','Low':'#94a3b8','Без приоритета':'var(--text-3)'};
      const assMap=new Map(); for(const x of items){const a=JiraPulse._assignee(x.issue);const k=a?a.name:'Без исполнителя';assMap.set(k,(assMap.get(k)||0)+1);}
      body=`<div class="jp-metrics-grid">
        ${JiraPulse._widgetHist('Возраст в бэклоге (дн)',ages,[0,7,30,90,180,365])}
        ${JiraPulse._widgetDonut('Типы задач',types)}
        ${JiraPulse._widgetDonut('Приоритеты',[...prio.entries()].map(([k,v])=>({label:k,value:v,color:prioColors[k]||'var(--accent)'})))}
        ${JiraPulse._widgetBars('По исполнителям',[...assMap.entries()].map(([n,v])=>({name:n,val:v})).sort((a,b)=>b.val-a.val).slice(0,10))}
      </div>`;
    } else if(JiraPulse._backlogTab==='dashboards') {
      const cards=areas.map(a=>{
        const cnt=(a.backlogKeys||[]).length, bugs=(a.issues||[]).filter(it=>(a.backlogKeys||[]).includes(it.key)&&JiraPulse._typeBucket(it)==='bug').length;
        const noAss=(a.issues||[]).filter(it=>(a.backlogKeys||[]).includes(it.key)&&!it.fields?.assignee).length;
        const hi=(a.issues||[]).filter(it=>(a.backlogKeys||[]).includes(it.key)&&['highest','high','blocker','critical'].includes((it.fields?.priority?.name||'').toLowerCase())).length;
        const old=(a.issues||[]).filter(it=>(a.backlogKeys||[]).includes(it.key)).map(it=>JiraPulse._daysSince(it.fields?.created)).filter(d=>d!=null).sort((a,b)=>b-a)[0]||0;
        const mx=Math.max(cnt,bugs,noAss,hi,old/3,1);
        return`<div class="jp-area-card"><div class="jp-area-card-title">${JiraPulse._esc(a.name)} <span class="jp-area-chip">${JiraPulse._esc(a.projectKey)}</span></div>
          <div class="jp-hbar-row"><div class="jp-hbar-label">Всего</div><div class="jp-hbar"><span style="width:${cnt/mx*100}%"></span></div><div class="jp-hbar-val">${cnt}</div></div>
          <div class="jp-hbar-row"><div class="jp-hbar-label">Высокий prio</div><div class="jp-hbar bad"><span style="width:${hi/mx*100}%"></span></div><div class="jp-hbar-val">${hi}</div></div>
          <div class="jp-hbar-row"><div class="jp-hbar-label">Багов</div><div class="jp-hbar warn"><span style="width:${bugs/mx*100}%"></span></div><div class="jp-hbar-val">${bugs}</div></div>
          <div class="jp-hbar-row"><div class="jp-hbar-label">Без исполнителя</div><div class="jp-hbar warn"><span style="width:${noAss/mx*100}%"></span></div><div class="jp-hbar-val">${noAss}</div></div>
        </div>`;
      }).join('');
      body=`<div class="jp-panel"><div class="jp-panel-title">Бэклог по пространствам</div><div class="jp-area-grid">${cards}</div></div>`;
    } else {
      // insights
      const ins=[];
      if(items.length>200) ins.push({sev:'warn',icon:'🗃',tag:'overload',title:`Бэклог раздут: ${items.length} задач`,desc:'Нужен grooming / архивация.'});
      const old90=items.filter(x=>(JiraPulse._daysSince(x.issue.fields?.created)||0)>90);
      if(old90.length) ins.push({sev:'warn',icon:'🗿',tag:'ancient',title:`Старше 90 дней: ${old90.length}`,desc:old90.slice(0,6).map(x=>`<a href="${JiraPulse._issueUrl(x.issue.key)}" target="_blank">${JiraPulse._esc(x.issue.key)}</a>`).join(', ')});
      const noPrio=items.filter(x=>!x.issue.fields?.priority?.name);
      if(noPrio.length) ins.push({sev:'info',icon:'❓',tag:'prio',title:`Без приоритета: ${noPrio.length}`,desc:''});
      if(!ins.length) ins.push({sev:'good',icon:'✅',tag:'ok',title:'Бэклог в хорошей форме',desc:''});
      body=`<div class="jp-insights-list">${ins.map(JiraPulse._insightCard).join('')}</div>`;
    }

    return`<div class="jp-bl-controls">${areaSel}<div class="jp-subtabs jp-bl-tabs">${tabs}</div></div>${body}`;
  },

  // ============ MAIN RENDER ============
  render() {
    const el=document.getElementById('jp-content');
    if(!el)return;
    if(!JiraPulse._report) { el.innerHTML=document.getElementById('jp-empty')?.outerHTML||''; return; }
    // Area chips
    JiraPulse._renderAreaChips();

    let html='';
    if(JiraPulse._activeTab==='people') html=JiraPulse.renderPeople();
    else if(JiraPulse._activeTab==='summary') html=JiraPulse.renderSummary();
    else if(JiraPulse._activeTab==='sprints') html=JiraPulse.renderSprints();
    else if(JiraPulse._activeTab==='insights') html=JiraPulse.renderInsights();
    else if(JiraPulse._activeTab==='metrics') html=JiraPulse.renderMetrics();
    else if(JiraPulse._activeTab==='backlog') html=JiraPulse.renderBacklog();

    el.innerHTML=`<div class="jp-tab-content">${html}</div>`;

    // Bind backlog sub-tab and area events after render
    el.querySelector('#jp-bl-area')?.addEventListener('change',e=>{ JiraPulse._backlogArea=e.target.value; JiraPulse.render(); });
    el.querySelectorAll('[data-bltab]').forEach(btn=>btn.addEventListener('click',()=>{ JiraPulse._backlogTab=btn.dataset.bltab; JiraPulse.render(); }));

    // Sprint area subtabs
    if(JiraPulse._activeTab==='sprints') JiraPulse._bindSprintSubtabs();
  },
  _renderAreaChips() {
    const row=document.getElementById('jp-area-row'), chips=document.getElementById('jp-area-chips');
    if(!row||!chips)return;
    const areas=JiraPulse._report?.areas||[];
    if(areas.length<=1){row.classList.add('hidden');return;}
    row.classList.remove('hidden');
    chips.innerHTML=[
      `<button class="jp-area-filter-btn${JiraPulse._activeArea==='__all__'?' active':''}" data-area="__all__">Все</button>`,
      ...areas.map(a=>`<button class="jp-area-filter-btn${JiraPulse._activeArea===a.projectKey?' active':''}" data-area="${JiraPulse._esc(a.projectKey)}">${JiraPulse._esc(a.name)}</button>`)
    ].join('');
    chips.querySelectorAll('[data-area]').forEach(btn=>btn.addEventListener('click',()=>{ JiraPulse._activeArea=btn.dataset.area; JiraPulse.render(); }));
  },
  _bindSprintSubtabs() {
    const areas=JiraPulse._report?.areas||[];
    if(areas.length<=1)return;
    // Already handled via area chips for sprint too
  },

  // ============ DATA LOAD ============
  async refresh() {
    if(JiraPulse._loading)return;
    JiraPulse._loading=true;
    const btn=document.getElementById('jp-btn-refresh');
    if(btn){btn.disabled=true;btn.textContent='⟳ Загрузка…';}
    try {
      const resp=await fetch('/api/jira/report',{method:'POST',headers:{'Content-Type':'application/json'}});
      const data=await resp.json();
      if(!resp.ok) throw new Error(data.error||`HTTP ${resp.status}`);
      JiraPulse._report=data;
      const meta=document.getElementById('jp-meta');
      if(meta){const at=new Date(data.generatedAt);meta.textContent=`обновлено ${at.toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})} · ${data.areas.length} пространств`;}
      JiraPulse.render();
      showToast('Jira Pulse обновлён','success');
    } catch(e) {
      showToast('Ошибка загрузки Jira: '+e.message,'error',4000);
      document.getElementById('jp-content').innerHTML=`<div class="jp-empty-card"><p>Ошибка: ${JiraPulse._esc(e.message)}</p><p style="margin-top:8px;font-size:12px;color:var(--text-3)">Проверьте настройки подключения к Jira.</p></div>`;
    } finally {
      JiraPulse._loading=false;
      if(btn){btn.disabled=false;btn.textContent='⟳ Обновить';}
    }
  },

  // ============ SETTINGS ============
  async loadConfig() {
    try {
      const resp=await fetch('/api/jira/config'); if(!resp.ok)return;
      JiraPulse._config=await resp.json();
    } catch(_){}
  },
  _openSettings() {
    const cfg=JiraPulse._config||{};
    document.getElementById('jp-cfg-url').value=cfg.jiraBaseUrl||'';
    document.getElementById('jp-cfg-token').value='';
    document.getElementById('jp-cfg-token').placeholder=cfg.hasJiraToken?'•••••••• (пусто = не менять)':'Введите токен';
    document.getElementById('jp-cfg-bb-url').value=cfg.bitbucketBaseUrl||'';
    document.getElementById('jp-cfg-bb-token').value='';
    document.getElementById('jp-cfg-bb-keys').value=cfg.bitbucketProjectKeys||'';
    document.getElementById('jp-cfg-insecure').checked=!!cfg.allowInsecureTls;
    document.getElementById('jp-cfg-stale').value=cfg.staleDays??3;
    document.getElementById('jp-cfg-nomov').value=cfg.noMovementDays??2;
    JiraPulse._renderAreasEditor(cfg.areas||[]);
    document.getElementById('jp-settings-error').classList.add('hidden');
    document.getElementById('jp-settings-modal').classList.remove('hidden');
  },
  _renderAreasEditor(areas) {
    const root=document.getElementById('jp-areas-editor'); root.innerHTML='';
    const list=areas.length?areas:[{name:'',projectKey:''}];
    for(const a of list) JiraPulse._addAreaRow(a.name||'',a.projectKey||'');
  },
  _addAreaRow(name='',projectKey='') {
    const root=document.getElementById('jp-areas-editor');
    const row=document.createElement('div'); row.className='jp-area-row';
    row.innerHTML=`<input class="form-input jp-area-name" placeholder="Имя (Платежи)" value="${JiraPulse._esc(name)}"><input class="form-input jp-area-key" placeholder="KEY (PAY)" value="${JiraPulse._esc(projectKey)}"><button class="btn btn-ghost btn-sm jp-area-del">✕</button>`;
    row.querySelector('.jp-area-del').addEventListener('click',()=>row.remove());
    root.appendChild(row);
  },
  _collectSettings() {
    const areas=[...document.querySelectorAll('#jp-areas-editor .jp-area-row')].map(row=>({name:row.querySelector('.jp-area-name').value.trim(),projectKey:row.querySelector('.jp-area-key').value.trim()})).filter(a=>a.projectKey);
    const payload={jiraBaseUrl:document.getElementById('jp-cfg-url').value.trim(),areas,bitbucketBaseUrl:document.getElementById('jp-cfg-bb-url').value.trim(),bitbucketProjectKeys:document.getElementById('jp-cfg-bb-keys').value.trim(),allowInsecureTls:document.getElementById('jp-cfg-insecure').checked,staleDays:Number(document.getElementById('jp-cfg-stale').value)||3,noMovementDays:Number(document.getElementById('jp-cfg-nomov').value)||2};
    const t=document.getElementById('jp-cfg-token').value; if(t)payload.jiraToken=t;
    const bt=document.getElementById('jp-cfg-bb-token').value; if(bt)payload.bitbucketToken=bt;
    return payload;
  },
  async _saveSettings() {
    const errEl=document.getElementById('jp-settings-error'); errEl.classList.add('hidden');
    try {
      const resp=await fetch('/api/jira/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(JiraPulse._collectSettings())});
      const data=await resp.json(); if(!resp.ok)throw new Error(data.error);
      JiraPulse._config=data;
      document.getElementById('jp-settings-modal').classList.add('hidden');
      showToast('Настройки Jira сохранены','success');
      JiraPulse.refresh();
    } catch(e){errEl.textContent='Ошибка: '+e.message;errEl.classList.remove('hidden');}
  },
  async _verifySettings() {
    const errEl=document.getElementById('jp-settings-error'); errEl.classList.add('hidden');
    try {
      await fetch('/api/jira/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(JiraPulse._collectSettings())});
      const resp=await fetch('/api/jira/verify',{method:'POST',headers:{'Content-Type':'application/json'}});
      const data=await resp.json(); if(!resp.ok)throw new Error(data.error);
      showToast(`Jira: ${data.who}. Подключение успешно!`,'success',4000);
    } catch(e){errEl.textContent='Ошибка: '+e.message;errEl.classList.remove('hidden');}
  },

  // ============ INIT ============
  init() {
    // Subtabs
    document.getElementById('jp-subtabs')?.querySelectorAll('[data-jptab]').forEach(btn=>{
      btn.addEventListener('click',()=>{
        JiraPulse._activeTab=btn.dataset.jptab;
        document.querySelectorAll('#jp-subtabs [data-jptab]').forEach(b=>b.classList.toggle('active',b.dataset.jptab===btn.dataset.jptab));
        JiraPulse.render();
      });
    });
    // Buttons
    document.getElementById('jp-btn-refresh')?.addEventListener('click',()=>JiraPulse.refresh());
    document.getElementById('jp-btn-settings')?.addEventListener('click',()=>JiraPulse._openSettings());
    document.getElementById('jp-btn-setup')?.addEventListener('click',()=>JiraPulse._openSettings());
    // Settings modal
    document.getElementById('jp-settings-close')?.addEventListener('click',()=>document.getElementById('jp-settings-modal').classList.add('hidden'));
    document.getElementById('jp-settings-cancel')?.addEventListener('click',()=>document.getElementById('jp-settings-modal').classList.add('hidden'));
    document.getElementById('jp-btn-save')?.addEventListener('click',()=>JiraPulse._saveSettings());
    document.getElementById('jp-btn-verify')?.addEventListener('click',()=>JiraPulse._verifySettings());
    document.getElementById('jp-add-area')?.addEventListener('click',()=>JiraPulse._addAreaRow());
    document.getElementById('jp-settings-modal')?.addEventListener('click',e=>{ if(e.target===document.getElementById('jp-settings-modal')) document.getElementById('jp-settings-modal').classList.add('hidden'); });
    // Load config on init
    JiraPulse.loadConfig();
  },
};

document.addEventListener('DOMContentLoaded',()=>App.init());
