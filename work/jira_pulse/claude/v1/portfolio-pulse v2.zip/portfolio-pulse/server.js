// Portfolio Pulse — лёгкий Node.js бэкенд-прокси к Jira / Bitbucket / Confluence Server.
// Поддерживает несколько проектных пространств (areas). Без внешних зависимостей.

'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const CONFIG_FILE = path.join(ROOT, 'config.json');

const PORT = Number(process.env.PORT) || 5174;
const HOST = process.env.HOST || '127.0.0.1';

// ------------------------- Конфиг -------------------------

const DEFAULT_CONFIG = {
    jiraBaseUrl: '',
    jiraToken: '',
    areas: [],                      // [{ name, projectKey }]
    bitbucketBaseUrl: '',
    bitbucketToken: '',
    bitbucketProjectKeys: '',       // через запятую
    confluenceBaseUrl: '',
    confluenceToken: '',
    allowInsecureTls: false,
    staleDays: 3,
    noMovementDays: 2,
    // Второй контур — Черный дашборд
    jira2BaseUrl: '',
    jira2Token: '',
    jira2EpicKeys: ''               // ключи квартальных эпиков-целей через запятую
};

function readConfig() {
    try {
        const raw = fs.readFileSync(CONFIG_FILE, 'utf8');
        const parsed = JSON.parse(raw);
        // Совместимость: одиночный projectKey → одно area
        if (!Array.isArray(parsed.areas) && parsed.projectKey) {
            parsed.areas = [{ name: parsed.projectKey, projectKey: parsed.projectKey }];
        }
        return { ...DEFAULT_CONFIG, ...parsed };
    } catch (_) {
        return { ...DEFAULT_CONFIG };
    }
}

function writeConfig(patch) {
    const current = readConfig();
    const next = { ...current, ...patch };
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(next, null, 2), 'utf8');
    return next;
}

function sanitizeAreas(areas) {
    if (!Array.isArray(areas)) return [];
    const seen = new Set();
    const out = [];
    for (const a of areas) {
        if (!a || typeof a !== 'object') continue;
        const projectKey = String(a.projectKey || '').trim();
        const name = String(a.name || projectKey || '').trim();
        if (!projectKey) continue;
        if (seen.has(projectKey)) continue;
        seen.add(projectKey);
        out.push({ name, projectKey });
    }
    return out;
}

function sanitizeConfig(cfg) {
    return {
        jiraBaseUrl: cfg.jiraBaseUrl || '',
        areas: sanitizeAreas(cfg.areas),
        bitbucketBaseUrl: cfg.bitbucketBaseUrl || '',
        bitbucketProjectKeys: cfg.bitbucketProjectKeys || '',
        confluenceBaseUrl: cfg.confluenceBaseUrl || '',
        allowInsecureTls: !!cfg.allowInsecureTls,
        staleDays: cfg.staleDays ?? 3,
        noMovementDays: cfg.noMovementDays ?? 2,
        hasJiraToken: !!cfg.jiraToken,
        hasBitbucketToken: !!cfg.bitbucketToken,
        hasConfluenceToken: !!cfg.confluenceToken,
        jira2BaseUrl: cfg.jira2BaseUrl || '',
        jira2EpicKeys: cfg.jira2EpicKeys || '',
        hasJira2Token: !!cfg.jira2Token
    };
}

// ------------------------- HTTP утилиты -------------------------

function sendJson(res, code, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(code, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Cache-Control': 'no-store'
    });
    res.end(body);
}
function sendText(res, code, text, type = 'text/plain; charset=utf-8') {
    const body = Buffer.from(text, 'utf8');
    res.writeHead(code, { 'Content-Type': type, 'Content-Length': body.length, 'Cache-Control': 'no-store' });
    res.end(body);
}
function readBody(req) {
    return new Promise((resolve, reject) => {
        const chunks = []; let total = 0;
        req.on('data', (c) => {
            total += c.length;
            if (total > 4 * 1024 * 1024) { reject(new Error('Тело запроса слишком большое')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', () => {
            const raw = Buffer.concat(chunks).toString('utf8');
            if (!raw) return resolve({});
            try { resolve(JSON.parse(raw)); } catch (e) { reject(new Error('Некорректный JSON: ' + e.message)); }
        });
        req.on('error', reject);
    });
}

function forward({ targetUrl, method = 'GET', headers = {}, body = null, allowInsecureTls = false, timeoutMs = 25000 }) {
    return new Promise((resolve, reject) => {
        let parsed;
        try { parsed = new URL(targetUrl); } catch (e) { return reject(new Error('Некорректный URL: ' + targetUrl)); }
        const lib = parsed.protocol === 'https:' ? https : http;
        const options = {
            method,
            hostname: parsed.hostname,
            port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
            path: parsed.pathname + (parsed.search || ''),
            headers: { 'Accept': 'application/json', 'User-Agent': 'portfolio-pulse/1.0', ...headers },
            rejectUnauthorized: !allowInsecureTls
        };
        const req = lib.request(options, (resp) => {
            const chunks = [];
            resp.on('data', (c) => chunks.push(c));
            resp.on('end', () => resolve({ status: resp.statusCode || 0, headers: resp.headers, text: Buffer.concat(chunks).toString('utf8') }));
        });
        req.setTimeout(timeoutMs, () => req.destroy(new Error(`Таймаут запроса к ${parsed.hostname}`)));
        req.on('error', reject);
        if (body != null) {
            const payload = typeof body === 'string' ? body : JSON.stringify(body);
            req.setHeader('Content-Type', 'application/json');
            req.setHeader('Content-Length', Buffer.byteLength(payload));
            req.write(payload);
        }
        req.end();
    });
}

function joinUrl(base, pathname) {
    if (!base) throw new Error('baseUrl не задан');
    const trimmed = base.replace(/\/+$/, '');
    const p = pathname.startsWith('/') ? pathname : '/' + pathname;
    return trimmed + p;
}

function parseResponse(resp, target, product) {
    if (resp.status < 200 || resp.status >= 300) {
        let msg = `${product} ${resp.status} при обращении к ${target}`;
        try {
            const j = JSON.parse(resp.text);
            if (j.errorMessages && j.errorMessages.length) msg += ': ' + j.errorMessages.join('; ');
            else if (j.message) msg += ': ' + j.message;
            else if (j.errors && Object.keys(j.errors).length) msg += ': ' + JSON.stringify(j.errors);
        } catch (_) {
            if (resp.text) msg += ': ' + resp.text.slice(0, 300);
        }
        const err = new Error(msg);
        err.status = resp.status;
        throw err;
    }
    if (!resp.text) return {};
    try { return JSON.parse(resp.text); } catch (e) { throw new Error(`${product} вернул не JSON: ` + resp.text.slice(0, 200)); }
}

// ------------------------- Jira -------------------------

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function jiraRequest(cfg, method, apiPath, body, maxRetries = 4) {
    const target = joinUrl(cfg.jiraBaseUrl, apiPath);
    let delay = 2000;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        const resp = await forward({ targetUrl: target, method, headers: { 'Authorization': 'Bearer ' + cfg.jiraToken }, body: body ?? null, allowInsecureTls: cfg.allowInsecureTls });
        if (resp.status === 429) {
            if (attempt === maxRetries) {
                const err = new Error(`Jira 429 при обращении к ${target}: Rate limit exceeded`);
                err.status = 429;
                throw err;
            }
            // Уважаем Retry-After если есть, иначе exponential backoff
            const retryAfter = parseInt(resp.headers['retry-after'] || resp.headers['x-ratelimit-reset'] || '0', 10);
            const wait = retryAfter > 0 ? retryAfter * 1000 : delay;
            console.warn(`[Jira] 429 Rate limit, ждём ${wait}ms (попытка ${attempt + 1}/${maxRetries})...`);
            await sleep(wait);
            delay = Math.min(delay * 2, 30000);
            continue;
        }
        return parseResponse(resp, target, 'Jira');
    }
}

async function jiraGet(cfg, apiPath) { return jiraRequest(cfg, 'GET', apiPath, null); }
async function jiraPost(cfg, apiPath, body) { return jiraRequest(cfg, 'POST', apiPath, body); }

async function jiraSearchAll(cfg, jql, fields, expand, hardCap = 2000) {
    const out = [];
    let startAt = 0;
    const pageSize = 100;
    while (true) {
        const body = { jql, startAt, maxResults: pageSize, fields, expand };
        const data = await jiraPost(cfg, '/rest/api/2/search', body);
        const issues = data.issues || [];
        out.push(...issues);
        if (issues.length < pageSize || out.length >= (data.total || out.length)) break;
        startAt += issues.length;
        if (startAt > hardCap) break;
    }
    return out;
}

async function jiraDevStatus(cfg, issueId, dataType /* 'repository' | 'pullrequest' */) {
    try {
        const target = joinUrl(cfg.jiraBaseUrl, `/rest/dev-status/1.0/issue/detail?issueId=${encodeURIComponent(issueId)}&applicationType=bitbucket&dataType=${dataType}`);
        const resp = await forward({ targetUrl: target, method: 'GET', headers: { 'Authorization': 'Bearer ' + cfg.jiraToken }, allowInsecureTls: cfg.allowInsecureTls });
        if (resp.status < 200 || resp.status >= 300) return null;
        return JSON.parse(resp.text || '{}');
    } catch (_) { return null; }
}

// ------------------------- Bitbucket Server -------------------------

async function bbGet(cfg, apiPath) {
    const target = joinUrl(cfg.bitbucketBaseUrl, apiPath);
    const resp = await forward({ targetUrl: target, method: 'GET', headers: { 'Authorization': 'Bearer ' + cfg.bitbucketToken }, allowInsecureTls: cfg.allowInsecureTls });
    return parseResponse(resp, target, 'Bitbucket');
}

function pLimit(concurrency, tasks) {
    return new Promise((resolve) => {
        const results = new Array(tasks.length);
        let i = 0, done = 0, running = 0;
        const next = () => {
            while (running < concurrency && i < tasks.length) {
                const idx = i++;
                running++;
                Promise.resolve().then(() => tasks[idx]()).then((r) => { results[idx] = r; }, (e) => { results[idx] = { __error: e.message || String(e) }; })
                    .then(() => { running--; done++; if (done === tasks.length) resolve(results); else next(); });
            }
        };
        if (!tasks.length) resolve([]); else next();
    });
}

async function fetchBitbucket(cfg, hours) {
    const keys = String(cfg.bitbucketProjectKeys || '').split(/[,;\s]+/).map((s) => s.trim()).filter(Boolean);
    if (!keys.length) return null;
    const since = Date.now() - hours * 3600 * 1000;

    const commits = [];
    const prs = [];
    const errors = [];

    for (const k of keys) {
        let repos = [];
        try {
            const r = await bbGet(cfg, `/rest/api/1.0/projects/${encodeURIComponent(k)}/repos?limit=100`);
            repos = (r.values || []).slice(0, 30);
        } catch (e) {
            errors.push(`repos(${k}): ${e.message}`);
            continue;
        }
        const tasks = repos.map((r) => async () => {
            const out = { cs: [], ps: [] };
            try {
                const c = await bbGet(cfg, `/rest/api/1.0/projects/${encodeURIComponent(k)}/repos/${encodeURIComponent(r.slug)}/commits?limit=100`);
                for (const x of (c.values || [])) {
                    if ((x.authorTimestamp || 0) < since) continue;
                    out.cs.push({
                        project: k, repo: r.slug, repoName: r.name,
                        id: x.displayId || (x.id || '').slice(0, 7),
                        author: x.author?.name || '',
                        authorEmail: x.author?.emailAddress || '',
                        authorDisplay: x.author?.displayName || x.author?.name || '—',
                        at: x.authorTimestamp,
                        message: (x.message || '').split('\n')[0].slice(0, 200),
                        url: (cfg.bitbucketBaseUrl.replace(/\/+$/, '')) + `/projects/${k}/repos/${r.slug}/commits/${x.id}`
                    });
                }
            } catch (e) { errors.push(`commits(${k}/${r.slug}): ${e.message}`); }
            try {
                const p = await bbGet(cfg, `/rest/api/1.0/projects/${encodeURIComponent(k)}/repos/${encodeURIComponent(r.slug)}/pull-requests?state=ALL&order=NEWEST&limit=50`);
                for (const x of (p.values || [])) {
                    const ts = x.updatedDate || x.createdDate || 0;
                    if (ts < since) continue;
                    out.ps.push({
                        project: k, repo: r.slug, repoName: r.name,
                        id: x.id, title: x.title, state: x.state,
                        author: x.author?.user?.name || '',
                        authorEmail: x.author?.user?.emailAddress || '',
                        authorDisplay: x.author?.user?.displayName || x.author?.user?.name || '—',
                        createdAt: x.createdDate,
                        updatedAt: x.updatedDate,
                        url: x.links?.self?.[0]?.href || null
                    });
                }
            } catch (e) { errors.push(`prs(${k}/${r.slug}): ${e.message}`); }
            return out;
        });
        const results = await pLimit(5, tasks);
        for (const r of results) {
            if (r && r.cs) commits.push(...r.cs);
            if (r && r.ps) prs.push(...r.ps);
        }
    }

    return { commits, prs, errors };
}

// ------------------------- Confluence -------------------------

async function confGet(cfg, apiPath) {
    const target = joinUrl(cfg.confluenceBaseUrl, apiPath);
    const resp = await forward({ targetUrl: target, method: 'GET', headers: { 'Authorization': 'Bearer ' + cfg.confluenceToken }, allowInsecureTls: cfg.allowInsecureTls });
    return parseResponse(resp, target, 'Confluence');
}

async function fetchConfluence(cfg, hours) {
    if (!cfg.confluenceBaseUrl || !cfg.confluenceToken) return null;
    const sinceMs = Date.now() - hours * 3600 * 1000;
    const cql = `type=page and lastmodified >= now("-${hours}h")`;
    const target = `/rest/api/content/search?cql=${encodeURIComponent(cql)}&limit=200&expand=version,version.by,history,history.lastUpdated,history.lastUpdated.by,space`;
    let data;
    try { data = await confGet(cfg, target); }
    catch (e) { return { error: e.message, pages: [] }; }

    const baseDisplay = (cfg.confluenceBaseUrl || '').replace(/\/+$/, '');
    const pages = [];
    for (const r of (data.results || [])) {
        const v = r.version || r.history?.lastUpdated || {};
        const by = v.by || {};
        const when = v.when || r.history?.lastUpdated?.when;
        if (!when) continue;
        if (new Date(when).getTime() < sinceMs) continue;
        const webui = r._links?.webui || '';
        pages.push({
            id: r.id,
            title: r.title,
            space: r.space?.name || r._expandable?.space || '',
            byLogin: by.username || by.name || '',
            byName: by.displayName || by.publicName || by.username || '—',
            byEmail: by.email || by.emailAddress || '',
            at: when,
            url: webui ? baseDisplay + webui : null
        });
    }
    return { pages };
}

// ------------------------- Черный дашборд (второй контур Jira) -------------------------

async function jira2Request(cfg, method, apiPath, body, maxRetries = 3) {
    const target = joinUrl(cfg.jira2BaseUrl, apiPath);
    let delay = 2000;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        const resp = await forward({ targetUrl: target, method, headers: { 'Authorization': 'Bearer ' + cfg.jira2Token }, body: body ?? null, allowInsecureTls: cfg.allowInsecureTls });
        if (resp.status === 429) {
            if (attempt === maxRetries) { const e = new Error(`Jira2 429: Rate limit exceeded (${target})`); e.status = 429; throw e; }
            const wait = parseInt(resp.headers['retry-after'] || '0', 10);
            await sleep(wait > 0 ? wait * 1000 : delay);
            delay = Math.min(delay * 2, 20000);
            continue;
        }
        return parseResponse(resp, target, 'Jira2');
    }
}
async function jira2Get(cfg, apiPath) { return jira2Request(cfg, 'GET', apiPath, null); }
async function jira2Post(cfg, apiPath, body) { return jira2Request(cfg, 'POST', apiPath, body); }

async function jira2SearchAll(cfg, jql, fields, hardCap = 500) {
    const out = [];
    let startAt = 0;
    const pageSize = 100;
    while (true) {
        const data = await jira2Post(cfg, '/rest/api/2/search', { jql, startAt, maxResults: pageSize, fields });
        const issues = data.issues || [];
        out.push(...issues);
        if (issues.length < pageSize || out.length >= (data.total || out.length)) break;
        startAt += issues.length;
        if (startAt > hardCap) break;
    }
    return out;
}

async function fetchBlackDash(cfg) {
    if (!cfg.jira2BaseUrl || !cfg.jira2Token) {
        const e = new Error('Не настроен второй контур: укажите Jira2 baseURL и token в настройках (раздел «Черный дашборд»).');
        e.status = 400; throw e;
    }
    const epicKeys = String(cfg.jira2EpicKeys || '').split(/[,;\s]+/).map((s) => s.trim()).filter(Boolean);
    if (!epicKeys.length) {
        const e = new Error('Не указаны ключи эпиков-целей (jira2EpicKeys). Добавьте их в настройках.');
        e.status = 400; throw e;
    }

    // Ищем ID кастомного поля "Domain link"
    let domainLinkFieldId = null;
    try {
        const fields = await jira2Get(cfg, '/rest/api/2/field');
        const f = Array.isArray(fields) ? fields.find((x) => (x.name || '').toLowerCase() === 'domain link') : null;
        if (f) domainLinkFieldId = f.id;
    } catch (_) {}

    const fieldParams = ['summary', 'status', 'issuetype', 'priority', domainLinkFieldId].filter(Boolean).join(',');

    // Загружаем эпики-цели из jira2
    const goals = [];
    for (const key of epicKeys.slice(0, 60)) {
        try {
            const issue = await jira2Get(cfg, `/rest/api/2/issue/${encodeURIComponent(key)}?fields=${fieldParams}`);
            const rawLink = domainLinkFieldId ? (issue.fields?.[domainLinkFieldId] || '') : '';
            const linkedKeys = String(rawLink).split(/[,;\n\r;]+/).map((s) => s.trim()).filter((k) => /^[A-Z]+-\d+$/i.test(k));
            goals.push({
                key,
                summary: issue.fields?.summary || key,
                status: issue.fields?.status?.name || '—',
                statusCat: issue.fields?.status?.statusCategory?.key || 'new',
                priority: issue.fields?.priority?.name || '—',
                linkedKeys,
                error: null
            });
        } catch (e) {
            goals.push({ key, summary: key, status: '—', statusCat: 'new', priority: '—', linkedKeys: [], error: e.message });
        }
    }

    const allLinkedSet = new Set(goals.flatMap((g) => g.linkedKeys));

    // Загружаем все эпики+истории из delta Jira по настроенным area
    const areas = sanitizeAreas(cfg.areas);
    const deltaIssues = []; // { key, summary, status, statusCat, type, priority, assignee, area }

    for (const area of areas) {
        try {
            const jql = `project = "${area.projectKey}" AND issuetype in (Epic, Story, История, Эпик)`;
            const issues = await jiraSearchAll(cfg, jql, ['summary', 'status', 'issuetype', 'priority', 'assignee', 'project'], [], 500);
            for (const it of issues) {
                deltaIssues.push({
                    key: it.key,
                    summary: it.fields?.summary || '',
                    status: it.fields?.status?.name || '—',
                    statusCat: it.fields?.status?.statusCategory?.key || 'new',
                    type: it.fields?.issuetype?.name || '—',
                    priority: it.fields?.priority?.name || '—',
                    assignee: it.fields?.assignee?.displayName || it.fields?.assignee?.name || null,
                    area: { name: area.name, projectKey: area.projectKey }
                });
            }
        } catch (_) {}
    }

    // Добираем связанные ключи, которых нет в delta issues
    const existingKeys = new Set(deltaIssues.map((x) => x.key));
    const missingLinked = [...allLinkedSet].filter((k) => !existingKeys.has(k));
    for (const k of missingLinked.slice(0, 100)) {
        try {
            const it = await jiraGet(cfg, `/rest/api/2/issue/${encodeURIComponent(k)}?fields=summary,status,issuetype,priority,assignee,project`);
            const pk = it.fields?.project?.key || k.split('-')[0];
            const area = areas.find((a) => a.projectKey === pk) || { name: pk, projectKey: pk };
            deltaIssues.push({
                key: k,
                summary: it.fields?.summary || '',
                status: it.fields?.status?.name || '—',
                statusCat: it.fields?.status?.statusCategory?.key || 'new',
                type: it.fields?.issuetype?.name || '—',
                priority: it.fields?.priority?.name || '—',
                assignee: it.fields?.assignee?.displayName || null,
                area
            });
            existingKeys.add(k);
        } catch (_) {}
    }

    const deltaByKey = Object.fromEntries(deltaIssues.map((x) => [x.key, x]));
    const linked = deltaIssues.filter((x) => allLinkedSet.has(x.key));
    const unlinked = deltaIssues.filter((x) => !allLinkedSet.has(x.key));

    // Обогащаем цели деталями привязанных задач
    const enrichedGoals = goals.map((g) => ({
        ...g,
        linkedIssues: g.linkedKeys.map((k) => deltaByKey[k] || { key: k, summary: k, status: '?', statusCat: 'new', type: '?', priority: '?', assignee: null, area: null, notFound: true })
    }));

    // Статистика по командам
    const teamStats = {};
    for (const area of areas) {
        const pk = area.projectKey;
        const team = deltaIssues.filter((x) => x.area.projectKey === pk);
        const teamLinked = team.filter((x) => allLinkedSet.has(x.key));
        teamStats[pk] = { name: area.name, total: team.length, linked: teamLinked.length, unlinked: team.length - teamLinked.length };
    }

    return {
        goals: enrichedGoals,
        linked,
        unlinked,
        teamStats,
        domainLinkFieldId,
        stats: {
            totalGoals: goals.length,
            totalDelta: deltaIssues.length,
            linkedCount: linked.length,
            unlinkedCount: unlinked.length,
            coveragePct: deltaIssues.length ? Math.round(linked.length / deltaIssues.length * 100) : 0
        }
    };
}

// ------------------------- Агрегация по area -------------------------

function startOfYesterday(now = new Date()) { const d = new Date(now); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - 1); return d; }
function startOfToday(now = new Date()) { const d = new Date(now); d.setHours(0, 0, 0, 0); return d; }
function startOfDayBeforeYesterday(now = new Date()) { const d = startOfYesterday(now); d.setDate(d.getDate() - 1); return d; }

const ISSUE_FIELDS = [
    'summary', 'description', 'status', 'assignee', 'reporter', 'updated', 'created',
    'priority', 'issuetype', 'labels', 'duedate', 'timetracking', 'timeoriginalestimate',
    'timeestimate', 'aggregatetimespent', 'worklog', 'comment', 'parent', 'subtasks',
    'resolution', 'resolutiondate'
];

async function fetchAreaIssues(cfg, projectKey) {
    const sprintJql = `project = "${projectKey}" AND sprint in openSprints()`;
    const recentJql = `project = "${projectKey}" AND updated >= -3d`;
    const inProgressJql = `project = "${projectKey}" AND statusCategory = "In Progress"`;
    const backlogJql = `project = "${projectKey}" AND statusCategory != Done AND (sprint is EMPTY OR sprint not in openSprints())`;

    // Последовательно, чтобы не провоцировать rate-limit burst
    const sprintIssues = await jiraSearchAll(cfg, sprintJql, ISSUE_FIELDS, ['changelog'], 2000)
        .catch((e) => { throw new Error(`[${projectKey}] sprint: ` + e.message); });
    const recentIssues = await jiraSearchAll(cfg, recentJql, ISSUE_FIELDS, ['changelog'], 2000)
        .catch((e) => { throw new Error(`[${projectKey}] recent: ` + e.message); });
    const inProgressIssues = await jiraSearchAll(cfg, inProgressJql, ISSUE_FIELDS, ['changelog'], 2000)
        .catch((e) => { throw new Error(`[${projectKey}] in-progress: ` + e.message); });
    const backlogIssues = await jiraSearchAll(cfg, backlogJql, ISSUE_FIELDS, ['changelog'], 2000)
        .catch((e) => { throw new Error(`[${projectKey}] backlog: ` + e.message); });

    return { sprintIssues, recentIssues, inProgressIssues, backlogIssues };
}

async function buildAreaReport(cfg, area) {
    let sprintIssues, recentIssues, inProgressIssues, backlogIssues, error = null;
    try {
        ({ sprintIssues, recentIssues, inProgressIssues, backlogIssues } = await fetchAreaIssues(cfg, area.projectKey));
    } catch (e) {
        return {
            name: area.name, projectKey: area.projectKey,
            issues: [], sprintKeys: [], inProgressKeys: [], backlogKeys: [], devStatus: {},
            error: e.message
        };
    }

    const byKey = new Map();
    for (const arr of [sprintIssues, recentIssues, inProgressIssues, backlogIssues]) {
        for (const it of arr) byKey.set(it.key, it);
    }
    const allIssues = Array.from(byKey.values());

    // dev-status — для активных и in-progress задач, до 60 на area
    const now = Date.now();
    const devCandidates = allIssues
        .filter((it) => {
            const active = it.fields?.updated && (now - new Date(it.fields.updated).getTime() < 48 * 3600 * 1000);
            const wip = it.fields?.status?.statusCategory?.key === 'indeterminate';
            return active || wip;
        })
        .slice(0, 60);

    let devStatus = {};
    if (devCandidates.length) {
        const tasks = devCandidates.map((it) => async () => {
            const [repo, pr] = await Promise.all([
                jiraDevStatus(cfg, it.id, 'repository'),
                jiraDevStatus(cfg, it.id, 'pullrequest')
            ]);
            return [it.key, { repo, pr }];
        });
        const results = await pLimit(2, tasks);
        devStatus = Object.fromEntries(results.filter(Boolean).filter((r) => !r.__error));
    }

    return {
        name: area.name,
        projectKey: area.projectKey,
        issues: allIssues,
        sprintKeys: sprintIssues.map((i) => i.key),
        inProgressKeys: inProgressIssues.map((i) => i.key),
        backlogKeys: backlogIssues.map((i) => i.key),
        devStatus,
        error: null
    };
}

async function buildReport(cfg) {
    const cfgErr = (msg) => { const e = new Error(msg); e.status = 400; return e; };
    if (!cfg.jiraBaseUrl) throw cfgErr('Не задан Jira baseURL');
    if (!cfg.jiraToken) throw cfgErr('Не задан Jira token');
    const areas = sanitizeAreas(cfg.areas);
    if (!areas.length) throw cfgErr('Не задано ни одного пространства (areas). Добавьте хотя бы одно в настройках.');

    const staleDays = Number(cfg.staleDays) || 3;
    const noMovementDays = Number(cfg.noMovementDays) || 2;

    // Параллельно по area, но с лимитом конкурентности
    const areaTasks = areas.map((a) => () => buildAreaReport(cfg, a));
    const areaReports = await pLimit(2, areaTasks);

    // Bitbucket / Confluence — общие, грузим один раз
    let bitbucket = null;
    if (cfg.bitbucketBaseUrl && cfg.bitbucketToken && cfg.bitbucketProjectKeys) {
        try { bitbucket = await fetchBitbucket(cfg, 48); }
        catch (e) { bitbucket = { error: e.message, commits: [], prs: [] }; }
    }
    let confluence = null;
    if (cfg.confluenceBaseUrl && cfg.confluenceToken) {
        try { confluence = await fetchConfluence(cfg, 48); }
        catch (e) { confluence = { error: e.message, pages: [] }; }
    }

    const yFrom = startOfYesterday();
    const yTo = startOfToday();
    const dbyFrom = startOfDayBeforeYesterday();
    const dbyTo = yFrom;
    const last48hFrom = new Date(Date.now() - 48 * 3600 * 1000);
    const last48hTo = new Date();

    return {
        generatedAt: new Date().toISOString(),
        yesterdayRange: { from: yFrom.toISOString(), to: yTo.toISOString() },
        dayBeforeYesterdayRange: { from: dbyFrom.toISOString(), to: dbyTo.toISOString() },
        last48hRange: { from: last48hFrom.toISOString(), to: last48hTo.toISOString() },
        staleDays,
        noMovementDays,
        areas: areaReports,
        bitbucket,
        confluence
    };
}

// ------------------------- Статика -------------------------

const MIME = {
    '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8', '.mjs': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
    '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8'
};
function serveStatic(req, res, urlPath) {
    let rel = decodeURIComponent(urlPath.split('?')[0]);
    if (rel === '/' || rel === '') rel = '/index.html';
    const filePath = path.join(PUBLIC_DIR, rel);
    if (!filePath.startsWith(PUBLIC_DIR)) return sendText(res, 403, 'Forbidden');
    fs.stat(filePath, (err, stat) => {
        if (err || !stat.isFile()) return sendText(res, 404, 'Not found');
        const ext = path.extname(filePath).toLowerCase();
        res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': stat.size, 'Cache-Control': 'no-cache' });
        fs.createReadStream(filePath).pipe(res);
    });
}

// ------------------------- Роутинг -------------------------

async function handle(req, res) {
    const parsed = url.parse(req.url);
    const pathname = parsed.pathname || '/';
    const method = req.method || 'GET';

    if (pathname.startsWith('/api/')) {
        try {
            if (pathname === '/api/config' && method === 'GET') return sendJson(res, 200, sanitizeConfig(readConfig()));

            if (pathname === '/api/config' && method === 'POST') {
                const body = await readBody(req);
                const patch = {};
                for (const k of ['jiraBaseUrl', 'bitbucketBaseUrl', 'bitbucketProjectKeys', 'confluenceBaseUrl']) {
                    if (typeof body[k] === 'string') patch[k] = body[k].trim();
                }
                if (Array.isArray(body.areas)) patch.areas = sanitizeAreas(body.areas);
                if (typeof body.allowInsecureTls === 'boolean') patch.allowInsecureTls = body.allowInsecureTls;
                if (typeof body.staleDays === 'number') patch.staleDays = body.staleDays;
                if (typeof body.noMovementDays === 'number') patch.noMovementDays = body.noMovementDays;
                if (typeof body.jiraToken === 'string' && body.jiraToken.length) patch.jiraToken = body.jiraToken;
                if (typeof body.bitbucketToken === 'string' && body.bitbucketToken.length) patch.bitbucketToken = body.bitbucketToken;
                if (typeof body.confluenceToken === 'string' && body.confluenceToken.length) patch.confluenceToken = body.confluenceToken;
                if (typeof body.jira2Token === 'string' && body.jira2Token.length) patch.jira2Token = body.jira2Token;
                if (body.clearJiraToken === true) patch.jiraToken = '';
                if (body.clearBitbucketToken === true) patch.bitbucketToken = '';
                if (body.clearConfluenceToken === true) patch.confluenceToken = '';
                if (body.clearJira2Token === true) patch.jira2Token = '';
                if (typeof body.jira2BaseUrl === 'string') patch.jira2BaseUrl = body.jira2BaseUrl.trim();
                if (typeof body.jira2EpicKeys === 'string') patch.jira2EpicKeys = body.jira2EpicKeys.trim();
                const next = writeConfig(patch);
                return sendJson(res, 200, sanitizeConfig(next));
            }

            if (pathname === '/api/verify' && method === 'POST') {
                const cfg = readConfig();
                if (!cfg.jiraBaseUrl || !cfg.jiraToken) return sendJson(res, 400, { ok: false, error: 'Сначала заполните Jira baseURL и token' });
                const me = await jiraGet(cfg, '/rest/api/2/myself');
                const checks = { jira: { ok: true, who: me.displayName || me.name } };
                if (cfg.bitbucketBaseUrl && cfg.bitbucketToken) {
                    try {
                        const bbMe = await bbGet(cfg, '/rest/api/1.0/users');
                        checks.bitbucket = { ok: true, sample: (bbMe.values || []).length + ' users' };
                    } catch (e) { checks.bitbucket = { ok: false, error: e.message }; }
                }
                if (cfg.confluenceBaseUrl && cfg.confluenceToken) {
                    try {
                        const cMe = await confGet(cfg, '/rest/api/user/current');
                        checks.confluence = { ok: true, who: cMe.displayName || cMe.username };
                    } catch (e) { checks.confluence = { ok: false, error: e.message }; }
                }
                return sendJson(res, 200, { ok: true, checks });
            }

            if (pathname === '/api/report' && method === 'POST') {
                const cfg = readConfig();
                const report = await buildReport(cfg);
                return sendJson(res, 200, report);
            }

            if (pathname === '/api/blackdash' && method === 'POST') {
                const cfg = readConfig();
                const result = await fetchBlackDash(cfg);
                return sendJson(res, 200, result);
            }

            return sendJson(res, 404, { error: 'Неизвестный API-метод' });
        } catch (e) {
            const status = e.status && e.status >= 400 && e.status < 600 ? e.status : 500;
            return sendJson(res, status, { error: e.message || String(e) });
        }
    }

    if (method !== 'GET' && method !== 'HEAD') return sendText(res, 405, 'Method not allowed');
    return serveStatic(req, res, pathname);
}

const server = http.createServer((req, res) => {
    handle(req, res).catch((e) => { try { sendJson(res, 500, { error: 'Внутренняя ошибка: ' + (e.message || String(e)) }); } catch (_) {} });
});

server.listen(PORT, HOST, () => {
    const addr = `http://${HOST}:${PORT}`;
    console.log('\n╭──────────────────────────────────────────────╮');
    console.log('│  Portfolio Pulse запущен                     │');
    console.log(`│  Откройте: ${addr.padEnd(34)}│`);
    console.log('│  Остановка: Ctrl+C                           │');
    console.log('╰──────────────────────────────────────────────╯\n');
});

process.on('SIGINT', () => { console.log('\nОстанавливаемся…'); server.close(() => process.exit(0)); });
process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
