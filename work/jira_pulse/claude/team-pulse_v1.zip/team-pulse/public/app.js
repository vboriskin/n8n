// Team Pulse — frontend. Vanilla JS.

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const state = {
    config: null,
    report: null,
    activeTab: 'people',
    filterPeopleText: '',
    onlyYesterday: false,
    people: null,
    unassigned: null
};

// ============ Утилиты ============

const TERMINAL_NAME_HINTS = ['done', 'closed', 'resolved', 'completed', 'cancel', 'rejected', 'готово', 'закрыт', 'выполн', 'отмен', 'отклон'];
const INITIAL_NAME_HINTS  = ['open', 'to do', 'todo', 'backlog', 'created', 'new', 'draft', 'reopened', 'к выполнению', 'открыт', 'новая', 'черновик'];

function fmtDateTime(iso) { if (!iso) return ''; return new Date(iso).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); }
function fmtDate(iso) { if (!iso) return ''; return new Date(iso).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }); }
function fmtTimeShort(iso) { if (!iso) return ''; return new Date(iso).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }); }
function daysSince(iso) { if (!iso) return null; return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000); }
function hoursToReadable(seconds) {
    if (!seconds) return '';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    if (h && m) return `${h}ч ${m}м`;
    if (h) return `${h}ч`;
    return `${m}м`;
}
function escapeHtml(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function initials(name) {
    if (!name) return '?';
    const parts = String(name).trim().split(/\s+/);
    return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase() || '?';
}
function colorFromString(s) {
    let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    const hue = h % 360;
    return `linear-gradient(135deg, hsl(${hue} 55% 30%), hsl(${(hue + 60) % 360} 55% 30%))`;
}

function toast(text, kind = '') {
    const el = $('#toast');
    el.textContent = text;
    el.className = 'toast ' + kind;
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.add('hidden'), 3500);
}

// ============ API ============

async function api(path, opts = {}) {
    const resp = await fetch(path, {
        method: opts.method || 'GET',
        headers: { 'Content-Type': 'application/json' },
        body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    const text = await resp.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (_) { data = { error: text }; }
    if (!resp.ok) throw new Error((data && data.error) || `HTTP ${resp.status}`);
    return data;
}

// ============ Настройки ============

async function loadConfig() { state.config = await api('/api/config'); return state.config; }

function openSettings() {
    const cfg = state.config || {};
    $('#cfg-jira-url').value = cfg.jiraBaseUrl || '';
    $('#cfg-project').value = cfg.projectKey || '';
    $('#cfg-jira-token').value = ''; $('#cfg-jira-token').placeholder = cfg.hasJiraToken ? '•••••••• (пусто = не менять)' : '';
    $('#cfg-bb-url').value = cfg.bitbucketBaseUrl || '';
    $('#cfg-bb-token').value = ''; $('#cfg-bb-token').placeholder = cfg.hasBitbucketToken ? '•••••••• (пусто = не менять)' : '';
    $('#cfg-bb-projects').value = cfg.bitbucketProjectKeys || '';
    $('#cfg-conf-url').value = cfg.confluenceBaseUrl || '';
    $('#cfg-conf-token').value = ''; $('#cfg-conf-token').placeholder = cfg.hasConfluenceToken ? '•••••••• (пусто = не менять)' : '';
    $('#cfg-stale').value = cfg.staleDays ?? 3;
    $('#cfg-nomov').value = cfg.noMovementDays ?? 2;
    $('#cfg-insecure').checked = !!cfg.allowInsecureTls;
    $('#settings-error').classList.add('hidden');
    $('#modal-settings').classList.remove('hidden');
    $('#cfg-jira-url').focus();
}
function closeSettings() { $('#modal-settings').classList.add('hidden'); }

function collectSettingsPayload() {
    const payload = {
        jiraBaseUrl: $('#cfg-jira-url').value.trim(),
        projectKey: $('#cfg-project').value.trim(),
        bitbucketBaseUrl: $('#cfg-bb-url').value.trim(),
        bitbucketProjectKeys: $('#cfg-bb-projects').value.trim(),
        confluenceBaseUrl: $('#cfg-conf-url').value.trim(),
        staleDays: Number($('#cfg-stale').value) || 3,
        noMovementDays: Number($('#cfg-nomov').value) || 2,
        allowInsecureTls: $('#cfg-insecure').checked
    };
    const jt = $('#cfg-jira-token').value; if (jt) payload.jiraToken = jt;
    const bt = $('#cfg-bb-token').value; if (bt) payload.bitbucketToken = bt;
    const ct = $('#cfg-conf-token').value; if (ct) payload.confluenceToken = ct;
    return payload;
}

async function saveSettings() {
    const errEl = $('#settings-error'); errEl.classList.add('hidden');
    try {
        const cfg = await api('/api/config', { method: 'POST', body: collectSettingsPayload() });
        state.config = cfg;
        toast('Настройки сохранены', 'good');
        closeSettings();
        await refresh();
    } catch (e) { errEl.textContent = 'Не удалось сохранить: ' + e.message; errEl.classList.remove('hidden'); }
}

async function verifySettings() {
    const errEl = $('#settings-error'); errEl.classList.add('hidden');
    try {
        await api('/api/config', { method: 'POST', body: collectSettingsPayload() });
        const r = await api('/api/verify', { method: 'POST' });
        const checks = r.checks || {};
        const lines = [];
        if (checks.jira) lines.push(`Jira: ${checks.jira.who}`);
        if (checks.bitbucket) lines.push(`Bitbucket: ${checks.bitbucket.ok ? 'ok' : 'ошибка — ' + checks.bitbucket.error}`);
        if (checks.confluence) lines.push(`Confluence: ${checks.confluence.ok ? checks.confluence.who : 'ошибка — ' + checks.confluence.error}`);
        toast('Подключение: ' + lines.join(' · '), 'good');
    } catch (e) { errEl.textContent = 'Ошибка подключения: ' + e.message; errEl.classList.remove('hidden'); }
}

// ============ Основной цикл ============

async function refresh() {
    const cfg = await loadConfig();
    if (!cfg.jiraBaseUrl || !cfg.hasJiraToken || !cfg.projectKey) { showPane('empty'); return; }

    const btn = $('#btn-refresh'); btn.classList.add('is-loading'); btn.disabled = true;
    try {
        state.report = await api('/api/report', { method: 'POST' });
        renderAll();
        showPane(state.activeTab);
        const at = new Date(state.report.generatedAt);
        $('#meta').textContent = `обновлено ${at.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })} · проект ${state.report.projectKey}`;
    } catch (e) { toast('Не удалось загрузить отчёт: ' + e.message, 'bad'); console.error(e); }
    finally { btn.classList.remove('is-loading'); btn.disabled = false; }
}

function showPane(name) {
    state.activeTab = name;
    $$('.pane').forEach((p) => p.classList.add('hidden'));
    const el = $('#pane-' + name);
    if (el) el.classList.remove('hidden');
    $$('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
}

// ============ Семантика статусов ============

function statusCategory(issue) { return issue.fields?.status?.statusCategory?.key || 'new'; }
function statusName(issue) { return issue.fields?.status?.name || ''; }

function isTerminalStatusName(name) {
    if (!name) return false;
    const n = name.toLowerCase();
    return TERMINAL_NAME_HINTS.some((h) => n.includes(h));
}
function isInitialStatusName(name) {
    if (!name) return true;
    const n = name.toLowerCase();
    return INITIAL_NAME_HINTS.some((h) => n.includes(h));
}

function hasAnyStatusChange(issue) {
    const hist = issue.changelog?.histories || [];
    return hist.some((h) => (h.items || []).some((i) => i.field === 'status'));
}
function hasAnyWorklog(issue) { return (issue.fields?.worklog?.worklogs || []).length > 0; }

// WIP: не done И (indeterminate ИЛИ есть изменения статуса/worklog/комменты)
function isWip(issue) {
    if (statusCategory(issue) === 'done') return false;
    if (statusCategory(issue) === 'indeterminate') return true;
    if (hasAnyStatusChange(issue)) return true;
    if (hasAnyWorklog(issue)) return true;
    const cm = issue.fields?.comment?.comments || [];
    if (cm.length) return true;
    return false;
}

function statusChip(issue) {
    const cat = statusCategory(issue);
    const cls = cat === 'done' ? 'status-done' : cat === 'indeterminate' ? 'status-inprogress' : 'status-todo';
    return `<span class="chip ${cls}" title="${escapeHtml(statusName(issue))}">${escapeHtml(statusName(issue))}</span>`;
}
function priorityChip(issue) {
    const p = issue.fields?.priority?.name; if (!p) return '';
    const cls = 'prio-' + p.toLowerCase().replace(/\s+/g, '-');
    return `<span class="chip ${cls}">${escapeHtml(p)}</span>`;
}

// ============ Типы задач ============

const TYPE_ICONS = {
    'story': '📗', 'история': '📗',
    'task':  '✅', 'задача': '✅',
    'bug':   '🐞', 'баг': '🐞', 'дефект': '🐞',
    'sub-task': '↳', 'subtask': '↳', 'подзадача': '↳',
    'epic':  '🟪', 'эпик': '🟪',
    'improvement': '✨', 'new feature': '🌱'
};
function issueType(issue) { return issue.fields?.issuetype?.name || '—'; }
function isSubtask(issue) {
    return !!issue.fields?.issuetype?.subtask
        || /sub.?task|подзадача/i.test(issueType(issue));
}
function typeBucket(issue) {
    const t = (issueType(issue) || '').toLowerCase();
    if (isSubtask(issue)) return 'sub-task';
    if (/story|история/.test(t)) return 'story';
    if (/bug|баг|дефект/.test(t)) return 'bug';
    return 'task';
}
function typeIcon(type) { return TYPE_ICONS[(type || '').toLowerCase()] || '•'; }
function parentKeyOf(issue) { return issue.fields?.parent?.key || null; }
function parentSummaryOf(issue) { return issue.fields?.parent?.fields?.summary || ''; }

// ============ Активность за период ============

function inRange(iso, range) {
    if (!iso || !range) return false;
    const t = new Date(iso).getTime();
    return t >= new Date(range.from).getTime() && t < new Date(range.to).getTime();
}

function extractActivity(issue, range) {
    const out = { transitions: [], worklogs: [], commits: [], prs: [], updatesByUser: {}, comments: [] };
    for (const h of (issue.changelog?.histories || [])) {
        if (!inRange(h.created, range)) continue;
        const user = h.author?.name || h.author?.displayName || '—';
        out.updatesByUser[user] = (out.updatesByUser[user] || 0) + 1;
        for (const it of (h.items || [])) {
            if (it.field === 'status') out.transitions.push({ from: it.fromString, to: it.toString, at: h.created, by: user, byName: h.author?.displayName || user });
        }
    }
    for (const w of (issue.fields?.worklog?.worklogs || [])) {
        if (!inRange(w.started, range)) continue;
        out.worklogs.push({
            authorLogin: w.author?.name || '', authorName: w.author?.displayName || w.author?.name || '—',
            timeSpentSeconds: w.timeSpentSeconds || 0, started: w.started,
            comment: (typeof w.comment === 'string') ? w.comment : ''
        });
    }
    for (const c of (issue.fields?.comment?.comments || [])) {
        if (!inRange(c.created, range)) continue;
        out.comments.push({
            authorLogin: c.author?.name || '', authorName: c.author?.displayName || c.author?.name || '—',
            at: c.created, body: typeof c.body === 'string' ? c.body : ''
        });
    }
    // dev-status (Jira): commits & PRs за тот же период
    const ds = state.report?.devStatus?.[issue.key];
    if (ds) {
        for (const d of (ds.repo?.detail || [])) {
            for (const r of (d.repositories || [])) {
                for (const c of (r.commits || [])) {
                    if (inRange(c.authorTimestamp, range)) {
                        out.commits.push({
                            authorLogin: c.author?.name || c.author?.username || '',
                            authorName: c.author?.displayName || c.author?.name || c.author?.username || '—',
                            at: c.authorTimestamp,
                            message: c.message || '',
                            url: c.url || null,
                            source: 'dev'
                        });
                    }
                }
            }
        }
        for (const d of (ds.pr?.detail || [])) {
            for (const p of (d.pullRequests || [])) {
                const at = p.lastUpdate || p.updateDate;
                if (inRange(at, range)) {
                    out.prs.push({
                        authorLogin: p.author?.username || p.author?.name || '',
                        authorName: p.author?.displayName || p.author?.name || '—',
                        at, status: p.status || '', title: p.name || '', url: p.url || null, source: 'dev'
                    });
                }
            }
        }
    }
    return out;
}

function lastMovementIso(issue) {
    const dates = [];
    if (issue.fields?.updated) dates.push(issue.fields.updated);
    for (const h of (issue.changelog?.histories || [])) if (h.created) dates.push(h.created);
    for (const w of (issue.fields?.worklog?.worklogs || [])) if (w.started) dates.push(w.started);
    for (const c of (issue.fields?.comment?.comments || [])) if (c.created) dates.push(c.created);
    return dates.length ? dates.sort().at(-1) : null;
}

function assigneeOf(issue) {
    const a = issue.fields?.assignee; if (!a) return null;
    return {
        key: a.name || a.accountId || a.key || a.displayName,
        name: a.displayName || a.name || '—',
        login: a.name || a.accountId || '',
        email: a.emailAddress || ''
    };
}

// ============ Сопоставление пользователя с активностью BB/Confluence ============

function matchesUser(person, eventLogin, eventEmail, eventName) {
    if (!person) return false;
    const login = (eventLogin || '').toLowerCase();
    const email = (eventEmail || '').toLowerCase();
    const name = (eventName || '').toLowerCase();
    const pLogin = (person.login || '').toLowerCase();
    const pEmail = (person.email || '').toLowerCase();
    const pName = (person.name || '').toLowerCase();
    if (login && pLogin && login === pLogin) return true;
    if (email && pEmail && email === pEmail) return true;
    if (name && pName && name === pName) return true;
    return false;
}

// ============ Агрегация по людям ============

function aggregatePeople(report) {
    const ranges = {
        yesterday: report.yesterdayRange,
        dayBefore: report.dayBeforeYesterdayRange,
        last48h: report.last48hRange
    };

    const people = new Map();
    const ensure = (a) => {
        const key = a ? a.key : '__unassigned__';
        const name = a ? a.name : 'Без исполнителя';
        const login = a ? a.login : '';
        const email = a ? a.email : '';
        if (!people.has(key)) {
            people.set(key, {
                key, name, login, email,
                inProgress: [],            // [{issue, daysIdle?}]
                doneYesterday: [],         // [{issue, toStatus}]
                doneDayBefore: [],         // [{issue, toStatus}]
                yesterdayItems: [],        // [{issue, ya}]
                dayBeforeItems: [],        // [{issue, ya}]
                comments48h: [],           // [{issue, c}]
                stale: [],                 // [{issue, daysIdle}]
                stats: {
                    workSecYesterday: 0, workSecDayBefore: 0, workSec48h: 0,
                    commits48h: 0, prs48h: 0, confluence48h: 0
                },
                confluence: []             // [{title, url, at, space}]
            });
        }
        return people.get(key);
    };

    for (const issue of report.issues) {
        const a = assigneeOf(issue);
        const p = ensure(a);

        if (isWip(issue)) p.inProgress.push({ issue });

        const yA = extractActivity(issue, ranges.yesterday);
        const dA = extractActivity(issue, ranges.dayBefore);
        const lA = extractActivity(issue, ranges.last48h);

        // doneXxx — последняя транзиция в терминальный статус (категория done ИЛИ имя похоже на терминальное)
        const doneTrans = (acts) => acts.transitions.filter((t) => {
            const toCat = (t.toCategory || '').toLowerCase();
            return toCat === 'done' || isTerminalStatusName(t.to);
        });
        // у транзиций нет toCategory — приходится опираться на имя цели; ок т.к. INITIAL/TERMINAL hints покрывают разные локализации
        const yDone = doneTrans(yA);
        const dDone = doneTrans(dA);
        if (yDone.length) p.doneYesterday.push({ issue, toStatus: yDone[yDone.length - 1].to });
        if (dDone.length) p.doneDayBefore.push({ issue, toStatus: dDone[dDone.length - 1].to });

        const hasYAct = yA.transitions.length || yA.worklogs.length || yA.commits.length || yA.prs.length || Object.keys(yA.updatesByUser).length;
        const hasDAct = dA.transitions.length || dA.worklogs.length || dA.commits.length || dA.prs.length || Object.keys(dA.updatesByUser).length;
        if (hasYAct) p.yesterdayItems.push({ issue, ya: yA });
        if (hasDAct) p.dayBeforeItems.push({ issue, ya: dA });

        // комментарии 48ч этого исполнителя — сюда же должны попадать комменты, оставленные на чужих задачах,
        // но для карточки мы агрегируем по автору комментария (см. дальше отдельный проход)
        for (const c of lA.comments) {
            // ничего тут — авторов разнесём отдельным проходом
        }

        p.stats.workSecYesterday += yA.worklogs.reduce((s, w) => s + (w.timeSpentSeconds || 0), 0);
        p.stats.workSecDayBefore += dA.worklogs.reduce((s, w) => s + (w.timeSpentSeconds || 0), 0);
        p.stats.workSec48h += lA.worklogs.reduce((s, w) => s + (w.timeSpentSeconds || 0), 0);
        p.stats.commits48h += lA.commits.length;
        p.stats.prs48h += lA.prs.length;

        // stale
        if (isWip(issue)) {
            const mv = lastMovementIso(issue) || issue.fields?.updated;
            if (mv) {
                const d = daysSince(mv);
                if (d != null && d >= report.staleDays) p.stale.push({ issue, daysIdle: d });
            }
        }
    }

    // Комментарии 48ч — по автору (могут быть оставлены на чужих задачах в нашем датасете)
    for (const issue of report.issues) {
        for (const c of (issue.fields?.comment?.comments || [])) {
            if (!inRange(c.created, ranges.last48h)) continue;
            const login = c.author?.name || '';
            const email = c.author?.emailAddress || '';
            const name = c.author?.displayName || c.author?.name || '';
            // ищем подходящего человека в нашем списке
            let target = null;
            for (const p of people.values()) {
                if (matchesUser(p, login, email, name)) { target = p; break; }
            }
            if (!target && login) target = ensureExternal(people, { key: login, name: name || login, login, email });
            if (!target) continue;
            target.comments48h.push({ issue, c: { authorName: name || login, at: c.created, body: typeof c.body === 'string' ? c.body : '' } });
        }
    }

    // Bitbucket commits/PR — добавим к статистике и (если задача не в нашем датасете) — отдельным списком
    if (report.bitbucket) {
        for (const c of (report.bitbucket.commits || [])) {
            for (const p of people.values()) {
                if (matchesUser(p, c.author, c.authorEmail, c.authorDisplay)) {
                    p.stats.commits48h += 1;
                    p._bbCommits = p._bbCommits || []; p._bbCommits.push(c);
                    break;
                }
            }
        }
        for (const pr of (report.bitbucket.prs || [])) {
            for (const p of people.values()) {
                if (matchesUser(p, pr.author, pr.authorEmail, pr.authorDisplay)) {
                    p.stats.prs48h += 1;
                    p._bbPrs = p._bbPrs || []; p._bbPrs.push(pr);
                    break;
                }
            }
        }
    }

    // Confluence
    if (report.confluence) {
        for (const pg of (report.confluence.pages || [])) {
            for (const p of people.values()) {
                if (matchesUser(p, pg.byLogin, pg.byEmail, pg.byName)) {
                    p.confluence.push(pg);
                    p.stats.confluence48h += 1;
                    break;
                }
            }
        }
    }

    // Уберём пустого "без исполнителя" если нечего показать
    const un = people.get('__unassigned__');
    if (un && !un.inProgress.length && !un.yesterdayItems.length && !un.dayBeforeItems.length && !un.doneYesterday.length && !un.comments48h.length && !un.confluence.length) {
        people.delete('__unassigned__');
    }

    // Разделим: основные люди (по алфавиту, активные сверху) и unassigned — отдельно
    const arr = Array.from(people.values()).filter((p) => p.key !== '__unassigned__');
    arr.sort((a, b) => {
        const aA = a.yesterdayItems.length + a.doneYesterday.length;
        const bA = b.yesterdayItems.length + b.doneYesterday.length;
        if (bA !== aA) return bA - aA;
        return (a.name || '').localeCompare(b.name || '', 'ru');
    });
    return { people: arr, unassigned: people.get('__unassigned__') || null };
}

function ensureExternal(map, info) {
    if (map.has(info.key)) return map.get(info.key);
    const p = {
        key: info.key, name: info.name, login: info.login, email: info.email || '',
        inProgress: [], doneYesterday: [], doneDayBefore: [], yesterdayItems: [], dayBeforeItems: [],
        comments48h: [], stale: [], confluence: [],
        stats: { workSecYesterday: 0, workSecDayBefore: 0, workSec48h: 0, commits48h: 0, prs48h: 0, confluence48h: 0 },
        external: true
    };
    map.set(info.key, p);
    return p;
}

// ============ Тултип ============

const tipEl = () => $('#tip');
function showTip(html, x, y) {
    const t = tipEl();
    t.innerHTML = html;
    t.classList.remove('hidden');
    const w = t.offsetWidth, h = t.offsetHeight;
    const px = Math.min(window.innerWidth - w - 12, Math.max(8, x + 14));
    const py = Math.min(window.innerHeight - h - 12, Math.max(8, y + 14));
    t.style.left = px + 'px'; t.style.top = py + 'px';
}
function hideTip() { tipEl().classList.add('hidden'); }

function tipForIssue(issue) {
    const f = issue.fields || {};
    const desc = (f.description || '').toString().replace(/\r/g, '').slice(0, 600);
    const parent = parentKeyOf(issue);
    const tIcon = typeIcon(typeBucket(issue));
    return `
        <div class="tip-row">
            <span class="tip-title">${escapeHtml(issue.key)}</span>
            <span>${tIcon} ${escapeHtml(issueType(issue))}</span>
            ${statusChip(issue)} ${priorityChip(issue)}
        </div>
        <div class="tip-row"><b>${escapeHtml(f.summary || '')}</b></div>
        ${parent ? `<div class="tip-row" style="color:var(--text-mute)">↳ родитель: ${escapeHtml(parent)} ${escapeHtml(parentSummaryOf(issue))}</div>` : ''}
        ${desc ? `<div class="tip-desc">${escapeHtml(desc)}${(f.description || '').length > 600 ? '…' : ''}</div>` : '<div class="tip-row" style="color:var(--text-mute)">— без описания —</div>'}
    `;
}

// ============ Рендер: общее ============

function issueUrl(key) {
    const base = (state.config?.jiraBaseUrl || '').replace(/\/+$/, '');
    return base ? `${base}/browse/${key}` : '#';
}

function issueLine(issue, extra = {}) {
    const key = issue.key;
    const summary = issue.fields?.summary || '';
    const parentKey = parentKeyOf(issue);
    const right = [];
    right.push(statusChip(issue));
    const prio = priorityChip(issue); if (prio) right.push(prio);
    if (extra.daysIdle != null) right.push(`<span class="chip stale">${extra.daysIdle} дн без движения</span>`);
    if (extra.toStatus) right.push(`<span class="chip status-done">→ ${escapeHtml(extra.toStatus)}</span>`);
    if (extra.workSec) right.push(`<span class="chip">⏱ ${hoursToReadable(extra.workSec)}</span>`);
    return `
        <div class="issue">
            <a class="issue-key" href="${issueUrl(key)}" target="_blank" rel="noreferrer">${escapeHtml(key)}</a>
            <div class="issue-title">
                ${parentKey && isSubtask(issue) ? `<span class="parent">↳ ${escapeHtml(parentKey)}</span>` : ''}
                <span data-issue-key="${escapeHtml(key)}">${escapeHtml(summary)}</span>
                <span class="tip-icon" data-tip-issue="${escapeHtml(key)}" aria-label="детали">?</span>
            </div>
            <div class="issue-meta">${right.join(' ')}</div>
        </div>`;
}

// группировка задач по типам
function groupByType(issues) {
    const order = ['story', 'task', 'bug', 'sub-task'];
    const byType = new Map();
    for (const it of issues) {
        const t = typeBucket(it);
        if (!byType.has(t)) byType.set(t, []);
        byType.get(t).push(it);
    }
    return order.filter((t) => byType.has(t)).map((t) => ({ type: t, items: byType.get(t) }));
}
function typeLabel(t) { return ({ 'story': 'Истории', 'task': 'Задачи', 'bug': 'Баги', 'sub-task': 'Подзадачи' })[t] || t; }

function renderTypeGroups(items, mapper) {
    if (!items.length) return '<div class="empty">Пусто.</div>';
    const groups = groupByType(items);
    return groups.map((g) => `
        <div class="type-group">
            <div class="type-header">
                <span class="type-icon">${typeIcon(g.type)}</span>
                <span class="type-name">${typeLabel(g.type)}</span>
                <span class="type-count">· ${g.items.length}</span>
            </div>
            ${g.items.map(mapper).join('')}
        </div>`).join('');
}

// ============ Рендер: Команда ============

function renderPeople() {
    const report = state.report;
    const { people, unassigned } = aggregatePeople(report);
    state.people = people; state.unassigned = unassigned;

    const text = state.filterPeopleText.trim().toLowerCase();
    const filtered = people.filter((p) => {
        if (state.onlyYesterday && !p.yesterdayItems.length && !p.doneYesterday.length) return false;
        if (!text) return true;
        return (p.name || '').toLowerCase().includes(text) || (p.login || '').toLowerCase().includes(text);
    });

    const list = $('#people-list');
    list.innerHTML = filtered.length ? filtered.map((p) => personCard(p, report)).join('') : `<div class="empty-card"><p>Никого не нашли по фильтрам.</p></div>`;

    const un = $('#people-unassigned');
    un.innerHTML = unassigned ? personCard(unassigned, report, true) : '';
}

function personCard(p, report, isUnassigned = false) {
    // Сводные бейджи
    const badges = [];
    badges.push(`<span class="badge info">в работе:&nbsp;${p.inProgress.length}</span>`);
    if (p.doneYesterday.length) badges.push(`<span class="badge good">✅ закрыто вчера:&nbsp;${p.doneYesterday.length}</span>`);
    if (p.doneDayBefore.length) badges.push(`<span class="badge good">✅ позавчера:&nbsp;${p.doneDayBefore.length}</span>`);
    if (p.stats.workSec48h) badges.push(`<span class="badge">⏱ logtime 48ч:&nbsp;${hoursToReadable(p.stats.workSec48h)}</span>`);
    if (p.stats.commits48h) badges.push(`<span class="badge">⌥ commits:&nbsp;${p.stats.commits48h}</span>`);
    if (p.stats.prs48h) badges.push(`<span class="badge">PR:&nbsp;${p.stats.prs48h}</span>`);
    if (p.stats.confluence48h) badges.push(`<span class="badge">📄 Confluence:&nbsp;${p.stats.confluence48h}</span>`);
    if (p.comments48h.length) badges.push(`<span class="badge">💬 комментов:&nbsp;${p.comments48h.length}</span>`);
    if (p.stale.length) badges.push(`<span class="badge bad">🐌 висит:&nbsp;${p.stale.length}</span>`);

    // Секция «В работе сейчас»
    const inProgressItems = p.inProgress.map((x) => x.issue);
    const inProgressBody = renderTypeGroups(inProgressItems, (it) => {
        const mv = lastMovementIso(it) || it.fields.updated;
        const d = daysSince(mv);
        return issueLine(it, d != null && d >= report.staleDays ? { daysIdle: d } : {});
    });

    // Универсальный билдер «что делал» по списку yesterdayItems / dayBeforeItems
    const buildActivityList = (items) => {
        if (!items.length) return '<div class="empty">Без изменений.</div>';
        // группируем эти задачи по типам и рисуем для каждой описание активности (себя как автора)
        const issues = items.map((x) => x.issue);
        return renderTypeGroups(issues, (it) => {
            const a = items.find((x) => x.issue.key === it.key)?.ya;
            const lines = [];
            for (const t of (a?.transitions || [])) {
                const cat = isTerminalStatusName(t.to) ? 'status-done' : 'status-inprogress';
                lines.push(`<li><span class="bullet">→</span> Перевели в <span class="chip ${cat}">${escapeHtml(t.to)}</span> <span style="color:var(--text-mute)">(из ${escapeHtml(t.from || '—')}, ${fmtTimeShort(t.at)})</span></li>`);
            }
            for (const w of (a?.worklogs || [])) {
                lines.push(`<li><span class="bullet">⏱</span> logtime ${hoursToReadable(w.timeSpentSeconds)}${w.comment ? ' — ' + escapeHtml(w.comment.slice(0, 120)) : ''}</li>`);
            }
            for (const c of (a?.commits || [])) {
                lines.push(`<li><span class="bullet">⌥</span> ${c.url ? `<a href="${escapeHtml(c.url)}" target="_blank">commit</a>` : 'commit'}: ${escapeHtml((c.message || '').split('\n')[0].slice(0, 140))} <span style="color:var(--text-mute)">${fmtTimeShort(c.at)}</span></li>`);
            }
            for (const pr of (a?.prs || [])) {
                lines.push(`<li><span class="bullet">PR</span> ${pr.url ? `<a href="${escapeHtml(pr.url)}" target="_blank">${escapeHtml(pr.title)}</a>` : escapeHtml(pr.title)} <span style="color:var(--text-mute)">${escapeHtml(pr.status || '')} · ${fmtTimeShort(pr.at)}</span></li>`);
            }
            if (!lines.length && a && Object.keys(a.updatesByUser || {}).length) {
                lines.push(`<li><span class="bullet">✎</span> правки полей</li>`);
            }
            return `
                <div class="issue">
                    <a class="issue-key" href="${issueUrl(it.key)}" target="_blank">${escapeHtml(it.key)}</a>
                    <div class="issue-title">
                        ${parentKeyOf(it) && isSubtask(it) ? `<span class="parent">↳ ${escapeHtml(parentKeyOf(it))}</span>` : ''}
                        <span>${escapeHtml(it.fields.summary)}</span>
                        <span class="tip-icon" data-tip-issue="${escapeHtml(it.key)}">?</span>
                        <ul class="activity-list">${lines.join('')}</ul>
                    </div>
                    <div class="issue-meta">${statusChip(it)} ${priorityChip(it)}</div>
                </div>`;
        });
    };

    const yesterdayBody = buildActivityList(p.yesterdayItems);
    const dayBeforeBody = buildActivityList(p.dayBeforeItems);

    // Комменты 48ч
    const commentsBody = p.comments48h.length
        ? `<ul class="activity-list">${p.comments48h.slice(0, 50).map((x) => `
            <li>
                <a class="issue-key" href="${issueUrl(x.issue.key)}" target="_blank">${escapeHtml(x.issue.key)}</a>
                <span style="color:var(--text-mute)"> · ${fmtDateTime(x.c.at)}</span>
                <div style="color:var(--text-dim);margin-top:2px">${escapeHtml(x.c.body.slice(0, 280))}${x.c.body.length > 280 ? '…' : ''}</div>
            </li>`).join('')}</ul>`
        : '<div class="empty">Комментариев за 48ч не оставлял.</div>';

    // Confluence 48ч
    const confluenceBody = p.confluence.length
        ? `<ul class="activity-list">${p.confluence.slice(0, 50).map((pg) => `
            <li>
                ${pg.url ? `<a href="${escapeHtml(pg.url)}" target="_blank">${escapeHtml(pg.title)}</a>` : escapeHtml(pg.title)}
                <span style="color:var(--text-mute)"> · ${escapeHtml(pg.space || '')} · ${fmtDateTime(pg.at)}</span>
            </li>`).join('')}</ul>`
        : (state.config?.hasConfluenceToken ? '<div class="empty">Правок в Confluence за 48ч не было.</div>' : '<div class="empty">Confluence не настроен — заполните baseURL и token в настройках.</div>');

    return `
        <div class="person-card${isUnassigned ? ' unassigned' : ''}">
            <div class="person-head">
                <div class="avatar" style="background:${colorFromString(p.key || p.name)}">${escapeHtml(initials(p.name))}</div>
                <div class="person-id">
                    <div class="person-name">${escapeHtml(p.name)}</div>
                    <div class="person-login">${escapeHtml(p.login || '')}${p.external ? ' · только активность' : ''}</div>
                </div>
                <div class="person-stats">${badges.join('')}</div>
            </div>

            <details class="section">
                <summary>В работе сейчас <span class="count">${p.inProgress.length}</span></summary>
                <div class="body">${inProgressBody}</div>
            </details>

            <details class="section">
                <summary>Сделал вчера <span class="count">${p.yesterdayItems.length + p.doneYesterday.length}</span></summary>
                <div class="body">${yesterdayBody}</div>
            </details>

            <details class="section">
                <summary>Сделал позавчера <span class="count">${p.dayBeforeItems.length + p.doneDayBefore.length}</span></summary>
                <div class="body">${dayBeforeBody}</div>
            </details>

            <details class="section">
                <summary>Оставил комментарии (48ч) <span class="count">${p.comments48h.length}</span></summary>
                <div class="body">${commentsBody}</div>
            </details>

            <details class="section">
                <summary>Изменения в Confluence (48ч) <span class="count">${p.confluence.length}</span></summary>
                <div class="body">${confluenceBody}</div>
            </details>

            ${p.stale.length ? `
                <details class="section" open>
                    <summary>Висят &gt; ${report.staleDays} дн <span class="count">${p.stale.length}</span></summary>
                    <div class="body">${p.stale.map((s) => issueLine(s.issue, { daysIdle: s.daysIdle })).join('')}</div>
                </details>
            ` : ''}
        </div>`;
}

// ============ Рендер: Сводная ============

function renderSummary() {
    const report = state.report;
    const { people } = aggregatePeople(report);

    const sprintCount = report.sprintKeys.length;
    const wipCount = report.issues.filter(isWip).length;
    const staleCount = people.reduce((s, p) => s + p.stale.length, 0);
    const doneYesterdayCount = people.reduce((s, p) => s + p.doneYesterday.length, 0);

    $('#stat-sprint').textContent = sprintCount;
    $('#stat-sprint-sub').textContent = 'в активном спринте';
    $('#stat-wip').textContent = wipCount;
    $('#stat-wip-sub').textContent = 'in-progress либо с активностью';
    $('#stat-stale').textContent = staleCount;
    $('#stat-stale-sub').textContent = `порог ${report.staleDays} дн без движения`;
    $('#stat-done').textContent = doneYesterdayCount;
    $('#stat-done-sub').textContent = 'переведены в терминальный статус вчера';

    // Разбивка по типам — вчера: done / wip / todo (среди задач, обновлённых вчера или в активном спринте)
    const scope = report.issues.filter((it) => report.sprintKeys.includes(it.key) || inRange(it.fields?.updated, report.yesterdayRange));
    $('#summary-types').innerHTML = renderTypeBreakdown(scope);

    // Что делали вчера
    const yEl = $('#summary-yesterday');
    const yRows = people.filter((p) => p.yesterdayItems.length || p.doneYesterday.length).slice(0, 50).map((p) => {
        const bits = [];
        if (p.doneYesterday.length) bits.push(`<span class="chip status-done">✅ ${p.doneYesterday.length}</span>`);
        if (p.stats.workSecYesterday) bits.push(`<span class="chip">⏱ ${hoursToReadable(p.stats.workSecYesterday)}</span>`);
        if (p.stats.commits48h) bits.push(`<span class="chip">⌥ ${p.stats.commits48h}</span>`);
        const issues = [...new Set([...p.doneYesterday.map((d) => d.issue), ...p.yesterdayItems.map((a) => a.issue)])].slice(0, 6);
        const links = issues.map((it) => `
            <a class="issue-key" href="${issueUrl(it.key)}" target="_blank">${it.key}</a><span class="tip-icon" data-tip-issue="${escapeHtml(it.key)}">?</span>`).join(' ');
        return `<div class="issue">
            <div class="issue-key">${escapeHtml(p.name)}</div>
            <div class="issue-title">${links || '<span style="color:var(--text-mute)">—</span>'}</div>
            <div class="issue-meta">${bits.join(' ')}</div>
        </div>`;
    });
    yEl.innerHTML = yRows.length ? yRows.join('') : '<div class="empty">Вчера тишина.</div>';

    // План на сегодня = всё в работе
    const plan = new Map();
    for (const p of people) for (const x of p.inProgress) {
        if (!plan.has(p.name)) plan.set(p.name, []);
        plan.get(p.name).push(x.issue);
    }
    const planEl = $('#summary-today');
    if (!plan.size) planEl.innerHTML = '<div class="empty">Нет задач в работе.</div>';
    else planEl.innerHTML = Array.from(plan.entries()).sort((a, b) => a[0].localeCompare(b[0], 'ru')).map(([name, arr]) => {
        const links = arr.map((it) => `<a class="issue-key" href="${issueUrl(it.key)}" target="_blank">${it.key}</a><span class="tip-icon" data-tip-issue="${escapeHtml(it.key)}">?</span>`).join(' ');
        return `<div class="issue">
            <div class="issue-key">${escapeHtml(name)}</div>
            <div class="issue-title">${links}</div>
            <div class="issue-meta"><span class="chip">${arr.length}</span></div>
        </div>`;
    }).join('');
}

function renderTypeBreakdown(scope) {
    const types = ['story', 'task', 'bug', 'sub-task'];
    const total = { done: 0, wip: 0, todo: 0 };
    const byType = {};
    for (const t of types) byType[t] = { done: 0, wip: 0, todo: 0 };
    for (const it of scope) {
        const t = typeBucket(it);
        const cat = statusCategory(it);
        const wip = isWip(it);
        let bucket;
        if (cat === 'done') bucket = 'done';
        else if (wip) bucket = 'wip';
        else bucket = 'todo';
        byType[t][bucket] += 1;
        total[bucket] += 1;
    }

    const legend = `
        <div class="legend" style="margin-bottom:10px">
            <span><span class="dot done"></span> Готово</span>
            <span><span class="dot wip"></span> В работе</span>
            <span><span class="dot todo"></span> Не приступали</span>
        </div>`;
    const rows = types.filter((t) => (byType[t].done + byType[t].wip + byType[t].todo) > 0).map((t) => {
        const sum = byType[t].done + byType[t].wip + byType[t].todo;
        const pct = (n) => sum ? Math.round(n / sum * 100) : 0;
        return `
            <div class="type-row">
                <div class="type-title"><span>${typeIcon(t)}</span><span>${typeLabel(t)}</span></div>
                <div class="bar">
                    <span class="seg-done" style="width:${pct(byType[t].done)}%"></span>
                    <span class="seg-wip"  style="width:${pct(byType[t].wip)}%"></span>
                    <span class="seg-todo" style="width:${pct(byType[t].todo)}%"></span>
                </div>
                <div style="text-align:right;color:var(--text-dim);font-size:12px">
                    ✅ ${byType[t].done} · ▶ ${byType[t].wip} · ☐ ${byType[t].todo}
                </div>
            </div>`;
    }).join('');
    return legend + rows;
}

// ============ Рендер: Спринт ============

function renderSprint() {
    const report = state.report;
    const sprintIssues = report.issues.filter((it) => report.sprintKeys.includes(it.key));
    if (!sprintIssues.length) {
        $('#sprint-stats').innerHTML = '';
        $('#sprint-types').innerHTML = '<div class="empty">Активный спринт не найден.</div>';
        $('#sprint-insights').innerHTML = '';
        return;
    }

    const total = sprintIssues.length;
    const done = sprintIssues.filter((it) => statusCategory(it) === 'done').length;
    const wip  = sprintIssues.filter(isWip).length;
    const todo = total - done - wip;
    const pct = Math.round(done / total * 100);

    $('#sprint-stats').innerHTML = `
        <div class="stat-card stat-info">
            <div class="stat-label">Всего</div>
            <div class="stat-value">${total}</div>
            <div class="stat-sub">в активном спринте</div>
        </div>
        <div class="stat-card stat-good">
            <div class="stat-label">Готово</div>
            <div class="stat-value">${done}</div>
            <div class="stat-sub">${pct}% спринта</div>
        </div>
        <div class="stat-card stat-info">
            <div class="stat-label">В работе</div>
            <div class="stat-value">${wip}</div>
        </div>
        <div class="stat-card stat-warn">
            <div class="stat-label">Не приступали</div>
            <div class="stat-value">${todo}</div>
        </div>`;

    $('#sprint-types').innerHTML = renderTypeBreakdown(sprintIssues);

    // Инсайты по спринту
    const sIns = [];
    if (todo / total > 0.5) sIns.push({ sev: 'warn', icon: '⏳', title: `${Math.round(todo / total * 100)}% спринта ещё не взято в работу`, desc: 'Если спринт уже на середине — пора брать или резать scope.', tag: 'scope' });
    if (wip / Math.max(1, total - done) > 0.5) sIns.push({ sev: 'warn', icon: '🪢', title: `WIP ${wip} из ${total - done} оставшихся (>50%)`, desc: 'Слишком много задач в работе одновременно — поток ломается, переключения дорогие.', tag: 'wip' });
    // перекос на одного человека
    const counts = new Map();
    for (const it of sprintIssues) { const a = assigneeOf(it); const k = a ? a.name : '—'; counts.set(k, (counts.get(k) || 0) + 1); }
    const sortedC = Array.from(counts.entries()).sort((a, b) => b[1] - a[1]);
    if (sortedC[0] && sortedC[0][1] / total > 0.4 && sortedC[0][0] !== '—') {
        sIns.push({ sev: 'warn', icon: '🧍', title: `One-man-show: ${escapeHtml(sortedC[0][0])} — ${sortedC[0][1]} из ${total}`, desc: 'Возможный bus-factor 1. Подумайте про перераспределение.', tag: 'risk' });
    }
    // багов в спринте
    const bugs = sprintIssues.filter((it) => typeBucket(it) === 'bug');
    if (bugs.length / total > 0.3) sIns.push({ sev: 'info', icon: '🐞', title: `Доля багов в спринте — ${Math.round(bugs.length / total * 100)}%`, desc: 'Высокий технический долг или регресс. Возможно, стоит обсудить корневые причины.', tag: 'quality' });
    // подзадачи без родителя в спринте
    const orphans = sprintIssues.filter((it) => isSubtask(it) && !sprintIssues.some((p) => p.key === parentKeyOf(it)));
    if (orphans.length) sIns.push({ sev: 'info', icon: '🧩', title: `Подзадач без родителя в спринте: ${orphans.length}`, desc: orphans.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', '), tag: 'sync' });
    // closed parents с открытыми сабтасками
    const desync = sprintIssues.filter((p) => statusCategory(p) === 'done' && (p.fields?.subtasks || []).some((s) => s.fields?.status?.statusCategory?.key !== 'done'));
    if (desync.length) sIns.push({ sev: 'bad', icon: '🧷', title: `Закрытые задачи с незакрытыми подзадачами: ${desync.length}`, desc: desync.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', '), tag: 'quality' });
    // due date this week
    const inWeek = sprintIssues.filter((it) => {
        const d = it.fields?.duedate; if (!d || statusCategory(it) === 'done') return false;
        const t = new Date(d).getTime(); return t > Date.now() && t < Date.now() + 7 * 86400000;
    });
    if (inWeek.length) sIns.push({ sev: 'warn', icon: '📅', title: `Срок ≤7 дней: ${inWeek.length}`, desc: inWeek.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a> (до ${fmtDate(it.fields.duedate)})`).join(', '), tag: 'deadline' });

    $('#sprint-insights').innerHTML = sIns.length ? sIns.map(insightHtml).join('') : '<div class="empty">Сигналов по спринту нет.</div>';
}

// ============ Рендер: Метрики ============

function renderMetrics() {
    const report = state.report;
    const { people } = aggregatePeople(report);
    const grid = $('#metrics-grid');

    const widgets = [];

    // 1) WIP по людям
    const wipByPerson = people.map((p) => ({ name: p.name, val: p.inProgress.length })).filter((x) => x.val > 0).sort((a, b) => b.val - a.val).slice(0, 12);
    widgets.push(widgetHorizontalBars('WIP по людям', wipByPerson, ''));

    // 2) Logtime вчера по людям
    const logYest = people.map((p) => ({ name: p.name, val: Math.round((p.stats.workSecYesterday / 3600) * 10) / 10 })).filter((x) => x.val > 0).sort((a, b) => b.val - a.val).slice(0, 12);
    widgets.push(widgetHorizontalBars('Logtime вчера, ч', logYest, 'good'));

    // 3) Возраст задач в работе
    const ages = report.issues.filter(isWip).map((it) => daysSince(lastMovementIso(it) || it.fields?.updated)).filter((x) => x != null);
    widgets.push(widgetHistogram('Возраст задач в работе (дн)', ages, [0, 1, 3, 7, 14, 30]));

    // 4) Распределение по статус-категориям
    const cats = { 'To Do': 0, 'In Progress': 0, 'Done': 0 };
    for (const it of report.issues.filter((x) => report.sprintKeys.includes(x.key))) {
        const c = statusCategory(it);
        if (c === 'done') cats['Done'] += 1;
        else if (c === 'indeterminate') cats['In Progress'] += 1;
        else cats['To Do'] += 1;
    }
    widgets.push(widgetDonut('Спринт: статусы', [
        { label: 'Done', value: cats['Done'], color: 'var(--good)' },
        { label: 'In Progress', value: cats['In Progress'], color: 'var(--accent)' },
        { label: 'To Do', value: cats['To Do'], color: 'var(--text-mute)' }
    ]));

    // 5) Распределение по приоритетам
    const prio = new Map();
    for (const it of report.issues) {
        const p = it.fields?.priority?.name || '—';
        prio.set(p, (prio.get(p) || 0) + 1);
    }
    const colors = { 'Highest': 'var(--bad)', 'High': '#e08585', 'Medium': 'var(--warn)', 'Low': 'var(--text-mute)', 'Lowest': '#7a8597' };
    const prioData = Array.from(prio.entries()).map(([k, v]) => ({ label: k, value: v, color: colors[k] || 'var(--accent)' }));
    widgets.push(widgetDonut('Приоритеты (всё в датасете)', prioData));

    // 6) Commits/PR за 48ч по людям
    const commits = people.map((p) => ({ name: p.name, val: p.stats.commits48h + p.stats.prs48h })).filter((x) => x.val > 0).sort((a, b) => b.val - a.val).slice(0, 12);
    widgets.push(widgetHorizontalBars('Commits + PR (48ч)', commits, 'warn'));

    // 7) Confluence pages 48ч
    const conf = people.map((p) => ({ name: p.name, val: p.stats.confluence48h })).filter((x) => x.val > 0).sort((a, b) => b.val - a.val).slice(0, 12);
    widgets.push(widgetHorizontalBars('Confluence-правки (48ч)', conf, 'warn'));

    // 8) Закрыто vs открыто вчера
    const closedY = report.issues.filter((it) => {
        return (it.changelog?.histories || []).some((h) => inRange(h.created, report.yesterdayRange) && (h.items || []).some((i) => i.field === 'status' && (i.toString && (isTerminalStatusName(i.toString)))));
    }).length;
    const openedY = report.issues.filter((it) => inRange(it.fields?.created, report.yesterdayRange)).length;
    widgets.push(widgetTwoNumbers('Поток вчера', { left: { label: 'Закрыто', value: closedY, kind: 'good' }, right: { label: 'Открыто', value: openedY, kind: 'info' } }));

    grid.innerHTML = widgets.join('');
}

function widgetHorizontalBars(title, data, kind = '') {
    if (!data.length) return `<div class="widget"><h3>${escapeHtml(title)}</h3><div class="empty">Нет данных.</div></div>`;
    const max = Math.max(1, ...data.map((d) => d.val));
    return `<div class="widget"><h3>${escapeHtml(title)}</h3>
        ${data.map((d) => `
            <div class="hbar-row">
                <div title="${escapeHtml(d.name)}" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text)">${escapeHtml(d.name)}</div>
                <div class="hbar ${kind}"><span style="width:${(d.val / max * 100).toFixed(1)}%"></span></div>
                <div class="val">${d.val}</div>
            </div>`).join('')}
    </div>`;
}

function widgetHistogram(title, values, bins) {
    if (!values.length) return `<div class="widget"><h3>${escapeHtml(title)}</h3><div class="empty">Нет данных.</div></div>`;
    const buckets = [];
    for (let i = 0; i < bins.length; i++) {
        const lo = bins[i];
        const hi = i + 1 < bins.length ? bins[i + 1] : Infinity;
        const label = hi === Infinity ? `${lo}+` : `${lo}–${hi - 1}`;
        const count = values.filter((v) => v >= lo && v < hi).length;
        buckets.push({ name: label + ' дн', val: count });
    }
    return widgetHorizontalBars(title, buckets, 'warn').replace('class="widget"', 'class="widget"');
}

function widgetDonut(title, segments) {
    const total = segments.reduce((s, x) => s + x.value, 0);
    if (!total) return `<div class="widget"><h3>${escapeHtml(title)}</h3><div class="empty">Нет данных.</div></div>`;
    const r = 38, c = 2 * Math.PI * r;
    let acc = 0;
    const ringSegments = segments.map((s) => {
        const len = (s.value / total) * c;
        const off = c - len;
        const dasharray = `${len} ${c - len}`;
        const rotate = (acc / total) * 360 - 90;
        acc += s.value;
        return `<circle cx="50" cy="50" r="${r}" fill="none" stroke="${s.color}" stroke-width="14" stroke-dasharray="${dasharray}" stroke-dashoffset="0" transform="rotate(${rotate} 50 50)"></circle>`;
    }).join('');
    const legend = segments.filter((s) => s.value > 0).map((s) => `<div><span class="dot" style="display:inline-block;width:10px;height:10px;border-radius:999px;background:${s.color};margin-right:6px;"></span>${escapeHtml(s.label)} — ${s.value} (${Math.round(s.value / total * 100)}%)</div>`).join('');
    return `<div class="widget"><h3>${escapeHtml(title)}</h3>
        <div class="donut-wrap">
            <svg viewBox="0 0 100 100" width="120" height="120" aria-hidden="true">
                <circle cx="50" cy="50" r="${r}" fill="none" stroke="var(--bg-soft)" stroke-width="14"></circle>
                ${ringSegments}
                <text x="50" y="54" text-anchor="middle" font-size="13" fill="var(--text)">${total}</text>
            </svg>
            <div class="donut-legend">${legend}</div>
        </div>
    </div>`;
}

function widgetTwoNumbers(title, p) {
    const cell = (x) => `<div style="flex:1"><div class="big" style="color:${x.kind === 'good' ? 'var(--good)' : x.kind === 'bad' ? 'var(--bad)' : 'var(--accent)'}">${x.value}</div><div class="sub">${escapeHtml(x.label)}</div></div>`;
    return `<div class="widget"><h3>${escapeHtml(title)}</h3><div style="display:flex;gap:18px">${cell(p.left)}${cell(p.right)}</div></div>`;
}

// ============ Рендер: Инсайты ============

function insightHtml(i) {
    return `<div class="insight sev-${i.sev}">
        <div class="icon">${i.icon}</div>
        <div>
            <div class="title">${escapeHtml(i.title)}</div>
            <div class="desc">${i.desc}</div>
        </div>
        <div class="tag">${escapeHtml(i.tag || '')}</div>
    </div>`;
}

function computeInsights(report, people) {
    const insights = [];
    const wipIssues = report.issues.filter(isWip);

    // 1) Висит долго
    const staleAll = [];
    for (const p of people) for (const s of p.stale) staleAll.push({ ...s, person: p });
    if (staleAll.length) insights.push({
        sev: 'bad', icon: '🐌', tag: 'стагнация',
        title: `Висит в работе > ${report.staleDays} дн: ${staleAll.length}`,
        desc: staleAll.slice(0, 8).map((s) => `<a href="${issueUrl(s.issue.key)}" target="_blank">${s.issue.key}</a> · ${s.daysIdle}дн · ${escapeHtml(s.person.name)}`).join('<br>')
    });

    // 2) Тишина — есть в работе, но вчера ноль активности
    const silent = people.filter((p) => p.inProgress.length && !p.yesterdayItems.length && !p.doneYesterday.length && !p.external);
    if (silent.length) insights.push({
        sev: 'warn', icon: '🤫', tag: 'тишина',
        title: `Без активности вчера: ${silent.length} чел.`,
        desc: silent.slice(0, 8).map((p) => `${escapeHtml(p.name)} <span class="tag">(в работе ${p.inProgress.length})</span>`).join(' · ')
    });

    // 3) WIP > 3
    const overload = people.filter((p) => p.inProgress.length > 3);
    if (overload.length) insights.push({
        sev: 'warn', icon: '🧨', tag: 'перегруз',
        title: `WIP > 3 у ${overload.length} участника(ов)`,
        desc: overload.map((p) => `${escapeHtml(p.name)} — ${p.inProgress.length}`).join(' · ')
    });

    // 4) В спринте без исполнителя
    const noAssignee = report.issues.filter((it) => !it.fields?.assignee && report.sprintKeys.includes(it.key));
    if (noAssignee.length) insights.push({
        sev: 'warn', icon: '👻', tag: 'owner',
        title: `В спринте без исполнителя: ${noAssignee.length}`,
        desc: noAssignee.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ')
    });

    // 5) Просрочены
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const overdue = report.issues.filter((it) => {
        const d = it.fields?.duedate; if (!d || statusCategory(it) === 'done') return false;
        return new Date(d).getTime() < today.getTime();
    });
    if (overdue.length) insights.push({
        sev: 'bad', icon: '⏰', tag: 'срок',
        title: `Просрочены: ${overdue.length}`,
        desc: overdue.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a> (до ${fmtDate(it.fields.duedate)})`).join('<br>')
    });

    // 6) Высокий приоритет, не взято
    const hiTodo = report.issues.filter((it) => {
        const p = (it.fields?.priority?.name || '').toLowerCase();
        return ['highest', 'high', 'blocker', 'critical'].includes(p) && statusCategory(it) === 'new' && report.sprintKeys.includes(it.key);
    });
    if (hiTodo.length) insights.push({
        sev: 'warn', icon: '🔥', tag: 'prio',
        title: `Высокий приоритет не взят: ${hiTodo.length}`,
        desc: hiTodo.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ')
    });

    // 7) Закрыто вчера (позитив)
    const doneTotal = people.reduce((s, p) => s + p.doneYesterday.length, 0);
    if (doneTotal) {
        const top = people.filter((p) => p.doneYesterday.length).sort((a, b) => b.doneYesterday.length - a.doneYesterday.length).slice(0, 5);
        insights.push({ sev: 'good', icon: '✅', tag: 'win', title: `Перевели в Done вчера: ${doneTotal}`, desc: top.map((p) => `${escapeHtml(p.name)} — ${p.doneYesterday.length}`).join(' · ') });
    }

    // 8) Без logtime вчера
    const noWl = people.filter((p) => p.inProgress.length && !p.stats.workSecYesterday && (p.yesterdayItems.length || p.doneYesterday.length));
    if (noWl.length) insights.push({ sev: 'info', icon: '⏱', tag: 'worklog', title: `Без logtime вчера: ${noWl.length}`, desc: noWl.slice(0, 8).map((p) => escapeHtml(p.name)).join(' · ') });

    // 9) Ping-pong: задача, у которой >= 3 смен статуса вчера
    const pp = report.issues.filter((it) => {
        const ts = (it.changelog?.histories || []).filter((h) => inRange(h.created, report.yesterdayRange) && (h.items || []).some((i) => i.field === 'status'));
        return ts.length >= 3;
    });
    if (pp.length) insights.push({ sev: 'warn', icon: '🏓', tag: 'pingpong', title: `Скакали по статусам вчера: ${pp.length}`, desc: pp.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ') });

    // 10) Closed without worklog: задачи, закрытые вчера, без зарегистрированного worklog когда-либо
    const closedNoWl = report.issues.filter((it) => {
        const yDone = (it.changelog?.histories || []).some((h) => inRange(h.created, report.yesterdayRange) && (h.items || []).some((i) => i.field === 'status' && isTerminalStatusName(i.toString)));
        if (!yDone) return false;
        return !(it.fields?.worklog?.worklogs || []).length;
    });
    if (closedNoWl.length) insights.push({ sev: 'info', icon: '🧾', tag: 'учёт', title: `Закрыто вчера без worklog: ${closedNoWl.length}`, desc: closedNoWl.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ') });

    // 11) Блокеры без апдейта > 1 дня
    const blockers = report.issues.filter((it) => {
        const p = (it.fields?.priority?.name || '').toLowerCase();
        if (!['blocker', 'highest', 'critical'].includes(p)) return false;
        if (statusCategory(it) === 'done') return false;
        const mv = lastMovementIso(it) || it.fields?.updated; if (!mv) return false;
        return daysSince(mv) >= 1;
    });
    if (blockers.length) insights.push({ sev: 'bad', icon: '🛑', tag: 'blocker', title: `Блокеры без апдейта ≥1 дня: ${blockers.length}`, desc: blockers.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ') });

    // 12) Подзадача в работе, родитель — нет
    const subWipNoParent = report.issues.filter((it) => isSubtask(it) && isWip(it)).filter((it) => {
        const pk = parentKeyOf(it); if (!pk) return false;
        const parent = report.issues.find((x) => x.key === pk);
        return parent && !isWip(parent) && statusCategory(parent) !== 'done';
    });
    if (subWipNoParent.length) insights.push({ sev: 'info', icon: '🧩', tag: 'sync', title: `Подзадача в работе, родитель — нет: ${subWipNoParent.length}`, desc: subWipNoParent.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a> (родитель ${escapeHtml(parentKeyOf(it))})`).join('<br>') });

    // 13) Обратное: родитель Done, есть открытые подзадачи
    const orphanOpen = report.issues.filter((p) => statusCategory(p) === 'done' && (p.fields?.subtasks || []).some((s) => s.fields?.status?.statusCategory?.key !== 'done'));
    if (orphanOpen.length) insights.push({ sev: 'bad', icon: '🪤', tag: 'sync', title: `Done, но есть открытые подзадачи: ${orphanOpen.length}`, desc: orphanOpen.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ') });

    // 14) Долго в одном статусе (не двигалась N+ дней при noMovementDays<staleDays)
    const idle = wipIssues.map((it) => ({ it, d: daysSince(lastMovementIso(it) || it.fields?.updated) }))
        .filter((x) => x.d != null && x.d >= report.noMovementDays && x.d < report.staleDays);
    if (idle.length) insights.push({ sev: 'info', icon: '🌀', tag: 'idle', title: `Без движения ${report.noMovementDays}–${report.staleDays - 1} дн: ${idle.length}`, desc: idle.slice(0, 6).map((x) => `<a href="${issueUrl(x.it.key)}" target="_blank">${x.it.key}</a> (${x.d}дн)`).join(', ') });

    // 15) Пустой пульс
    if (!wipIssues.length) insights.push({ sev: 'info', icon: '📭', tag: 'empty', title: 'В работе сейчас нет задач', desc: 'Похоже, никто ничего не двигает. Возможно, надо взять что-то из бэклога спринта.' });

    return insights;
}

function renderInsights() {
    const report = state.report;
    const { people } = aggregatePeople(report);
    const list = computeInsights(report, people);
    const el = $('#insights-list');
    el.innerHTML = list.length ? list.map(insightHtml).join('') : '<div class="empty-card"><p>🎉 Очевидных сигналов нет.</p></div>';
}

// ============ Рендер: Backlog (не в работе в спринте) ============

function renderBacklog() {
    const report = state.report;
    const inSprintTodo = report.issues.filter((it) => report.sprintKeys.includes(it.key) && !isWip(it) && statusCategory(it) !== 'done');
    const el = $('#backlog-list');
    if (!inSprintTodo.length) { el.innerHTML = '<div class="empty-card"><p>В активном спринте нет нетронутых задач. 👌</p></div>'; return; }
    const byPerson = new Map();
    for (const it of inSprintTodo) {
        const a = assigneeOf(it) || { key: '__u__', name: 'Без исполнителя' };
        if (!byPerson.has(a.key)) byPerson.set(a.key, { name: a.name, items: [] });
        byPerson.get(a.key).items.push(it);
    }
    const groups = Array.from(byPerson.values()).sort((x, y) => y.items.length - x.items.length);
    el.innerHTML = groups.map((g) => `
        <div class="panel">
            <h2>${escapeHtml(g.name)} <span style="color:var(--text-mute);font-weight:400">· ${g.items.length}</span></h2>
            ${renderTypeGroups(g.items, (it) => issueLine(it))}
        </div>`).join('');
}

// ============ Главный рендер ============

function renderAll() {
    renderPeople();
    renderSummary();
    renderSprint();
    renderMetrics();
    renderInsights();
    renderBacklog();
}

// ============ Биндинги ============

function bind() {
    $$('.tab').forEach((t) => t.addEventListener('click', () => showPane(t.dataset.tab)));
    $('#btn-settings').addEventListener('click', openSettings);
    $('#btn-settings-2')?.addEventListener('click', openSettings);
    $('#btn-refresh').addEventListener('click', refresh);
    $('#btn-save').addEventListener('click', saveSettings);
    $('#btn-verify').addEventListener('click', verifySettings);
    $$('#modal-settings [data-close]').forEach((el) => el.addEventListener('click', closeSettings));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { closeSettings(); hideTip(); }
        if (e.key.toLowerCase() === 'r' && !e.metaKey && !e.ctrlKey && !e.altKey && e.target?.tagName !== 'INPUT' && e.target?.tagName !== 'TEXTAREA') refresh();
    });
    $('#filter-people').addEventListener('input', (e) => { state.filterPeopleText = e.target.value; renderPeople(); });
    $('#only-with-yesterday').addEventListener('change', (e) => { state.onlyYesterday = e.target.checked; renderPeople(); });

    // Тултип на ?-иконке
    document.addEventListener('mouseover', (e) => {
        const t = e.target.closest('[data-tip-issue]');
        if (!t) return;
        const key = t.getAttribute('data-tip-issue');
        const issue = state.report?.issues.find((x) => x.key === key);
        if (!issue) return;
        showTip(tipForIssue(issue), e.clientX, e.clientY);
    });
    document.addEventListener('mousemove', (e) => {
        if (tipEl().classList.contains('hidden')) return;
        const t = e.target.closest('[data-tip-issue]');
        if (!t) return hideTip();
        const r = t.getBoundingClientRect();
        showTip(tipEl().innerHTML, r.right, r.bottom);
    });
    document.addEventListener('mouseout', (e) => {
        const t = e.target.closest('[data-tip-issue]'); if (!t) return;
        const to = e.relatedTarget;
        if (to && to.closest && to.closest('[data-tip-issue]') === t) return;
        hideTip();
    });
}

(async function init() {
    bind();
    try {
        const cfg = await loadConfig();
        if (!cfg.jiraBaseUrl || !cfg.hasJiraToken || !cfg.projectKey) { showPane('empty'); openSettings(); }
        else await refresh();
    } catch (e) { console.error(e); showPane('empty'); toast('Ошибка инициализации: ' + e.message, 'bad'); }
})();
