#!/usr/bin/env bash
# Team Pulse — запуск одной кнопкой (macOS / Linux).
# Требуется установленный Node.js 18+.

set -euo pipefail
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
    echo
    echo " Node.js не найден. Установите Node 18+ и попробуйте снова."
    echo "   macOS:   brew install node"
    echo "   Ubuntu:  sudo apt install nodejs"
    echo
    exit 1
fi

URL="http://127.0.0.1:${PORT:-5173}"

echo
echo " Стартуем Team Pulse..."
echo " Как только сервер запустится — откроется браузер на ${URL}"
echo

# Откроем браузер через 2 секунды в фоне
(
    sleep 2
    if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" >/dev/null 2>&1 || true
    elif command -v open      >/dev/null 2>&1; then open "$URL"       >/dev/null 2>&1 || true
    fi
) &

exec node server.js

