// Portfolio Pulse — frontend. Vanilla JS, ES module.
// Несколько проектных пространств, двухуровневая навигация.

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const state = {
    config: null,
    report: null,
    activeTab: 'people',                // top tab id
    activeSubtab: { people: '__all__', summary: '__all__', sprints: null, insights: '__all__', metrics: '__all__' },
    backlogSubtab: 'summary',           // подвкладки внутри Бэклог
    backlogArea: '__all__',
    filterPeopleText: '',
    onlyYesterday: false
};

// ============ Утилиты ============

const TERMINAL_NAME_HINTS = ['done', 'closed', 'resolved', 'completed', 'cancel', 'rejected', 'готово', 'закрыт', 'выполн', 'отмен', 'отклон'];
const INITIAL_NAME_HINTS  = ['open', 'to do', 'todo', 'backlog', 'created', 'new', 'draft', 'reopened', 'к выполнению', 'открыт', 'новая', 'черновик'];

function fmtDateTime(iso) { if (!iso) return ''; return new Date(iso).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); }
function fmtDate(iso) { if (!iso) return ''; return new Date(iso).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }); }
function fmtTimeShort(iso) { if (!iso) return ''; return new Date(iso).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }); }
function daysSince(iso) { if (!iso) return null; return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000); }
function hoursToReadable(seconds) {
    if (!seconds) return '';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    if (h && m) return `${h}ч ${m}м`;
    if (h) return `${h}ч`;
    return `${m}м`;
}
function escapeHtml(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function initials(name) {
    if (!name) return '?';
    const parts = String(name).trim().split(/\s+/);
    return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase() || '?';
}
function colorFromString(s) {
    let h = 0; for (let i = 0; i < (s || '').length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    const hue = h % 360;
    return `linear-gradient(135deg, hsl(${hue} 55% 30%), hsl(${(hue + 60) % 360} 55% 30%))`;
}

function toast(text, kind = '') {
    const el = $('#toast');
    el.textContent = text;
    el.className = 'toast ' + kind;
    el.classList.remove('hidden');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.add('hidden'), 3500);
}

// ============ API ============

async function api(path, opts = {}) {
    const resp = await fetch(path, {
        method: opts.method || 'GET',
        headers: { 'Content-Type': 'application/json' },
        body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    const text = await resp.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (_) { data = { error: text }; }
    if (!resp.ok) throw new Error((data && data.error) || `HTTP ${resp.status}`);
    return data;
}

// ============ Настройки ============

async function loadConfig() { state.config = await api('/api/config'); return state.config; }

function renderAreasEditor(areas) {
    const root = $('#areas-editor');
    root.innerHTML = '';
    const list = areas && areas.length ? areas : [{ name: '', projectKey: '' }];
    for (const a of list) addAreaRow(a.name || '', a.projectKey || '');
    if (!areas || !areas.length) return;
}

function addAreaRow(name = '', projectKey = '') {
    const root = $('#areas-editor');
    const row = document.createElement('div');
    row.className = 'area-row';
    row.innerHTML = `
        <input type="text" class="area-name" placeholder="Имя (например: Платежи)" value="${escapeHtml(name)}" />
        <input type="text" class="area-key" placeholder="KEY (например: PAY)" value="${escapeHtml(projectKey)}" />
        <button type="button" class="remove-area" title="Удалить">✕</button>
    `;
    row.querySelector('.remove-area').addEventListener('click', () => row.remove());
    root.appendChild(row);
}

function collectAreas() {
    const out = [];
    for (const row of $$('#areas-editor .area-row')) {
        const name = row.querySelector('.area-name').value.trim();
        const key = row.querySelector('.area-key').value.trim();
        if (!key) continue;
        out.push({ name: name || key, projectKey: key });
    }
    return out;
}

function openSettings() {
    const cfg = state.config || {};
    $('#cfg-jira-url').value = cfg.jiraBaseUrl || '';
    $('#cfg-jira-token').value = ''; $('#cfg-jira-token').placeholder = cfg.hasJiraToken ? '•••••••• (пусто = не менять)' : '';
    $('#cfg-bb-url').value = cfg.bitbucketBaseUrl || '';
    $('#cfg-bb-token').value = ''; $('#cfg-bb-token').placeholder = cfg.hasBitbucketToken ? '•••••••• (пусто = не менять)' : '';
    $('#cfg-bb-projects').value = cfg.bitbucketProjectKeys || '';
    $('#cfg-conf-url').value = cfg.confluenceBaseUrl || '';
    $('#cfg-conf-token').value = ''; $('#cfg-conf-token').placeholder = cfg.hasConfluenceToken ? '•••••••• (пусто = не менять)' : '';
    $('#cfg-stale').value = cfg.staleDays ?? 3;
    $('#cfg-nomov').value = cfg.noMovementDays ?? 2;
    $('#cfg-insecure').checked = !!cfg.allowInsecureTls;
    renderAreasEditor(cfg.areas);
    $('#settings-error').classList.add('hidden');
    $('#modal-settings').classList.remove('hidden');
    $('#cfg-jira-url').focus();
}
function closeSettings() { $('#modal-settings').classList.add('hidden'); }

function collectSettingsPayload() {
    const payload = {
        jiraBaseUrl: $('#cfg-jira-url').value.trim(),
        areas: collectAreas(),
        bitbucketBaseUrl: $('#cfg-bb-url').value.trim(),
        bitbucketProjectKeys: $('#cfg-bb-projects').value.trim(),
        confluenceBaseUrl: $('#cfg-conf-url').value.trim(),
        staleDays: Number($('#cfg-stale').value) || 3,
        noMovementDays: Number($('#cfg-nomov').value) || 2,
        allowInsecureTls: $('#cfg-insecure').checked
    };
    const jt = $('#cfg-jira-token').value; if (jt) payload.jiraToken = jt;
    const bt = $('#cfg-bb-token').value; if (bt) payload.bitbucketToken = bt;
    const ct = $('#cfg-conf-token').value; if (ct) payload.confluenceToken = ct;
    return payload;
}

async function saveSettings() {
    const errEl = $('#settings-error'); errEl.classList.add('hidden');
    try {
        const cfg = await api('/api/config', { method: 'POST', body: collectSettingsPayload() });
        state.config = cfg;
        toast('Настройки сохранены', 'good');
        closeSettings();
        await refresh();
    } catch (e) { errEl.textContent = 'Не удалось сохранить: ' + e.message; errEl.classList.remove('hidden'); }
}

async function verifySettings() {
    const errEl = $('#settings-error'); errEl.classList.add('hidden');
    try {
        await api('/api/config', { method: 'POST', body: collectSettingsPayload() });
        const r = await api('/api/verify', { method: 'POST' });
        const checks = r.checks || {};
        const lines = [];
        if (checks.jira) lines.push(`Jira: ${checks.jira.who}`);
        if (checks.bitbucket) lines.push(`Bitbucket: ${checks.bitbucket.ok ? 'ok' : 'ошибка — ' + checks.bitbucket.error}`);
        if (checks.confluence) lines.push(`Confluence: ${checks.confluence.ok ? checks.confluence.who : 'ошибка — ' + checks.confluence.error}`);
        toast('Подключение: ' + lines.join(' · '), 'good');
    } catch (e) { errEl.textContent = 'Ошибка подключения: ' + e.message; errEl.classList.remove('hidden'); }
}

// ============ Основной цикл ============

async function refresh() {
    const cfg = await loadConfig();
    if (!cfg.jiraBaseUrl || !cfg.hasJiraToken || !(cfg.areas || []).length) { showPane('empty'); return; }

    const btn = $('#btn-refresh'); btn.classList.add('is-loading'); btn.disabled = true;
    try {
        state.report = await api('/api/report', { method: 'POST' });
        // выровнять active subtab спринтов по первой area
        if (state.report.areas.length && !state.activeSubtab.sprints) {
            state.activeSubtab.sprints = state.report.areas[0].projectKey;
        }
        renderAll();
        showPane(state.activeTab);
        const at = new Date(state.report.generatedAt);
        const areaNames = state.report.areas.map((a) => a.name).join(', ');
        $('#meta').textContent = `обновлено ${at.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })} · ${state.report.areas.length} пространств · ${areaNames}`;
    } catch (e) { toast('Не удалось загрузить отчёт: ' + e.message, 'bad'); console.error(e); }
    finally { btn.classList.remove('is-loading'); btn.disabled = false; }
}

function showPane(name) {
    state.activeTab = name;
    $$('.pane').forEach((p) => p.classList.add('hidden'));
    const el = $('#pane-' + name);
    if (el) el.classList.remove('hidden');
    $$('#top-tabs .tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
}

// ============ Семантика статусов ============

function statusCategory(issue) { return issue.fields?.status?.statusCategory?.key || 'new'; }
function statusName(issue) { return issue.fields?.status?.name || ''; }
function isTerminalStatusName(name) { if (!name) return false; const n = name.toLowerCase(); return TERMINAL_NAME_HINTS.some((h) => n.includes(h)); }
function isInitialStatusName(name) { if (!name) return true; const n = name.toLowerCase(); return INITIAL_NAME_HINTS.some((h) => n.includes(h)); }
function hasAnyStatusChange(issue) { const hist = issue.changelog?.histories || []; return hist.some((h) => (h.items || []).some((i) => i.field === 'status')); }
function hasAnyWorklog(issue) { return (issue.fields?.worklog?.worklogs || []).length > 0; }

function isWip(issue) {
    if (statusCategory(issue) === 'done') return false;
    if (statusCategory(issue) === 'indeterminate') return true;
    if (hasAnyStatusChange(issue)) return true;
    if (hasAnyWorklog(issue)) return true;
    const cm = issue.fields?.comment?.comments || [];
    if (cm.length) return true;
    return false;
}

function statusChip(issue) {
    const cat = statusCategory(issue);
    const cls = cat === 'done' ? 'status-done' : cat === 'indeterminate' ? 'status-inprogress' : 'status-todo';
    return `<span class="chip ${cls}" title="${escapeHtml(statusName(issue))}">${escapeHtml(statusName(issue))}</span>`;
}
function priorityChip(issue) {
    const p = issue.fields?.priority?.name; if (!p) return '';
    const cls = 'prio-' + p.toLowerCase().replace(/\s+/g, '-');
    return `<span class="chip ${cls}">${escapeHtml(p)}</span>`;
}
function areaTag(area) {
    if (!area) return '';
    return `<span class="area-tag" title="${escapeHtml(area.name)}">${escapeHtml(area.projectKey)}</span>`;
}

// ============ Типы задач ============

const TYPE_ICONS = {
    'story': '📗', 'история': '📗',
    'task':  '✅', 'задача': '✅',
    'bug':   '🐞', 'баг': '🐞', 'дефект': '🐞',
    'sub-task': '↳', 'subtask': '↳', 'подзадача': '↳',
    'epic':  '🟪', 'эпик': '🟪',
    'improvement': '✨', 'new feature': '🌱'
};
function issueType(issue) { return issue.fields?.issuetype?.name || '—'; }
function isSubtask(issue) {
    return !!issue.fields?.issuetype?.subtask
        || /sub.?task|подзадача/i.test(issueType(issue));
}
function typeBucket(issue) {
    const t = (issueType(issue) || '').toLowerCase();
    if (isSubtask(issue)) return 'sub-task';
    if (/story|история/.test(t)) return 'story';
    if (/bug|баг|дефект/.test(t)) return 'bug';
    return 'task';
}
function typeIcon(type) { return TYPE_ICONS[(type || '').toLowerCase()] || '•'; }
function parentKeyOf(issue) { return issue.fields?.parent?.key || null; }
function parentSummaryOf(issue) { return issue.fields?.parent?.fields?.summary || ''; }

// ============ Активность за период ============

function inRange(iso, range) {
    if (!iso || !range) return false;
    const t = new Date(iso).getTime();
    return t >= new Date(range.from).getTime() && t < new Date(range.to).getTime();
}

function extractActivity(issue, range, devStatusMap) {
    const out = { transitions: [], worklogs: [], commits: [], prs: [], updatesByUser: {}, comments: [] };
    for (const h of (issue.changelog?.histories || [])) {
        if (!inRange(h.created, range)) continue;
        const user = h.author?.name || h.author?.displayName || '—';
        out.updatesByUser[user] = (out.updatesByUser[user] || 0) + 1;
        for (const it of (h.items || [])) {
            if (it.field === 'status') out.transitions.push({ from: it.fromString, to: it.toString, at: h.created, by: user, byName: h.author?.displayName || user });
        }
    }
    for (const w of (issue.fields?.worklog?.worklogs || [])) {
        if (!inRange(w.started, range)) continue;
        out.worklogs.push({
            authorLogin: w.author?.name || '', authorName: w.author?.displayName || w.author?.name || '—',
            timeSpentSeconds: w.timeSpentSeconds || 0, started: w.started,
            comment: (typeof w.comment === 'string') ? w.comment : ''
        });
    }
    for (const c of (issue.fields?.comment?.comments || [])) {
        if (!inRange(c.created, range)) continue;
        out.comments.push({
            authorLogin: c.author?.name || '', authorName: c.author?.displayName || c.author?.name || '—',
            at: c.created, body: typeof c.body === 'string' ? c.body : ''
        });
    }
    const ds = devStatusMap?.[issue.key];
    if (ds) {
        for (const d of (ds.repo?.detail || [])) {
            for (const r of (d.repositories || [])) {
                for (const c of (r.commits || [])) {
                    if (inRange(c.authorTimestamp, range)) {
                        out.commits.push({
                            authorLogin: c.author?.name || c.author?.username || '',
                            authorName: c.author?.displayName || c.author?.name || c.author?.username || '—',
                            at: c.authorTimestamp,
                            message: c.message || '',
                            url: c.url || null,
                            source: 'dev'
                        });
                    }
                }
            }
        }
        for (const d of (ds.pr?.detail || [])) {
            for (const p of (d.pullRequests || [])) {
                const at = p.lastUpdate || p.updateDate;
                if (inRange(at, range)) {
                    out.prs.push({
                        authorLogin: p.author?.username || p.author?.name || '',
                        authorName: p.author?.displayName || p.author?.name || '—',
                        at, status: p.status || '', title: p.name || '', url: p.url || null, source: 'dev'
                    });
                }
            }
        }
    }
    return out;
}

function lastMovementIso(issue) {
    const dates = [];
    if (issue.fields?.updated) dates.push(issue.fields.updated);
    for (const h of (issue.changelog?.histories || [])) if (h.created) dates.push(h.created);
    for (const w of (issue.fields?.worklog?.worklogs || [])) if (w.started) dates.push(w.started);
    for (const c of (issue.fields?.comment?.comments || [])) if (c.created) dates.push(c.created);
    return dates.length ? dates.sort().at(-1) : null;
}

function assigneeOf(issue) {
    const a = issue.fields?.assignee; if (!a) return null;
    return {
        key: a.name || a.accountId || a.key || a.displayName,
        name: a.displayName || a.name || '—',
        login: a.name || a.accountId || '',
        email: a.emailAddress || ''
    };
}

function matchesUser(person, eventLogin, eventEmail, eventName) {
    if (!person) return false;
    const login = (eventLogin || '').toLowerCase();
    const email = (eventEmail || '').toLowerCase();
    const name = (eventName || '').toLowerCase();
    const pLogin = (person.login || '').toLowerCase();
    const pEmail = (person.email || '').toLowerCase();
    const pName = (person.name || '').toLowerCase();
    if (login && pLogin && login === pLogin) return true;
    if (email && pEmail && email === pEmail) return true;
    if (name && pName && name === pName) return true;
    return false;
}

// ============ Доступ к данным по area ============

// Возвращает массив area-объектов: либо все, либо отфильтрованный
function selectedAreas(subKey /* '__all__' или projectKey */) {
    const areas = state.report?.areas || [];
    if (!subKey || subKey === '__all__') return areas;
    return areas.filter((a) => a.projectKey === subKey);
}

// Все задачи из выбранных areas (с пометкой area)
function flatIssues(areas) {
    const out = [];
    for (const a of areas) for (const it of (a.issues || [])) out.push({ issue: it, area: { name: a.name, projectKey: a.projectKey } });
    return out;
}

// ============ Агрегация по людям (один или несколько area) ============

function aggregatePeople(areas) {
    const report = state.report;
    const ranges = {
        yesterday: report.yesterdayRange,
        dayBefore: report.dayBeforeYesterdayRange,
        last48h: report.last48hRange
    };

    const people = new Map();
    const ensure = (a, areaInfo) => {
        const key = a ? a.key : '__unassigned__';
        const name = a ? a.name : 'Без исполнителя';
        const login = a ? a.login : '';
        const email = a ? a.email : '';
        if (!people.has(key)) {
            people.set(key, {
                key, name, login, email,
                areas: new Set(),
                inProgress: [],
                doneYesterday: [],
                doneDayBefore: [],
                yesterdayItems: [],
                dayBeforeItems: [],
                comments48h: [],
                stale: [],
                stats: {
                    workSecYesterday: 0, workSecDayBefore: 0, workSec48h: 0,
                    commits48h: 0, prs48h: 0, confluence48h: 0
                },
                confluence: []
            });
        }
        const p = people.get(key);
        if (areaInfo) p.areas.add(areaInfo.projectKey + '|' + areaInfo.name);
        return p;
    };

    for (const area of areas) {
        const areaInfo = { name: area.name, projectKey: area.projectKey };
        for (const issue of area.issues || []) {
            const a = assigneeOf(issue);
            const p = ensure(a, areaInfo);

            if (isWip(issue)) p.inProgress.push({ issue, area: areaInfo });

            const yA = extractActivity(issue, ranges.yesterday, area.devStatus);
            const dA = extractActivity(issue, ranges.dayBefore, area.devStatus);
            const lA = extractActivity(issue, ranges.last48h, area.devStatus);

            const doneTrans = (acts) => acts.transitions.filter((t) => isTerminalStatusName(t.to));
            const yDone = doneTrans(yA);
            const dDone = doneTrans(dA);
            if (yDone.length) p.doneYesterday.push({ issue, area: areaInfo, toStatus: yDone[yDone.length - 1].to });
            if (dDone.length) p.doneDayBefore.push({ issue, area: areaInfo, toStatus: dDone[dDone.length - 1].to });

            const hasYAct = yA.transitions.length || yA.worklogs.length || yA.commits.length || yA.prs.length || Object.keys(yA.updatesByUser).length;
            const hasDAct = dA.transitions.length || dA.worklogs.length || dA.commits.length || dA.prs.length || Object.keys(dA.updatesByUser).length;
            if (hasYAct) p.yesterdayItems.push({ issue, area: areaInfo, ya: yA });
            if (hasDAct) p.dayBeforeItems.push({ issue, area: areaInfo, ya: dA });

            p.stats.workSecYesterday += yA.worklogs.reduce((s, w) => s + (w.timeSpentSeconds || 0), 0);
            p.stats.workSecDayBefore += dA.worklogs.reduce((s, w) => s + (w.timeSpentSeconds || 0), 0);
            p.stats.workSec48h += lA.worklogs.reduce((s, w) => s + (w.timeSpentSeconds || 0), 0);
            p.stats.commits48h += lA.commits.length;
            p.stats.prs48h += lA.prs.length;

            if (isWip(issue)) {
                const mv = lastMovementIso(issue) || issue.fields?.updated;
                if (mv) {
                    const d = daysSince(mv);
                    if (d != null && d >= report.staleDays) p.stale.push({ issue, area: areaInfo, daysIdle: d });
                }
            }
        }

        // Комментарии 48ч — по автору
        for (const issue of area.issues || []) {
            for (const c of (issue.fields?.comment?.comments || [])) {
                if (!inRange(c.created, ranges.last48h)) continue;
                const login = c.author?.name || '';
                const email = c.author?.emailAddress || '';
                const name = c.author?.displayName || c.author?.name || '';
                let target = null;
                for (const p of people.values()) {
                    if (matchesUser(p, login, email, name)) { target = p; break; }
                }
                if (!target && login) target = ensureExternal(people, { key: login, name: name || login, login, email });
                if (!target) continue;
                target.comments48h.push({ issue, area: areaInfo, c: { authorName: name || login, at: c.created, body: typeof c.body === 'string' ? c.body : '' } });
            }
        }
    }

    // Bitbucket commits/PR — общие, добавим к статистике (если матчится)
    if (report.bitbucket) {
        for (const c of (report.bitbucket.commits || [])) {
            for (const p of people.values()) {
                if (matchesUser(p, c.author, c.authorEmail, c.authorDisplay)) {
                    p.stats.commits48h += 1;
                    p._bbCommits = p._bbCommits || []; p._bbCommits.push(c);
                    break;
                }
            }
        }
        for (const pr of (report.bitbucket.prs || [])) {
            for (const p of people.values()) {
                if (matchesUser(p, pr.author, pr.authorEmail, pr.authorDisplay)) {
                    p.stats.prs48h += 1;
                    p._bbPrs = p._bbPrs || []; p._bbPrs.push(pr);
                    break;
                }
            }
        }
    }
    if (report.confluence) {
        for (const pg of (report.confluence.pages || [])) {
            for (const p of people.values()) {
                if (matchesUser(p, pg.byLogin, pg.byEmail, pg.byName)) {
                    p.confluence.push(pg);
                    p.stats.confluence48h += 1;
                    break;
                }
            }
        }
    }

    const un = people.get('__unassigned__');
    if (un && !un.inProgress.length && !un.yesterdayItems.length && !un.dayBeforeItems.length && !un.doneYesterday.length && !un.comments48h.length && !un.confluence.length) {
        people.delete('__unassigned__');
    }

    const arr = Array.from(people.values()).filter((p) => p.key !== '__unassigned__');
    arr.sort((a, b) => {
        const aA = a.yesterdayItems.length + a.doneYesterday.length;
        const bA = b.yesterdayItems.length + b.doneYesterday.length;
        if (bA !== aA) return bA - aA;
        return (a.name || '').localeCompare(b.name || '', 'ru');
    });
    return { people: arr, unassigned: people.get('__unassigned__') || null };
}

function ensureExternal(map, info) {
    if (map.has(info.key)) return map.get(info.key);
    const p = {
        key: info.key, name: info.name, login: info.login, email: info.email || '',
        areas: new Set(),
        inProgress: [], doneYesterday: [], doneDayBefore: [], yesterdayItems: [], dayBeforeItems: [],
        comments48h: [], stale: [], confluence: [],
        stats: { workSecYesterday: 0, workSecDayBefore: 0, workSec48h: 0, commits48h: 0, prs48h: 0, confluence48h: 0 },
        external: true
    };
    map.set(info.key, p);
    return p;
}

// ============ Тултип ============

const tipEl = () => $('#tip');
function showTip(html, x, y) {
    const t = tipEl();
    t.innerHTML = html;
    t.classList.remove('hidden');
    const w = t.offsetWidth, h = t.offsetHeight;
    const px = Math.min(window.innerWidth - w - 12, Math.max(8, x + 14));
    const py = Math.min(window.innerHeight - h - 12, Math.max(8, y + 14));
    t.style.left = px + 'px'; t.style.top = py + 'px';
}
function hideTip() { tipEl().classList.add('hidden'); }

function findIssueByKey(key) {
    for (const a of state.report?.areas || []) {
        const it = (a.issues || []).find((x) => x.key === key);
        if (it) return { issue: it, area: a };
    }
    return null;
}

function tipForIssue(issue, area) {
    const f = issue.fields || {};
    const desc = (f.description || '').toString().replace(/\r/g, '').slice(0, 600);
    const parent = parentKeyOf(issue);
    const tIcon = typeIcon(typeBucket(issue));
    return `
        <div class="tip-row">
            <span class="tip-title">${escapeHtml(issue.key)}</span>
            ${area ? areaTag({ name: area.name, projectKey: area.projectKey }) : ''}
            <span>${tIcon} ${escapeHtml(issueType(issue))}</span>
            ${statusChip(issue)} ${priorityChip(issue)}
        </div>
        <div class="tip-row"><b>${escapeHtml(f.summary || '')}</b></div>
        ${parent ? `<div class="tip-row" style="color:var(--text-mute)">↳ родитель: ${escapeHtml(parent)} ${escapeHtml(parentSummaryOf(issue))}</div>` : ''}
        ${desc ? `<div class="tip-desc">${escapeHtml(desc)}${(f.description || '').length > 600 ? '…' : ''}</div>` : '<div class="tip-row" style="color:var(--text-mute)">— без описания —</div>'}
    `;
}

// ============ Рендер: общее ============

function issueUrl(key) {
    const base = (state.config?.jiraBaseUrl || '').replace(/\/+$/, '');
    return base ? `${base}/browse/${key}` : '#';
}

function issueLine(issue, area, extra = {}) {
    const key = issue.key;
    const summary = issue.fields?.summary || '';
    const parentKey = parentKeyOf(issue);
    const right = [];
    if (area) right.push(areaTag({ name: area.name, projectKey: area.projectKey }));
    right.push(statusChip(issue));
    const prio = priorityChip(issue); if (prio) right.push(prio);
    if (extra.daysIdle != null) right.push(`<span class="chip stale">${extra.daysIdle} дн без движения</span>`);
    if (extra.toStatus) right.push(`<span class="chip status-done">→ ${escapeHtml(extra.toStatus)}</span>`);
    if (extra.workSec) right.push(`<span class="chip">⏱ ${hoursToReadable(extra.workSec)}</span>`);
    return `
        <div class="issue">
            <a class="issue-key" href="${issueUrl(key)}" target="_blank" rel="noreferrer">${escapeHtml(key)}</a>
            <div class="issue-title">
                ${parentKey && isSubtask(issue) ? `<span class="parent">↳ ${escapeHtml(parentKey)}</span>` : ''}
                <span data-issue-key="${escapeHtml(key)}">${escapeHtml(summary)}</span>
                <span class="tip-icon" data-tip-issue="${escapeHtml(key)}" aria-label="детали">?</span>
            </div>
            <div class="issue-meta">${right.join(' ')}</div>
        </div>`;
}

function groupByType(issues) {
    const order = ['story', 'task', 'bug', 'sub-task'];
    const byType = new Map();
    for (const it of issues) {
        const t = typeBucket(it);
        if (!byType.has(t)) byType.set(t, []);
        byType.get(t).push(it);
    }
    return order.filter((t) => byType.has(t)).map((t) => ({ type: t, items: byType.get(t) }));
}
function typeLabel(t) { return ({ 'story': 'Истории', 'task': 'Задачи', 'bug': 'Баги', 'sub-task': 'Подзадачи' })[t] || t; }

function renderTypeGroups(items, mapper) {
    if (!items.length) return '<div class="empty">Пусто.</div>';
    const groups = groupByType(items);
    return groups.map((g) => `
        <div class="type-group">
            <div class="type-header">
                <span class="type-icon">${typeIcon(g.type)}</span>
                <span class="type-name">${typeLabel(g.type)}</span>
                <span class="type-count">· ${g.items.length}</span>
            </div>
            ${g.items.map(mapper).join('')}
        </div>`).join('');
}

// ============ Подвкладки ============

function buildAreaSubtabs(target /* DOM id */, activeKey, includeAll = true) {
    const root = $(target);
    const areas = state.report?.areas || [];
    const buttons = [];
    if (includeAll) {
        buttons.push(`<button class="subtab${activeKey === '__all__' ? ' active' : ''}" data-sub="__all__">🌐 Все пространства</button>`);
    }
    for (const a of areas) {
        buttons.push(`<button class="subtab${activeKey === a.projectKey ? ' active' : ''}" data-sub="${escapeHtml(a.projectKey)}">${escapeHtml(a.name)} <span style="opacity:.6">${escapeHtml(a.projectKey)}</span></button>`);
    }
    root.innerHTML = buttons.join('');
}

// ============ Рендер: Все команды ============

function renderPeople() {
    const sub = state.activeSubtab.people;
    buildAreaSubtabs('#subtabs-people', sub, true);

    const areas = selectedAreas(sub);
    const { people, unassigned } = aggregatePeople(areas);

    const text = state.filterPeopleText.trim().toLowerCase();
    const filtered = people.filter((p) => {
        if (state.onlyYesterday && !p.yesterdayItems.length && !p.doneYesterday.length) return false;
        if (!text) return true;
        return (p.name || '').toLowerCase().includes(text) || (p.login || '').toLowerCase().includes(text);
    });

    const list = $('#people-list');
    list.innerHTML = filtered.length ? filtered.map((p) => personCard(p, state.report)).join('') : `<div class="empty-card"><p>Никого не нашли по фильтрам.</p></div>`;

    const un = $('#people-unassigned');
    un.innerHTML = unassigned ? personCard(unassigned, state.report, true) : '';
}

function personCard(p, report, isUnassigned = false) {
    const badges = [];
    badges.push(`<span class="badge info">в работе:&nbsp;${p.inProgress.length}</span>`);
    if (p.doneYesterday.length) badges.push(`<span class="badge good">✅ закрыто вчера:&nbsp;${p.doneYesterday.length}</span>`);
    if (p.doneDayBefore.length) badges.push(`<span class="badge good">✅ позавчера:&nbsp;${p.doneDayBefore.length}</span>`);
    if (p.stats.workSec48h) badges.push(`<span class="badge">⏱ logtime 48ч:&nbsp;${hoursToReadable(p.stats.workSec48h)}</span>`);
    if (p.stats.commits48h) badges.push(`<span class="badge">⌥ commits:&nbsp;${p.stats.commits48h}</span>`);
    if (p.stats.prs48h) badges.push(`<span class="badge">PR:&nbsp;${p.stats.prs48h}</span>`);
    if (p.stats.confluence48h) badges.push(`<span class="badge">📄 Confluence:&nbsp;${p.stats.confluence48h}</span>`);
    if (p.comments48h.length) badges.push(`<span class="badge">💬 комментов:&nbsp;${p.comments48h.length}</span>`);
    if (p.stale.length) badges.push(`<span class="badge bad">🐌 висит:&nbsp;${p.stale.length}</span>`);

    // Список area, к которым относится участник
    const areaList = Array.from(p.areas || []).map((s) => {
        const [key, name] = s.split('|');
        return areaTag({ name, projectKey: key });
    }).join(' ');

    // Универсальный билдер задач с областью
    const issueLineWithArea = (it, area, extra = {}) => issueLine(it, area, extra);

    // Секция «В работе сейчас»
    const inProgressBody = (() => {
        const items = p.inProgress;
        if (!items.length) return '<div class="empty">Пусто.</div>';
        // группируем сами вручную с областями
        return renderTypeGroups(items.map((x) => x.issue), (it) => {
            const x = items.find((y) => y.issue.key === it.key);
            const mv = lastMovementIso(it) || it.fields.updated;
            const d = daysSince(mv);
            return issueLineWithArea(it, x?.area, d != null && d >= report.staleDays ? { daysIdle: d } : {});
        });
    })();

    const buildActivityList = (items) => {
        if (!items.length) return '<div class="empty">Без изменений.</div>';
        return renderTypeGroups(items.map((x) => x.issue), (it) => {
            const x = items.find((y) => y.issue.key === it.key);
            const a = x?.ya;
            const lines = [];
            for (const t of (a?.transitions || [])) {
                const cat = isTerminalStatusName(t.to) ? 'status-done' : 'status-inprogress';
                lines.push(`<li><span class="bullet">→</span> Перевели в <span class="chip ${cat}">${escapeHtml(t.to)}</span> <span style="color:var(--text-mute)">(из ${escapeHtml(t.from || '—')}, ${fmtTimeShort(t.at)})</span></li>`);
            }
            for (const w of (a?.worklogs || [])) {
                lines.push(`<li><span class="bullet">⏱</span> logtime ${hoursToReadable(w.timeSpentSeconds)}${w.comment ? ' — ' + escapeHtml(w.comment.slice(0, 120)) : ''}</li>`);
            }
            for (const c of (a?.commits || [])) {
                lines.push(`<li><span class="bullet">⌥</span> ${c.url ? `<a href="${escapeHtml(c.url)}" target="_blank">commit</a>` : 'commit'}: ${escapeHtml((c.message || '').split('\n')[0].slice(0, 140))} <span style="color:var(--text-mute)">${fmtTimeShort(c.at)}</span></li>`);
            }
            for (const pr of (a?.prs || [])) {
                lines.push(`<li><span class="bullet">PR</span> ${pr.url ? `<a href="${escapeHtml(pr.url)}" target="_blank">${escapeHtml(pr.title)}</a>` : escapeHtml(pr.title)} <span style="color:var(--text-mute)">${escapeHtml(pr.status || '')} · ${fmtTimeShort(pr.at)}</span></li>`);
            }
            if (!lines.length && a && Object.keys(a.updatesByUser || {}).length) {
                lines.push(`<li><span class="bullet">✎</span> правки полей</li>`);
            }
            return `
                <div class="issue">
                    <a class="issue-key" href="${issueUrl(it.key)}" target="_blank">${escapeHtml(it.key)}</a>
                    <div class="issue-title">
                        ${parentKeyOf(it) && isSubtask(it) ? `<span class="parent">↳ ${escapeHtml(parentKeyOf(it))}</span>` : ''}
                        <span>${escapeHtml(it.fields.summary)}</span>
                        <span class="tip-icon" data-tip-issue="${escapeHtml(it.key)}">?</span>
                        <ul class="activity-list">${lines.join('')}</ul>
                    </div>
                    <div class="issue-meta">${x?.area ? areaTag(x.area) : ''} ${statusChip(it)} ${priorityChip(it)}</div>
                </div>`;
        });
    };

    const yesterdayBody = buildActivityList(p.yesterdayItems);
    const dayBeforeBody = buildActivityList(p.dayBeforeItems);

    const commentsBody = p.comments48h.length
        ? `<ul class="activity-list">${p.comments48h.slice(0, 60).map((x) => `
            <li>
                <a class="issue-key" href="${issueUrl(x.issue.key)}" target="_blank">${escapeHtml(x.issue.key)}</a>
                ${x.area ? areaTag(x.area) : ''}
                <span style="color:var(--text-mute)"> · ${fmtDateTime(x.c.at)}</span>
                <div style="color:var(--text-dim);margin-top:2px">${escapeHtml(x.c.body.slice(0, 280))}${x.c.body.length > 280 ? '…' : ''}</div>
            </li>`).join('')}</ul>`
        : '<div class="empty">Комментариев за 48ч не оставлял.</div>';

    const confluenceBody = p.confluence.length
        ? `<ul class="activity-list">${p.confluence.slice(0, 50).map((pg) => `
            <li>
                ${pg.url ? `<a href="${escapeHtml(pg.url)}" target="_blank">${escapeHtml(pg.title)}</a>` : escapeHtml(pg.title)}
                <span style="color:var(--text-mute)"> · ${escapeHtml(pg.space || '')} · ${fmtDateTime(pg.at)}</span>
            </li>`).join('')}</ul>`
        : (state.config?.hasConfluenceToken ? '<div class="empty">Правок в Confluence за 48ч не было.</div>' : '<div class="empty">Confluence не настроен — заполните baseURL и token в настройках.</div>');

    return `
        <div class="person-card${isUnassigned ? ' unassigned' : ''}">
            <div class="person-head">
                <div class="avatar" style="background:${colorFromString(p.key || p.name)}">${escapeHtml(initials(p.name))}</div>
                <div class="person-id">
                    <div class="person-name">${escapeHtml(p.name)} ${areaList}</div>
                    <div class="person-login">${escapeHtml(p.login || '')}${p.external ? ' · только активность' : ''}</div>
                </div>
                <div class="person-stats">${badges.join('')}</div>
            </div>

            <details class="section">
                <summary>В работе сейчас <span class="count">${p.inProgress.length}</span></summary>
                <div class="body">${inProgressBody}</div>
            </details>

            <details class="section">
                <summary>Сделал вчера <span class="count">${p.yesterdayItems.length + p.doneYesterday.length}</span></summary>
                <div class="body">${yesterdayBody}</div>
            </details>

            <details class="section">
                <summary>Сделал позавчера <span class="count">${p.dayBeforeItems.length + p.doneDayBefore.length}</span></summary>
                <div class="body">${dayBeforeBody}</div>
            </details>

            <details class="section">
                <summary>Оставил комментарии (48ч) <span class="count">${p.comments48h.length}</span></summary>
                <div class="body">${commentsBody}</div>
            </details>

            <details class="section">
                <summary>Изменения в Confluence (48ч) <span class="count">${p.confluence.length}</span></summary>
                <div class="body">${confluenceBody}</div>
            </details>

            ${p.stale.length ? `
                <details class="section" open>
                    <summary>Висят &gt; ${report.staleDays} дн <span class="count">${p.stale.length}</span></summary>
                    <div class="body">${p.stale.map((s) => issueLineWithArea(s.issue, s.area, { daysIdle: s.daysIdle })).join('')}</div>
                </details>
            ` : ''}
        </div>`;
}

// ============ Рендер: Сводка ============

function renderSummary() {
    const sub = state.activeSubtab.summary;
    buildAreaSubtabs('#subtabs-summary', sub, true);
    const root = $('#summary-body');
    const areas = selectedAreas(sub);
    if (!areas.length) { root.innerHTML = '<div class="empty">Нет выбранных пространств.</div>'; return; }

    if (sub === '__all__') {
        // Дашборд: общие цифры + плитка по пространствам
        const totals = computeTotals(areas);
        const tilesHtml = state.report.areas.map((a) => areaCard(a)).join('');
        root.innerHTML = `
            ${renderTotalsCards(totals)}
            <div class="panel">
                <h2>Разбивка по типам — вчера (все пространства)</h2>
                <div>${renderTypeBreakdown(totals.scope)}</div>
            </div>
            <div class="panel">
                <h2>Сводка по пространствам</h2>
                <div class="area-card-grid">${tilesHtml}</div>
            </div>
            <div class="two-col">
                <div class="panel">
                    <h2>Что делали вчера</h2>
                    <div class="list">${renderYesterdayList(areas)}</div>
                </div>
                <div class="panel">
                    <h2>План на сегодня</h2>
                    <div class="list">${renderTodayList(areas)}</div>
                </div>
            </div>
        `;
    } else {
        // Конкретное пространство
        const a = areas[0];
        if (a.error) { root.innerHTML = `<div class="area-error">[${escapeHtml(a.projectKey)}] Ошибка загрузки: ${escapeHtml(a.error)}</div>`; return; }
        const totals = computeTotals([a]);
        root.innerHTML = `
            ${renderTotalsCards(totals)}
            <div class="panel">
                <h2>Разбивка по типам — вчера</h2>
                <div>${renderTypeBreakdown(totals.scope)}</div>
            </div>
            <div class="two-col">
                <div class="panel">
                    <h2>Что делали вчера</h2>
                    <div class="list">${renderYesterdayList([a])}</div>
                </div>
                <div class="panel">
                    <h2>План на сегодня</h2>
                    <div class="list">${renderTodayList([a])}</div>
                </div>
            </div>
        `;
    }
}

function computeTotals(areas) {
    const report = state.report;
    const sprintCount = areas.reduce((s, a) => s + (a.sprintKeys || []).length, 0);
    const allIssues = areas.flatMap((a) => a.issues || []);
    const wipCount = allIssues.filter(isWip).length;
    const { people } = aggregatePeople(areas);
    const staleCount = people.reduce((s, p) => s + p.stale.length, 0);
    const doneYesterdayCount = people.reduce((s, p) => s + p.doneYesterday.length, 0);
    const sprintKeySet = new Set(areas.flatMap((a) => a.sprintKeys || []));
    const scope = allIssues.filter((it) => sprintKeySet.has(it.key) || inRange(it.fields?.updated, report.yesterdayRange));
    return { sprintCount, wipCount, staleCount, doneYesterdayCount, scope, people };
}

function renderTotalsCards(t) {
    const report = state.report;
    return `
        <div class="cards-row">
            <div class="stat-card stat-info">
                <div class="stat-label">Активный спринт, задач</div>
                <div class="stat-value">${t.sprintCount}</div>
                <div class="stat-sub">в активных спринтах</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">В работе сейчас</div>
                <div class="stat-value">${t.wipCount}</div>
                <div class="stat-sub">in-progress либо с активностью</div>
            </div>
            <div class="stat-card stat-warn">
                <div class="stat-label">Висят &gt; N дней</div>
                <div class="stat-value">${t.staleCount}</div>
                <div class="stat-sub">порог ${report.staleDays} дн без движения</div>
            </div>
            <div class="stat-card stat-good">
                <div class="stat-label">Закрыто вчера</div>
                <div class="stat-value">${t.doneYesterdayCount}</div>
                <div class="stat-sub">переведены в терминальный статус вчера</div>
            </div>
        </div>`;
}

function areaCard(a) {
    if (a.error) return `<div class="area-card"><h3>${escapeHtml(a.name)} ${areaTag(a)}</h3><div class="area-error">${escapeHtml(a.error)}</div></div>`;
    const issues = a.issues || [];
    const wip = issues.filter(isWip).length;
    const done = issues.filter((i) => statusCategory(i) === 'done').length;
    const sprint = (a.sprintKeys || []).length;
    const backlog = (a.backlogKeys || []).length;
    const { people } = aggregatePeople([a]);
    const stale = people.reduce((s, p) => s + p.stale.length, 0);
    const doneY = people.reduce((s, p) => s + p.doneYesterday.length, 0);
    return `
        <div class="area-card">
            <h3>${escapeHtml(a.name)} ${areaTag(a)}</h3>
            <div class="hbar-row"><div>В спринте</div><div class="hbar"><span style="width:${Math.min(100, sprint)}%"></span></div><div class="val">${sprint}</div></div>
            <div class="hbar-row"><div>В работе</div><div class="hbar good"><span style="width:${Math.min(100, wip * 5)}%"></span></div><div class="val">${wip}</div></div>
            <div class="hbar-row"><div>Висят</div><div class="hbar warn"><span style="width:${Math.min(100, stale * 10)}%"></span></div><div class="val">${stale}</div></div>
            <div class="hbar-row"><div>Закрыто вчера</div><div class="hbar good"><span style="width:${Math.min(100, doneY * 10)}%"></span></div><div class="val">${doneY}</div></div>
            <div class="hbar-row"><div>Бэклог</div><div class="hbar warn"><span style="width:${Math.min(100, backlog * 2)}%"></span></div><div class="val">${backlog}</div></div>
        </div>`;
}

function renderYesterdayList(areas) {
    const { people } = aggregatePeople(areas);
    const rows = people.filter((p) => p.yesterdayItems.length || p.doneYesterday.length).slice(0, 60).map((p) => {
        const bits = [];
        if (p.doneYesterday.length) bits.push(`<span class="chip status-done">✅ ${p.doneYesterday.length}</span>`);
        if (p.stats.workSecYesterday) bits.push(`<span class="chip">⏱ ${hoursToReadable(p.stats.workSecYesterday)}</span>`);
        const itemsCombined = [...p.doneYesterday, ...p.yesterdayItems];
        const seen = new Set();
        const uniq = [];
        for (const x of itemsCombined) {
            if (seen.has(x.issue.key)) continue;
            seen.add(x.issue.key);
            uniq.push(x);
            if (uniq.length >= 8) break;
        }
        const links = uniq.map((x) => `<a class="issue-key" href="${issueUrl(x.issue.key)}" target="_blank">${x.issue.key}</a>${x.area ? areaTag(x.area) : ''}<span class="tip-icon" data-tip-issue="${escapeHtml(x.issue.key)}">?</span>`).join(' ');
        return `<div class="issue">
            <div class="issue-key">${escapeHtml(p.name)}</div>
            <div class="issue-title">${links || '<span style="color:var(--text-mute)">—</span>'}</div>
            <div class="issue-meta">${bits.join(' ')}</div>
        </div>`;
    });
    return rows.length ? rows.join('') : '<div class="empty">Вчера тишина.</div>';
}

function renderTodayList(areas) {
    const { people } = aggregatePeople(areas);
    const plan = new Map();
    for (const p of people) for (const x of p.inProgress) {
        if (!plan.has(p.name)) plan.set(p.name, []);
        plan.get(p.name).push(x);
    }
    if (!plan.size) return '<div class="empty">Нет задач в работе.</div>';
    return Array.from(plan.entries()).sort((a, b) => a[0].localeCompare(b[0], 'ru')).map(([name, arr]) => {
        const links = arr.slice(0, 10).map((x) => `<a class="issue-key" href="${issueUrl(x.issue.key)}" target="_blank">${x.issue.key}</a>${x.area ? areaTag(x.area) : ''}<span class="tip-icon" data-tip-issue="${escapeHtml(x.issue.key)}">?</span>`).join(' ');
        return `<div class="issue">
            <div class="issue-key">${escapeHtml(name)}</div>
            <div class="issue-title">${links}</div>
            <div class="issue-meta"><span class="chip">${arr.length}</span></div>
        </div>`;
    }).join('');
}

function renderTypeBreakdown(scope) {
    const types = ['story', 'task', 'bug', 'sub-task'];
    const total = { done: 0, wip: 0, todo: 0 };
    const byType = {};
    for (const t of types) byType[t] = { done: 0, wip: 0, todo: 0 };
    for (const it of scope) {
        const t = typeBucket(it);
        const cat = statusCategory(it);
        const wip = isWip(it);
        let bucket;
        if (cat === 'done') bucket = 'done';
        else if (wip) bucket = 'wip';
        else bucket = 'todo';
        byType[t][bucket] += 1;
        total[bucket] += 1;
    }

    const legend = `
        <div class="legend" style="margin-bottom:10px">
            <span><span class="dot done"></span> Готово</span>
            <span><span class="dot wip"></span> В работе</span>
            <span><span class="dot todo"></span> Не приступали</span>
        </div>`;
    const rows = types.filter((t) => (byType[t].done + byType[t].wip + byType[t].todo) > 0).map((t) => {
        const sum = byType[t].done + byType[t].wip + byType[t].todo;
        const pct = (n) => sum ? Math.round(n / sum * 100) : 0;
        return `
            <div class="type-row">
                <div class="type-title"><span>${typeIcon(t)}</span><span>${typeLabel(t)}</span></div>
                <div class="bar">
                    <span class="seg-done" style="width:${pct(byType[t].done)}%"></span>
                    <span class="seg-wip"  style="width:${pct(byType[t].wip)}%"></span>
                    <span class="seg-todo" style="width:${pct(byType[t].todo)}%"></span>
                </div>
                <div style="text-align:right;color:var(--text-dim);font-size:12px">
                    ✅ ${byType[t].done} · ▶ ${byType[t].wip} · ☐ ${byType[t].todo}
                </div>
            </div>`;
    }).join('');
    return legend + (rows || '<div class="empty">Нет задач для разбивки.</div>');
}

// ============ Рендер: Спринты ============

function renderSprints() {
    const areas = state.report?.areas || [];
    if (!areas.length) { $('#sprints-body').innerHTML = '<div class="empty">Нет пространств.</div>'; return; }
    const sub = state.activeSubtab.sprints || areas[0].projectKey;
    state.activeSubtab.sprints = sub;
    buildAreaSubtabs('#subtabs-sprints', sub, false);

    const a = areas.find((x) => x.projectKey === sub) || areas[0];
    if (!a) { $('#sprints-body').innerHTML = '<div class="empty">Нет данных.</div>'; return; }
    if (a.error) { $('#sprints-body').innerHTML = `<div class="area-error">[${escapeHtml(a.projectKey)}] ${escapeHtml(a.error)}</div>`; return; }

    const sprintIssues = (a.issues || []).filter((it) => (a.sprintKeys || []).includes(it.key));
    if (!sprintIssues.length) {
        $('#sprints-body').innerHTML = `<div class="empty-card"><p>В пространстве «${escapeHtml(a.name)}» активный спринт не найден.</p></div>`;
        return;
    }

    const total = sprintIssues.length;
    const done = sprintIssues.filter((it) => statusCategory(it) === 'done').length;
    const wip  = sprintIssues.filter(isWip).length;
    const todo = total - done - wip;
    const pct = Math.round(done / total * 100);

    const sIns = computeSprintInsights(a, sprintIssues);

    $('#sprints-body').innerHTML = `
        <div class="cards-row">
            <div class="stat-card stat-info">
                <div class="stat-label">Всего</div>
                <div class="stat-value">${total}</div>
                <div class="stat-sub">в активном спринте</div>
            </div>
            <div class="stat-card stat-good">
                <div class="stat-label">Готово</div>
                <div class="stat-value">${done}</div>
                <div class="stat-sub">${pct}% спринта</div>
            </div>
            <div class="stat-card stat-info">
                <div class="stat-label">В работе</div>
                <div class="stat-value">${wip}</div>
            </div>
            <div class="stat-card stat-warn">
                <div class="stat-label">Не приступали</div>
                <div class="stat-value">${todo}</div>
            </div>
        </div>
        <div class="panel">
            <h2>По типам задач — спринт ${escapeHtml(a.name)} ${areaTag(a)}</h2>
            <div>${renderTypeBreakdown(sprintIssues)}</div>
        </div>
        <div class="panel">
            <h2>Инсайты по спринту</h2>
            <div class="insights">${sIns.length ? sIns.map(insightHtml).join('') : '<div class="empty">Сигналов по спринту нет.</div>'}</div>
        </div>
    `;
}

function computeSprintInsights(a, sprintIssues) {
    const sIns = [];
    const total = sprintIssues.length;
    const done = sprintIssues.filter((it) => statusCategory(it) === 'done').length;
    const wip = sprintIssues.filter(isWip).length;
    const todo = total - done - wip;
    if (todo / total > 0.5) sIns.push({ sev: 'warn', icon: '⏳', title: `${Math.round(todo / total * 100)}% спринта ещё не взято в работу`, desc: 'Если спринт уже на середине — пора брать или резать scope.', tag: 'scope' });
    if (wip / Math.max(1, total - done) > 0.5) sIns.push({ sev: 'warn', icon: '🪢', title: `WIP ${wip} из ${total - done} оставшихся (>50%)`, desc: 'Слишком много задач в работе одновременно.', tag: 'wip' });
    const counts = new Map();
    for (const it of sprintIssues) { const ass = assigneeOf(it); const k = ass ? ass.name : '—'; counts.set(k, (counts.get(k) || 0) + 1); }
    const sortedC = Array.from(counts.entries()).sort((x, y) => y[1] - x[1]);
    if (sortedC[0] && sortedC[0][1] / total > 0.4 && sortedC[0][0] !== '—') {
        sIns.push({ sev: 'warn', icon: '🧍', title: `One-man-show: ${escapeHtml(sortedC[0][0])} — ${sortedC[0][1]} из ${total}`, desc: 'Возможный bus-factor 1.', tag: 'risk' });
    }
    const bugs = sprintIssues.filter((it) => typeBucket(it) === 'bug');
    if (bugs.length / total > 0.3) sIns.push({ sev: 'info', icon: '🐞', title: `Доля багов в спринте — ${Math.round(bugs.length / total * 100)}%`, desc: 'Высокий технический долг или регресс.', tag: 'quality' });
    const orphans = sprintIssues.filter((it) => isSubtask(it) && !sprintIssues.some((p) => p.key === parentKeyOf(it)));
    if (orphans.length) sIns.push({ sev: 'info', icon: '🧩', title: `Подзадач без родителя в спринте: ${orphans.length}`, desc: orphans.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', '), tag: 'sync' });
    const desync = sprintIssues.filter((p) => statusCategory(p) === 'done' && (p.fields?.subtasks || []).some((s) => s.fields?.status?.statusCategory?.key !== 'done'));
    if (desync.length) sIns.push({ sev: 'bad', icon: '🧷', title: `Закрытые задачи с незакрытыми подзадачами: ${desync.length}`, desc: desync.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', '), tag: 'quality' });
    const inWeek = sprintIssues.filter((it) => {
        const d = it.fields?.duedate; if (!d || statusCategory(it) === 'done') return false;
        const t = new Date(d).getTime(); return t > Date.now() && t < Date.now() + 7 * 86400000;
    });
    if (inWeek.length) sIns.push({ sev: 'warn', icon: '📅', title: `Срок ≤7 дней: ${inWeek.length}`, desc: inWeek.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a> (до ${fmtDate(it.fields.duedate)})`).join(', '), tag: 'deadline' });
    return sIns;
}

// ============ Рендер: Метрики ============

function renderMetricsTab() {
    const sub = state.activeSubtab.metrics;
    buildAreaSubtabs('#subtabs-metrics', sub, true);
    const areas = selectedAreas(sub);
    $('#metrics-body').innerHTML = renderMetricsBody(areas);
}

function renderMetricsBody(areas) {
    const report = state.report;
    const { people } = aggregatePeople(areas);
    const allIssues = areas.flatMap((a) => a.issues || []);
    const sprintKeySet = new Set(areas.flatMap((a) => a.sprintKeys || []));

    const widgets = [];

    // 1) WIP по людям
    const wipByPerson = people.map((p) => ({ name: p.name, val: p.inProgress.length })).filter((x) => x.val > 0).sort((a, b) => b.val - a.val).slice(0, 12);
    widgets.push(widgetHorizontalBars('WIP по людям', wipByPerson, ''));

    // 2) Logtime вчера
    const logYest = people.map((p) => ({ name: p.name, val: Math.round((p.stats.workSecYesterday / 3600) * 10) / 10 })).filter((x) => x.val > 0).sort((a, b) => b.val - a.val).slice(0, 12);
    widgets.push(widgetHorizontalBars('Logtime вчера, ч', logYest, 'good'));

    // 3) Возраст задач в работе
    const ages = allIssues.filter(isWip).map((it) => daysSince(lastMovementIso(it) || it.fields?.updated)).filter((x) => x != null);
    widgets.push(widgetHistogram('Возраст задач в работе (дн)', ages, [0, 1, 3, 7, 14, 30]));

    // 4) Распределение по статус-категориям спринта
    const cats = { 'To Do': 0, 'In Progress': 0, 'Done': 0 };
    for (const it of allIssues.filter((x) => sprintKeySet.has(x.key))) {
        const c = statusCategory(it);
        if (c === 'done') cats['Done'] += 1;
        else if (c === 'indeterminate') cats['In Progress'] += 1;
        else cats['To Do'] += 1;
    }
    widgets.push(widgetDonut('Спринт: статусы', [
        { label: 'Done', value: cats['Done'], color: 'var(--good)' },
        { label: 'In Progress', value: cats['In Progress'], color: 'var(--accent)' },
        { label: 'To Do', value: cats['To Do'], color: 'var(--text-mute)' }
    ]));

    // 5) Распределение по приоритетам
    const prio = new Map();
    for (const it of allIssues) {
        const p = it.fields?.priority?.name || '—';
        prio.set(p, (prio.get(p) || 0) + 1);
    }
    const colors = { 'Highest': 'var(--bad)', 'High': '#e08585', 'Medium': 'var(--warn)', 'Low': 'var(--text-mute)', 'Lowest': '#7a8597' };
    const prioData = Array.from(prio.entries()).map(([k, v]) => ({ label: k, value: v, color: colors[k] || 'var(--accent)' }));
    widgets.push(widgetDonut('Приоритеты', prioData));

    // 6) Распределение по пространствам
    if (areas.length > 1) {
        const segs = areas.map((a) => ({ label: a.name, value: (a.issues || []).length, color: `hsl(${[...a.projectKey].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 0) % 360} 60% 50%)` }));
        widgets.push(widgetDonut('Задачи по пространствам', segs));
    }

    // 7) Commits/PR за 48ч по людям
    const commits = people.map((p) => ({ name: p.name, val: p.stats.commits48h + p.stats.prs48h })).filter((x) => x.val > 0).sort((a, b) => b.val - a.val).slice(0, 12);
    widgets.push(widgetHorizontalBars('Commits + PR (48ч)', commits, 'warn'));

    // 8) Confluence
    const conf = people.map((p) => ({ name: p.name, val: p.stats.confluence48h })).filter((x) => x.val > 0).sort((a, b) => b.val - a.val).slice(0, 12);
    widgets.push(widgetHorizontalBars('Confluence-правки (48ч)', conf, 'warn'));

    // 9) Закрыто vs открыто вчера
    const closedY = allIssues.filter((it) => {
        return (it.changelog?.histories || []).some((h) => inRange(h.created, report.yesterdayRange) && (h.items || []).some((i) => i.field === 'status' && (i.toString && (isTerminalStatusName(i.toString)))));
    }).length;
    const openedY = allIssues.filter((it) => inRange(it.fields?.created, report.yesterdayRange)).length;
    widgets.push(widgetTwoNumbers('Поток вчера', { left: { label: 'Закрыто', value: closedY, kind: 'good' }, right: { label: 'Открыто', value: openedY, kind: 'info' } }));

    // 10) Сравнение пространств: WIP / Done
    if (areas.length > 1) {
        const rows = areas.map((a) => ({ name: a.name + ' [' + a.projectKey + ']', val: (a.issues || []).filter(isWip).length }));
        widgets.push(widgetHorizontalBars('WIP по пространствам', rows.sort((a, b) => b.val - a.val)));
    }

    return `<div class="metrics-grid">${widgets.join('')}</div>`;
}

function widgetHorizontalBars(title, data, kind = '') {
    if (!data.length) return `<div class="widget"><h3>${escapeHtml(title)}</h3><div class="empty">Нет данных.</div></div>`;
    const max = Math.max(1, ...data.map((d) => d.val));
    return `<div class="widget"><h3>${escapeHtml(title)}</h3>
        ${data.map((d) => `
            <div class="hbar-row">
                <div title="${escapeHtml(d.name)}" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text)">${escapeHtml(d.name)}</div>
                <div class="hbar ${kind}"><span style="width:${(d.val / max * 100).toFixed(1)}%"></span></div>
                <div class="val">${d.val}</div>
            </div>`).join('')}
    </div>`;
}

function widgetHistogram(title, values, bins) {
    if (!values.length) return `<div class="widget"><h3>${escapeHtml(title)}</h3><div class="empty">Нет данных.</div></div>`;
    const buckets = [];
    for (let i = 0; i < bins.length; i++) {
        const lo = bins[i];
        const hi = i + 1 < bins.length ? bins[i + 1] : Infinity;
        const label = hi === Infinity ? `${lo}+` : `${lo}–${hi - 1}`;
        const count = values.filter((v) => v >= lo && v < hi).length;
        buckets.push({ name: label + ' дн', val: count });
    }
    return widgetHorizontalBars(title, buckets, 'warn');
}

function widgetDonut(title, segments) {
    const total = segments.reduce((s, x) => s + x.value, 0);
    if (!total) return `<div class="widget"><h3>${escapeHtml(title)}</h3><div class="empty">Нет данных.</div></div>`;
    const r = 38, c = 2 * Math.PI * r;
    let acc = 0;
    const ringSegments = segments.map((s) => {
        const len = (s.value / total) * c;
        const dasharray = `${len} ${c - len}`;
        const rotate = (acc / total) * 360 - 90;
        acc += s.value;
        return `<circle cx="50" cy="50" r="${r}" fill="none" stroke="${s.color}" stroke-width="14" stroke-dasharray="${dasharray}" stroke-dashoffset="0" transform="rotate(${rotate} 50 50)"></circle>`;
    }).join('');
    const legend = segments.filter((s) => s.value > 0).map((s) => `<div><span style="display:inline-block;width:10px;height:10px;border-radius:999px;background:${s.color};margin-right:6px;"></span>${escapeHtml(s.label)} — ${s.value} (${Math.round(s.value / total * 100)}%)</div>`).join('');
    return `<div class="widget"><h3>${escapeHtml(title)}</h3>
        <div class="donut-wrap">
            <svg viewBox="0 0 100 100" width="120" height="120" aria-hidden="true">
                <circle cx="50" cy="50" r="${r}" fill="none" stroke="var(--bg-soft)" stroke-width="14"></circle>
                ${ringSegments}
                <text x="50" y="54" text-anchor="middle" font-size="13" fill="var(--text)">${total}</text>
            </svg>
            <div class="donut-legend">${legend}</div>
        </div>
    </div>`;
}

function widgetTwoNumbers(title, p) {
    const cell = (x) => `<div style="flex:1"><div class="big" style="color:${x.kind === 'good' ? 'var(--good)' : x.kind === 'bad' ? 'var(--bad)' : 'var(--accent)'}">${x.value}</div><div class="sub">${escapeHtml(x.label)}</div></div>`;
    return `<div class="widget"><h3>${escapeHtml(title)}</h3><div style="display:flex;gap:18px">${cell(p.left)}${cell(p.right)}</div></div>`;
}

// ============ Рендер: Инсайты ============

function insightHtml(i) {
    return `<div class="insight sev-${i.sev}">
        <div class="icon">${i.icon}</div>
        <div>
            <div class="title">${escapeHtml(i.title)}</div>
            <div class="desc">${i.desc}</div>
        </div>
        <div class="tag">${escapeHtml(i.tag || '')}</div>
    </div>`;
}

function computeInsights(areas) {
    const report = state.report;
    const { people } = aggregatePeople(areas);
    const allIssues = areas.flatMap((a) => a.issues || []);
    const sprintKeySet = new Set(areas.flatMap((a) => a.sprintKeys || []));
    const wipIssues = allIssues.filter(isWip);
    const insights = [];

    // 0) Ошибки загрузки area
    for (const a of areas) {
        if (a.error) insights.push({ sev: 'bad', icon: '⛔', tag: 'error', title: `Ошибка загрузки ${a.name} [${a.projectKey}]`, desc: escapeHtml(a.error) });
    }

    // 1) Висит долго
    const staleAll = [];
    for (const p of people) for (const s of p.stale) staleAll.push({ ...s, person: p });
    if (staleAll.length) insights.push({
        sev: 'bad', icon: '🐌', tag: 'стагнация',
        title: `Висит в работе > ${report.staleDays} дн: ${staleAll.length}`,
        desc: staleAll.slice(0, 8).map((s) => `<a href="${issueUrl(s.issue.key)}" target="_blank">${s.issue.key}</a> ${s.area ? areaTag(s.area) : ''} · ${s.daysIdle}дн · ${escapeHtml(s.person.name)}`).join('<br>')
    });

    // 2) Тишина
    const silent = people.filter((p) => p.inProgress.length && !p.yesterdayItems.length && !p.doneYesterday.length && !p.external);
    if (silent.length) insights.push({
        sev: 'warn', icon: '🤫', tag: 'тишина',
        title: `Без активности вчера: ${silent.length} чел.`,
        desc: silent.slice(0, 12).map((p) => `${escapeHtml(p.name)} <span class="tag">(в работе ${p.inProgress.length})</span>`).join(' · ')
    });

    // 3) WIP > 3
    const overload = people.filter((p) => p.inProgress.length > 3);
    if (overload.length) insights.push({
        sev: 'warn', icon: '🧨', tag: 'перегруз',
        title: `WIP > 3 у ${overload.length} участника(ов)`,
        desc: overload.map((p) => `${escapeHtml(p.name)} — ${p.inProgress.length}`).join(' · ')
    });

    // 4) В спринте без исполнителя
    const noAssignee = allIssues.filter((it) => !it.fields?.assignee && sprintKeySet.has(it.key));
    if (noAssignee.length) insights.push({
        sev: 'warn', icon: '👻', tag: 'owner',
        title: `В спринте без исполнителя: ${noAssignee.length}`,
        desc: noAssignee.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ')
    });

    // 5) Просрочены
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const overdue = allIssues.filter((it) => {
        const d = it.fields?.duedate; if (!d || statusCategory(it) === 'done') return false;
        return new Date(d).getTime() < today.getTime();
    });
    if (overdue.length) insights.push({
        sev: 'bad', icon: '⏰', tag: 'срок',
        title: `Просрочены: ${overdue.length}`,
        desc: overdue.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a> (до ${fmtDate(it.fields.duedate)})`).join('<br>')
    });

    // 6) Высокий приоритет, не взято
    const hiTodo = allIssues.filter((it) => {
        const p = (it.fields?.priority?.name || '').toLowerCase();
        return ['highest', 'high', 'blocker', 'critical'].includes(p) && statusCategory(it) === 'new' && sprintKeySet.has(it.key);
    });
    if (hiTodo.length) insights.push({
        sev: 'warn', icon: '🔥', tag: 'prio',
        title: `Высокий приоритет не взят: ${hiTodo.length}`,
        desc: hiTodo.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ')
    });

    // 7) Закрыто вчера
    const doneTotal = people.reduce((s, p) => s + p.doneYesterday.length, 0);
    if (doneTotal) {
        const top = people.filter((p) => p.doneYesterday.length).sort((a, b) => b.doneYesterday.length - a.doneYesterday.length).slice(0, 5);
        insights.push({ sev: 'good', icon: '✅', tag: 'win', title: `Перевели в Done вчера: ${doneTotal}`, desc: top.map((p) => `${escapeHtml(p.name)} — ${p.doneYesterday.length}`).join(' · ') });
    }

    // 8) Без logtime вчера
    const noWl = people.filter((p) => p.inProgress.length && !p.stats.workSecYesterday && (p.yesterdayItems.length || p.doneYesterday.length));
    if (noWl.length) insights.push({ sev: 'info', icon: '⏱', tag: 'worklog', title: `Без logtime вчера: ${noWl.length}`, desc: noWl.slice(0, 8).map((p) => escapeHtml(p.name)).join(' · ') });

    // 9) Ping-pong
    const pp = allIssues.filter((it) => {
        const ts = (it.changelog?.histories || []).filter((h) => inRange(h.created, report.yesterdayRange) && (h.items || []).some((i) => i.field === 'status'));
        return ts.length >= 3;
    });
    if (pp.length) insights.push({ sev: 'warn', icon: '🏓', tag: 'pingpong', title: `Скакали по статусам вчера: ${pp.length}`, desc: pp.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ') });

    // 10) Closed без worklog
    const closedNoWl = allIssues.filter((it) => {
        const yDone = (it.changelog?.histories || []).some((h) => inRange(h.created, report.yesterdayRange) && (h.items || []).some((i) => i.field === 'status' && isTerminalStatusName(i.toString)));
        if (!yDone) return false;
        return !(it.fields?.worklog?.worklogs || []).length;
    });
    if (closedNoWl.length) insights.push({ sev: 'info', icon: '🧾', tag: 'учёт', title: `Закрыто вчера без worklog: ${closedNoWl.length}`, desc: closedNoWl.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ') });

    // 11) Блокеры без апдейта > 1 дня
    const blockers = allIssues.filter((it) => {
        const p = (it.fields?.priority?.name || '').toLowerCase();
        if (!['blocker', 'highest', 'critical'].includes(p)) return false;
        if (statusCategory(it) === 'done') return false;
        const mv = lastMovementIso(it) || it.fields?.updated; if (!mv) return false;
        return daysSince(mv) >= 1;
    });
    if (blockers.length) insights.push({ sev: 'bad', icon: '🛑', tag: 'blocker', title: `Блокеры без апдейта ≥1 дня: ${blockers.length}`, desc: blockers.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ') });

    // 12) Подзадача в работе, родитель — нет
    const subWipNoParent = allIssues.filter((it) => isSubtask(it) && isWip(it)).filter((it) => {
        const pk = parentKeyOf(it); if (!pk) return false;
        const parent = allIssues.find((x) => x.key === pk);
        return parent && !isWip(parent) && statusCategory(parent) !== 'done';
    });
    if (subWipNoParent.length) insights.push({ sev: 'info', icon: '🧩', tag: 'sync', title: `Подзадача в работе, родитель — нет: ${subWipNoParent.length}`, desc: subWipNoParent.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join('<br>') });

    // 13) Done с открытыми подзадачами
    const orphanOpen = allIssues.filter((p) => statusCategory(p) === 'done' && (p.fields?.subtasks || []).some((s) => s.fields?.status?.statusCategory?.key !== 'done'));
    if (orphanOpen.length) insights.push({ sev: 'bad', icon: '🪤', tag: 'sync', title: `Done, но есть открытые подзадачи: ${orphanOpen.length}`, desc: orphanOpen.slice(0, 6).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ') });

    // 14) Idle 2-3 дня
    const idle = wipIssues.map((it) => ({ it, d: daysSince(lastMovementIso(it) || it.fields?.updated) }))
        .filter((x) => x.d != null && x.d >= report.noMovementDays && x.d < report.staleDays);
    if (idle.length) insights.push({ sev: 'info', icon: '🌀', tag: 'idle', title: `Без движения ${report.noMovementDays}–${report.staleDays - 1} дн: ${idle.length}`, desc: idle.slice(0, 6).map((x) => `<a href="${issueUrl(x.it.key)}" target="_blank">${x.it.key}</a> (${x.d}дн)`).join(', ') });

    // 15) Перекос между пространствами по WIP
    if (areas.length > 1) {
        const wipPerArea = areas.map((a) => ({ a, wip: (a.issues || []).filter(isWip).length }));
        const maxA = wipPerArea.sort((x, y) => y.wip - x.wip)[0];
        const totalW = wipPerArea.reduce((s, x) => s + x.wip, 0);
        if (totalW && maxA.wip / totalW > 0.6) {
            insights.push({ sev: 'info', icon: '⚖', tag: 'распределение', title: `Перекос WIP: ${maxA.a.name} держит ${Math.round(maxA.wip / totalW * 100)}% всего WIP портфеля`, desc: `${maxA.wip} из ${totalW} активных задач`, tag: 'распределение' });
        }
    }

    if (!wipIssues.length) insights.push({ sev: 'info', icon: '📭', tag: 'empty', title: 'В работе сейчас нет задач', desc: 'Похоже, никто ничего не двигает.' });

    return insights;
}

function renderInsightsTab() {
    const sub = state.activeSubtab.insights;
    buildAreaSubtabs('#subtabs-insights', sub, true);
    const areas = selectedAreas(sub);
    const list = computeInsights(areas);
    const el = $('#insights-body');
    el.innerHTML = list.length
        ? `<div class="insights">${list.map(insightHtml).join('')}</div>`
        : '<div class="empty-card"><p>🎉 Очевидных сигналов нет.</p></div>';
}

// ============ Рендер: Бэклог ============

function renderBacklog() {
    // Заполнить селектор пространств
    const sel = $('#backlog-area-filter');
    if (sel) {
        const cur = state.backlogArea;
        const areas = state.report?.areas || [];
        sel.innerHTML = '<option value="__all__">Все пространства</option>' + areas.map((a) => `<option value="${escapeHtml(a.projectKey)}">${escapeHtml(a.name)} [${escapeHtml(a.projectKey)}]</option>`).join('');
        sel.value = cur || '__all__';
    }

    // Активная подвкладка
    $$('#subtabs-backlog .subtab').forEach((t) => t.classList.toggle('active', t.dataset.bsub === state.backlogSubtab));

    const areas = state.backlogArea === '__all__' ? (state.report?.areas || []) : (state.report?.areas || []).filter((a) => a.projectKey === state.backlogArea);
    const backlogItems = areas.flatMap((a) => (a.issues || []).filter((it) => (a.backlogKeys || []).includes(it.key)).map((it) => ({ issue: it, area: { name: a.name, projectKey: a.projectKey } })));

    const root = $('#backlog-body');
    if (!backlogItems.length) {
        root.innerHTML = '<div class="empty-card"><p>В бэклоге нет открытых задач. 👌</p></div>';
        return;
    }

    if (state.backlogSubtab === 'summary') {
        root.innerHTML = renderBacklogSummary(backlogItems, areas);
    } else if (state.backlogSubtab === 'metrics') {
        root.innerHTML = renderBacklogMetrics(backlogItems, areas);
    } else if (state.backlogSubtab === 'dashboards') {
        root.innerHTML = renderBacklogDashboards(backlogItems, areas);
    } else {
        root.innerHTML = renderBacklogInsights(backlogItems, areas);
    }
}

function renderBacklogSummary(items, areas) {
    const total = items.length;
    const noPrio = items.filter((x) => !x.issue.fields?.priority?.name).length;
    const noAssignee = items.filter((x) => !x.issue.fields?.assignee).length;
    const oldest = items.map((x) => daysSince(x.issue.fields?.created)).filter((d) => d != null).sort((a, b) => b - a)[0] || 0;
    const byType = { story: 0, task: 0, bug: 0, 'sub-task': 0 };
    for (const x of items) byType[typeBucket(x.issue)] = (byType[typeBucket(x.issue)] || 0) + 1;

    // Топ по area
    const byArea = new Map();
    for (const x of items) {
        const k = x.area.projectKey;
        if (!byArea.has(k)) byArea.set(k, { area: x.area, count: 0 });
        byArea.get(k).count += 1;
    }
    const areaRows = Array.from(byArea.values()).sort((a, b) => b.count - a.count);

    return `
        <div class="cards-row">
            <div class="stat-card stat-info">
                <div class="stat-label">Всего в бэклоге</div>
                <div class="stat-value">${total}</div>
                <div class="stat-sub">не в активном спринте, не сделаны</div>
            </div>
            <div class="stat-card stat-warn">
                <div class="stat-label">Без приоритета</div>
                <div class="stat-value">${noPrio}</div>
            </div>
            <div class="stat-card stat-warn">
                <div class="stat-label">Без исполнителя</div>
                <div class="stat-value">${noAssignee}</div>
            </div>
            <div class="stat-card stat-bad">
                <div class="stat-label">Самая старая</div>
                <div class="stat-value">${oldest}</div>
                <div class="stat-sub">дней с создания</div>
            </div>
        </div>
        <div class="panel">
            <h2>По типам</h2>
            <div class="legend" style="margin-bottom:6px"><span>📗 Истории — ${byType.story}</span> <span>✅ Задачи — ${byType.task}</span> <span>🐞 Баги — ${byType.bug}</span> <span>↳ Подзадачи — ${byType['sub-task'] || 0}</span></div>
        </div>
        <div class="panel">
            <h2>По пространствам</h2>
            ${areaRows.map((r) => `
                <div class="hbar-row">
                    <div>${escapeHtml(r.area.name)} ${areaTag(r.area)}</div>
                    <div class="hbar"><span style="width:${(r.count / total * 100).toFixed(1)}%"></span></div>
                    <div class="val">${r.count}</div>
                </div>`).join('')}
        </div>
        <div class="panel">
            <h2>Список (топ-100, по возрасту)</h2>
            <div class="list">${items.sort((a, b) => (daysSince(b.issue.fields?.created) || 0) - (daysSince(a.issue.fields?.created) || 0)).slice(0, 100).map((x) => issueLine(x.issue, x.area, { daysIdle: daysSince(x.issue.fields?.created) })).join('')}</div>
        </div>
    `;
}

function renderBacklogMetrics(items, areas) {
    const ages = items.map((x) => daysSince(x.issue.fields?.created)).filter((d) => d != null);
    const widgets = [];
    widgets.push(widgetHistogram('Возраст в бэклоге (дн)', ages, [0, 7, 30, 90, 180, 365]));

    // По типам
    const types = ['story', 'task', 'bug', 'sub-task'];
    const typeData = types.map((t) => ({ label: typeLabel(t), value: items.filter((x) => typeBucket(x.issue) === t).length, color: 'var(--accent)' })).filter((x) => x.value);
    widgets.push(widgetDonut('Типы задач в бэклоге', typeData));

    // По приоритетам
    const prios = new Map();
    for (const x of items) {
        const p = x.issue.fields?.priority?.name || 'Без приоритета';
        prios.set(p, (prios.get(p) || 0) + 1);
    }
    const colors = { 'Highest': 'var(--bad)', 'High': '#e08585', 'Medium': 'var(--warn)', 'Low': 'var(--text-mute)', 'Lowest': '#7a8597', 'Без приоритета': 'var(--text-mute)' };
    const prioSegs = Array.from(prios.entries()).map(([k, v]) => ({ label: k, value: v, color: colors[k] || 'var(--accent)' }));
    widgets.push(widgetDonut('Приоритеты в бэклоге', prioSegs));

    // По исполнителям (топ-10)
    const ass = new Map();
    for (const x of items) {
        const a = assigneeOf(x.issue); const k = a ? a.name : 'Без исполнителя';
        ass.set(k, (ass.get(k) || 0) + 1);
    }
    const assRows = Array.from(ass.entries()).map(([n, v]) => ({ name: n, val: v })).sort((a, b) => b.val - a.val).slice(0, 10);
    widgets.push(widgetHorizontalBars('Бэклог по людям (топ-10)', assRows));

    // По пространствам
    const byArea = areas.map((a) => ({ name: a.name + ' [' + a.projectKey + ']', val: (a.backlogKeys || []).length })).filter((r) => r.val > 0).sort((a, b) => b.val - a.val);
    if (byArea.length > 1) widgets.push(widgetHorizontalBars('Бэклог по пространствам', byArea, 'warn'));

    return `<div class="metrics-grid">${widgets.join('')}</div>`;
}

function renderBacklogDashboards(items, areas) {
    // Дашборды — сгруппированные плитки по area
    const cards = areas.map((a) => {
        const cnt = (a.backlogKeys || []).length;
        const bugs = (a.issues || []).filter((it) => (a.backlogKeys || []).includes(it.key) && typeBucket(it) === 'bug').length;
        const noAss = (a.issues || []).filter((it) => (a.backlogKeys || []).includes(it.key) && !it.fields?.assignee).length;
        const hi = (a.issues || []).filter((it) => (a.backlogKeys || []).includes(it.key) && ['highest', 'high', 'blocker', 'critical'].includes((it.fields?.priority?.name || '').toLowerCase())).length;
        const oldDays = (a.issues || []).filter((it) => (a.backlogKeys || []).includes(it.key)).map((it) => daysSince(it.fields?.created)).filter((d) => d != null).sort((x, y) => y - x)[0] || 0;
        return `
            <div class="area-card">
                <h3>${escapeHtml(a.name)} ${areaTag(a)}</h3>
                <div class="hbar-row"><div>Всего</div><div class="hbar"><span style="width:${Math.min(100, cnt)}%"></span></div><div class="val">${cnt}</div></div>
                <div class="hbar-row"><div>Высокий приоритет</div><div class="hbar bad"><span style="width:${Math.min(100, hi * 5)}%"></span></div><div class="val">${hi}</div></div>
                <div class="hbar-row"><div>Багов</div><div class="hbar warn"><span style="width:${Math.min(100, bugs * 5)}%"></span></div><div class="val">${bugs}</div></div>
                <div class="hbar-row"><div>Без исполнителя</div><div class="hbar warn"><span style="width:${Math.min(100, noAss * 5)}%"></span></div><div class="val">${noAss}</div></div>
                <div class="hbar-row"><div>Самая старая</div><div class="hbar"><span style="width:${Math.min(100, oldDays / 3)}%"></span></div><div class="val">${oldDays}д</div></div>
            </div>`;
    }).join('');

    // Топы
    const topOld = [...items].sort((a, b) => (daysSince(b.issue.fields?.created) || 0) - (daysSince(a.issue.fields?.created) || 0)).slice(0, 10);
    const topHi  = items.filter((x) => ['highest', 'high', 'blocker', 'critical'].includes((x.issue.fields?.priority?.name || '').toLowerCase())).slice(0, 15);
    return `
        <div class="panel"><h2>Бэклог по пространствам</h2>
            <div class="area-card-grid">${cards}</div>
        </div>
        <div class="two-col">
            <div class="panel">
                <h2>Топ-10 самых старых</h2>
                <div class="list">${topOld.map((x) => issueLine(x.issue, x.area, { daysIdle: daysSince(x.issue.fields?.created) })).join('') || '<div class="empty">—</div>'}</div>
            </div>
            <div class="panel">
                <h2>Высокий приоритет в бэклоге</h2>
                <div class="list">${topHi.length ? topHi.map((x) => issueLine(x.issue, x.area)).join('') : '<div class="empty">Нет высокоприоритетных в бэклоге.</div>'}</div>
            </div>
        </div>
    `;
}

function renderBacklogInsights(items, areas) {
    const insights = [];

    // 1) Слишком большой бэклог
    if (items.length > 200) insights.push({ sev: 'warn', icon: '🗃', tag: 'overload', title: `Бэклог раздут: ${items.length} задач`, desc: 'Имеет смысл провести groomming/архивацию.' });

    // 2) Старые задачи (> 90 дней)
    const ancient = items.filter((x) => (daysSince(x.issue.fields?.created) || 0) > 90);
    if (ancient.length) insights.push({ sev: 'info', icon: '🦴', tag: 'старьё', title: `Старше 90 дней: ${ancient.length}`, desc: ancient.slice(0, 8).map((x) => `<a href="${issueUrl(x.issue.key)}" target="_blank">${x.issue.key}</a> (${daysSince(x.issue.fields?.created)}д)`).join('<br>') });

    // 3) Без приоритета
    const noPrio = items.filter((x) => !x.issue.fields?.priority?.name);
    if (noPrio.length) insights.push({ sev: 'info', icon: '🏷', tag: 'prio', title: `Без приоритета: ${noPrio.length}`, desc: noPrio.slice(0, 6).map((x) => `<a href="${issueUrl(x.issue.key)}" target="_blank">${x.issue.key}</a>`).join(', ') });

    // 4) Высокий приоритет в бэклоге
    const hi = items.filter((x) => ['highest', 'blocker', 'critical', 'high'].includes((x.issue.fields?.priority?.name || '').toLowerCase()));
    if (hi.length) insights.push({ sev: 'bad', icon: '🔥', tag: 'prio', title: `Высокий приоритет в бэклоге: ${hi.length}`, desc: hi.slice(0, 8).map((x) => `<a href="${issueUrl(x.issue.key)}" target="_blank">${x.issue.key}</a> ${areaTag(x.area)}`).join('<br>') });

    // 5) Просроченные due date в бэклоге
    const today = Date.now();
    const overdue = items.filter((x) => x.issue.fields?.duedate && new Date(x.issue.fields.duedate).getTime() < today);
    if (overdue.length) insights.push({ sev: 'bad', icon: '⏰', tag: 'срок', title: `Бэклог-задачи с просроченным сроком: ${overdue.length}`, desc: overdue.slice(0, 8).map((x) => `<a href="${issueUrl(x.issue.key)}" target="_blank">${x.issue.key}</a> (до ${fmtDate(x.issue.fields.duedate)})`).join('<br>') });

    // 6) Подзадачи в бэклоге без родителя
    const orphans = items.filter((x) => isSubtask(x.issue)).filter((x) => {
        const pk = parentKeyOf(x.issue); if (!pk) return true;
        return !areas.some((a) => (a.issues || []).some((i) => i.key === pk));
    });
    if (orphans.length) insights.push({ sev: 'info', icon: '🧩', tag: 'sync', title: `Подзадач в бэклоге без родителя: ${orphans.length}`, desc: orphans.slice(0, 6).map((x) => `<a href="${issueUrl(x.issue.key)}" target="_blank">${x.issue.key}</a>`).join(', ') });

    // 7) Перекос: один проект собирает основной бэклог
    if (areas.length > 1) {
        const total = items.length;
        const max = areas.map((a) => ({ a, n: items.filter((x) => x.area.projectKey === a.projectKey).length })).sort((x, y) => y.n - x.n)[0];
        if (max && max.n / total > 0.5) insights.push({ sev: 'info', icon: '⚖', tag: 'распределение', title: `${max.a.name} держит ${Math.round(max.n / total * 100)}% всего бэклога`, desc: `${max.n} из ${total} задач` });
    }

    // 8) Бэклог багов
    const bugs = items.filter((x) => typeBucket(x.issue) === 'bug');
    if (bugs.length / Math.max(1, items.length) > 0.4) insights.push({ sev: 'warn', icon: '🐞', tag: 'quality', title: `${Math.round(bugs.length / items.length * 100)}% бэклога — баги`, desc: 'Качество кодовой базы или регресс. Стоит пересмотреть тестовые практики.' });

    // 9) Без описания
    const noDesc = items.filter((x) => !(x.issue.fields?.description || '').toString().trim());
    if (noDesc.length / items.length > 0.3) insights.push({ sev: 'info', icon: '📝', tag: 'качество', title: `Без описания: ${noDesc.length}`, desc: 'Большой процент задач без описания усложняет планирование.' });

    return insights.length
        ? `<div class="insights">${insights.map(insightHtml).join('')}</div>`
        : '<div class="empty-card"><p>🎉 По бэклогу — без сигналов.</p></div>';
}

// ============ Главный рендер ============

function renderAll() {
    renderPeople();
    renderSummary();
    renderSprints();
    renderInsightsTab();
    renderMetricsTab();
    renderBacklog();
}

// ============ Биндинги ============

function bind() {
    $$('#top-tabs .tab').forEach((t) => t.addEventListener('click', () => showPane(t.dataset.tab)));
    $('#btn-settings').addEventListener('click', openSettings);
    $('#btn-settings-2')?.addEventListener('click', openSettings);
    $('#btn-refresh').addEventListener('click', refresh);
    $('#btn-save').addEventListener('click', saveSettings);
    $('#btn-verify').addEventListener('click', verifySettings);
    $('#btn-add-area').addEventListener('click', () => addAreaRow('', ''));
    $$('#modal-settings [data-close]').forEach((el) => el.addEventListener('click', closeSettings));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { closeSettings(); hideTip(); }
        if (e.key.toLowerCase() === 'r' && !e.metaKey && !e.ctrlKey && !e.altKey && e.target?.tagName !== 'INPUT' && e.target?.tagName !== 'TEXTAREA') refresh();
    });
    $('#filter-people').addEventListener('input', (e) => { state.filterPeopleText = e.target.value; renderPeople(); });
    $('#only-with-yesterday').addEventListener('change', (e) => { state.onlyYesterday = e.target.checked; renderPeople(); });

    // Делегирование кликов по подвкладкам
    document.addEventListener('click', (e) => {
        const sb = e.target.closest('.subtab[data-sub]');
        if (sb) {
            const root = sb.closest('.subtabs').id; // subtabs-people, subtabs-summary etc.
            const tab = root.replace('subtabs-', '');
            state.activeSubtab[tab] = sb.dataset.sub;
            if (tab === 'people') renderPeople();
            else if (tab === 'summary') renderSummary();
            else if (tab === 'sprints') renderSprints();
            else if (tab === 'insights') renderInsightsTab();
            else if (tab === 'metrics') renderMetricsTab();
            return;
        }
        const bsb = e.target.closest('.subtab[data-bsub]');
        if (bsb) {
            state.backlogSubtab = bsb.dataset.bsub;
            renderBacklog();
            return;
        }
    });

    $('#backlog-area-filter')?.addEventListener('change', (e) => {
        state.backlogArea = e.target.value;
        renderBacklog();
    });

    // Тултип на ?-иконке
    document.addEventListener('mouseover', (e) => {
        const t = e.target.closest('[data-tip-issue]');
        if (!t) return;
        const key = t.getAttribute('data-tip-issue');
        const found = findIssueByKey(key);
        if (!found) return;
        showTip(tipForIssue(found.issue, found.area), e.clientX, e.clientY);
    });
    document.addEventListener('mousemove', (e) => {
        if (tipEl().classList.contains('hidden')) return;
        const t = e.target.closest('[data-tip-issue]');
        if (!t) return hideTip();
        const r = t.getBoundingClientRect();
        showTip(tipEl().innerHTML, r.right, r.bottom);
    });
    document.addEventListener('mouseout', (e) => {
        const t = e.target.closest('[data-tip-issue]'); if (!t) return;
        const to = e.relatedTarget;
        if (to && to.closest && to.closest('[data-tip-issue]') === t) return;
        hideTip();
    });
}

(async function init() {
    bind();
    try {
        const cfg = await loadConfig();
        if (!cfg.jiraBaseUrl || !cfg.hasJiraToken || !(cfg.areas || []).length) { showPane('empty'); openSettings(); }
        else await refresh();
    } catch (e) { console.error(e); showPane('empty'); toast('Ошибка инициализации: ' + e.message, 'bad'); }
})();
