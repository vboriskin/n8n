@echo off
REM Portfolio Pulse — запуск одной кнопкой (Windows).
REM Требуется установленный Node.js 18+ (https://nodejs.org).

setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
    echo.
    echo  Node.js не найден. Установите Node 18+ с https://nodejs.org и попробуйте снова.
    echo.
    pause
    exit /b 1
)

if "%PORT%"=="" set PORT=5174

echo.
echo  Стартуем Portfolio Pulse...
echo  Как только в окне появится URL — откройте http://127.0.0.1:%PORT% в браузере.
echo.

REM Откроем браузер автоматически через пару секунд
start "" /min cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:%PORT%"

node server.js
endlocal
