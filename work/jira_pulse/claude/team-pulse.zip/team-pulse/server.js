// Team Pulse — лёгкий Node.js бэкенд-прокси к Jira Server 8.x и Bitbucket Server.
// Без внешних зависимостей: только встроенные модули Node.js.
// Запуск: `node server.js` (или через start.bat / start.sh).

'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const CONFIG_FILE = path.join(ROOT, 'config.json');

const PORT = Number(process.env.PORT) || 5173;
const HOST = process.env.HOST || '127.0.0.1';

// ------------------------- Конфиг -------------------------

function readConfig() {
    try {
        const raw = fs.readFileSync(CONFIG_FILE, 'utf8');
        return JSON.parse(raw);
    } catch (_) {
        return {
            jiraBaseUrl: '',
            jiraToken: '',
            projectKey: '',
            bitbucketBaseUrl: '',
            bitbucketToken: '',
            allowInsecureTls: false,
            staleDays: 3,
            noMovementDays: 2
        };
    }
}

function writeConfig(patch) {
    const current = readConfig();
    const next = { ...current, ...patch };
    // токены не возвращаем в sanitized-виде, но сохранять — сохраняем
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(next, null, 2), 'utf8');
    return next;
}

function sanitizeConfig(cfg) {
    return {
        jiraBaseUrl: cfg.jiraBaseUrl || '',
        projectKey: cfg.projectKey || '',
        bitbucketBaseUrl: cfg.bitbucketBaseUrl || '',
        allowInsecureTls: !!cfg.allowInsecureTls,
        staleDays: cfg.staleDays ?? 3,
        noMovementDays: cfg.noMovementDays ?? 2,
        hasJiraToken: !!cfg.jiraToken,
        hasBitbucketToken: !!cfg.bitbucketToken
    };
}

// ------------------------- HTTP утилиты -------------------------

function sendJson(res, code, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(code, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Cache-Control': 'no-store'
    });
    res.end(body);
}

function sendText(res, code, text, type = 'text/plain; charset=utf-8') {
    const body = Buffer.from(text, 'utf8');
    res.writeHead(code, {
        'Content-Type': type,
        'Content-Length': body.length,
        'Cache-Control': 'no-store'
    });
    res.end(body);
}

function readBody(req) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        let total = 0;
        req.on('data', (c) => {
            total += c.length;
            if (total > 4 * 1024 * 1024) { // 4 MB лимит
                reject(new Error('Тело запроса слишком большое'));
                req.destroy();
                return;
            }
            chunks.push(c);
        });
        req.on('end', () => {
            const raw = Buffer.concat(chunks).toString('utf8');
            if (!raw) return resolve({});
            try { resolve(JSON.parse(raw)); }
            catch (e) { reject(new Error('Некорректный JSON: ' + e.message)); }
        });
        req.on('error', reject);
    });
}

// Прокси к внешнему HTTP(S) с Bearer-токеном
function forward({ targetUrl, method = 'GET', headers = {}, body = null, allowInsecureTls = false, timeoutMs = 25000 }) {
    return new Promise((resolve, reject) => {
        let parsed;
        try { parsed = new URL(targetUrl); }
        catch (e) { return reject(new Error('Некорректный URL: ' + targetUrl)); }

        const lib = parsed.protocol === 'https:' ? https : http;
        const options = {
            method,
            hostname: parsed.hostname,
            port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
            path: parsed.pathname + (parsed.search || ''),
            headers: {
                'Accept': 'application/json',
                'User-Agent': 'team-pulse/1.0',
                ...headers
            },
            rejectUnauthorized: !allowInsecureTls
        };

        const req = lib.request(options, (resp) => {
            const chunks = [];
            resp.on('data', (c) => chunks.push(c));
            resp.on('end', () => {
                const buf = Buffer.concat(chunks);
                const text = buf.toString('utf8');
                resolve({ status: resp.statusCode || 0, headers: resp.headers, text });
            });
        });

        req.setTimeout(timeoutMs, () => {
            req.destroy(new Error(`Таймаут запроса к ${parsed.hostname}`));
        });
        req.on('error', reject);

        if (body != null) {
            const payload = typeof body === 'string' ? body : JSON.stringify(body);
            req.setHeader('Content-Type', 'application/json');
            req.setHeader('Content-Length', Buffer.byteLength(payload));
            req.write(payload);
        }
        req.end();
    });
}

function joinUrl(base, pathname) {
    if (!base) throw new Error('baseUrl не задан');
    const trimmed = base.replace(/\/+$/, '');
    const p = pathname.startsWith('/') ? pathname : '/' + pathname;
    return trimmed + p;
}

// ------------------------- Jira -------------------------

async function jiraGet(cfg, apiPath) {
    const target = joinUrl(cfg.jiraBaseUrl, apiPath);
    const resp = await forward({
        targetUrl: target,
        method: 'GET',
        headers: { 'Authorization': 'Bearer ' + cfg.jiraToken },
        allowInsecureTls: cfg.allowInsecureTls
    });
    return parseJiraResponse(resp, target);
}

async function jiraPost(cfg, apiPath, body) {
    const target = joinUrl(cfg.jiraBaseUrl, apiPath);
    const resp = await forward({
        targetUrl: target,
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + cfg.jiraToken },
        body,
        allowInsecureTls: cfg.allowInsecureTls
    });
    return parseJiraResponse(resp, target);
}

function parseJiraResponse(resp, target) {
    if (resp.status < 200 || resp.status >= 300) {
        let msg = `Jira ${resp.status} при обращении к ${target}`;
        try {
            const j = JSON.parse(resp.text);
            if (j.errorMessages && j.errorMessages.length) msg += ': ' + j.errorMessages.join('; ');
            else if (j.message) msg += ': ' + j.message;
        } catch (_) {
            if (resp.text) msg += ': ' + resp.text.slice(0, 300);
        }
        const err = new Error(msg);
        err.status = resp.status;
        throw err;
    }
    if (!resp.text) return {};
    try { return JSON.parse(resp.text); }
    catch (e) { throw new Error('Jira вернула не JSON: ' + resp.text.slice(0, 200)); }
}

async function jiraSearchAll(cfg, jql, fields, expand) {
    const out = [];
    let startAt = 0;
    const pageSize = 100;
    while (true) {
        const body = {
            jql,
            startAt,
            maxResults: pageSize,
            fields: fields || ['summary', 'status', 'assignee', 'updated', 'created', 'priority', 'issuetype', 'labels', 'duedate', 'timetracking', 'worklog', 'parent', 'subtasks'],
            expand: expand || ['changelog']
        };
        const data = await jiraPost(cfg, '/rest/api/2/search', body);
        const issues = data.issues || [];
        out.push(...issues);
        if (issues.length < pageSize || out.length >= (data.total || out.length)) break;
        startAt += issues.length;
        if (startAt > 2000) break; // защита
    }
    return out;
}

// dev-status (нативный в Jira) — красиво отдаёт commit/PR по каждому issue.
async function jiraDevStatus(cfg, issueId, dataType /* 'repository' | 'pullrequest' */) {
    try {
        const target = joinUrl(cfg.jiraBaseUrl, `/rest/dev-status/1.0/issue/detail?issueId=${encodeURIComponent(issueId)}&applicationType=bitbucket&dataType=${dataType}`);
        const resp = await forward({
            targetUrl: target,
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + cfg.jiraToken },
            allowInsecureTls: cfg.allowInsecureTls
        });
        if (resp.status < 200 || resp.status >= 300) return null;
        return JSON.parse(resp.text || '{}');
    } catch (_) {
        return null;
    }
}

// ------------------------- Агрегация отчёта -------------------------

function startOfYesterday(now = new Date()) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - 1);
    return d;
}
function startOfToday(now = new Date()) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    return d;
}

function dateInRange(iso, from, to) {
    if (!iso) return false;
    const t = new Date(iso).getTime();
    return t >= from.getTime() && t < to.getTime();
}

async function buildReport(cfg) {
    if (!cfg.jiraBaseUrl) throw new Error('Не задан Jira baseURL');
    if (!cfg.jiraToken) throw new Error('Не задан Jira token');
    if (!cfg.projectKey) throw new Error('Не задан ключ команды/проекта');

    const projectKey = cfg.projectKey.trim();
    const staleDays = Number(cfg.staleDays) || 3;
    const noMovementDays = Number(cfg.noMovementDays) || 2;

    // 1) Задачи активного спринта
    const sprintJql = `project = "${projectKey}" AND sprint in openSprints()`;
    // 2) Задачи, обновлённые за последние 2 дня (ловим "вчера" + буфер на разные TZ/выходные)
    const recentJql = `project = "${projectKey}" AND updated >= -2d`;
    // 3) Задачи в работе
    const inProgressJql = `project = "${projectKey}" AND statusCategory = "In Progress"`;

    const fields = [
        'summary', 'status', 'assignee', 'reporter', 'updated', 'created',
        'priority', 'issuetype', 'labels', 'duedate', 'timetracking',
        'worklog', 'parent', 'subtasks', 'resolution', 'resolutiondate',
        'customfield_10007' // частый ID поля Sprint в Jira Server — попробуем, но безопасно если пусто
    ];

    const [sprintIssues, recentIssues, inProgressIssues] = await Promise.all([
        jiraSearchAll(cfg, sprintJql, fields, ['changelog']).catch((e) => { throw new Error('Ошибка выборки активного спринта: ' + e.message); }),
        jiraSearchAll(cfg, recentJql, fields, ['changelog']).catch((e) => { throw new Error('Ошибка выборки обновлённых за 2 дня: ' + e.message); }),
        jiraSearchAll(cfg, inProgressJql, fields, ['changelog']).catch((e) => { throw new Error('Ошибка выборки задач в работе: ' + e.message); })
    ]);

    // Объединяем по ключу
    const byKey = new Map();
    for (const arr of [sprintIssues, recentIssues, inProgressIssues]) {
        for (const it of arr) byKey.set(it.key, it);
    }
    const allIssues = Array.from(byKey.values());

    // Опционально: dev-status по задачам, которые обновлены вчера — чтобы поймать коммиты/PR.
    const yFrom = startOfYesterday();
    const yTo = startOfToday();

    let devStatus = {};
    if (cfg.bitbucketBaseUrl || cfg.jiraBaseUrl) {
        const yesterdayActive = allIssues.filter((it) => dateInRange(it.fields.updated, yFrom, yTo));
        // ограничим, чтобы не положить сервер
        const slice = yesterdayActive.slice(0, 40);
        const results = await Promise.all(slice.map(async (it) => {
            const [repo, pr] = await Promise.all([
                jiraDevStatus(cfg, it.id, 'repository'),
                jiraDevStatus(cfg, it.id, 'pullrequest')
            ]);
            return [it.key, { repo, pr }];
        }));
        devStatus = Object.fromEntries(results);
    }

    return {
        generatedAt: new Date().toISOString(),
        yesterdayRange: { from: yFrom.toISOString(), to: yTo.toISOString() },
        staleDays,
        noMovementDays,
        projectKey,
        issues: allIssues,
        sprintKeys: sprintIssues.map((i) => i.key),
        inProgressKeys: inProgressIssues.map((i) => i.key),
        devStatus
    };
}

// ------------------------- Статика -------------------------

const MIME = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.mjs': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.ico': 'image/x-icon',
    '.txt': 'text/plain; charset=utf-8'
};

function serveStatic(req, res, urlPath) {
    let rel = decodeURIComponent(urlPath.split('?')[0]);
    if (rel === '/' || rel === '') rel = '/index.html';
    const filePath = path.join(PUBLIC_DIR, rel);
    // защита от выхода за пределы public
    if (!filePath.startsWith(PUBLIC_DIR)) {
        return sendText(res, 403, 'Forbidden');
    }
    fs.stat(filePath, (err, stat) => {
        if (err || !stat.isFile()) return sendText(res, 404, 'Not found');
        const ext = path.extname(filePath).toLowerCase();
        res.writeHead(200, {
            'Content-Type': MIME[ext] || 'application/octet-stream',
            'Content-Length': stat.size,
            'Cache-Control': 'no-cache'
        });
        fs.createReadStream(filePath).pipe(res);
    });
}

// ------------------------- Роутинг -------------------------

async function handle(req, res) {
    const parsed = url.parse(req.url);
    const pathname = parsed.pathname || '/';
    const method = req.method || 'GET';

    // API
    if (pathname.startsWith('/api/')) {
        try {
            if (pathname === '/api/config' && method === 'GET') {
                return sendJson(res, 200, sanitizeConfig(readConfig()));
            }
            if (pathname === '/api/config' && method === 'POST') {
                const body = await readBody(req);
                const patch = {};
                if (typeof body.jiraBaseUrl === 'string') patch.jiraBaseUrl = body.jiraBaseUrl.trim();
                if (typeof body.projectKey === 'string') patch.projectKey = body.projectKey.trim();
                if (typeof body.bitbucketBaseUrl === 'string') patch.bitbucketBaseUrl = body.bitbucketBaseUrl.trim();
                if (typeof body.allowInsecureTls === 'boolean') patch.allowInsecureTls = body.allowInsecureTls;
                if (typeof body.staleDays === 'number') patch.staleDays = body.staleDays;
                if (typeof body.noMovementDays === 'number') patch.noMovementDays = body.noMovementDays;
                // токены принимаем только если непустые; пустое поле = "не менять"
                if (typeof body.jiraToken === 'string' && body.jiraToken.length) patch.jiraToken = body.jiraToken;
                if (typeof body.bitbucketToken === 'string' && body.bitbucketToken.length) patch.bitbucketToken = body.bitbucketToken;
                if (body.clearJiraToken === true) patch.jiraToken = '';
                if (body.clearBitbucketToken === true) patch.bitbucketToken = '';
                const next = writeConfig(patch);
                return sendJson(res, 200, sanitizeConfig(next));
            }
            if (pathname === '/api/verify' && method === 'POST') {
                const cfg = readConfig();
                if (!cfg.jiraBaseUrl || !cfg.jiraToken) {
                    return sendJson(res, 400, { ok: false, error: 'Сначала заполните Jira baseURL и token' });
                }
                const me = await jiraGet(cfg, '/rest/api/2/myself');
                return sendJson(res, 200, { ok: true, me: { name: me.name, displayName: me.displayName, emailAddress: me.emailAddress } });
            }
            if (pathname === '/api/report' && method === 'POST') {
                const cfg = readConfig();
                const report = await buildReport(cfg);
                return sendJson(res, 200, report);
            }
            return sendJson(res, 404, { error: 'Неизвестный API-метод' });
        } catch (e) {
            const status = e.status && e.status >= 400 && e.status < 600 ? e.status : 500;
            return sendJson(res, status, { error: e.message || String(e) });
        }
    }

    // статика
    if (method !== 'GET' && method !== 'HEAD') return sendText(res, 405, 'Method not allowed');
    return serveStatic(req, res, pathname);
}

const server = http.createServer((req, res) => {
    handle(req, res).catch((e) => {
        try { sendJson(res, 500, { error: 'Внутренняя ошибка: ' + (e.message || String(e)) }); } catch (_) {}
    });
});

server.listen(PORT, HOST, () => {
    const addr = `http://${HOST}:${PORT}`;
    console.log('\n╭──────────────────────────────────────────────╮');
    console.log('│  Team Pulse запущен                          │');
    console.log(`│  Откройте: ${addr.padEnd(34)}│`);
    console.log('│  Остановка: Ctrl+C                           │');
    console.log('╰──────────────────────────────────────────────╯\n');
});

process.on('SIGINT', () => { console.log('\nОстанавливаемся…'); server.close(() => process.exit(0)); });
process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
