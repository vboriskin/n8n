// Team Pulse — frontend. Vanilla JS, без фреймворков.

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const state = {
    config: null,
    report: null,
    activeTab: 'people',
    filterPeopleText: '',
    onlyYesterday: false
};

// -------------------------- Утилиты --------------------------

function fmtDateTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}
function fmtDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' });
}
function fmtTimeShort(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}
function daysSince(iso) {
    if (!iso) return null;
    const diffMs = Date.now() - new Date(iso).getTime();
    return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}
function businessHoursToReadable(seconds) {
    if (!seconds) return '';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    if (h && m) return `${h}ч ${m}м`;
    if (h) return `${h}ч`;
    return `${m}м`;
}
function escapeHtml(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function initials(name) {
    if (!name) return '?';
    const parts = String(name).trim().split(/\s+/);
    const chars = (parts[0]?.[0] || '') + (parts[1]?.[0] || '');
    return chars.toUpperCase() || '?';
}
function colorFromString(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    const hue = h % 360;
    return `linear-gradient(135deg, hsl(${hue} 55% 30%), hsl(${(hue + 60) % 360} 55% 30%))`;
}

function toast(text, kind = '') {
    const el = $('#toast');
    el.textContent = text;
    el.className = 'toast ' + kind;
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.add('hidden'), 3500);
}

// -------------------------- API --------------------------

async function api(path, opts = {}) {
    const resp = await fetch(path, {
        method: opts.method || 'GET',
        headers: { 'Content-Type': 'application/json' },
        body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    const text = await resp.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (_) { data = { error: text }; }
    if (!resp.ok) throw new Error((data && data.error) || `HTTP ${resp.status}`);
    return data;
}

// -------------------------- Настройки --------------------------

async function loadConfig() {
    state.config = await api('/api/config');
    return state.config;
}

function openSettings() {
    const cfg = state.config || {};
    $('#cfg-jira-url').value = cfg.jiraBaseUrl || '';
    $('#cfg-project').value = cfg.projectKey || '';
    $('#cfg-jira-token').value = '';
    $('#cfg-jira-token').placeholder = cfg.hasJiraToken ? '•••••••• (оставьте пустым, чтобы не менять)' : '';
    $('#cfg-bb-url').value = cfg.bitbucketBaseUrl || '';
    $('#cfg-bb-token').value = '';
    $('#cfg-bb-token').placeholder = cfg.hasBitbucketToken ? '•••••••• (оставьте пустым, чтобы не менять)' : '';
    $('#cfg-stale').value = cfg.staleDays ?? 3;
    $('#cfg-nomov').value = cfg.noMovementDays ?? 2;
    $('#cfg-insecure').checked = !!cfg.allowInsecureTls;
    $('#settings-error').classList.add('hidden');
    $('#modal-settings').classList.remove('hidden');
    $('#cfg-jira-url').focus();
}
function closeSettings() { $('#modal-settings').classList.add('hidden'); }

async function saveSettings() {
    const payload = {
        jiraBaseUrl: $('#cfg-jira-url').value.trim(),
        projectKey: $('#cfg-project').value.trim(),
        bitbucketBaseUrl: $('#cfg-bb-url').value.trim(),
        staleDays: Number($('#cfg-stale').value) || 3,
        noMovementDays: Number($('#cfg-nomov').value) || 2,
        allowInsecureTls: $('#cfg-insecure').checked
    };
    const jt = $('#cfg-jira-token').value;
    if (jt) payload.jiraToken = jt;
    const bt = $('#cfg-bb-token').value;
    if (bt) payload.bitbucketToken = bt;

    const errEl = $('#settings-error');
    errEl.classList.add('hidden');
    try {
        const cfg = await api('/api/config', { method: 'POST', body: payload });
        state.config = cfg;
        toast('Настройки сохранены', 'good');
        closeSettings();
        await refresh();
    } catch (e) {
        errEl.textContent = 'Не удалось сохранить: ' + e.message;
        errEl.classList.remove('hidden');
    }
}

async function verifySettings() {
    // сначала сохраним, чтобы verify шёл с актуальными значениями
    const payload = {
        jiraBaseUrl: $('#cfg-jira-url').value.trim(),
        projectKey: $('#cfg-project').value.trim(),
        bitbucketBaseUrl: $('#cfg-bb-url').value.trim(),
        staleDays: Number($('#cfg-stale').value) || 3,
        noMovementDays: Number($('#cfg-nomov').value) || 2,
        allowInsecureTls: $('#cfg-insecure').checked
    };
    const jt = $('#cfg-jira-token').value;
    if (jt) payload.jiraToken = jt;
    const bt = $('#cfg-bb-token').value;
    if (bt) payload.bitbucketToken = bt;

    const errEl = $('#settings-error');
    errEl.classList.add('hidden');
    try {
        await api('/api/config', { method: 'POST', body: payload });
        const r = await api('/api/verify', { method: 'POST' });
        toast(`Подключение ок: ${r.me.displayName || r.me.name}`, 'good');
    } catch (e) {
        errEl.textContent = 'Ошибка подключения: ' + e.message;
        errEl.classList.remove('hidden');
    }
}

// -------------------------- Основной сценарий --------------------------

async function refresh() {
    const cfg = await loadConfig();
    const incomplete = !cfg.jiraBaseUrl || !cfg.hasJiraToken || !cfg.projectKey;
    if (incomplete) {
        showPane('empty');
        return;
    }

    const btn = $('#btn-refresh');
    btn.classList.add('is-loading'); btn.disabled = true;
    try {
        state.report = await api('/api/report', { method: 'POST' });
        renderAll();
        showPane(state.activeTab);
        const at = new Date(state.report.generatedAt);
        $('#meta').textContent = `обновлено ${at.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })} · проект ${state.report.projectKey}`;
    } catch (e) {
        toast('Не удалось загрузить отчёт: ' + e.message, 'bad');
        console.error(e);
    } finally {
        btn.classList.remove('is-loading'); btn.disabled = false;
    }
}

function showPane(name) {
    state.activeTab = name;
    $$('.pane').forEach((p) => p.classList.add('hidden'));
    const el = $('#pane-' + name);
    if (el) el.classList.remove('hidden');
    $$('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
}

// -------------------------- Агрегация --------------------------

function inYesterday(iso, report) {
    if (!iso) return false;
    const t = new Date(iso).getTime();
    const from = new Date(report.yesterdayRange.from).getTime();
    const to = new Date(report.yesterdayRange.to).getTime();
    return t >= from && t < to;
}

function issueUrl(key) {
    const base = (state.config?.jiraBaseUrl || '').replace(/\/+$/, '');
    return base ? `${base}/browse/${key}` : '#';
}

function statusCategory(issue) {
    return issue.fields?.status?.statusCategory?.key || 'new';
}
function statusName(issue) { return issue.fields?.status?.name || ''; }
function statusChip(issue) {
    const cat = statusCategory(issue);
    const cls = cat === 'done' ? 'status-done' : cat === 'indeterminate' ? 'status-inprogress' : 'status-todo';
    return `<span class="chip ${cls}" title="${escapeHtml(statusName(issue))}">${escapeHtml(statusName(issue))}</span>`;
}
function priorityChip(issue) {
    const p = issue.fields?.priority?.name;
    if (!p) return '';
    const low = p.toLowerCase();
    const cls = 'prio-' + low.replace(/\s+/g, '-');
    return `<span class="chip ${cls}">${escapeHtml(p)}</span>`;
}
function typeLabel(issue) {
    const t = issue.fields?.issuetype?.name;
    return t ? `<span class="chip">${escapeHtml(t)}</span>` : '';
}
function assigneeOf(issue) {
    const a = issue.fields?.assignee;
    if (!a) return null;
    return {
        key: a.name || a.accountId || a.key || a.displayName,
        name: a.displayName || a.name || '—',
        login: a.name || a.accountId || ''
    };
}

function extractYesterdayActivity(issue, report) {
    const out = {
        transitions: [],    // [{from, to, at, by}]
        commentsByUser: {}, // {userKey: count}
        worklogs: [],       // [{author, timeSpentSeconds, started, comment}]
        updatesByUser: {},  // {userKey: count}
        commits: []         // [{author, at, message}]
    };

    // changelog
    const hist = issue.changelog?.histories || [];
    for (const h of hist) {
        if (!inYesterday(h.created, report)) continue;
        const user = h.author?.name || h.author?.displayName || '—';
        out.updatesByUser[user] = (out.updatesByUser[user] || 0) + 1;
        for (const it of (h.items || [])) {
            if (it.field === 'status') {
                out.transitions.push({ from: it.fromString, to: it.toString, at: h.created, by: user });
            }
        }
    }
    // worklog
    const wls = issue.fields?.worklog?.worklogs || [];
    for (const w of wls) {
        if (!inYesterday(w.started, report)) continue;
        out.worklogs.push({
            author: w.author?.displayName || w.author?.name || '—',
            login: w.author?.name || '',
            timeSpentSeconds: w.timeSpentSeconds || 0,
            started: w.started,
            comment: (typeof w.comment === 'string') ? w.comment : ''
        });
    }
    // dev status
    const ds = report.devStatus?.[issue.key];
    if (ds) {
        const repoData = ds.repo?.detail || [];
        for (const d of repoData) {
            for (const r of (d.repositories || [])) {
                for (const c of (r.commits || [])) {
                    if (inYesterday(c.authorTimestamp, report)) {
                        out.commits.push({
                            author: c.author?.name || c.author?.username || '—',
                            at: c.authorTimestamp,
                            message: c.message || '',
                            url: c.url || null
                        });
                    }
                }
            }
        }
        const prData = ds.pr?.detail || [];
        for (const d of prData) {
            for (const p of (d.pullRequests || [])) {
                if (inYesterday(p.lastUpdate, report) || inYesterday(p.updateDate, report)) {
                    out.commits.push({
                        author: p.author?.name || '—',
                        at: p.lastUpdate || p.updateDate,
                        message: `PR ${p.status || ''}: ${p.name || ''}`.trim(),
                        url: p.url || null,
                        isPR: true
                    });
                }
            }
        }
    }
    return out;
}

function lastMovementIso(issue, yesterdayActivity) {
    const dates = [issue.fields?.updated].filter(Boolean);
    for (const h of (issue.changelog?.histories || [])) if (h.created) dates.push(h.created);
    for (const w of (issue.fields?.worklog?.worklogs || [])) if (w.started) dates.push(w.started);
    if (!dates.length) return null;
    return dates.sort().at(-1);
}

function aggregatePeople(report) {
    const people = new Map(); // key -> { key, name, login, inProgress: [], doneYesterday: [], activityIssues: [], stale: [], todo: [], all: [] }
    const ensure = (a) => {
        if (!a) a = { key: '__unassigned__', name: 'Без исполнителя', login: '' };
        if (!people.has(a.key)) {
            people.set(a.key, {
                key: a.key, name: a.name, login: a.login,
                inProgress: [], doneYesterday: [], activityIssues: [],
                stale: [], todo: [], all: [], yesterdayActivity: {
                    commits: 0, worklogSeconds: 0, transitions: 0, comments: 0, updates: 0
                }
            });
        }
        return people.get(a.key);
    };

    for (const issue of report.issues) {
        const a = assigneeOf(issue);
        const p = ensure(a);
        p.all.push(issue);

        const cat = statusCategory(issue);
        if (cat === 'indeterminate') p.inProgress.push(issue);
        if (cat === 'new') p.todo.push(issue);

        const ya = extractYesterdayActivity(issue, report);

        // doneYesterday — если последняя транзиция вчера привела в Done
        const toDone = ya.transitions.find((t) => (t.to || '').toLowerCase().match(/done|closed|готово|закрыт/));
        if (toDone) p.doneYesterday.push(issue);

        const hasActivity = ya.transitions.length || ya.worklogs.length || ya.commits.length || Object.keys(ya.updatesByUser).length;
        if (hasActivity) {
            p.activityIssues.push({ issue, ya });
            p.yesterdayActivity.transitions += ya.transitions.length;
            p.yesterdayActivity.commits += ya.commits.length;
            p.yesterdayActivity.worklogSeconds += ya.worklogs.reduce((s, w) => s + (w.timeSpentSeconds || 0), 0);
            p.yesterdayActivity.updates += Object.values(ya.updatesByUser).reduce((s, n) => s + n, 0);
        }

        // stale: в работе и не двигалась > staleDays
        const mv = lastMovementIso(issue, ya) || issue.fields?.updated;
        if (cat === 'indeterminate' && mv) {
            const d = daysSince(mv);
            if (d != null && d >= report.staleDays) p.stale.push({ issue, daysIdle: d });
        }
    }

    // убираем пустых "без исполнителя" если там нет ничего
    const un = people.get('__unassigned__');
    if (un && !un.todo.length && !un.inProgress.length && !un.activityIssues.length) {
        people.delete('__unassigned__');
    }

    // сортировка
    return Array.from(people.values()).sort((a, b) => {
        // активные вчера — выше
        const aAct = a.activityIssues.length + a.doneYesterday.length;
        const bAct = b.activityIssues.length + b.doneYesterday.length;
        if (bAct !== aAct) return bAct - aAct;
        return (a.name || '').localeCompare(b.name || '', 'ru');
    });
}

function computeInsights(report, people) {
    const insights = [];
    const inProgressTotal = report.inProgressKeys.length;

    // 1) Задачи, висящие > staleDays
    const staleAll = [];
    for (const p of people) for (const s of p.stale) staleAll.push({ ...s, person: p });
    if (staleAll.length) {
        insights.push({
            sev: 'bad',
            icon: '🐌',
            title: `Висит в работе > ${report.staleDays} дн: ${staleAll.length}`,
            desc: staleAll.slice(0, 8).map((s) => `<a href="${issueUrl(s.issue.key)}" target="_blank">${s.issue.key}</a> — ${escapeHtml(s.issue.fields.summary)} <span class="tag">· ${s.daysIdle} дн · ${escapeHtml(s.person.name)}</span>`).join('<br>'),
            tag: 'стагнация'
        });
    }

    // 2) Люди без активности вчера, но с задачами в работе
    const silent = people.filter((p) => p.inProgress.length > 0 && p.activityIssues.length === 0 && p.doneYesterday.length === 0 && p.key !== '__unassigned__');
    if (silent.length) {
        insights.push({
            sev: 'warn',
            icon: '🤫',
            title: `Без активности вчера: ${silent.length} чел.`,
            desc: silent.slice(0, 8).map((p) => `${escapeHtml(p.name)} <span class="tag">(в работе ${p.inProgress.length})</span>`).join(' · '),
            tag: 'тишина'
        });
    }

    // 3) WIP-лимит: у кого > 3 задач одновременно
    const overload = people.filter((p) => p.inProgress.length > 3);
    if (overload.length) {
        insights.push({
            sev: 'warn',
            icon: '🧨',
            title: `WIP > 3 у ${overload.length} участника(ов)`,
            desc: overload.map((p) => `${escapeHtml(p.name)} — ${p.inProgress.length} задач`).join(' · '),
            tag: 'перегруз'
        });
    }

    // 4) Задачи без исполнителя в активном спринте
    const noAssignee = report.issues.filter((it) => !it.fields?.assignee && report.sprintKeys.includes(it.key));
    if (noAssignee.length) {
        insights.push({
            sev: 'warn',
            icon: '👻',
            title: `В спринте без исполнителя: ${noAssignee.length}`,
            desc: noAssignee.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a> — ${escapeHtml(it.fields.summary)}`).join('<br>'),
            tag: 'owner'
        });
    }

    // 5) Просрочен duedate
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const overdue = report.issues.filter((it) => {
        const dd = it.fields?.duedate; if (!dd) return false;
        if (statusCategory(it) === 'done') return false;
        return new Date(dd).getTime() < today.getTime();
    });
    if (overdue.length) {
        insights.push({
            sev: 'bad',
            icon: '⏰',
            title: `Просрочены (duedate): ${overdue.length}`,
            desc: overdue.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a> — ${escapeHtml(it.fields.summary)} <span class="tag">(до ${fmtDate(it.fields.duedate)})</span>`).join('<br>'),
            tag: 'срок'
        });
    }

    // 6) Высокий приоритет и ещё не в работе
    const hiTodo = report.issues.filter((it) => {
        const p = (it.fields?.priority?.name || '').toLowerCase();
        return (p === 'highest' || p === 'high' || p === 'blocker' || p === 'critical') && statusCategory(it) === 'new' && report.sprintKeys.includes(it.key);
    });
    if (hiTodo.length) {
        insights.push({
            sev: 'warn',
            icon: '🔥',
            title: `Высокий приоритет, но не взято: ${hiTodo.length}`,
            desc: hiTodo.slice(0, 8).map((it) => `<a href="${issueUrl(it.key)}" target="_blank">${it.key}</a> — ${escapeHtml(it.fields.summary)}`).join('<br>'),
            tag: 'prio'
        });
    }

    // 7) Позитив — что закрыто вчера
    const doneYesterdayTotal = people.reduce((s, p) => s + p.doneYesterday.length, 0);
    if (doneYesterdayTotal) {
        const top = people.filter((p) => p.doneYesterday.length).sort((a, b) => b.doneYesterday.length - a.doneYesterday.length).slice(0, 5);
        insights.push({
            sev: 'good',
            icon: '✅',
            title: `Закрыто вчера: ${doneYesterdayTotal}`,
            desc: top.map((p) => `${escapeHtml(p.name)} — ${p.doneYesterday.length}`).join(' · '),
            tag: 'win'
        });
    }

    // 8) В работе без логирования времени вчера
    const noWorklog = people.filter((p) => p.inProgress.length && p.yesterdayActivity.worklogSeconds === 0 && p.activityIssues.length > 0);
    if (noWorklog.length) {
        insights.push({
            sev: 'info',
            icon: '⏱',
            title: `Без logtime вчера: ${noWorklog.length}`,
            desc: noWorklog.slice(0, 8).map((p) => escapeHtml(p.name)).join(' · '),
            tag: 'worklog'
        });
    }

    // 9) Общий пульс
    if (inProgressTotal === 0) {
        insights.push({ sev: 'info', icon: '📭', title: 'В работе сейчас нет задач', desc: 'Проверьте, не нужно ли двигать backlog в спринт.', tag: 'empty' });
    }

    return insights;
}

// -------------------------- Рендер --------------------------

function renderAll() {
    renderPeople();
    renderSummary();
    renderInsights();
    renderBacklog();
}

function issueRow(issue, extra = {}) {
    const key = issue.key;
    const summary = issue.fields?.summary || '';
    const last = issue.fields?.updated ? fmtDateTime(issue.fields.updated) : '';
    const metaRight = [];
    metaRight.push(statusChip(issue));
    const prio = priorityChip(issue); if (prio) metaRight.push(prio);
    if (extra.daysIdle != null) metaRight.push(`<span class="chip stale">${extra.daysIdle} дн без движения</span>`);
    if (extra.doneYesterday) metaRight.push(`<span class="chip status-done">закрыто вчера</span>`);
    if (extra.worklogSec) metaRight.push(`<span class="chip">⏱ ${businessHoursToReadable(extra.worklogSec)}</span>`);
    return `
        <div class="issue">
            <a class="issue-key" href="${issueUrl(key)}" target="_blank" rel="noreferrer">${escapeHtml(key)}</a>
            <div class="issue-title" title="${escapeHtml(summary)}${last ? ' · ' + last : ''}">${escapeHtml(summary)}</div>
            <div class="issue-meta">${metaRight.join(' ')}</div>
        </div>`;
}

function renderPeople() {
    const report = state.report;
    const people = aggregatePeople(report);
    state.people = people;

    const grid = $('#people-grid');
    const text = state.filterPeopleText.trim().toLowerCase();
    const filtered = people.filter((p) => {
        if (state.onlyYesterday && !p.activityIssues.length && !p.doneYesterday.length) return false;
        if (!text) return true;
        return (p.name || '').toLowerCase().includes(text) || (p.login || '').toLowerCase().includes(text);
    });

    if (!filtered.length) {
        grid.innerHTML = `<div class="empty-card"><p>Никого не нашли по фильтрам.</p></div>`;
        return;
    }

    grid.innerHTML = filtered.map((p) => personCard(p, report)).join('');
}

function personCard(p, report) {
    const badges = [];
    if (p.doneYesterday.length) badges.push(`<span class="badge good">✅ закрыто ${p.doneYesterday.length}</span>`);
    if (p.activityIssues.length) badges.push(`<span class="badge">• активно ${p.activityIssues.length}</span>`);
    if (p.yesterdayActivity.worklogSeconds) badges.push(`<span class="badge">⏱ ${businessHoursToReadable(p.yesterdayActivity.worklogSeconds)}</span>`);
    if (p.yesterdayActivity.commits) badges.push(`<span class="badge">⌥ коммитов ${p.yesterdayActivity.commits}</span>`);
    if (p.stale.length) badges.push(`<span class="badge bad">🐌 висит ${p.stale.length}</span>`);

    const inProgressHtml = p.inProgress.length
        ? p.inProgress.map((it) => {
            const mv = lastMovementIso(it, null) || it.fields.updated;
            const d = daysSince(mv);
            const extra = {};
            if (d != null && d >= report.staleDays) extra.daysIdle = d;
            return issueRow(it, extra);
        }).join('')
        : `<div class="empty">Ничего сейчас не в работе.</div>`;

    // Что делал вчера — объединённый список
    const yItems = [];
    for (const a of p.activityIssues) {
        const it = a.issue; const ya = a.ya;
        const bits = [];
        for (const t of ya.transitions) bits.push(`<span class="bullet">→</span> ${escapeHtml(t.from || '—')} → <b>${escapeHtml(t.to || '—')}</b> <span class="tag">${fmtTimeShort(t.at)}</span>`);
        for (const w of ya.worklogs) bits.push(`<span class="bullet">⏱</span> logtime ${businessHoursToReadable(w.timeSpentSeconds)}${w.comment ? ' — ' + escapeHtml(w.comment.slice(0, 120)) : ''}`);
        for (const c of ya.commits) bits.push(`<span class="bullet">${c.isPR ? 'PR' : '⌥'}</span> ${escapeHtml((c.message || '').split('\n')[0].slice(0, 120))} <span class="tag">${fmtTimeShort(c.at)}</span>`);
        if (!bits.length && ya.updates) bits.push(`<span class="bullet">✎</span> обновление полей`);
        if (bits.length) {
            yItems.push(`
                <li>
                    <div style="flex:1">
                        <a class="issue-key" href="${issueUrl(it.key)}" target="_blank">${escapeHtml(it.key)}</a>
                        <span style="color:var(--text-dim)">${escapeHtml(it.fields.summary)}</span>
                        <ul class="activity-list">${bits.map((b) => `<li>${b}</li>`).join('')}</ul>
                    </div>
                </li>`);
        }
    }
    const yHtml = yItems.length
        ? `<ul class="activity-list">${yItems.join('')}</ul>`
        : `<div class="empty">Вчера без изменений.</div>`;

    const staleHtml = p.stale.length
        ? p.stale.map((s) => issueRow(s.issue, { daysIdle: s.daysIdle })).join('')
        : '';

    return `
        <div class="person-card">
            <div class="person-head">
                <div class="avatar" style="background:${colorFromString(p.key || p.name)}">${escapeHtml(initials(p.name))}</div>
                <div style="min-width:0">
                    <div class="person-name">${escapeHtml(p.name)}</div>
                    <div class="person-login">${escapeHtml(p.login || '')}</div>
                </div>
                <div class="person-badges">${badges.join('')}</div>
            </div>

            <div class="person-section">
                <h3>В работе сейчас (${p.inProgress.length})</h3>
                ${inProgressHtml}
            </div>

            <div class="person-section">
                <h3>Что делал вчера</h3>
                ${yHtml}
            </div>

            ${p.stale.length ? `
            <div class="person-section">
                <h3>Висят &gt; ${report.staleDays} дн (${p.stale.length})</h3>
                ${staleHtml}
            </div>` : ''}
        </div>`;
}

function renderSummary() {
    const report = state.report;
    const people = state.people || aggregatePeople(report);

    const sprintCount = report.sprintKeys.length;
    const wipCount = report.inProgressKeys.length;
    const staleCount = people.reduce((s, p) => s + p.stale.length, 0);
    const doneYesterdayCount = people.reduce((s, p) => s + p.doneYesterday.length, 0);

    $('#stat-sprint').textContent = sprintCount;
    $('#stat-sprint-sub').textContent = 'в активном спринте';
    $('#stat-wip').textContent = wipCount;
    $('#stat-wip-sub').textContent = 'категория «In Progress»';
    $('#stat-stale').textContent = staleCount;
    $('#stat-stale-sub').textContent = `порог ${report.staleDays} дн без движения`;
    $('#stat-done').textContent = doneYesterdayCount;
    $('#stat-done-sub').textContent = 'транзиция в Done вчера';

    // Вчера — сжатая сводка по людям
    const yContainer = $('#summary-yesterday');
    const yRows = people
        .filter((p) => p.activityIssues.length || p.doneYesterday.length)
        .slice(0, 50)
        .map((p) => {
            const bits = [];
            if (p.doneYesterday.length) bits.push(`<span class="chip status-done">✅ ${p.doneYesterday.length}</span>`);
            if (p.yesterdayActivity.worklogSeconds) bits.push(`<span class="chip">⏱ ${businessHoursToReadable(p.yesterdayActivity.worklogSeconds)}</span>`);
            if (p.yesterdayActivity.commits) bits.push(`<span class="chip">⌥ ${p.yesterdayActivity.commits}</span>`);
            if (p.yesterdayActivity.transitions) bits.push(`<span class="chip">→ ${p.yesterdayActivity.transitions}</span>`);
            const issues = [...new Set([...p.doneYesterday, ...p.activityIssues.map((a) => a.issue)])]
                .slice(0, 5)
                .map((it) => `<a class="issue-key" href="${issueUrl(it.key)}" target="_blank">${it.key}</a>`).join(', ');
            return `
                <div class="issue">
                    <div class="issue-key">${escapeHtml(p.name)}</div>
                    <div class="issue-title">${issues || '<span style="color:var(--text-mute)">—</span>'}</div>
                    <div class="issue-meta">${bits.join(' ')}</div>
                </div>`;
        });
    yContainer.innerHTML = yRows.length ? yRows.join('') : '<div class="empty">Вчера тишина.</div>';

    // План на сегодня = всё в работе + высокоприоритетное из спринта без исполнителя
    const todayRows = [];
    for (const p of people) {
        for (const it of p.inProgress) {
            todayRows.push({ person: p.name, it });
        }
    }
    // группировка по человеку
    todayRows.sort((a, b) => a.person.localeCompare(b.person, 'ru'));
    const planEl = $('#summary-today');
    if (!todayRows.length) {
        planEl.innerHTML = '<div class="empty">Нет задач в работе.</div>';
    } else {
        const byPerson = new Map();
        for (const r of todayRows) {
            if (!byPerson.has(r.person)) byPerson.set(r.person, []);
            byPerson.get(r.person).push(r.it);
        }
        planEl.innerHTML = Array.from(byPerson.entries()).map(([name, arr]) => `
            <div class="issue">
                <div class="issue-key">${escapeHtml(name)}</div>
                <div class="issue-title">
                    ${arr.map((it) => `<a class="issue-key" href="${issueUrl(it.key)}" target="_blank" title="${escapeHtml(it.fields.summary)}">${it.key}</a>`).join(', ')}
                </div>
                <div class="issue-meta"><span class="chip">${arr.length}</span></div>
            </div>`).join('');
    }
}

function renderInsights() {
    const report = state.report;
    const people = state.people || aggregatePeople(report);
    const list = computeInsights(report, people);
    const el = $('#insights-list');
    if (!list.length) {
        el.innerHTML = '<div class="empty-card"><p>🎉 Всё ровно: очевидных сигналов нет.</p></div>';
        return;
    }
    el.innerHTML = list.map((i) => `
        <div class="insight sev-${i.sev}">
            <div class="icon">${i.icon}</div>
            <div>
                <div class="title">${escapeHtml(i.title)}</div>
                <div class="desc">${i.desc}</div>
            </div>
            <div class="tag">${escapeHtml(i.tag || '')}</div>
        </div>`).join('');
}

function renderBacklog() {
    const report = state.report;
    const el = $('#backlog-list');
    const inSprintTodo = report.issues.filter((it) => report.sprintKeys.includes(it.key) && statusCategory(it) === 'new');
    if (!inSprintTodo.length) {
        el.innerHTML = '<div class="empty-card"><p>В активном спринте нет задач вне работы. 👌</p></div>';
        return;
    }
    // группировка по исполнителю
    const byPerson = new Map();
    for (const it of inSprintTodo) {
        const a = assigneeOf(it) || { key: '__u__', name: 'Без исполнителя' };
        if (!byPerson.has(a.key)) byPerson.set(a.key, { name: a.name, items: [] });
        byPerson.get(a.key).items.push(it);
    }
    const groups = Array.from(byPerson.values()).sort((x, y) => y.items.length - x.items.length);
    el.innerHTML = groups.map((g) => `
        <div class="panel" style="margin-bottom:10px">
            <h2>${escapeHtml(g.name)} <span class="tag" style="color:var(--text-mute);font-weight:400">· ${g.items.length}</span></h2>
            ${g.items.map((it) => issueRow(it)).join('')}
        </div>`).join('');
}

// -------------------------- Бутстрап --------------------------

function bind() {
    $$('.tab').forEach((t) => t.addEventListener('click', () => showPane(t.dataset.tab)));
    $('#btn-settings').addEventListener('click', openSettings);
    $('#btn-settings-2')?.addEventListener('click', openSettings);
    $('#btn-refresh').addEventListener('click', refresh);
    $('#btn-save').addEventListener('click', saveSettings);
    $('#btn-verify').addEventListener('click', verifySettings);
    $$('#modal-settings [data-close]').forEach((el) => el.addEventListener('click', closeSettings));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeSettings();
        if (e.key.toLowerCase() === 'r' && !e.metaKey && !e.ctrlKey && !e.altKey && e.target?.tagName !== 'INPUT' && e.target?.tagName !== 'TEXTAREA') refresh();
    });
    $('#filter-people').addEventListener('input', (e) => { state.filterPeopleText = e.target.value; renderPeople(); });
    $('#only-with-yesterday').addEventListener('change', (e) => { state.onlyYesterday = e.target.checked; renderPeople(); });
}

(async function init() {
    bind();
    try {
        const cfg = await loadConfig();
        const incomplete = !cfg.jiraBaseUrl || !cfg.hasJiraToken || !cfg.projectKey;
        if (incomplete) {
            showPane('empty');
            openSettings();
        } else {
            await refresh();
        }
    } catch (e) {
        console.error(e);
        showPane('empty');
        toast('Ошибка инициализации: ' + e.message, 'bad');
    }
})();
