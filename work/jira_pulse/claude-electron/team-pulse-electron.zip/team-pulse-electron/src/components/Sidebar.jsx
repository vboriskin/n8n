import React from 'react'
import {
  LayoutDashboard,
  Users,
  Lightbulb,
  Target,
  Settings as SettingsIcon,
  RefreshCw,
  Sun,
  Moon,
  Monitor,
  Activity,
} from 'lucide-react'
import { useApp } from '../context/AppContext'
import { cn } from '../utils/classNames'

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'employees', label: 'Employees', icon: Users },
  { id: 'insights',  label: 'Insights',  icon: Lightbulb },
  { id: 'sprint',    label: 'Sprint',    icon: Target },
  { id: 'settings',  label: 'Settings',  icon: SettingsIcon },
]

const THEME_ICON = { light: Sun, dark: Moon, system: Monitor }

export default function Sidebar() {
  const { route, setRoute, theme, setTheme, loading, refresh, analytics, config } = useApp()

  const canRefresh = !!(config.jiraBaseUrl && config.jiraToken && config.jqlQuery)

  const cycleTheme = () => {
    const next = theme === 'light' ? 'dark' : theme === 'dark' ? 'system' : 'light'
    setTheme(next)
  }
  const ThemeIcon = THEME_ICON[theme] || Monitor

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-ink-200 bg-white/70 backdrop-blur dark:border-ink-800 dark:bg-ink-900/60">
      {/* Brand */}
      <div className="flex items-center gap-2 px-5 py-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 shadow-soft">
          <Activity className="h-5 w-5 text-white" />
        </div>
        <div>
          <p className="text-sm font-semibold tracking-tight text-ink-900 dark:text-ink-50">
            Team Pulse
          </p>
          <p className="text-[11px] text-ink-500 dark:text-ink-400">Jira team analytics</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="mt-2 flex-1 px-3">
        {NAV.map(({ id, label, icon: Icon }) => {
          const active = route === id
          return (
            <button
              key={id}
              type="button"
              onClick={() => setRoute(id)}
              className={cn(
                'mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition',
                active
                  ? 'bg-brand-50 text-brand-700 shadow-sm dark:bg-brand-500/10 dark:text-brand-300'
                  : 'text-ink-600 hover:bg-ink-100 hover:text-ink-900 dark:text-ink-300 dark:hover:bg-ink-800 dark:hover:text-ink-50'
              )}
            >
              <Icon className={cn('h-4 w-4', active && 'text-brand-600 dark:text-brand-400')} />
              {label}
            </button>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-ink-200 p-3 dark:border-ink-800">
        <button
          type="button"
          disabled={!canRefresh || loading}
          onClick={() => refresh()}
          className="mb-2 flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-3 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-60"
        >
          <RefreshCw className={cn('h-4 w-4', loading && 'animate-spin')} />
          {loading ? 'Refreshing…' : 'Refresh data'}
        </button>
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={cycleTheme}
            className="flex items-center gap-2 rounded-xl px-2 py-1.5 text-xs text-ink-600 transition hover:bg-ink-100 dark:text-ink-300 dark:hover:bg-ink-800"
            title="Toggle theme"
          >
            <ThemeIcon className="h-4 w-4" />
            <span className="capitalize">{theme}</span>
          </button>
          {analytics?.generatedAt && (
            <span className="text-[10px] text-ink-400">
              {new Date(analytics.generatedAt).toLocaleTimeString()}
            </span>
          )}
        </div>
      </div>
    </aside>
  )
}
