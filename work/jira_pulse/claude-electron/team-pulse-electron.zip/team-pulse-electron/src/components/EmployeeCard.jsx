import React, { useState } from 'react'
import {
  ChevronDown,
  ChevronRight,
  Clock,
  MessageSquare,
  FileText,
  GitCommit,
  GitPullRequest,
  ExternalLink,
} from 'lucide-react'
import Card from './Card'
import StatusBadge from './StatusBadge'
import { cn } from '../utils/classNames'
import { formatRelative } from '../utils/date'

function Avatar({ name }) {
  const initials = (name || '??')
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('')
  return (
    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-brand-700 text-sm font-semibold text-white shadow-sm">
      {initials}
    </div>
  )
}

function IssueRow({ issue }) {
  const tone =
    issue.activityYesterday === 'YES'
      ? 'green'
      : issue.activityYesterday === 'PARTIAL'
        ? 'yellow'
        : 'gray'
  return (
    <div className="flex items-start gap-3 rounded-xl border border-ink-100 bg-ink-50/50 p-3 dark:border-ink-800 dark:bg-ink-950/50">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <a
            href={issue.url || '#'}
            target="_blank"
            rel="noreferrer"
            className="truncate text-sm font-medium text-ink-900 hover:text-brand-600 dark:text-ink-100 dark:hover:text-brand-400"
          >
            {issue.key} · {issue.summary}
          </a>
          {issue.url && <ExternalLink className="h-3 w-3 text-ink-400" />}
        </div>
        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-ink-500 dark:text-ink-400">
          <StatusBadge tone="blue" label={issue.status} />
          <StatusBadge tone={tone} label={`Activity: ${issue.activityYesterday}`} />
          {issue.isStale && <StatusBadge preset="stale" />}
          {issue.isInProgress && (
            <span>
              {issue.daysInProgress}d in progress
            </span>
          )}
          {issue.loggedYesterdaySeconds > 0 && (
            <span className="text-emerald-600 dark:text-emerald-400">
              +{issue.loggedYesterdayPretty} yesterday
            </span>
          )}
          {issue.lastActivityAt && (
            <span>· last {formatRelative(issue.lastActivityAt)}</span>
          )}
        </div>
      </div>
    </div>
  )
}

export default function EmployeeCard({ employee, defaultExpanded = false }) {
  const [expanded, setExpanded] = useState(defaultExpanded)

  const confluence = employee.confluenceActivity || []
  const commits = employee.bitbucket?.commits || []
  const prs = employee.bitbucket?.pullRequests || []
  const hasExternal = confluence.length + commits.length + prs.length > 0

  return (
    <Card className="animate-fade-in">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="flex w-full items-start gap-4 p-5 text-left"
      >
        <Avatar name={employee.displayName} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="truncate text-base font-semibold text-ink-900 dark:text-ink-50">
              {employee.displayName}
            </h3>
            <StatusBadge
              tone={employee.wasActiveYesterday ? 'green' : 'gray'}
              label={employee.wasActiveYesterday ? 'Active yesterday' : 'No activity'}
            />
            {employee.staleIssuesCount > 0 && (
              <StatusBadge tone="red" label={`${employee.staleIssuesCount} stale`} />
            )}
          </div>

          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Metric label="In progress" value={employee.totalIssuesInProgress} />
            <Metric label="Logged yesterday" value={employee.totalLoggedYesterdayPretty} />
            <Metric label="Inactive issues" value={employee.inactiveIssuesCount} />
            <Metric label="Last activity" value={formatRelative(employee.lastActivityAt)} />
          </div>
        </div>
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-ink-400 transition group-hover:bg-ink-100 dark:group-hover:bg-ink-800">
          {expanded ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
        </div>
      </button>

      {expanded && (
        <div className="animate-fade-in border-t border-ink-100 px-5 pb-5 pt-4 dark:border-ink-800">
          {/* Issues */}
          <Section title="Issues" count={employee.issues.length}>
            {employee.issues.length === 0 ? (
              <Empty>No assigned issues</Empty>
            ) : (
              <div className="space-y-2">
                {employee.issues.map((i) => (
                  <IssueRow key={i.key} issue={i} />
                ))}
              </div>
            )}
          </Section>

          {/* Comments yesterday */}
          <Section
            title="Comments yesterday"
            icon={MessageSquare}
            count={employee.commentsYesterday.length}
          >
            {employee.commentsYesterday.length === 0 ? (
              <Empty>No comments posted yesterday</Empty>
            ) : (
              <div className="space-y-2">
                {employee.commentsYesterday.map((c, idx) => (
                  <div
                    key={`${c.issueKey}-${idx}`}
                    className="rounded-xl border border-ink-100 bg-ink-50/50 p-3 text-sm dark:border-ink-800 dark:bg-ink-950/50"
                  >
                    <div className="flex items-center justify-between gap-2 text-[11px] text-ink-500 dark:text-ink-400">
                      <span className="font-medium text-ink-700 dark:text-ink-200">
                        {c.issueKey} · {c.issueSummary}
                      </span>
                      <span>{formatRelative(c.createdAt)}</span>
                    </div>
                    <p className="mt-1.5 whitespace-pre-wrap text-ink-700 dark:text-ink-200">
                      {c.commentText}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </Section>

          {/* Confluence */}
          {confluence.length > 0 && (
            <Section title="Confluence" icon={FileText} count={confluence.length}>
              <ul className="space-y-1.5 text-sm">
                {confluence.map((p, idx) => (
                  <li key={idx}>
                    <a
                      href={p.url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-2 text-ink-700 hover:text-brand-600 dark:text-ink-200 dark:hover:text-brand-400"
                    >
                      <span className="truncate">{p.pageTitle}</span>
                      <span className="text-[11px] text-ink-400">
                        {formatRelative(p.updatedAt)}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </Section>
          )}

          {/* Bitbucket */}
          {(commits.length > 0 || prs.length > 0) && (
            <Section title="Bitbucket">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-ink-500 dark:text-ink-400">
                    <GitCommit className="h-4 w-4" /> Commits ({commits.length})
                  </p>
                  {commits.length === 0 ? (
                    <Empty>—</Empty>
                  ) : (
                    <ul className="space-y-1 text-sm">
                      {commits.slice(0, 6).map((c) => (
                        <li key={c.hash} className="truncate">
                          <span className="font-mono text-xs text-ink-400">{c.displayId}</span>{' '}
                          <span className="text-ink-700 dark:text-ink-200">
                            {c.message?.split('\n')[0]}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div>
                  <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-ink-500 dark:text-ink-400">
                    <GitPullRequest className="h-4 w-4" /> Pull Requests ({prs.length})
                  </p>
                  {prs.length === 0 ? (
                    <Empty>—</Empty>
                  ) : (
                    <ul className="space-y-1 text-sm">
                      {prs.map((p) => (
                        <li key={p.id} className="truncate">
                          <a
                            href={p.url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-ink-700 hover:text-brand-600 dark:text-ink-200 dark:hover:text-brand-400"
                          >
                            #{p.id} · {p.title}
                          </a>{' '}
                          <StatusBadge
                            tone={p.state === 'MERGED' ? 'green' : p.state === 'DECLINED' ? 'red' : 'blue'}
                            label={p.state}
                            className="ml-1"
                          />
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </Section>
          )}

          {!hasExternal && (
            <p className="mt-4 text-center text-xs text-ink-400">
              No Confluence / Bitbucket activity attached to this user.
            </p>
          )}
        </div>
      )}
    </Card>
  )
}

function Metric({ label, value }) {
  return (
    <div className="min-w-0">
      <p className="text-[10px] font-medium uppercase tracking-wide text-ink-400">{label}</p>
      <p className="mt-0.5 truncate text-sm font-semibold text-ink-900 dark:text-ink-100">
        {value}
      </p>
    </div>
  )
}

function Section({ title, icon: Icon, count, children }) {
  return (
    <div className="mt-5 first:mt-0">
      <div className="mb-2 flex items-center justify-between">
        <h4 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-ink-500 dark:text-ink-400">
          {Icon && <Icon className="h-3.5 w-3.5" />}
          {title}
          {typeof count === 'number' && (
            <span className="rounded-full bg-ink-100 px-1.5 py-0.5 text-[10px] font-medium text-ink-600 dark:bg-ink-800 dark:text-ink-300">
              {count}
            </span>
          )}
        </h4>
      </div>
      {children}
    </div>
  )
}

function Empty({ children }) {
  return <p className="text-xs italic text-ink-400">{children}</p>
}
