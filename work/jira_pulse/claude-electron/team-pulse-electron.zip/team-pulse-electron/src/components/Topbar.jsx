import React from 'react'
import { RefreshCw, AlertCircle } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { cn } from '../utils/classNames'

const TITLES = {
  dashboard: 'Dashboard',
  employees: 'Employees',
  insights: 'Insights',
  sprint: 'Sprint',
  settings: 'Settings',
}

export default function Topbar() {
  const { route, loading, progress, error, analytics, refresh, config } = useApp()
  const canRefresh = !!(config.jiraBaseUrl && config.jiraToken && config.jqlQuery)

  return (
    <header className="sticky top-0 z-20 border-b border-ink-200 bg-white/70 px-8 py-4 backdrop-blur-md dark:border-ink-800 dark:bg-ink-950/60">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold tracking-tight text-ink-900 dark:text-ink-50">
            {TITLES[route] || 'Team Pulse'}
          </h1>
          {analytics?.generatedAt && (
            <p className="text-xs text-ink-500 dark:text-ink-400">
              Snapshot {new Date(analytics.generatedAt).toLocaleString()}
            </p>
          )}
        </div>
        <div className="flex items-center gap-3">
          {loading && progress.phase && (
            <div className="flex items-center gap-2 text-xs text-ink-500 dark:text-ink-400">
              <RefreshCw className="h-4 w-4 animate-spin" />
              <span>{progress.phase}</span>
              {progress.total > 0 && (
                <span className="tabular-nums text-ink-400">
                  {progress.done}/{progress.total}
                </span>
              )}
            </div>
          )}
          <button
            type="button"
            onClick={() => refresh()}
            disabled={!canRefresh || loading}
            className="tp-button"
          >
            <RefreshCw className={cn('h-4 w-4', loading && 'animate-spin')} />
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="mt-3 flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-800 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-200">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </header>
  )
}
