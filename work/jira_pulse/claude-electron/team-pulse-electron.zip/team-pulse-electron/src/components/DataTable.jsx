import React, { useMemo, useState } from 'react'
import { ArrowUpDown, ArrowUp, ArrowDown, Search } from 'lucide-react'
import { cn } from '../utils/classNames'

/**
 * Lightweight, dependency-free data table with sorting + filtering.
 * columns: [{ key, label, render?, sortable?, className? }]
 */
export default function DataTable({
  columns,
  rows,
  initialSort,
  searchKeys,
  searchPlaceholder = 'Search…',
  emptyMessage = 'No results',
  stickyHeader = true,
}) {
  const [sort, setSort] = useState(initialSort || { key: null, dir: 'asc' })
  const [query, setQuery] = useState('')

  const filtered = useMemo(() => {
    let r = rows
    if (query && searchKeys?.length) {
      const q = query.toLowerCase()
      r = r.filter((row) =>
        searchKeys.some((k) => String(row[k] ?? '').toLowerCase().includes(q))
      )
    }
    if (sort.key) {
      r = [...r].sort((a, b) => {
        const av = a[sort.key]
        const bv = b[sort.key]
        if (av === bv) return 0
        if (av == null) return 1
        if (bv == null) return -1
        if (typeof av === 'number' && typeof bv === 'number') {
          return sort.dir === 'asc' ? av - bv : bv - av
        }
        return sort.dir === 'asc'
          ? String(av).localeCompare(String(bv))
          : String(bv).localeCompare(String(av))
      })
    }
    return r
  }, [rows, query, sort, searchKeys])

  const toggleSort = (key) => {
    setSort((s) => {
      if (s.key !== key) return { key, dir: 'asc' }
      if (s.dir === 'asc') return { key, dir: 'desc' }
      return { key: null, dir: 'asc' }
    })
  }

  return (
    <div className="space-y-3">
      {searchKeys?.length > 0 && (
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input
            className="tp-input pl-9"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={searchPlaceholder}
          />
        </div>
      )}
      <div className="overflow-auto rounded-2xl border border-ink-200 bg-white shadow-card dark:border-ink-800 dark:bg-ink-900">
        <table className="min-w-full text-sm">
          <thead
            className={cn(
              'bg-ink-50 text-left text-[11px] font-semibold uppercase tracking-wide text-ink-500 dark:bg-ink-900/60 dark:text-ink-400',
              stickyHeader && 'sticky top-0 z-10'
            )}
          >
            <tr>
              {columns.map((col) => {
                const sorted = sort.key === col.key
                const Icon = !sorted ? ArrowUpDown : sort.dir === 'asc' ? ArrowUp : ArrowDown
                return (
                  <th
                    key={col.key}
                    className={cn(
                      'border-b border-ink-200 px-4 py-2.5 dark:border-ink-800',
                      col.className
                    )}
                  >
                    {col.sortable ? (
                      <button
                        type="button"
                        onClick={() => toggleSort(col.key)}
                        className={cn(
                          'inline-flex items-center gap-1 hover:text-ink-900 dark:hover:text-ink-100',
                          sorted && 'text-ink-900 dark:text-ink-100'
                        )}
                      >
                        {col.label}
                        <Icon className="h-3 w-3" />
                      </button>
                    ) : (
                      col.label
                    )}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length}
                  className="px-4 py-10 text-center text-sm italic text-ink-400"
                >
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              filtered.map((row, idx) => (
                <tr
                  key={row.id ?? row.key ?? idx}
                  className="border-b border-ink-100 last:border-0 hover:bg-ink-50/70 dark:border-ink-800 dark:hover:bg-ink-800/40"
                >
                  {columns.map((col) => (
                    <td
                      key={col.key}
                      className={cn('px-4 py-3 align-middle', col.className)}
                    >
                      {col.render ? col.render(row) : row[col.key]}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <p className="text-[11px] text-ink-400">
        {filtered.length} of {rows.length} rows
      </p>
    </div>
  )
}
