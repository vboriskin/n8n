import React, { useMemo, useState } from 'react'
import { CheckCircle2 } from 'lucide-react'
import { useApp } from '../context/AppContext'
import InsightBanner from '../components/InsightBanner'
import EmptyState from '../components/EmptyState'
import { cn } from '../utils/classNames'

const SCOPES = ['all', 'team', 'employee', 'issue']
const LEVELS = ['all', 'critical', 'warning', 'info']

export default function Insights() {
  const { analytics } = useApp()
  const [scope, setScope] = useState('all')
  const [level, setLevel] = useState('all')

  const filtered = useMemo(() => {
    if (!analytics) return []
    return analytics.insights.filter(
      (i) => (scope === 'all' || i.scope === scope) && (level === 'all' || i.level === level)
    )
  }, [analytics, scope, level])

  if (!analytics) {
    return <EmptyState title="No data yet" description="Pull a snapshot first." />
  }

  if (analytics.insights.length === 0) {
    return (
      <EmptyState
        icon={CheckCircle2}
        title="All clear"
        description="No issues detected — great work."
      />
    )
  }

  return (
    <div className="space-y-5">
      <div className="tp-sticky-header flex flex-wrap items-center gap-3">
        <Pills value={scope} onChange={setScope} options={SCOPES} label="Scope" />
        <Pills value={level} onChange={setLevel} options={LEVELS} label="Level" />
        <span className="ml-auto text-[11px] text-ink-400">
          {filtered.length} of {analytics.insights.length} signals
        </span>
      </div>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {filtered.map((ins, idx) => (
          <InsightBanner key={idx} insight={ins} />
        ))}
      </div>
    </div>
  )
}

function Pills({ value, onChange, options, label }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-[11px] font-medium uppercase tracking-wide text-ink-400">
        {label}
      </span>
      <div className="flex gap-1 rounded-xl border border-ink-200 bg-white p-1 text-xs dark:border-ink-800 dark:bg-ink-900">
        {options.map((o) => (
          <button
            key={o}
            type="button"
            onClick={() => onChange(o)}
            className={cn(
              'rounded-lg px-2.5 py-1 font-medium capitalize transition',
              value === o
                ? 'bg-brand-600 text-white shadow-sm'
                : 'text-ink-600 hover:bg-ink-100 dark:text-ink-300 dark:hover:bg-ink-800'
            )}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  )
}
