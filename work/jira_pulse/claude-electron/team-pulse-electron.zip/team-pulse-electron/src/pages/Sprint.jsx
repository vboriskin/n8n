import React from 'react'
import { Target, CheckCircle2 } from 'lucide-react'
import { useApp } from '../context/AppContext'
import Card, { CardBody, CardHeader } from '../components/Card'
import DataTable from '../components/DataTable'
import EmptyState from '../components/EmptyState'
import StatusBadge from '../components/StatusBadge'

export default function Sprint() {
  const { analytics } = useApp()

  if (!analytics) {
    return <EmptyState title="No data yet" description="Pull a snapshot first." />
  }

  const rows = analytics.sprintNotStarted
  const totalInProgress = analytics.summary.totalIssuesInProgress

  const columns = [
    {
      key: 'key',
      label: 'Key',
      sortable: true,
      render: (r) => (
        <span className="font-mono text-xs text-ink-700 dark:text-ink-200">{r.key}</span>
      ),
    },
    {
      key: 'summary',
      label: 'Summary',
      sortable: true,
      render: (r) => <span className="text-sm">{r.summary}</span>,
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (r) => <StatusBadge tone="yellow" label={r.status} />,
    },
    {
      key: 'assignee',
      label: 'Assignee',
      sortable: true,
    },
    {
      key: 'priority',
      label: 'Priority',
      sortable: true,
      render: (r) => r.priority || '—',
    },
  ]

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-500">
            Sprint tasks not started
          </p>
          <p className="mt-2 text-3xl font-semibold text-ink-900 dark:text-ink-50">
            {rows.length}
          </p>
        </Card>
        <Card className="p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-500">
            In progress
          </p>
          <p className="mt-2 text-3xl font-semibold text-ink-900 dark:text-ink-50">
            {totalInProgress}
          </p>
        </Card>
        <Card className="p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-500">
            Ratio
          </p>
          <p className="mt-2 text-3xl font-semibold text-ink-900 dark:text-ink-50">
            {totalInProgress + rows.length > 0
              ? `${Math.round((totalInProgress / (totalInProgress + rows.length)) * 100)}%`
              : '—'}
            <span className="ml-2 text-sm font-normal text-ink-500">started</span>
          </p>
        </Card>
      </div>

      <Card>
        <CardHeader
          title="Not started yet"
          subtitle="Active sprint issues that are still in To Do / backlog"
          right={<Target className="h-4 w-4 text-ink-400" />}
        />
        <CardBody>
          {rows.length === 0 ? (
            <div className="flex flex-col items-center py-8 text-center">
              <CheckCircle2 className="mb-3 h-8 w-8 text-emerald-500" />
              <p className="text-sm font-medium text-ink-900 dark:text-ink-100">
                Everything in the sprint is started.
              </p>
              <p className="text-xs text-ink-500">Nice work team.</p>
            </div>
          ) : (
            <DataTable
              columns={columns}
              rows={rows}
              searchKeys={['key', 'summary', 'assignee', 'status']}
              searchPlaceholder="Search sprint items…"
              initialSort={{ key: 'assignee', dir: 'asc' }}
            />
          )}
        </CardBody>
      </Card>
    </div>
  )
}
