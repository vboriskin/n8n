import React from 'react'
import {
  Users,
  Activity,
  ListChecks,
  Clock,
  AlertTriangle,
  Target,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react'
import { useApp } from '../context/AppContext'
import StatCard from '../components/StatCard'
import Card, { CardBody, CardHeader } from '../components/Card'
import InsightBanner from '../components/InsightBanner'
import EmptyState from '../components/EmptyState'
import StatusBadge from '../components/StatusBadge'
import { formatRelative } from '../utils/date'

export default function Dashboard() {
  const { analytics, loading, config, refresh, setRoute } = useApp()

  if (!analytics) {
    if (!config.jiraBaseUrl || !config.jiraToken) {
      return (
        <EmptyState
          icon={Activity}
          title="Connect your Jira instance"
          description="Add your Jira base URL, token, and JQL filter in Settings to get started."
          action={
            <button className="tp-button" onClick={() => setRoute('settings')}>
              Go to Settings
            </button>
          }
        />
      )
    }
    return (
      <EmptyState
        icon={TrendingUp}
        title={loading ? 'Crunching numbers…' : 'No snapshot yet'}
        description={loading ? 'First fetch in progress.' : 'Press Refresh to pull the latest data.'}
        action={
          !loading && (
            <button className="tp-button" onClick={() => refresh()}>
              Refresh now
            </button>
          )
        }
      />
    )
  }

  const s = analytics.summary
  const activePct =
    s.totalEmployees > 0 ? Math.round((s.activeEmployeesYesterday / s.totalEmployees) * 100) : 0
  const activityPct =
    s.totalIssuesInProgress > 0
      ? Math.round((s.issuesWithActivityYesterday / s.totalIssuesInProgress) * 100)
      : 0

  const topInsights = analytics.insights.slice(0, 3)
  const mostRecent = [...analytics.employees]
    .filter((e) => e.lastActivityAt)
    .sort((a, b) => new Date(b.lastActivityAt) - new Date(a.lastActivityAt))
    .slice(0, 5)

  const mostStale = [...analytics.issueMetrics]
    .filter((i) => i.isStale)
    .sort((a, b) => (b.daysSinceActivity || 0) - (a.daysSinceActivity || 0))
    .slice(0, 5)

  return (
    <div className="space-y-6">
      {/* Stat grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Team members"
          value={s.totalEmployees}
          hint={`${s.activeEmployeesYesterday} active yesterday (${activePct}%)`}
          icon={Users}
          tone="blue"
        />
        <StatCard
          label="In-progress issues"
          value={s.totalIssuesInProgress}
          hint={`${s.issuesWithActivityYesterday} with activity (${activityPct}%)`}
          icon={ListChecks}
          tone="neutral"
        />
        <StatCard
          label="Logged yesterday"
          value={s.totalLoggedYesterdayPretty}
          hint="Sum across all worklogs"
          icon={Clock}
          tone="green"
        />
        <StatCard
          label="Stale / not started"
          value={`${s.staleIssuesCount} / ${s.sprintNotStartedCount}`}
          hint="Needs attention"
          icon={AlertTriangle}
          tone={s.staleIssuesCount > 0 ? 'red' : 'yellow'}
        />
      </div>

      {/* Insights */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500 dark:text-ink-400">
            Top signals
          </h2>
          <button
            className="text-xs font-medium text-brand-600 hover:underline dark:text-brand-400"
            onClick={() => setRoute('insights')}
          >
            View all ({analytics.insights.length})
          </button>
        </div>
        {topInsights.length === 0 ? (
          <Card className="p-6 text-center text-sm text-ink-500 dark:text-ink-400">
            <CheckCircle2 className="mx-auto mb-2 h-6 w-6 text-emerald-500" />
            All clear — no team-level signals right now.
          </Card>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {topInsights.map((ins, idx) => (
              <InsightBanner key={idx} insight={ins} />
            ))}
          </div>
        )}
      </div>

      {/* Two-column: recent + stale */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Most recent activity"
            subtitle="People who touched Jira most recently"
            right={<Target className="h-4 w-4 text-ink-400" />}
          />
          <CardBody>
            {mostRecent.length === 0 ? (
              <p className="text-sm italic text-ink-400">No activity yet.</p>
            ) : (
              <ul className="divide-y divide-ink-100 dark:divide-ink-800">
                {mostRecent.map((e) => (
                  <li key={e.id} className="flex items-center justify-between gap-4 py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-ink-900 dark:text-ink-100">
                        {e.displayName}
                      </p>
                      <p className="text-xs text-ink-500 dark:text-ink-400">
                        {e.totalIssuesInProgress} in progress · {e.totalLoggedYesterdayPretty} yesterday
                      </p>
                    </div>
                    <span className="text-xs text-ink-500 dark:text-ink-400">
                      {formatRelative(e.lastActivityAt)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Most stale issues"
            subtitle={`No activity for > ${config.staleDaysThreshold} days`}
            right={<AlertTriangle className="h-4 w-4 text-rose-500" />}
          />
          <CardBody>
            {mostStale.length === 0 ? (
              <p className="text-sm italic text-ink-400">Nothing stale — nice job.</p>
            ) : (
              <ul className="space-y-2.5">
                {mostStale.map((i) => (
                  <li
                    key={i.key}
                    className="rounded-xl border border-ink-100 bg-ink-50/50 p-3 dark:border-ink-800 dark:bg-ink-950/50"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <a
                          href={i.url || '#'}
                          target="_blank"
                          rel="noreferrer"
                          className="truncate text-sm font-medium text-ink-900 hover:text-brand-600 dark:text-ink-100 dark:hover:text-brand-400"
                        >
                          {i.key} · {i.summary}
                        </a>
                        <p className="mt-1 text-xs text-ink-500 dark:text-ink-400">
                          {i.assigneeDisplay} · {i.daysSinceActivity ?? '?'}d no activity
                        </p>
                      </div>
                      <StatusBadge preset="stale" />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  )
}
