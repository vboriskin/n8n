import React, { useEffect, useState } from 'react'
import {
  Save,
  CheckCircle2,
  XCircle,
  Eye,
  EyeOff,
  Trash2,
  FlaskConical,
} from 'lucide-react'
import { useApp } from '../context/AppContext'
import Card, { CardBody, CardHeader } from '../components/Card'
import { clearCache } from '../store/cacheStore'
import * as jira from '../services/jiraService'
import * as confluence from '../services/confluenceService'
import * as bitbucket from '../services/bitbucketService'
import { cn } from '../utils/classNames'

export default function Settings() {
  const { config, updateConfig, refresh } = useApp()
  const [draft, setDraft] = useState(config)
  const [saved, setSaved] = useState(false)
  const [showTokens, setShowTokens] = useState(false)
  const [tests, setTests] = useState({ jira: null, confluence: null, bitbucket: null })
  const [testing, setTesting] = useState(false)

  useEffect(() => setDraft(config), [config])

  const set = (key, value) => setDraft((d) => ({ ...d, [key]: value }))
  const setStatuses = (value) =>
    set('statusesInProgress', value.split(',').map((s) => s.trim()).filter(Boolean))

  const save = async () => {
    await updateConfig(draft)
    setSaved(true)
    setTimeout(() => setSaved(false), 1500)
  }

  const saveAndRefresh = async () => {
    const next = await updateConfig(draft)
    setSaved(true)
    setTimeout(() => setSaved(false), 1500)
    refresh(next)
  }

  const runTests = async () => {
    setTesting(true)
    const results = { jira: null, confluence: null, bitbucket: null }
    if (draft.jiraBaseUrl && draft.jiraToken) {
      results.jira = await jira.testConnection({
        baseUrl: draft.jiraBaseUrl,
        token: draft.jiraToken,
      })
    }
    if (draft.confluenceBaseUrl && draft.confluenceToken) {
      results.confluence = await confluence.testConnection({
        baseUrl: draft.confluenceBaseUrl,
        token: draft.confluenceToken,
      })
    }
    if (draft.bitbucketBaseUrl && draft.bitbucketToken) {
      results.bitbucket = await bitbucket.testConnection({
        baseUrl: draft.bitbucketBaseUrl,
        token: draft.bitbucketToken,
      })
    }
    setTests(results)
    setTesting(false)
  }

  const Section = ({ title, subtitle, children }) => (
    <Card>
      <CardHeader title={title} subtitle={subtitle} />
      <CardBody>
        <div className="grid gap-4 md:grid-cols-2">{children}</div>
      </CardBody>
    </Card>
  )

  const Field = ({ label, children, full, hint }) => (
    <div className={cn(full && 'md:col-span-2')}>
      <label className="tp-label">{label}</label>
      {children}
      {hint && <p className="mt-1 text-[11px] text-ink-400">{hint}</p>}
    </div>
  )

  return (
    <div className="space-y-6">
      <Section
        title="Jira (required)"
        subtitle="Server/DC 8.20.x. Paste your Personal Access Token or a Basic credential."
      >
        <Field label="Base URL" full>
          <input
            className="tp-input"
            placeholder="https://jira.company.com"
            value={draft.jiraBaseUrl}
            onChange={(e) => set('jiraBaseUrl', e.target.value.trim())}
          />
        </Field>
        <Field
          label="Token"
          full
          hint="Prefix with 'Bearer' or 'Basic' to force that scheme; otherwise Bearer is used."
        >
          <TokenInput
            value={draft.jiraToken}
            onChange={(v) => set('jiraToken', v)}
            show={showTokens}
            onToggle={() => setShowTokens((v) => !v)}
          />
          <TestBadge result={tests.jira} label="Jira" />
        </Field>
        <Field label="JQL filter" full hint="Used as the master team query.">
          <input
            className="tp-input"
            placeholder="project = TEAM AND sprint in openSprints()"
            value={draft.jqlQuery}
            onChange={(e) => set('jqlQuery', e.target.value)}
          />
        </Field>
        <Field label="In-progress statuses (comma separated)">
          <input
            className="tp-input"
            placeholder="In Progress, In Review"
            value={(draft.statusesInProgress || []).join(', ')}
            onChange={(e) => setStatuses(e.target.value)}
          />
        </Field>
        <Field label="Stale threshold (days)">
          <input
            type="number"
            min={1}
            className="tp-input"
            value={draft.staleDaysThreshold}
            onChange={(e) => set('staleDaysThreshold', Math.max(1, Number(e.target.value) || 3))}
          />
        </Field>
      </Section>

      <Section title="Confluence (optional)" subtitle="Used for 'updated yesterday' page activity.">
        <Field label="Base URL" full>
          <input
            className="tp-input"
            placeholder="https://confluence.company.com"
            value={draft.confluenceBaseUrl}
            onChange={(e) => set('confluenceBaseUrl', e.target.value.trim())}
          />
        </Field>
        <Field label="Token" full>
          <TokenInput
            value={draft.confluenceToken}
            onChange={(v) => set('confluenceToken', v)}
            show={showTokens}
            onToggle={() => setShowTokens((v) => !v)}
          />
          <TestBadge result={tests.confluence} label="Confluence" />
        </Field>
      </Section>

      <Section
        title="Bitbucket (optional)"
        subtitle="Bitbucket Server — provide a project and repo to scope the activity feed."
      >
        <Field label="Base URL" full>
          <input
            className="tp-input"
            placeholder="https://bitbucket.company.com"
            value={draft.bitbucketBaseUrl}
            onChange={(e) => set('bitbucketBaseUrl', e.target.value.trim())}
          />
        </Field>
        <Field label="Token" full>
          <TokenInput
            value={draft.bitbucketToken}
            onChange={(v) => set('bitbucketToken', v)}
            show={showTokens}
            onToggle={() => setShowTokens((v) => !v)}
          />
          <TestBadge result={tests.bitbucket} label="Bitbucket" />
        </Field>
        <Field label="Project key">
          <input
            className="tp-input"
            placeholder="TEAM"
            value={draft.bitbucketProjectKey || ''}
            onChange={(e) => set('bitbucketProjectKey', e.target.value.trim())}
          />
        </Field>
        <Field label="Repo slug">
          <input
            className="tp-input"
            placeholder="backend"
            value={draft.bitbucketRepoSlug || ''}
            onChange={(e) => set('bitbucketRepoSlug', e.target.value.trim())}
          />
        </Field>
      </Section>

      {/* Actions */}
      <div className="sticky bottom-0 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-ink-200 bg-white/90 px-5 py-4 shadow-card backdrop-blur dark:border-ink-800 dark:bg-ink-900/90">
        <div className="flex items-center gap-3">
          <button type="button" className="tp-button" onClick={saveAndRefresh}>
            <Save className="h-4 w-4" /> Save & refresh
          </button>
          <button type="button" className="tp-button-secondary" onClick={save}>
            Save only
          </button>
          <button
            type="button"
            className="tp-button-secondary"
            onClick={runTests}
            disabled={testing}
          >
            <FlaskConical className={cn('h-4 w-4', testing && 'animate-pulse')} />
            {testing ? 'Testing…' : 'Test connections'}
          </button>
          <button
            type="button"
            className="tp-button-secondary"
            onClick={async () => {
              await clearCache()
              alert('Cache cleared.')
            }}
          >
            <Trash2 className="h-4 w-4" /> Clear cache
          </button>
        </div>
        {saved && (
          <span className="flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="h-4 w-4" /> Saved
          </span>
        )}
      </div>
    </div>
  )
}

function TokenInput({ value, onChange, show, onToggle }) {
  return (
    <div className="relative">
      <input
        className="tp-input pr-10 font-mono text-xs"
        type={show ? 'text' : 'password'}
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Bearer xxxxxxxxxxxx"
        spellCheck={false}
      />
      <button
        type="button"
        className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-ink-400 hover:bg-ink-100 dark:hover:bg-ink-800"
        onClick={onToggle}
        title={show ? 'Hide' : 'Show'}
      >
        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  )
}

function TestBadge({ result, label }) {
  if (!result) return null
  return (
    <div
      className={cn(
        'mt-2 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium',
        result.ok
          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400'
          : 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400'
      )}
    >
      {result.ok ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
      {label}: {result.ok ? `connected as ${result.user?.displayName || result.user?.name || 'user'}` : result.error}
    </div>
  )
}
