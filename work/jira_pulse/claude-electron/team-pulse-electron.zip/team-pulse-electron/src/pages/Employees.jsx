import React, { useMemo, useState } from 'react'
import { Search, Filter } from 'lucide-react'
import { useApp } from '../context/AppContext'
import EmployeeCard from '../components/EmployeeCard'
import EmptyState from '../components/EmptyState'
import { cn } from '../utils/classNames'

const FILTERS = [
  { id: 'all', label: 'All' },
  { id: 'active', label: 'Active yesterday' },
  { id: 'inactive', label: 'No activity' },
  { id: 'stale', label: 'Has stale issues' },
  { id: 'overloaded', label: 'Overloaded (>5)' },
]

const SORTS = [
  { id: 'name', label: 'Name' },
  { id: 'inProgress', label: 'In progress' },
  { id: 'stale', label: 'Stale count' },
  { id: 'logged', label: 'Logged yesterday' },
  { id: 'lastActivity', label: 'Last activity' },
]

export default function Employees() {
  const { analytics } = useApp()
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState('all')
  const [sort, setSort] = useState('name')

  const employees = useMemo(() => {
    if (!analytics) return []
    let list = analytics.employees.slice()

    if (q.trim()) {
      const s = q.toLowerCase()
      list = list.filter((e) => e.displayName.toLowerCase().includes(s))
    }

    list = list.filter((e) => {
      if (filter === 'active') return e.wasActiveYesterday
      if (filter === 'inactive') return !e.wasActiveYesterday
      if (filter === 'stale') return e.staleIssuesCount > 0
      if (filter === 'overloaded') return e.totalIssuesInProgress > 5
      return true
    })

    list.sort((a, b) => {
      switch (sort) {
        case 'inProgress':
          return b.totalIssuesInProgress - a.totalIssuesInProgress
        case 'stale':
          return b.staleIssuesCount - a.staleIssuesCount
        case 'logged':
          return (b.totalLoggedYesterdaySeconds || 0) - (a.totalLoggedYesterdaySeconds || 0)
        case 'lastActivity':
          return (
            new Date(b.lastActivityAt || 0).getTime() -
            new Date(a.lastActivityAt || 0).getTime()
          )
        case 'name':
        default:
          return a.displayName.localeCompare(b.displayName)
      }
    })

    return list
  }, [analytics, q, filter, sort])

  if (!analytics) {
    return <EmptyState title="No data yet" description="Pull a snapshot first." />
  }

  return (
    <div className="space-y-4">
      {/* Sticky toolbar */}
      <div className="tp-sticky-header">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[240px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input
              className="tp-input pl-9"
              placeholder="Search team members…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-1 rounded-xl border border-ink-200 bg-white p-1 text-xs dark:border-ink-800 dark:bg-ink-900">
            <Filter className="ml-1.5 h-3.5 w-3.5 text-ink-400" />
            {FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                className={cn(
                  'rounded-lg px-2.5 py-1 font-medium transition',
                  filter === f.id
                    ? 'bg-brand-600 text-white shadow-sm'
                    : 'text-ink-600 hover:bg-ink-100 dark:text-ink-300 dark:hover:bg-ink-800'
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          <select
            className="tp-input w-auto"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            {SORTS.map((s) => (
              <option key={s.id} value={s.id}>
                Sort: {s.label}
              </option>
            ))}
          </select>
        </div>
        <p className="mt-2 text-[11px] text-ink-400">
          Showing {employees.length} of {analytics.employees.length} members
        </p>
      </div>

      {/* Cards */}
      {employees.length === 0 ? (
        <EmptyState title="No matches" description="Try a different filter or search term." />
      ) : (
        <div className="grid gap-4 xl:grid-cols-2">
          {employees.map((e) => (
            <EmployeeCard key={e.id} employee={e} />
          ))}
        </div>
      )}
    </div>
  )
}
