import React from 'react'
import { AppProvider, useApp } from './context/AppContext'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import Dashboard from './pages/Dashboard'
import Employees from './pages/Employees'
import Insights from './pages/Insights'
import Sprint from './pages/Sprint'
import Settings from './pages/Settings'

function Shell() {
  const { route } = useApp()
  const Page =
    route === 'dashboard' ? Dashboard :
    route === 'employees' ? Employees :
    route === 'insights'  ? Insights  :
    route === 'sprint'    ? Sprint    :
    Settings

  return (
    <div className="flex h-full">
      <Sidebar />
      <main className="flex h-full min-w-0 flex-1 flex-col">
        <Topbar />
        <div className="flex-1 overflow-auto px-8 py-6">
          <Page />
        </div>
      </main>
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  )
}
