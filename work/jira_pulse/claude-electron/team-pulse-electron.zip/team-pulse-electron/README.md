# Team Pulse

A local Electron desktop dashboard for engineering managers. Connects to
**Jira Server/DC 8.20.x** (required) and optionally **Confluence** and
**Bitbucket Server**, and surfaces per-employee activity for yesterday plus
team-level insights.

Everything runs locally — no external server. Config and the last snapshot
are stored as JSON in your OS user-data directory.

## Stack

- **Electron** — single-click desktop app
- **React + Vite** — renderer
- **TailwindCSS** — styling (light + dark mode)
- **axios** — HTTP (runs in the main process to bypass browser CORS)
- **lucide-react** — icons

## Getting started

```bash
npm install
npm run dev
```

This launches Vite on `http://localhost:5173` and an Electron window pointing
at it (hot reload enabled).

To produce a distributable:

```bash
npm run build
```

Binaries land in `./release/` courtesy of `electron-builder`.

## Configuration

Open **Settings** in the sidebar and fill in:

| Field | Notes |
| --- | --- |
| `jiraBaseUrl` | e.g. `https://jira.company.com` |
| `jiraToken` | PAT or Basic. Raw tokens default to `Bearer`. |
| `jqlQuery` | The master team filter, e.g. `project = TEAM AND sprint in openSprints()` |
| `statusesInProgress` | Comma-separated list of statuses treated as "in progress". |
| `staleDaysThreshold` | Default `3`. |
| `confluenceBaseUrl` / `confluenceToken` | Optional — enables page-activity section. |
| `bitbucketBaseUrl` / `bitbucketToken` / `bitbucketProjectKey` / `bitbucketRepoSlug` | Optional — enables commit & PR section. |

Press **Save & refresh** to pull a snapshot. Use **Test connections** to
validate credentials before pulling.

## What it computes

### Per-issue

- `isInProgress` — status matches the config list
- `daysInProgress` — days since the most recent transition into an
  in-progress status (via changelog)
- `lastUpdated`, `lastActivityAt` — max across updates, worklogs, comments,
  changelog entries
- `activityYesterday` — `YES` if there's a worklog yesterday, `PARTIAL` if
  there's a comment/changelog change yesterday, else `NO`
- `isStale` — in progress AND no activity for more than the threshold
- `hasCommentYesterday` — by the assignee

### Per-employee

- Totals of in-progress, inactive, stale issues
- `totalLoggedYesterday` — sum of assignee worklogs whose `started` falls
  into yesterday
- `commentsYesterday` — full list of yesterday's comments from that user
  `[ { issueKey, issueSummary, commentText, createdAt } ]`
- Attached Confluence pages updated yesterday (if enabled)
- Attached Bitbucket commits + PR activity yesterday (if enabled)

### Team summary

- `totalEmployees`, `activeEmployeesYesterday`
- `totalIssuesInProgress`, `issuesWithActivityYesterday`
- `totalLoggedYesterday`, `staleIssuesCount`
- `sprintNotStartedCount`

### Insights

Structured signals at team / employee / issue scope with `level`
(`info | warning | critical`), `message`, `reason`, and `recommendation`.
Rules include:

- Many in-progress, low activity
- Many stale issues
- Sprint tasks not started
- Workload imbalance
- Too many issues per employee (> 5)
- No activity yesterday
- Many stale issues per person
- Many issues but no worklogs

## Architecture

```
electron/
  main.js          # window + IPC handlers (config, cache, http proxy)
  preload.js       # exposes window.api to the renderer
src/
  main.jsx         # React entry
  App.jsx          # shell: sidebar + topbar + page
  index.css        # Tailwind + form primitives
  context/
    AppContext.jsx # global state, orchestrates fetch + analytics
  components/
    Card.jsx
    StatCard.jsx
    StatusBadge.jsx
    InsightBanner.jsx
    EmployeeCard.jsx
    DataTable.jsx
    Sidebar.jsx
    Topbar.jsx
    EmptyState.jsx
  pages/
    Dashboard.jsx
    Employees.jsx
    Insights.jsx
    Sprint.jsx
    Settings.jsx
  services/
    httpClient.js       # wraps the preload IPC proxy
    jiraService.js      # /rest/api/2/{search,issue,worklog,comment}
    confluenceService.js # /rest/api/content/search (CQL)
    bitbucketService.js # /rest/api/1.0 commits & pull-requests
    analyticsService.js # pure metrics + insights engine
  store/
    configStore.js   # loadConfig / saveConfig (JSON via main, or localStorage fallback)
    cacheStore.js    # loadCache / saveCache
  utils/
    date.js
    classNames.js
```

The renderer never makes network calls directly — instead it calls
`window.api.request(...)`, which proxies through `axios` in the main process.
This avoids browser CORS and keeps tokens from leaking into renderer memory
beyond their purpose.

## Performance

- Jira `/search` is paginated (100 per page, cap at 2000 issues).
- Each issue's worklog + comments are fetched in **parallel** (concurrency 6).
- The last analytics result is persisted, so the UI renders from cache on
  startup while a fresh pull happens in the background.
- Confluence and Bitbucket are optional and run in parallel once the Jira
  data is in hand.

## Light / dark mode

Toggle in the sidebar footer. The choice (`light | dark | system`) is
persisted with the config.

## License

MIT
