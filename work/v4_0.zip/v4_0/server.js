// Static server + LLM proxy (Node built-ins only)
// Usage: node server.js [port]
'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = parseInt(process.argv[2], 10) || 8080;
const ROOT = __dirname;
const DEFAULT_GIGACHAT_BASE = process.env.GIGACHAT_API_BASE || 'https://gigachat.devices.sberbank.ru/api/v1';
const SERVER_ACCESS_TOKEN = process.env.GIGACHAT_ACCESS_TOKEN || '';
const MAX_BODY = 2 * 1024 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.csv': 'text/csv; charset=utf-8',
};

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

function writeJson(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', ...CORS_HEADERS });
  res.end(JSON.stringify(data));
}

function readBody(req, limitBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limitBytes) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
    req.on('error', reject);
  });
}

function buildChatEndpoint(base) {
  const normalized = String(base || DEFAULT_GIGACHAT_BASE).replace(/\/+$/, '');
  if (normalized.endsWith('/chat/completions')) return normalized;
  if (normalized.endsWith('/v1')) return `${normalized}/chat/completions`;
  if (normalized.endsWith('/api')) return `${normalized}/v1/chat/completions`;
  return `${normalized}/chat/completions`;
}

function forwardSSEOrChunk(upstreamRes, clientRes) {
  clientRes.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
    ...CORS_HEADERS,
  });
  clientRes.write('event: meta\ndata: {"ok":true}\n\n');
  upstreamRes.on('data', (chunk) => {
    clientRes.write(chunk);
  });
  upstreamRes.on('end', () => {
    clientRes.write('data: [DONE]\n\n');
    clientRes.end();
  });
}

function proxyChat(req, res) {
  readBody(req, MAX_BODY).then((raw) => {
    const body = raw ? JSON.parse(raw) : {};
    const token = String(body.token || '').trim() || SERVER_ACCESS_TOKEN;
    const clientId = String(body.clientId || '').trim();
    const clientSecret = String(body.clientSecret || '').trim();

    if (clientId && clientSecret && !token) {
      // TODO: OAuth/token exchange from client credentials before chat call.
      writeJson(res, 501, { error: 'OAuth token exchange is not implemented yet (TODO).' });
      return;
    }
    if (!token) {
      writeJson(res, 400, { error: 'Missing access token. Provide token in settings or via server env GIGACHAT_ACCESS_TOKEN.' });
      return;
    }

    const endpoint = buildChatEndpoint(body.apiBaseUrl || DEFAULT_GIGACHAT_BASE);
    const endpointUrl = new URL(endpoint);
    const payload = {
      model: body.model || 'GigaChat-2',
      messages: Array.isArray(body.messages) ? body.messages : [],
      stream: body.stream !== false,
      temperature: Number.isFinite(Number(body.temperature)) ? Number(body.temperature) : 0.2,
      max_tokens: Number.isFinite(Number(body.max_tokens)) ? Number(body.max_tokens) : 900,
    };
    const payloadRaw = JSON.stringify(payload);

    const transport = endpointUrl.protocol === 'http:' ? http : https;
    const upstreamReq = transport.request({
      protocol: endpointUrl.protocol,
      hostname: endpointUrl.hostname,
      port: endpointUrl.port || (endpointUrl.protocol === 'http:' ? 80 : 443),
      path: endpointUrl.pathname + endpointUrl.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        Accept: 'text/event-stream, application/json',
        'Content-Length': Buffer.byteLength(payloadRaw),
      },
    }, (upstreamRes) => {
      const status = upstreamRes.statusCode || 500;
      const upstreamType = (upstreamRes.headers['content-type'] || '').toLowerCase();

      if (status >= 400) {
        const errChunks = [];
        upstreamRes.on('data', (chunk) => errChunks.push(chunk));
        upstreamRes.on('end', () => {
          const errText = Buffer.concat(errChunks).toString('utf-8');
          const parsed = (() => { try { return JSON.parse(errText); } catch (_) { return null; } })();
          writeJson(res, status, {
            error: 'GigaChat upstream error',
            status,
            details: parsed || errText || 'Unknown upstream error',
          });
        });
        return;
      }

      if (payload.stream) {
        if (upstreamType.includes('text/event-stream') || upstreamType.includes('stream') || upstreamType.includes('json')) {
          forwardSSEOrChunk(upstreamRes, res);
        } else {
          // Fallback: non-streaming body -> emit as single SSE chunk.
          const chunks = [];
          upstreamRes.on('data', (chunk) => chunks.push(chunk));
          upstreamRes.on('end', () => {
            const text = Buffer.concat(chunks).toString('utf-8');
            res.writeHead(200, {
              'Content-Type': 'text/event-stream; charset=utf-8',
              'Cache-Control': 'no-cache, no-transform',
              Connection: 'keep-alive',
              ...CORS_HEADERS,
            });
            res.write(`data: ${text}\n\n`);
            res.write('data: [DONE]\n\n');
            res.end();
          });
        }
      } else {
        res.writeHead(200, { 'Content-Type': upstreamType || 'application/json; charset=utf-8' });
        upstreamRes.pipe(res);
      }
    });

    req.on('close', () => {
      if (!res.writableEnded) upstreamReq.destroy(new Error('Client disconnected'));
    });

    upstreamReq.on('error', (err) => {
      if (res.writableEnded) return;
      writeJson(res, 502, { error: 'Proxy request failed', details: String(err && err.message ? err.message : err) });
    });

    upstreamReq.write(payloadRaw);
    upstreamReq.end();
  }).catch((err) => {
    writeJson(res, /Payload too large/.test(String(err)) ? 413 : 400, {
      error: 'Invalid request body',
      details: String(err && err.message ? err.message : err),
    });
  });
}

function serveStatic(req, res) {
  let urlPath = req.url.split('?')[0];
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.join(ROOT, urlPath);

  if (!filePath.startsWith(ROOT)) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Forbidden');
    return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(`Not Found: ${urlPath}`);
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Server Error');
      }
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, CORS_HEADERS);
    res.end();
    return;
  }
  if (req.method === 'POST' && req.url.split('?')[0] === '/api/llm/chat') {
    proxyChat(req, res);
    return;
  }
  serveStatic(req, res);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`Q2 Plan Analyzer — http://localhost:${PORT}`);
  console.log('Ctrl+C to stop');
});
