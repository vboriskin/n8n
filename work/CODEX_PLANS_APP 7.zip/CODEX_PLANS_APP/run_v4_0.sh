#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${ROOT_DIR}/v4_0"
PORT="${1:-8080}"

exec "${APP_DIR}/start.sh" "${PORT}"
