'use strict';
/* ============================================================
   Q2 PLAN ANALYZER — app.js  (v3)
   ============================================================ */

// ============================================================
// CONSTANTS
// ============================================================
const STORAGE_KEY = 'q2_plan_v3';
const SETTINGS_KEY = 'q2_settings_v3';

const RELEASE_WINDOWS = {
  r120:    { label:'Релиз 1.20', short:'1.20', dates:'20.04–17.05', barCls:'gantt-bar-r120',    winCls:'gantt-window-r120',    stageCls:'stage-r120'    },
  r121:    { label:'Релиз 1.21', short:'1.21', dates:'18.05–14.06', barCls:'gantt-bar-r121',    winCls:'gantt-window-r121',    stageCls:'stage-r121'    },
  r122:    { label:'Релиз 1.22', short:'1.22', dates:'15.06–14.07', barCls:'gantt-bar-r122',    winCls:'gantt-window-r122',    stageCls:'stage-r122'    },
  overtime:{ label:'Овертайм',   short:'OT',   dates:'',            barCls:'gantt-bar-overtime', winCls:'gantt-window-overtime', stageCls:'stage-overtime' },
};

const WORK_TYPES = [
  'backend','frontend','тестирование','аналитика',
  'бизнес аналитика','внедрение','миграция данных','стабилизация','хотфикс',
];

const SCOPE_OPTIONS = ['Да','Нет','Требует подтверждения'];

const RISK_FLAGS = {
  CONFIRMATION_IN_RELEASE: 'Подтверждение, но уже в релизе',
  IN_SCOPE_WITHOUT_RELEASE: 'В scope, но без релиза',
  BLOCKING_NEAR_RELEASE:    'Блокер в ближайшем релизе',
};

const LEGACY_WT_MAP = {
  'разработка':'backend','backend':'backend','frontend':'frontend',
  'аналитика':'аналитика','тестирование':'тестирование','внедрение':'внедрение',
  'бизнес аналитика':'бизнес аналитика','миграция данных':'миграция данных',
  'стабилизация':'стабилизация','хотфикс':'хотфикс',
};

const WT_CLS = {
  'backend':'wt-backend','frontend':'wt-frontend',
  'тестирование':'wt-testing','аналитика':'wt-analytics','бизнес аналитика':'wt-analytics',
};

// Registry columns definition — epic FIRST (sticky)
const REGISTRY_COLS = [
  { key:'epic',               label:'Эпик',          type:'text',        visible:true,  width:180 },
  { key:'team',               label:'Команда',       type:'text',        visible:true,  width:110 },
  { key:'category',           label:'Категория',     type:'text',        visible:true,  width:110 },
  { key:'tasks',              label:'Задачи',        type:'jira',        visible:true,  width:220 },
  { key:'scopeStatus',        label:'Scope',         type:'scope',       visible:true,  width:130 },
  { key:'release120Types',    label:'1.20',          type:'multiselect', visible:true,  width:160 },
  { key:'release121Types',    label:'1.21',          type:'multiselect', visible:true,  width:160 },
  { key:'release122Types',    label:'1.22',          type:'multiselect', visible:true,  width:160 },
  { key:'overtimeTypes',      label:'Овертайм',      type:'multiselect', visible:true,  width:160 },
  { key:'role',               label:'Роли',          type:'tags',        visible:true,  width:150 },
  { key:'isDone',             label:'Сделано',       type:'checkbox',    visible:true,  width:70  },
  { key:'doneDate',           label:'Дата сделано',  type:'date',        visible:true,  width:120 },
  { key:'blockingDependency', label:'Блокер',        type:'checkbox',    visible:true,  width:60  },
  { key:'blockingDeadline',   label:'Deadline',      type:'date',        visible:true,  width:120 },
  { key:'backend',            label:'BE SP',         type:'number',      visible:false, width:70  },
  { key:'frontend',           label:'FE SP',         type:'number',      visible:false, width:70  },
  { key:'analytics_estimate', label:'Ан. SP',        type:'number',      visible:false, width:70  },
  { key:'testing_estimate',   label:'Тест. SP',      type:'number',      visible:false, width:70  },
  { key:'total_estimate',     label:'Оценка',        type:'number',      visible:false, width:70  },
  { key:'risks',              label:'Риски',         type:'text',        visible:false, width:180 },
  { key:'taskComment',        label:'Коммент.',      type:'text',        visible:false, width:180 },
  { key:'teamDependency',     label:'Зависимость',   type:'text',        visible:false, width:150 },
  { key:'comment',            label:'Комментарий',   type:'text',        visible:false, width:180 },
  { key:'sourceSheet',        label:'Лист',          type:'readonly',    visible:false, width:100 },
];

// ============================================================
// STATE
// ============================================================
const state = {
  rows: [],
  filters: {
    search:'', team:'', scope:'', release:'', workType:'', role:'',
    onlyBlocking:false, onlyDirty:false, onlyRisky:false, onlyDone:false, preset:null,
  },
  activeSection: 'dashboard',
  diagnostics: {
    sources:[], sheets:[], rowsPerSheet:{}, detectedColumns:{}, missingColumns:{}, warnings:[],
    registryCount:0, csvImportCount:0, localStorageCount:0,
  },
  sort: { col:null, dir:'asc' },
  ganttMode: 'compact',
  timelineMode: 'summary',
  podlozhkaGroup: 'team',
  colVisibility: {},
  colOrder: REGISTRY_COLS.map(c => c.key),
  colWidths: {},
  colLabels: {},
  pinnedCols: [],
  rowHeight: 36,
  customCols: [],
  sidebarCollapsed: false,
  _idCounter: 1,
};
REGISTRY_COLS.forEach(c => { state.colVisibility[c.key] = c.visible; });

function getAllCols() { return [...REGISTRY_COLS, ...state.customCols]; }

// ============================================================
// ID / UTILS
// ============================================================
function nextId() { return 'r_' + (state._idCounter++).toString(36) + '_' + Date.now().toString(36); }

const Utils = {
  normalizeHeader(h) {
    if (h == null) return '';
    return String(h).replace(/\r?\n/g,' ').replace(/\u00a0/g,' ')
      .replace(/[\u200b\u200c\u200d\ufeff]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
  },
  mapHeader(n) {
    if (n==='категория') return 'category';
    if (n==='эпик') return 'epic';
    if (n==='оценка') return 'estimation_legacy';
    if (n==='задачи') return 'tasks';
    if (n==='коммент к задачам') return 'task_comment';
    if (n==='зависимость от команд') return 'team_dependency';
    if (n==='риски') return 'risks';
    if (n.includes('релиз 1.20')) return 'release120';
    if (n.includes('релиз 1.21')) return 'release121';
    if (n.includes('релиз 1.22')) return 'release122';
    if (n.includes('входит в скоуп')) return 'scope';
    if (n==='комментарий') return 'comment';
    return null;
  },
  parseLegacyRelease(raw) {
    if (!raw) return [];
    const s = String(raw).trim();
    if (!s||s==='-'||s.toLowerCase()==='нет'||s==='0') return [];
    const lower = s.toLowerCase();
    const truthy = ['+','да','yes','1','x','✓','✔'];
    if (truthy.includes(lower)) return ['backend'];
    const parts = s.split(/[,;\n\/]+/).map(p=>p.trim().toLowerCase()).filter(Boolean);
    const res = [];
    for (const p of parts) {
      const m = LEGACY_WT_MAP[p];
      if (m) res.push(m);
      else if (truthy.includes(p)) res.push('backend');
    }
    return [...new Set(res.filter(Boolean))];
  },
  parsePipe(raw) {
    if (!raw) return [];
    return String(raw).split('|').map(s=>s.trim()).filter(Boolean);
  },
  serializePipe(arr) { return Array.isArray(arr) ? arr.join('|') : ''; },
  scopeFromRaw(raw) {
    if (!raw) return '';
    const s = String(raw).trim().toLowerCase();
    if (s==='да'||s==='yes'||s==='+'||s==='1') return 'Да';
    if (s==='нет'||s==='no'||s==='-'||s==='0') return 'Нет';
    if (s.includes('подтвержд')||s.includes('требует')) return 'Требует подтверждения';
    if (s) return raw.trim().charAt(0).toUpperCase()+raw.trim().slice(1);
    return '';
  },
  escapeCSV(v) {
    if (v==null) return '';
    const s = String(v);
    if (s.includes(',')||s.includes('"')||s.includes('\n')||s.includes('\r')) return '"'+s.replace(/"/g,'""')+'"';
    return s;
  },
  parseCSVLine(line) {
    const r=[]; let cur='', inQ=false;
    for (let i=0;i<line.length;i++) {
      const c=line[i];
      if (inQ) { if (c==='"'&&line[i+1]==='"'){cur+='"';i++;} else if(c==='"'){inQ=false;} else{cur+=c;} }
      else { if(c==='"'){inQ=true;} else if(c===','){r.push(cur);cur='';} else{cur+=c;} }
    }
    r.push(cur); return r;
  },
  parseFullCSV(text) {
    const lines=[]; let cur='', inQ=false;
    for (let i=0;i<text.length;i++) {
      const c=text[i];
      if (inQ) { if(c==='"'&&text[i+1]==='"'){cur+='"';i++;} else if(c==='"'){inQ=false;cur+=c;} else{cur+=c;} }
      else { if(c==='"'){inQ=true;cur+=c;} else if(c==='\n'){lines.push(cur);cur='';} else if(c==='\r'&&text[i+1]==='\n'){lines.push(cur);cur='';i++;} else if(c==='\r'){lines.push(cur);cur='';} else{cur+=c;} }
    }
    if (cur) lines.push(cur);
    return lines.map(l=>Utils.parseCSVLine(l));
  },
  truncate(s,n) { if(!s)return''; s=String(s); return s.length>n?s.slice(0,n)+'…':s; },
  unique(arr) { return [...new Set(arr.filter(Boolean))].sort(); },

  // Parse Jira-style URLs or standalone keys from a string
  parseJiraLinks(raw) {
    if (!raw) return [];
    const results = [];
    // Full URL pattern: .../browse/KEY-123
    const urlRe = /https?:\/\/[^\s,;"'<>]+\/browse\/([A-Z][A-Z0-9_]*-\d+)/gi;
    let m;
    while ((m = urlRe.exec(raw)) !== null) {
      results.push({ key: m[1], url: m[0] });
    }
    if (results.length) return results;
    // Standalone keys: KEY-123
    const keyRe = /\b([A-Z][A-Z0-9_]*-\d+)\b/g;
    while ((m = keyRe.exec(raw)) !== null) {
      results.push({ key: m[1], url: null });
    }
    if (results.length) return results;
    // Fallback: treat as plain text
    const trimmed = raw.trim();
    if (trimmed) results.push({ key: trimmed, url: null });
    return results;
  },
};

// ============================================================
// ROW FACTORY
// ============================================================
const RowFactory = {
  create(ov={}) {
    const now = new Date().toISOString();
    const row = {
      id: nextId(), sourceType:'', sourceSheet:'', team:'',
      category:'', epic:'',
      backend:'', frontend:'', analytics_estimate:'', testing_estimate:'', total_estimate:'',
      tasks:'', taskComment:'', teamDependency:'', risks:'',
      release120Raw:'', release121Raw:'', release122Raw:'', overtimeRaw:'',
      release120Types:[], release121Types:[], release122Types:[], overtimeTypes:[],
      hasRelease120:false, hasRelease121:false, hasRelease122:false, hasOvertime:false, isUnassigned:true,
      scopeStatus:'', role:'',
      blockingDependency:false, blockingDeadline:'',
      isDone:false, doneDate:'',
      comment:'', dirty:true, riskFlags:[],
      createdAt:now, updatedAt:now,
    };
    Object.assign(row, ov);
    RowFactory.updateDerived(row);
    return row;
  },
  updateDerived(row) {
    row.hasRelease120 = !!(row.release120Types && row.release120Types.length);
    row.hasRelease121 = !!(row.release121Types && row.release121Types.length);
    row.hasRelease122 = !!(row.release122Types && row.release122Types.length);
    row.hasOvertime   = !!(row.overtimeTypes   && row.overtimeTypes.length);
    row.isUnassigned  = !row.hasRelease120 && !row.hasRelease121 && !row.hasRelease122 && !row.hasOvertime;
    row.release120Raw = (row.release120Types||[]).join(', ');
    row.release121Raw = (row.release121Types||[]).join(', ');
    row.release122Raw = (row.release122Types||[]).join(', ');
    row.overtimeRaw   = (row.overtimeTypes||[]).join(', ');
    RiskEngine.computeFlags(row);
  },
};

// ============================================================
// RISK ENGINE
// ============================================================
const RiskEngine = {
  computeFlags(row) {
    const flags = [];
    const inAny = row.hasRelease120||row.hasRelease121||row.hasRelease122||row.hasOvertime;
    if (row.scopeStatus==='Требует подтверждения' && inAny) flags.push('CONFIRMATION_IN_RELEASE');
    if (row.scopeStatus==='Да' && row.isUnassigned) flags.push('IN_SCOPE_WITHOUT_RELEASE');
    if (row.blockingDependency && (row.hasRelease120||row.hasRelease121)) flags.push('BLOCKING_NEAR_RELEASE');
    row.riskFlags = flags;
  },
  computeAll() { state.rows.forEach(r => RiskEngine.computeFlags(r)); },
};

// ============================================================
// XLSX IMPORTER
// ============================================================
const XLSXImporter = {
  import(buffer) {
    if (typeof XLSX==='undefined') { alert('Положите libs/xlsx.full.min.js рядом с index.html'); return; }
    const wb = XLSX.read(buffer, {type:'array'});
    const newRows=[], diag={sources:['xlsx'],sheets:wb.SheetNames.slice(),rowsPerSheet:{},detectedColumns:{},missingColumns:{},warnings:[]};
    wb.SheetNames.forEach(sheetName => {
      const ws = wb.Sheets[sheetName];
      const raw = XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:false});
      if (!raw||raw.length<2) { diag.warnings.push(`Лист "${sheetName}": < 2 строк`); diag.rowsPerSheet[sheetName]=0; return; }
      let headerIdx=0;
      for (let i=0;i<Math.min(6,raw.length);i++) {
        if (raw[i].some(h=>Utils.mapHeader(Utils.normalizeHeader(h))!==null)) { headerIdx=i; break; }
      }
      const headerRow=raw[headerIdx], colMap={}, mapped={};
      headerRow.forEach((h,i) => {
        const n=Utils.normalizeHeader(h), f=Utils.mapHeader(n);
        if (f) { colMap[f]=i; mapped[f]={index:i,originalHeader:String(h).trim()}; }
      });
      diag.detectedColumns[sheetName]=mapped;
      const missing=['tasks'].filter(k=>!(k in colMap));
      if (missing.length) { diag.missingColumns[sheetName]=missing; diag.warnings.push(`Лист "${sheetName}": не найдены: ${missing.join(', ')}`); }
      const get=(f,cells)=>{ const i=colMap[f]; return i==null?'':String(cells[i]||'').trim(); };
      let cnt=0;
      for (let ri=headerIdx+1;ri<raw.length;ri++) {
        const cells=raw[ri];
        if (cells.every(c=>!String(c).trim())) continue;
        const r120=get('release120',cells), r121=get('release121',cells), scope=get('scope',cells);
        const row=RowFactory.create({
          sourceType:'xlsx', sourceSheet:sheetName, team:sheetName,
          category:get('category',cells), epic:get('epic',cells),
          total_estimate:get('estimation_legacy',cells),
          tasks:get('tasks',cells), taskComment:get('task_comment',cells),
          teamDependency:get('team_dependency',cells), risks:get('risks',cells),
          release120Raw:r120, release121Raw:r121,
          release120Types:Utils.parseLegacyRelease(r120), release121Types:Utils.parseLegacyRelease(r121),
          release122Types:[], overtimeTypes:[],
          scopeStatus:Utils.scopeFromRaw(scope), comment:get('comment',cells), dirty:false,
        });
        newRows.push(row); cnt++;
      }
      diag.rowsPerSheet[sheetName]=cnt;
    });
    state.rows=newRows;
    state.diagnostics={...state.diagnostics,...diag,registryCount:newRows.length};
    RiskEngine.computeAll(); Storage.save(); App.refreshAll(); App.updateTopbarBadge();
  },
};

// ============================================================
// CSV IMPORT / EXPORT
// ============================================================
const CSV = {
  COLS: [
    'id','sourceType','sourceSheet','team','category','epic',
    'backend','frontend','analytics_estimate','testing_estimate','total_estimate',
    'tasks','taskComment','teamDependency','risks',
    'release120Types','release121Types','release122Types','overtimeTypes',
    'scopeStatus','role','blockingDependency','blockingDeadline',
    'isDone','doneDate','comment','dirty','createdAt','updatedAt',
  ],
  SETTINGS_MARKER: '__Q2SETTINGS__',

  export() {
    const bom='\uFEFF';
    const customKeys=state.customCols.map(c=>c.key);
    const allCols=[...CSV.COLS,...customKeys];
    const header=allCols.join(',');
    const dataRows=state.rows.map(row=>
      allCols.map(col=>{
        let v=row[col];
        if (Array.isArray(v)) v=Utils.serializePipe(v);
        if (typeof v==='boolean') v=v?'true':'false';
        return Utils.escapeCSV(v==null?'':v);
      }).join(',')
    );
    // Append settings
    const settings={
      colOrder:state.colOrder, colWidths:state.colWidths, colVisibility:state.colVisibility,
      pinnedCols:state.pinnedCols, rowHeight:state.rowHeight, colLabels:state.colLabels, customCols:state.customCols,
    };
    const settingsRow=CSV.SETTINGS_MARKER+','+Utils.escapeCSV(JSON.stringify(settings));
    const content=bom+header+'\n'+dataRows.join('\n')+'\n'+settingsRow;
    const blob=new Blob([content],{type:'text/csv;charset=utf-8;'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a'); a.href=url; a.download=`q2_plan_${new Date().toISOString().slice(0,10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  },

  import(text) {
    if (text.charCodeAt(0)===0xFEFF) text=text.slice(1);
    const allRows=Utils.parseFullCSV(text);
    if (allRows.length<2) { alert('CSV пустой'); return; }
    const headers=allRows[0].map(h=>h.trim());
    const newRows=[]; let count=0;
    for (let i=1;i<allRows.length;i++) {
      const cells=allRows[i];
      if (cells.every(c=>!c.trim())) continue;
      if (cells[0]===CSV.SETTINGS_MARKER) {
        try {
          const s=JSON.parse(cells[1]);
          if (s.colOrder) state.colOrder=s.colOrder;
          if (s.colWidths) state.colWidths=s.colWidths;
          if (s.colVisibility) state.colVisibility=s.colVisibility;
          if (s.pinnedCols) state.pinnedCols=s.pinnedCols;
          if (s.rowHeight) state.rowHeight=s.rowHeight;
          if (s.colLabels) state.colLabels=s.colLabels;
          if (s.customCols) {
            state.customCols=s.customCols;
            state.customCols.forEach(c=>{ if(!state.colOrder.includes(c.key))state.colOrder.push(c.key); if(state.colVisibility[c.key]===undefined)state.colVisibility[c.key]=true; });
          }
        } catch(e) {}
        continue;
      }
      const obj={};
      headers.forEach((h,idx)=>{ obj[h]=cells[idx]!==undefined?cells[idx]:''; });
      ['release120Types','release121Types','release122Types','overtimeTypes'].forEach(f=>{
        obj[f]=Utils.parsePipe(obj[f]);
      });
      obj.blockingDependency=obj.blockingDependency==='true';
      obj.isDone=obj.isDone==='true';
      obj.dirty=obj.dirty==='true';
      const row=RowFactory.create({...obj, id:obj.id||nextId()});
      newRows.push(row); count++;
    }
    state.rows=newRows;
    state.diagnostics.csvImportCount=count; state.diagnostics.sources=['csv'];
    RiskEngine.computeAll(); Storage.save(); App.refreshAll(); App.updateTopbarBadge();
  },
};

// ============================================================
// LOCAL STORAGE
// ============================================================
const Storage = {
  _t: null,
  save() {
    clearTimeout(Storage._t);
    Storage._t=setTimeout(()=>{
      try { localStorage.setItem(STORAGE_KEY,JSON.stringify({rows:state.rows,savedAt:new Date().toISOString(),version:3})); } catch(e){}
      try { localStorage.setItem(SETTINGS_KEY,JSON.stringify({colOrder:state.colOrder,colWidths:state.colWidths,colVisibility:state.colVisibility,sidebarCollapsed:state.sidebarCollapsed,pinnedCols:state.pinnedCols,rowHeight:state.rowHeight,colLabels:state.colLabels,customCols:state.customCols})); } catch(e){}
    },400);
  },
  saveSetting(k,v) { state[k]=v; Storage.save(); },
  load() { try { return JSON.parse(localStorage.getItem(STORAGE_KEY)); } catch(e){ return null; } },
  loadSettings() {
    try {
      const s=JSON.parse(localStorage.getItem(SETTINGS_KEY));
      if (!s) return;
      if (s.colOrder) state.colOrder=s.colOrder;
      if (s.colWidths) state.colWidths=s.colWidths;
      if (s.colVisibility) state.colVisibility=s.colVisibility;
      if (typeof s.sidebarCollapsed==='boolean') state.sidebarCollapsed=s.sidebarCollapsed;
      if (s.pinnedCols) state.pinnedCols=s.pinnedCols;
      if (s.rowHeight) state.rowHeight=s.rowHeight;
      if (s.colLabels) state.colLabels=s.colLabels;
      if (s.customCols) {
        state.customCols=s.customCols;
        state.customCols.forEach(c=>{ if(!state.colOrder.includes(c.key))state.colOrder.push(c.key); if(state.colVisibility[c.key]===undefined)state.colVisibility[c.key]=true; });
      }
    } catch(e){}
  },
  clear() { localStorage.removeItem(STORAGE_KEY); localStorage.removeItem(SETTINGS_KEY); },
  restore(data) {
    state.rows=(data.rows||[]).map(r=>{
      ['release120Types','release121Types','release122Types','overtimeTypes'].forEach(f=>{
        if (!Array.isArray(r[f])) r[f]=Utils.parsePipe(r[f]||'');
      });
      if (typeof r.blockingDependency!=='boolean') r.blockingDependency=r.blockingDependency==='true';
      if (typeof r.isDone!=='boolean') r.isDone=r.isDone==='true';
      if (typeof r.dirty!=='boolean') r.dirty=r.dirty==='true';
      RowFactory.updateDerived(r);
      return r;
    });
    state.diagnostics.localStorageCount=state.rows.length;
    state.diagnostics.registryCount=state.rows.length;
    state.diagnostics.sources=['localStorage'];
  },
};

// ============================================================
// FILTER ENGINE
// ============================================================
const FilterEngine = {
  getFiltered() {
    const f=state.filters;
    return state.rows.filter(row=>{
      if (f.search) {
        const q=f.search.toLowerCase();
        if (![row.team,row.category,row.epic,row.tasks,row.taskComment,row.comment,row.role].join(' ').toLowerCase().includes(q)) return false;
      }
      if (f.team && row.team!==f.team) return false;
      if (f.scope && row.scopeStatus!==f.scope) return false;
      if (f.release) {
        if (f.release==='1.20'&&!row.hasRelease120) return false;
        if (f.release==='1.21'&&!row.hasRelease121) return false;
        if (f.release==='1.22'&&!row.hasRelease122) return false;
        if (f.release==='overtime'&&!row.hasOvertime) return false;
        if (f.release==='none'&&!row.isUnassigned) return false;
      }
      if (f.workType) {
        const all=[...row.release120Types,...row.release121Types,...row.release122Types,...row.overtimeTypes];
        if (!all.includes(f.workType)) return false;
      }
      if (f.role) {
        const roles=String(row.role||'').split(/[,|]/).map(s=>s.trim()).filter(Boolean);
        if (!roles.includes(f.role)) return false;
      }
      if (f.onlyBlocking&&!row.blockingDependency) return false;
      if (f.onlyDirty&&!row.dirty) return false;
      if (f.onlyRisky&&(!row.riskFlags||!row.riskFlags.length)) return false;
      if (f.onlyDone&&!row.isDone) return false;
      return true;
    });
  },
  getTeams() { return Utils.unique(state.rows.map(r=>r.team)); },
  getWorkTypes() {
    const all=[];
    state.rows.forEach(r=>all.push(...r.release120Types,...r.release121Types,...r.release122Types,...r.overtimeTypes));
    return Utils.unique(all);
  },
  getRoles() {
    const all=[];
    state.rows.forEach(r=>String(r.role||'').split(/[,|]/).map(s=>s.trim()).filter(Boolean).forEach(x=>all.push(x)));
    return Utils.unique(all);
  },
};

// ============================================================
// RENDER HELPERS
// ============================================================
const RH = {
  scopeChip(s) {
    if (!s) return '<span class="chip chip-gray">—</span>';
    const m={'Да':'chip chip-green','Нет':'chip chip-gray','Требует подтверждения':'chip chip-yellow'};
    return `<span class="${m[s]||'chip chip-gray'}">${s==='Требует подтверждения'?'Треб.':s}</span>`;
  },
  workTypeChips(types) {
    if (!types||!types.length) return '<span class="text-muted text-sm">—</span>';
    return types.map(t=>`<span class="wt-tag ${WT_CLS[t]||'wt-other'}">${t}</span>`).join('');
  },
  riskBadges(flags) {
    if (!flags||!flags.length) return '';
    return flags.map(f=>{
      const cls=f==='BLOCKING_NEAR_RELEASE'?'risk-badge risk-badge-danger':'risk-badge';
      return `<span class="${cls}" title="${RISK_FLAGS[f]||f}">⚠</span>`;
    }).join('');
  },
  dirtyBadge(d) { return d?'<span class="chip chip-dirty">✎</span>':''; },
  doneBadge(d) { return d?'<span class="chip chip-done">✅</span>':''; },
  jiraTagsHtml(raw) {
    const links=Utils.parseJiraLinks(raw);
    if (!links.length) return `<span class="tasks-cell-raw">${Utils.truncate(raw,40)}</span>`;
    return links.map(l=>{
      if (l.url) return `<a class="jira-tag" href="${l.url}" target="_blank" rel="noopener" title="${l.url}"><span class="jira-tag-icon">🔗</span>${l.key}</a>`;
      return `<span class="jira-tag" title="${l.key}">${l.key}</span>`;
    }).join('');
  },
  releaseChips(row) {
    const out=[];
    if (row.hasRelease120) out.push(`<span class="chip chip-indigo">1.20</span>`);
    if (row.hasRelease121) out.push(`<span class="chip chip-green">1.21</span>`);
    if (row.hasRelease122) out.push(`<span class="chip chip-yellow">1.22</span>`);
    if (row.hasOvertime) out.push(`<span class="chip chip-red">OT</span>`);
    return out.join('') || '<span class="chip chip-gray">—</span>';
  },
};

// ============================================================
// MULTISELECT COMPONENT
// ============================================================
const Multiselect = {
  _open: null,
  create(currentValues, onChange) {
    const container=document.createElement('div');
    container.className='ms-container';
    const display=document.createElement('div'); display.className='ms-display';
    const chipsWrap=document.createElement('span');
    const arrow=document.createElement('span'); arrow.className='ms-arrow'; arrow.textContent='▾';
    function renderChips() {
      chipsWrap.innerHTML='';
      if (!currentValues||!currentValues.length) {
        const ph=document.createElement('span'); ph.className='ms-placeholder'; ph.textContent='Выбрать...'; chipsWrap.appendChild(ph);
      } else {
        currentValues.forEach(v=>{ const c=document.createElement('span'); c.className='ms-chip'; c.textContent=v; chipsWrap.appendChild(c); });
      }
    }
    renderChips();
    display.appendChild(chipsWrap); display.appendChild(arrow);
    const dd=document.createElement('div'); dd.className='ms-dropdown hidden';
    WORK_TYPES.forEach(opt=>{
      const lbl=document.createElement('label'); lbl.className='ms-option';
      const cb=document.createElement('input'); cb.type='checkbox'; cb.value=opt;
      cb.checked=(currentValues||[]).includes(opt);
      cb.addEventListener('change',()=>{
        if(cb.checked){if(!currentValues.includes(opt))currentValues.push(opt);}
        else{const i=currentValues.indexOf(opt);if(i>-1)currentValues.splice(i,1);}
        renderChips(); if(onChange)onChange(currentValues.slice());
      });
      lbl.appendChild(cb); lbl.appendChild(document.createTextNode(' '+opt)); dd.appendChild(lbl);
    });
    display.addEventListener('click',e=>{
      e.stopPropagation();
      if (Multiselect._open&&Multiselect._open!==dd) { Multiselect._open.classList.add('hidden'); }
      const open=dd.classList.toggle('hidden');
      display.classList.toggle('open',!open);
      Multiselect._open=open?null:dd;
    });
    container.appendChild(display); container.appendChild(dd);
    return container;
  },
  closeAll() { document.querySelectorAll('.ms-dropdown').forEach(d=>d.classList.add('hidden')); document.querySelectorAll('.ms-display').forEach(d=>d.classList.remove('open')); Multiselect._open=null; },
};
document.addEventListener('click',()=>Multiselect.closeAll());

// ============================================================
// TAG INPUT COMPONENT (for roles)
// ============================================================
function createTagInput(initialTags, onChange) {
  const wrap=document.createElement('div'); wrap.className='tag-input-wrap';
  let tags=[...(initialTags||[])];
  function renderTags() {
    wrap.innerHTML='';
    tags.forEach((tag,i)=>{
      const item=document.createElement('span'); item.className='tag-item';
      item.textContent=tag;
      const rm=document.createElement('span'); rm.className='tag-remove'; rm.textContent='×';
      rm.addEventListener('click',e=>{ e.stopPropagation(); tags.splice(i,1); renderTags(); if(onChange)onChange(tags.slice()); });
      item.appendChild(rm); wrap.appendChild(item);
    });
    const inp=document.createElement('input'); inp.className='tag-input-field'; inp.placeholder=tags.length?'':'Роль...'; inp.type='text';
    inp.addEventListener('keydown',e=>{
      if ((e.key==='Enter'||e.key===',')&&inp.value.trim()) {
        e.preventDefault();
        const v=inp.value.trim().replace(/,$/,'');
        if (v&&!tags.includes(v)) { tags.push(v); renderTags(); if(onChange)onChange(tags.slice()); }
        else inp.value='';
      }
      if (e.key==='Backspace'&&!inp.value&&tags.length) {
        tags.pop(); renderTags(); if(onChange)onChange(tags.slice());
      }
    });
    inp.addEventListener('blur',()=>{
      if (inp.value.trim()) { const v=inp.value.trim(); if(!tags.includes(v)){tags.push(v);renderTags();if(onChange)onChange(tags.slice());} else inp.value=''; }
    });
    wrap.appendChild(inp);
  }
  renderTags();
  return wrap;
}

// ============================================================
// SIDEBAR
// ============================================================
const SidebarUI = {
  init() {
    document.getElementById('sidebar-toggle').addEventListener('click',()=>SidebarUI.toggle());
    if (state.sidebarCollapsed) SidebarUI.apply();
  },
  toggle() {
    state.sidebarCollapsed=!state.sidebarCollapsed;
    SidebarUI.apply();
    Storage.save();
  },
  apply() {
    const sb=document.getElementById('sidebar');
    const bd=document.body;
    if (state.sidebarCollapsed) { sb.classList.add('collapsed'); bd.classList.add('sidebar-collapsed'); }
    else { sb.classList.remove('collapsed'); bd.classList.remove('sidebar-collapsed'); }
  },
};

// ============================================================
// TOAST
// ============================================================
function showToast(msg, type='success', ms=2000) {
  const el=document.getElementById('toast');
  el.textContent=msg; el.className=`toast toast-${type}`;
  el.classList.remove('hidden');
  clearTimeout(showToast._t);
  showToast._t=setTimeout(()=>el.classList.add('hidden'),ms);
}

// ============================================================
// FORCE SAVE (button handler)
// ============================================================
function forceSave() {
  state.rows.forEach(r=>RowFactory.updateDerived(r));
  RiskEngine.computeAll();
  clearTimeout(Storage._t);
  try {
    localStorage.setItem(STORAGE_KEY,JSON.stringify({rows:state.rows,savedAt:new Date().toISOString(),version:3}));
    localStorage.setItem(SETTINGS_KEY,JSON.stringify({colOrder:state.colOrder,colWidths:state.colWidths,colVisibility:state.colVisibility,sidebarCollapsed:state.sidebarCollapsed}));
  } catch(e){}
  App.populateFilterDropdowns();
  App.refreshAll();
  App.updateTopbarBadge();
  showToast('✓ Сохранено и пересчитано');
}

// ============================================================
// DASHBOARD VIEW
// ============================================================
const DashboardView = {
  render() {
    const rows=FilterEngine.getFiltered();
    DashboardView.renderKPIs(rows);
    DashboardView.renderRisksPanel(rows);
    DashboardView.renderBlockingCard(rows);
    DashboardView.renderReleaseBreakdown(rows);
    DashboardView.renderTeamsSummary(rows);
    DashboardView.renderNoReleaseTable(rows);
    DashboardView.renderNeedsConfirmTable(rows);
  },
  renderKPIs(rows) {
    const done=rows.filter(r=>r.isDone).length;
    const kpis=[
      {label:'Всего задач',      value:rows.length,                                       cls:''},
      {label:'В scope (Да)',      value:rows.filter(r=>r.scopeStatus==='Да').length,       cls:'kpi-green'},
      {label:'Вне scope (Нет)',   value:rows.filter(r=>r.scopeStatus==='Нет').length,      cls:'kpi-gray'},
      {label:'Треб. подтв.',      value:rows.filter(r=>r.scopeStatus==='Требует подтверждения').length, cls:'kpi-yellow'},
      {label:'В релизе 1.20',     value:rows.filter(r=>r.hasRelease120).length,            cls:'kpi-blue'},
      {label:'В релизе 1.21',     value:rows.filter(r=>r.hasRelease121).length,            cls:'kpi-blue'},
      {label:'В релизе 1.22',     value:rows.filter(r=>r.hasRelease122).length,            cls:'kpi-blue'},
      {label:'В овертайме',       value:rows.filter(r=>r.hasOvertime).length,              cls:'kpi-red'},
      {label:'Без релиза',        value:rows.filter(r=>r.isUnassigned).length,             cls:'kpi-yellow'},
      {label:'Блокирующих зав.',  value:rows.filter(r=>r.blockingDependency).length,       cls:'kpi-red'},
      {label:'Строк с рисками',   value:rows.filter(r=>r.riskFlags&&r.riskFlags.length).length, cls:rows.filter(r=>r.riskFlags&&r.riskFlags.length).length>0?'kpi-red':'kpi-gray'},
      {label:'Изменённых строк',  value:rows.filter(r=>r.dirty).length,                   cls:'kpi-purple'},
      {label:'Сделано',           value:done,                                              cls:'kpi-teal'},
    ];
    document.getElementById('dashboard-kpi').innerHTML=kpis.map(k=>`
      <div class="kpi-card ${k.cls}"><div class="kpi-label">${k.label}</div><div class="kpi-value">${k.value}</div></div>`).join('');
  },
  renderRisksPanel(rows) {
    const byFlag={};
    rows.forEach(r=>(r.riskFlags||[]).forEach(f=>{byFlag[f]=(byFlag[f]||0)+1;}));
    const el=document.getElementById('risks-panel');
    if (!Object.keys(byFlag).length) { el.innerHTML='<div class="risks-panel-title">Риски внимания</div><div class="text-muted text-sm">Нет активных рисков</div>'; return; }
    el.innerHTML=`<div class="risks-panel-title">Риски внимания</div><div class="risks-panel-items">${
      Object.entries(byFlag).map(([f,c])=>`<div class="risk-counter"><div class="risk-counter-value">${c}</div><div class="risk-counter-label">${RISK_FLAGS[f]||f}</div></div>`).join('')
    }</div>`;
  },
  renderBlockingCard(rows) {
    const blocking=rows.filter(r=>r.blockingDependency);
    const el=document.getElementById('blocking-detail-card');
    if (!blocking.length) { el.innerHTML=''; return; }
    const rowsHtml=blocking.slice(0,20).map(r=>`
      <tr>
        <td>${Utils.truncate(r.team,16)}</td>
        <td>${Utils.truncate(r.epic,28)}</td>
        <td><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks)}</div></td>
        <td>${r.blockingDeadline||'—'}</td>
        <td>${RH.releaseChips(r)}</td>
        <td>${RH.scopeChip(r.scopeStatus)}</td>
      </tr>`).join('');
    el.innerHTML=`<div class="blocking-detail-card">
      <div class="blocking-detail-title">Блокирующие зависимости (${blocking.length})</div>
      <div style="overflow-x:auto"><table class="data-table">
        <thead><tr><th>Команда</th><th>Эпик</th><th>Задачи</th><th>Deadline</th><th>Релизы</th><th>Scope</th></tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table></div></div>`;
  },
  renderReleaseBreakdown(rows) {
    const releases=[
      {key:'r120',field:'hasRelease120',tf:'release120Types'},
      {key:'r121',field:'hasRelease121',tf:'release121Types'},
      {key:'r122',field:'hasRelease122',tf:'release122Types'},
      {key:'overtime',field:'hasOvertime',tf:'overtimeTypes'},
    ];
    document.getElementById('release-breakdown').innerHTML=releases.map(rel=>{
      const rw=RELEASE_WINDOWS[rel.key];
      const rr=rows.filter(r=>r[rel.field]);
      const wtMap={};
      rr.forEach(r=>(r[rel.tf]||[]).forEach(t=>{wtMap[t]=(wtMap[t]||0)+1;}));
      const scMap={'Да':0,'Нет':0,'Требует подтверждения':0};
      rr.forEach(r=>{if(r.scopeStatus in scMap)scMap[r.scopeStatus]++;});
      const done=rr.filter(r=>r.isDone).length;
      return `<div class="release-card">
        <div class="release-card-header"><div class="release-card-title">${rw.label}</div><div class="release-card-dates">${rw.dates}</div></div>
        <div class="release-card-count">${rr.length} задач</div>
        <div class="mini-breakdown">
          <div class="mini-breakdown-row"><span class="mini-breakdown-label">В scope (Да)</span><span class="mini-breakdown-val">${scMap['Да']}</span></div>
          <div class="mini-breakdown-row"><span class="mini-breakdown-label">Треб. подтв.</span><span class="mini-breakdown-val">${scMap['Требует подтверждения']}</span></div>
          <div class="mini-breakdown-row"><span class="mini-breakdown-label">Сделано</span><span class="mini-breakdown-val">${done}</span></div>
          ${Object.entries(wtMap).slice(0,3).map(([t,c])=>`<div class="mini-breakdown-row"><span class="mini-breakdown-label">${t}</span><span class="mini-breakdown-val">${c}</span></div>`).join('')}
        </div></div>`;
    }).join('');
  },
  renderTeamsSummary(rows) {
    const teams=Utils.unique(rows.map(r=>r.team));
    if (!teams.length) { document.getElementById('teams-summary-wrap').innerHTML=''; return; }
    document.getElementById('teams-summary-wrap').innerHTML=`<div class="data-table-wrap">
      <div class="data-table-title">📊 Сводка по командам</div>
      <div style="overflow-x:auto"><table class="data-table">
        <thead><tr><th>Команда</th><th>Всего</th><th>Да</th><th>Нет</th><th>Треб.</th><th>1.20</th><th>1.21</th><th>1.22</th><th>OT</th><th>Без рел.</th><th>Блокер</th><th>Риски</th><th>Изм.</th><th>Сделано</th></tr></thead>
        <tbody>${teams.map(team=>{
          const tr=rows.filter(r=>r.team===team);
          return `<tr><td><strong>${team}</strong></td>${[
            tr.length,
            tr.filter(r=>r.scopeStatus==='Да').length,
            tr.filter(r=>r.scopeStatus==='Нет').length,
            tr.filter(r=>r.scopeStatus==='Требует подтверждения').length,
            tr.filter(r=>r.hasRelease120).length,
            tr.filter(r=>r.hasRelease121).length,
            tr.filter(r=>r.hasRelease122).length,
            tr.filter(r=>r.hasOvertime).length,
            tr.filter(r=>r.isUnassigned).length,
            tr.filter(r=>r.blockingDependency).length,
            tr.filter(r=>r.riskFlags&&r.riskFlags.length).length,
            tr.filter(r=>r.dirty).length,
            tr.filter(r=>r.isDone).length,
          ].map(c=>`<td class="cell-number">${c||'—'}</td>`).join('')}</tr>`;
        }).join('')}</tbody>
      </table></div></div>`;
  },
  renderNoReleaseTable(rows) {
    const nr=rows.filter(r=>r.isUnassigned&&!r.isDone);
    const el=document.getElementById('no-release-wrap');
    if (!nr.length) { el.innerHTML=`<div class="data-table-wrap"><div class="data-table-title">📭 Без релиза</div><div style="padding:20px;color:var(--text-3);font-size:12px">Все задачи назначены</div></div>`; return; }
    el.innerHTML=`<div class="data-table-wrap"><div class="data-table-title">📭 Без релиза <span class="count-badge">${nr.length}</span></div>
      <div style="overflow-x:auto;max-height:320px;overflow-y:auto"><table class="data-table"><thead><tr><th>Команда</th><th>Эпик</th><th>Задача</th><th>Scope</th><th>Риски</th></tr></thead>
      <tbody>${nr.slice(0,50).map(r=>`<tr><td>${Utils.truncate(r.team,16)}</td><td>${Utils.truncate(r.epic,24)}</td><td><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks)}</div></td><td>${RH.scopeChip(r.scopeStatus)}</td><td>${RH.riskBadges(r.riskFlags)}</td></tr>`).join('')}</tbody>
      </table></div></div>`;
  },
  renderNeedsConfirmTable(rows) {
    const nc=rows.filter(r=>r.scopeStatus==='Требует подтверждения');
    const el=document.getElementById('needs-confirm-wrap');
    if (!nc.length) { el.innerHTML=`<div class="data-table-wrap"><div class="data-table-title">⚠ Требует подтверждения</div><div style="padding:20px;color:var(--text-3);font-size:12px">Нет задач</div></div>`; return; }
    el.innerHTML=`<div class="data-table-wrap"><div class="data-table-title">⚠ Требует подтверждения <span class="count-badge">${nc.length}</span></div>
      <div style="overflow-x:auto;max-height:320px;overflow-y:auto"><table class="data-table"><thead><tr><th>Команда</th><th>Эпик</th><th>Задача</th><th>Релизы</th><th>Риски</th></tr></thead>
      <tbody>${nc.slice(0,50).map(r=>`<tr><td>${Utils.truncate(r.team,16)}</td><td>${Utils.truncate(r.epic,24)}</td><td><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks)}</div></td><td>${RH.releaseChips(r)}</td><td>${RH.riskBadges(r.riskFlags)}</td></tr>`).join('')}</tbody>
      </table></div></div>`;
  },
};

// ============================================================
// REGISTRY VIEW
// ============================================================
let _dragColKey=null;

const RegistryView = {
  render() {
    const filtered=FilterEngine.getFiltered();
    const sorted=RegistryView.applySorting(filtered);
    const table=document.getElementById('registry-table');
    const empty=document.getElementById('registry-empty');
    const badge=document.getElementById('registry-count-badge');
    badge.textContent=`${sorted.length} / ${state.rows.length}`;
    if (!sorted.length) { table.classList.add('hidden'); empty.classList.remove('hidden'); return; }
    table.classList.remove('hidden'); empty.classList.add('hidden');
    RegistryView.renderHeader(); RegistryView.renderBody(sorted);
  },

  applySorting(rows) {
    const {col,dir}=state.sort; if (!col) return rows;
    return [...rows].sort((a,b)=>{
      let va=a[col],vb=b[col];
      if (va==null)va=''; if (vb==null)vb='';
      if (Array.isArray(va))va=va.join(','); if (Array.isArray(vb))vb=vb.join(',');
      const cmp=String(va).localeCompare(String(vb),'ru',{numeric:true});
      return dir==='asc'?cmp:-cmp;
    });
  },

  getVisibleCols() {
    const all=getAllCols();
    const ordered=state.colOrder
      .map(k=>all.find(c=>c.key===k))
      .filter(c=>c && state.colVisibility[c.key]!==false);
    const pinned=ordered.filter(c=>state.pinnedCols.includes(c.key));
    const rest=ordered.filter(c=>!state.pinnedCols.includes(c.key));
    return [...pinned,...rest];
  },

  _pinnedOffsets(visibleCols) {
    const map={};
    let left=36;
    for (const col of visibleCols) {
      if (!state.pinnedCols.includes(col.key)) break;
      map[col.key]=left;
      left+=(state.colWidths[col.key]||col.width||100);
    }
    return map;
  },

  renderHeader() {
    const thead=document.getElementById('registry-thead');
    const visibleCols=RegistryView.getVisibleCols();
    const offsets=RegistryView._pinnedOffsets(visibleCols);

    const ths=visibleCols.map((col)=>{
      const w=state.colWidths[col.key]||col.width||100;
      const sortCls=state.sort.col===col.key?(state.sort.dir==='asc'?'sort-asc':'sort-desc'):'';
      const isPinned=state.pinnedCols.includes(col.key);
      const stickyAttr=isPinned?'data-sticky="true"':'';
      const stickyLeft=isPinned?`left:${offsets[col.key]}px;`:'';
      const pinCls=isPinned?'pinned':'';
      const label=state.colLabels[col.key]||col.label;
      return `<th class="${sortCls}" data-sortcol="${col.key}" data-colkey="${col.key}" ${stickyAttr}
        style="min-width:${w}px;width:${w}px;${stickyLeft}" draggable="true">
        ${label}<button class="col-pin-btn ${pinCls}" data-pinkey="${col.key}" title="${isPinned?'Открепить':'Закрепить'} столбец">📌</button><span class="sort-icon"></span>
        <div class="col-resize-handle" data-resizecol="${col.key}"></div>
      </th>`;
    });

    thead.innerHTML=`<tr><th class="th-num">#</th>${ths.join('')}<th style="min-width:60px">Риски</th><th style="min-width:44px">Del</th></tr>`;

    // Pin toggle
    thead.querySelectorAll('.col-pin-btn').forEach(btn=>{
      btn.addEventListener('click',e=>{
        e.stopPropagation();
        const key=btn.dataset.pinkey;
        if (state.pinnedCols.includes(key)) state.pinnedCols=state.pinnedCols.filter(k=>k!==key);
        else state.pinnedCols.push(key);
        Storage.save(); RegistryView.render();
      });
    });

    // Sort click
    thead.querySelectorAll('[data-sortcol]').forEach(th=>{
      th.addEventListener('click',e=>{
        if (e.target.classList.contains('col-resize-handle')) return;
        const col=th.dataset.sortcol;
        state.sort.dir=(state.sort.col===col&&state.sort.dir==='asc')?'desc':'asc';
        state.sort.col=col;
        RegistryView.render();
      });
    });

    // Column DnD reorder
    thead.querySelectorAll('th[data-colkey]').forEach(th=>{
      th.addEventListener('dragstart',e=>{ _dragColKey=th.dataset.colkey; th.classList.add('dragging'); e.dataTransfer.effectAllowed='move'; });
      th.addEventListener('dragend',()=>{ th.classList.remove('dragging'); thead.querySelectorAll('th').forEach(t=>t.classList.remove('drag-over')); });
      th.addEventListener('dragover',e=>{ e.preventDefault(); th.classList.add('drag-over'); });
      th.addEventListener('dragleave',()=>th.classList.remove('drag-over'));
      th.addEventListener('drop',e=>{
        e.preventDefault(); th.classList.remove('drag-over');
        const target=th.dataset.colkey;
        if (!_dragColKey||_dragColKey===target) return;
        const from=state.colOrder.indexOf(_dragColKey), to=state.colOrder.indexOf(target);
        if (from<0||to<0) return;
        state.colOrder.splice(from,1); state.colOrder.splice(to,0,_dragColKey);
        Storage.save(); RegistryView.render();
      });
    });

    // Column resize
    thead.querySelectorAll('.col-resize-handle').forEach(handle=>{
      handle.addEventListener('mousedown',e=>{
        e.preventDefault(); e.stopPropagation();
        const colKey=handle.dataset.resizecol;
        const th=handle.closest('th');
        const startX=e.clientX, startW=th.offsetWidth;
        handle.classList.add('resizing');
        function onMove(e2) {
          const w=Math.max(50,startW+e2.clientX-startX);
          state.colWidths[colKey]=w;
          th.style.minWidth=w+'px'; th.style.width=w+'px';
          // Update all cells in this column
          document.querySelectorAll(`td[data-col="${colKey}"]`).forEach(td=>{ td.style.minWidth=w+'px'; td.style.maxWidth=w+'px'; });
        }
        function onUp() { handle.classList.remove('resizing'); document.removeEventListener('mousemove',onMove); document.removeEventListener('mouseup',onUp); Storage.save(); }
        document.addEventListener('mousemove',onMove); document.addEventListener('mouseup',onUp);
      });
    });
  },

  renderBody(rows) {
    const tbody=document.getElementById('registry-tbody'); tbody.innerHTML='';
    const visibleCols=RegistryView.getVisibleCols();
    const offsets=RegistryView._pinnedOffsets(visibleCols);

    rows.forEach((row,idx)=>{
      const tr=document.createElement('tr'); tr.dataset.rowId=row.id;
      if (row.dirty) tr.classList.add('row-dirty');
      if (row.riskFlags&&row.riskFlags.length) tr.classList.add('row-risky');
      if (row.isDone) tr.classList.add('row-done');

      const tdNum=document.createElement('td'); tdNum.className='td-num'; tdNum.textContent=idx+1; tr.appendChild(tdNum);

      visibleCols.forEach((col)=>{
        const td=document.createElement('td');
        td.dataset.col=col.key;
        const w=state.colWidths[col.key]||col.width||100;
        td.style.minWidth=w+'px'; td.style.maxWidth=w+'px';
        if (state.pinnedCols.includes(col.key)) {
          td.setAttribute('data-sticky','true');
          td.style.left=offsets[col.key]+'px';
        }
        RegistryView.renderCell(td,row,col);
        tr.appendChild(td);
      });

      const tdRisk=document.createElement('td');
      tdRisk.innerHTML=RH.riskBadges(row.riskFlags)+RH.dirtyBadge(row.dirty)+RH.doneBadge(row.isDone);
      tr.appendChild(tdRisk);

      const tdAct=document.createElement('td');
      const delBtn=document.createElement('button'); delBtn.className='row-act-btn'; delBtn.title='Удалить'; delBtn.innerHTML='✕';
      delBtn.addEventListener('click',()=>RegistryView.deleteRow(row.id));
      tdAct.appendChild(delBtn); tr.appendChild(tdAct);

      tbody.appendChild(tr);
    });
  },

  renderCell(td,row,col) {
    const val=row[col.key];

    if (col.type==='readonly') {
      td.innerHTML=`<span class="cell-text" style="pointer-events:none">${Utils.truncate(String(val||''),30)}</span>`; return;
    }
    if (col.type==='jira') {
      const wrap=document.createElement('div'); wrap.className='tasks-cell';
      wrap.innerHTML=RH.jiraTagsHtml(val);
      // Edit on double-click
      wrap.title='Двойной клик для редактирования';
      wrap.addEventListener('dblclick',()=>{
        const inp=document.createElement('input'); inp.type='text'; inp.className='cell-input'; inp.value=val||'';
        td.innerHTML=''; td.appendChild(inp); inp.focus();
        function save() { row[col.key]=inp.value.trim(); row.dirty=true; row.updatedAt=new Date().toISOString(); Storage.save(); RegistryView.renderCell(td,row,col); App.refreshDashboardIfActive(); }
        inp.addEventListener('blur',save);
        inp.addEventListener('keydown',e=>{if(e.key==='Enter')inp.blur(); if(e.key==='Escape'){row[col.key]=val;RegistryView.renderCell(td,row,col);}});
      });
      td.appendChild(wrap); return;
    }
    if (col.type==='multiselect') {
      const cv=Array.isArray(val)?val:[];
      const ms=Multiselect.create(cv,(newVals)=>{
        row[col.key]=newVals; row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row); Storage.save(); App.refreshDashboardIfActive();
        const tr=td.closest('tr'); if(tr){tr.classList.toggle('row-risky',!!(row.riskFlags&&row.riskFlags.length)); const tds=tr.querySelectorAll('td'); const rt=tds[tds.length-2]; if(rt)rt.innerHTML=RH.riskBadges(row.riskFlags)+RH.dirtyBadge(row.dirty)+RH.doneBadge(row.isDone);}
      });
      td.appendChild(ms); return;
    }
    if (col.type==='scope') {
      const sel=document.createElement('select'); sel.className='cell-select';
      ['',...SCOPE_OPTIONS].forEach(opt=>{const o=document.createElement('option');o.value=opt;o.textContent=opt||'—';if(val===opt)o.selected=true;sel.appendChild(o);});
      sel.addEventListener('change',()=>{
        row[col.key]=sel.value; row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row); Storage.save(); App.refreshDashboardIfActive();
        const tr=sel.closest('tr');if(tr){tr.classList.toggle('row-risky',!!(row.riskFlags&&row.riskFlags.length));const tds=tr.querySelectorAll('td');const rt=tds[tds.length-2];if(rt)rt.innerHTML=RH.riskBadges(row.riskFlags)+RH.dirtyBadge(row.dirty)+RH.doneBadge(row.isDone);}
      });
      td.appendChild(sel); return;
    }
    if (col.type==='checkbox') {
      const cb=document.createElement('input'); cb.type='checkbox'; cb.checked=!!val; cb.style.cursor='pointer';
      cb.addEventListener('change',()=>{
        row[col.key]=cb.checked; row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row);
        const tr=cb.closest('tr');
        if (tr) {
          tr.classList.toggle('row-risky',!!(row.riskFlags&&row.riskFlags.length));
          tr.classList.toggle('row-done',col.key==='isDone'&&cb.checked);
          const tds=tr.querySelectorAll('td'); const rt=tds[tds.length-2];
          if(rt)rt.innerHTML=RH.riskBadges(row.riskFlags)+RH.dirtyBadge(row.dirty)+RH.doneBadge(row.isDone);
          // Enable/disable associated date
          const assoc=col.key==='isDone'?'doneDate':col.key==='blockingDependency'?'blockingDeadline':null;
          if (assoc) { const dt=tr.querySelector(`[data-col="${assoc}"] input`); if(dt) dt.disabled=!cb.checked; }
        }
        Storage.save(); App.refreshDashboardIfActive();
      });
      td.appendChild(cb); return;
    }
    if (col.type==='date') {
      const inp=document.createElement('input'); inp.type='date'; inp.className='cell-input'; inp.value=val||'';
      const isDoneDate=col.key==='doneDate', isDeadline=col.key==='blockingDeadline';
      if (isDoneDate) inp.disabled=!row.isDone;
      if (isDeadline) inp.disabled=!row.blockingDependency;
      inp.addEventListener('change',()=>{ row[col.key]=inp.value; row.dirty=true; row.updatedAt=new Date().toISOString(); Storage.save(); });
      td.appendChild(inp); return;
    }
    if (col.type==='number') {
      const inp=document.createElement('input'); inp.type='number'; inp.className='cell-input cell-number'; inp.value=val||''; inp.min=0; inp.style.width='100%';
      inp.addEventListener('change',()=>{ row[col.key]=inp.value; row.dirty=true; row.updatedAt=new Date().toISOString(); Storage.save(); });
      td.appendChild(inp); return;
    }
    if (col.type==='tags') {
      // role field as tags
      const current=String(val||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
      const tw=createTagInput(current,(tags)=>{
        row[col.key]=tags.join('|'); row.dirty=true; row.updatedAt=new Date().toISOString();
        Storage.save(); App.populateFilterDropdowns();
      });
      td.appendChild(tw); return;
    }
    // Default text
    const inp=document.createElement('input'); inp.type='text'; inp.className='cell-input'; inp.value=val||''; inp.style.width='100%';
    inp.addEventListener('change',()=>{
      row[col.key]=inp.value.trim(); row.dirty=true; row.updatedAt=new Date().toISOString();
      RowFactory.updateDerived(row); App.populateFilterDropdowns(); Storage.save(); App.refreshDashboardIfActive();
    });
    td.appendChild(inp);
  },

  deleteRow(id) {
    state.rows=state.rows.filter(r=>r.id!==id);
    Storage.save(); RegistryView.render(); App.updateTopbarBadge(); App.refreshDashboardIfActive();
  },
  addRow() {
    const row=RowFactory.create({dirty:true,sourceType:'manual'});
    state.rows.unshift(row); Storage.save(); RegistryView.render(); App.updateTopbarBadge();
  },
  renderColTogglePanel() {
    const panel=document.getElementById('col-toggle-panel');
    panel.innerHTML=getAllCols().map(col=>`
      <label class="col-toggle-item">
        <input type="checkbox" data-col="${col.key}" ${state.colVisibility[col.key]!==false?'checked':''}> ${state.colLabels[col.key]||col.label}
      </label>`).join('');
    panel.querySelectorAll('input[data-col]').forEach(cb=>{
      cb.addEventListener('change',()=>{ state.colVisibility[cb.dataset.col]=cb.checked; Storage.save(); RegistryView.render(); });
    });
  },

  applyRowHeight() {
    document.documentElement.style.setProperty('--row-h', state.rowHeight+'px');
  },

  renderSettingsPanel() {
    const panel=document.getElementById('registry-settings-panel');
    const all=getAllCols();
    const colRows=all.map(col=>{
      const label=state.colLabels[col.key]||col.label;
      const w=state.colWidths[col.key]||col.width||100;
      const isPinned=state.pinnedCols.includes(col.key);
      const isCustom=!!state.customCols.find(c=>c.key===col.key);
      return `<span class="rsp-col-key" title="${col.key}">${col.key}</span>
        <input class="rsp-col-label-input" data-key="${col.key}" value="${label.replace(/"/g,'&quot;')}">
        <input class="rsp-col-width-input" type="number" data-key="${col.key}" value="${w}" min="40" max="800">
        <button class="rsp-pin-btn ${isPinned?'active':''}" data-key="${col.key}">${isPinned?'📌 Закреплён':'📌 Закрепить'}</button>
        ${isCustom?`<button class="rsp-del-btn" data-key="${col.key}">✕ Удалить</button>`:'<span></span>'}`;
    }).join('');

    panel.innerHTML=`
      <div class="rsp-section">
        <div class="rsp-title">Высота строк</div>
        <div class="rsp-row-height">
          <label>Высота</label>
          <input class="filter-input" type="number" id="rsp-row-h" value="${state.rowHeight}" min="24" max="200" style="width:80px">
          <span style="font-size:12px;color:var(--text-3)">px</span>
        </div>
      </div>
      <div class="rsp-section">
        <div class="rsp-title">Столбцы</div>
        <div class="rsp-cols-grid">
          <span class="rsp-col-header">Ключ</span>
          <span class="rsp-col-header">Название</span>
          <span class="rsp-col-header">Ширина</span>
          <span class="rsp-col-header">Закреплён</span>
          <span class="rsp-col-header"></span>
          ${colRows}
        </div>
      </div>
      <div class="rsp-section">
        <div class="rsp-title">Добавить столбец</div>
        <div class="rsp-add-col">
          <input id="rsp-new-name" placeholder="Название" style="flex:1;min-width:140px">
          <select id="rsp-new-type">
            <option value="text">Текст</option>
            <option value="number">Число</option>
            <option value="checkbox">Чекбокс</option>
            <option value="date">Дата</option>
          </select>
          <button class="btn btn-primary btn-sm" id="rsp-add-col-btn">+ Добавить</button>
        </div>
      </div>`;

    panel.querySelector('#rsp-row-h').addEventListener('input', e=>{
      const v=Math.max(24,Math.min(200,parseInt(e.target.value)||36));
      state.rowHeight=v; RegistryView.applyRowHeight(); Storage.save();
    });

    panel.querySelectorAll('.rsp-col-label-input').forEach(inp=>{
      inp.addEventListener('change', e=>{
        const key=e.target.dataset.key;
        const v=e.target.value.trim();
        if (v) state.colLabels[key]=v;
        else delete state.colLabels[key];
        Storage.save(); RegistryView.render();
      });
    });

    panel.querySelectorAll('.rsp-col-width-input').forEach(inp=>{
      inp.addEventListener('change', e=>{
        const v=Math.max(40,parseInt(e.target.value)||100);
        state.colWidths[e.target.dataset.key]=v;
        e.target.value=v;
        Storage.save(); RegistryView.render();
      });
    });

    panel.querySelectorAll('.rsp-pin-btn').forEach(btn=>{
      btn.addEventListener('click', e=>{
        const key=btn.dataset.key;
        if (state.pinnedCols.includes(key)) state.pinnedCols=state.pinnedCols.filter(k=>k!==key);
        else state.pinnedCols.push(key);
        Storage.save(); RegistryView.render(); RegistryView.renderSettingsPanel();
      });
    });

    panel.querySelectorAll('.rsp-del-btn').forEach(btn=>{
      btn.addEventListener('click', e=>{
        const key=btn.dataset.key;
        if (!confirm('Удалить столбец «'+key+'»?')) return;
        state.customCols=state.customCols.filter(c=>c.key!==key);
        state.colOrder=state.colOrder.filter(k=>k!==key);
        state.pinnedCols=state.pinnedCols.filter(k=>k!==key);
        delete state.colVisibility[key]; delete state.colWidths[key]; delete state.colLabels[key];
        state.rows.forEach(r=>delete r[key]);
        Storage.save(); RegistryView.render(); RegistryView.renderSettingsPanel();
      });
    });

    panel.querySelector('#rsp-add-col-btn').addEventListener('click', ()=>{
      const name=panel.querySelector('#rsp-new-name').value.trim();
      if (!name) { panel.querySelector('#rsp-new-name').focus(); return; }
      const type=panel.querySelector('#rsp-new-type').value;
      const key='custom_'+Date.now().toString(36);
      const col={ key, label:name, type, visible:true, width:150 };
      state.customCols.push(col);
      state.colOrder.push(key);
      state.colVisibility[key]=true;
      panel.querySelector('#rsp-new-name').value='';
      Storage.save(); RegistryView.render(); RegistryView.renderSettingsPanel();
    });
  },
};

// ============================================================
// GANTT VIEW
// ============================================================
const GanttView = {
  gf:{ team:'',scope:'',onlyBlocking:false,onlyNoRelease:false,onlyRisky:false,onlyDirty:false },
  render() { GanttView.renderFilters(); GanttView.renderChart(); },
  renderFilters() {
    const el=document.getElementById('gantt-filters');
    const teams=FilterEngine.getTeams();
    const f=GanttView.gf;
    el.innerHTML=`
      <div class="filter-group"><label class="filter-label">Команда</label>
        <select id="gf-team" class="filter-select"><option value="">Все</option>${teams.map(t=>`<option value="${t}"${f.team===t?' selected':''}>${t}</option>`).join('')}</select></div>
      <div class="filter-group"><label class="filter-label">Scope</label>
        <select id="gf-scope" class="filter-select"><option value="">Все</option>${SCOPE_OPTIONS.map(s=>`<option value="${s}"${f.scope===s?' selected':''}>${s}</option>`).join('')}</select></div>
      <label class="toggle-chip"><input type="checkbox" id="gf-blocking"${f.onlyBlocking?' checked':''}> Блокеры</label>
      <label class="toggle-chip"><input type="checkbox" id="gf-norel"${f.onlyNoRelease?' checked':''}> Без релиза</label>
      <label class="toggle-chip"><input type="checkbox" id="gf-risky"${f.onlyRisky?' checked':''}> Рисковые</label>
      <label class="toggle-chip"><input type="checkbox" id="gf-dirty"${f.onlyDirty?' checked':''}> Изменённые</label>`;
    el.querySelector('#gf-team').addEventListener('change',e=>{f.team=e.target.value;GanttView.renderChart();});
    el.querySelector('#gf-scope').addEventListener('change',e=>{f.scope=e.target.value;GanttView.renderChart();});
    el.querySelector('#gf-blocking').addEventListener('change',e=>{f.onlyBlocking=e.target.checked;GanttView.renderChart();});
    el.querySelector('#gf-norel').addEventListener('change',e=>{f.onlyNoRelease=e.target.checked;GanttView.renderChart();});
    el.querySelector('#gf-risky').addEventListener('change',e=>{f.onlyRisky=e.target.checked;GanttView.renderChart();});
    el.querySelector('#gf-dirty').addEventListener('change',e=>{f.onlyDirty=e.target.checked;GanttView.renderChart();});
  },
  getRows() {
    let rows=FilterEngine.getFiltered(); const f=GanttView.gf;
    if(f.team)rows=rows.filter(r=>r.team===f.team);
    if(f.scope)rows=rows.filter(r=>r.scopeStatus===f.scope);
    if(f.onlyBlocking)rows=rows.filter(r=>r.blockingDependency);
    if(f.onlyNoRelease)rows=rows.filter(r=>r.isUnassigned);
    if(f.onlyRisky)rows=rows.filter(r=>r.riskFlags&&r.riskFlags.length);
    if(f.onlyDirty)rows=rows.filter(r=>r.dirty);
    return rows;
  },
  renderChart() {
    const wrap=document.getElementById('gantt-wrap');
    const rows=GanttView.getRows();
    if (!rows.length){wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>';return;}
    const cols=[
      {key:'backlog',label:'Бэклог',sub:'',cls:'gantt-window-backlog'},
      {key:'r120',label:'1.20',sub:'20.04–17.05',cls:'gantt-window-r120'},
      {key:'r121',label:'1.21',sub:'18.05–14.06',cls:'gantt-window-r121'},
      {key:'r122',label:'1.22',sub:'15.06–14.07',cls:'gantt-window-r122'},
      {key:'overtime',label:'OT',sub:'Овертайм',cls:'gantt-window-overtime'},
    ];
    const lw=240, cw=160;
    const gt=`${lw}px repeat(${cols.length},${cw}px)`;
    const hasMap={backlog:'isUnassigned',r120:'hasRelease120',r121:'hasRelease121',r122:'hasRelease122',overtime:'hasOvertime'};
    const tfMap={r120:'release120Types',r121:'release121Types',r122:'release122Types',overtime:'overtimeTypes'};
    const header=`<div class="gantt-header" style="display:grid;grid-template-columns:${gt}">
      <div class="gantt-header-label">Команда / Задача</div>
      ${cols.map(c=>`<div class="gantt-header-col">${c.label}<br><span style="font-size:10px;font-weight:400;color:var(--text-4)">${c.sub}</span></div>`).join('')}
    </div>`;

    let body='';
    if (state.ganttMode==='compact') {
      Utils.unique(rows.map(r=>r.team)).forEach(team=>{
        const tr=rows.filter(r=>r.team===team);
        const cells=cols.map(col=>{
          const cnt=tr.filter(r=>r[hasMap[col.key]]).length;
          const barCls=RELEASE_WINDOWS[col.key]?RELEASE_WINDOWS[col.key].barCls:'gantt-bar-backlog';
          return `<div class="gantt-cell ${col.cls}">${cnt?`<div class="gantt-bar ${barCls}">${cnt} задач</div>`:''}</div>`;
        });
        body+=`<div class="gantt-row" style="display:grid;grid-template-columns:${gt}">
          <div class="gantt-row-label"><div class="gantt-row-label-name">${team}</div><div class="gantt-row-label-sub">${tr.length} задач</div></div>
          ${cells.join('')}</div>`;
      });
    } else {
      // Detailed with team "wells"
      const teams=Utils.unique(rows.map(r=>r.team));
      teams.forEach(team=>{
        const teamRows=rows.filter(r=>r.team===team);
        body+=`<div class="gantt-team-header" style="display:grid;grid-template-columns:${gt}">
          <div class="gantt-team-header-cell">▾ ${team} <span class="team-count">${teamRows.length} задач</span></div>
          ${cols.map(col=>{
            const cnt=teamRows.filter(r=>r[hasMap[col.key]]).length;
            return `<div class="gantt-team-header-cell" style="font-weight:400;color:var(--text-3)">${cnt||''}</div>`;
          }).join('')}
        </div>`;
        teamRows.slice(0,100).forEach(row=>{
          const cells=cols.map(col=>{
            const has=row[hasMap[col.key]];
            const barCls=RELEASE_WINDOWS[col.key]?RELEASE_WINDOWS[col.key].barCls:'gantt-bar-backlog';
            const types=(tfMap[col.key]?row[tfMap[col.key]]:[])||[];
            return `<div class="gantt-cell ${col.cls}">${has?`<div class="gantt-bar ${barCls}" title="${types.join(', ')}">${types.slice(0,2).join(',')||'•'}</div>`:''}</div>`;
          });
          body+=`<div class="gantt-row" style="display:grid;grid-template-columns:${gt}">
            <div class="gantt-row-label">
              <div class="gantt-row-label-name">${RH.riskBadges(row.riskFlags)}${RH.dirtyBadge(row.dirty)} ${Utils.truncate(row.epic||row.tasks,30)}</div>
            </div>${cells.join('')}</div>`;
        });
      });
    }

    const legend=`<div class="gantt-legend">
      ${[['#6b7280','Бэклог'],['#4f46e5','1.20'],['#059669','1.21'],['#d97706','1.22'],['#dc2626','OT']].map(([c,l])=>`<div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:${c}"></div>${l}</div>`).join('')}
    </div>`;
    wrap.innerHTML=`<div class="gantt-container">${header}<div>${body}</div>${legend}</div>`;
  },
};

// ============================================================
// KANBAN VIEW  (with drag & drop)
// ============================================================
const KanbanView = {
  _drag: { rowId:null, sourceCol:null },
  render() {
    const filtered=FilterEngine.getFiltered();
    const board=document.getElementById('kanban-board');
    const columns=[
      {key:'backlog',  label:'Без релиза', filter:r=>r.isUnassigned,  tfGet:null,          tfSet:null},
      {key:'r120',     label:'Релиз 1.20', filter:r=>r.hasRelease120, tfGet:'release120Types', tfSet:'release120Types'},
      {key:'r121',     label:'Релиз 1.21', filter:r=>r.hasRelease121, tfGet:'release121Types', tfSet:'release121Types'},
      {key:'r122',     label:'Релиз 1.22', filter:r=>r.hasRelease122, tfGet:'release122Types', tfSet:'release122Types'},
      {key:'overtime', label:'Овертайм',   filter:r=>r.hasOvertime,   tfGet:'overtimeTypes',  tfSet:'overtimeTypes'},
    ];
    const allTFFields=['release120Types','release121Types','release122Types','overtimeTypes'];

    board.innerHTML='';
    columns.forEach(col=>{
      const colRows=filtered.filter(col.filter);
      const colEl=document.createElement('div'); colEl.className='kanban-col'; colEl.dataset.colKey=col.key;

      colEl.innerHTML=`<div class="kanban-col-header"><span>${col.label}</span><span class="kanban-col-header-badge">${colRows.length}</span></div>`;
      const body=document.createElement('div'); body.className='kanban-col-body';

      // Drop target
      body.addEventListener('dragover',e=>{ e.preventDefault(); body.classList.add('drag-over'); colEl.classList.add('drag-target'); });
      body.addEventListener('dragleave',()=>{ body.classList.remove('drag-over'); colEl.classList.remove('drag-target'); });
      body.addEventListener('drop',e=>{
        e.preventDefault(); body.classList.remove('drag-over'); colEl.classList.remove('drag-target');
        const {rowId,sourceCol}=KanbanView._drag;
        if (!rowId||sourceCol===col.key) return;
        const row=state.rows.find(r=>r.id===rowId); if(!row) return;
        if (col.key==='backlog') {
          // Remove from source release only
          if (sourceCol!=='backlog'&&columns.find(c=>c.key===sourceCol)?.tfSet) {
            row[columns.find(c=>c.key===sourceCol).tfSet]=[];
          }
        } else {
          const targetField=col.tfSet;
          if (sourceCol==='backlog') {
            if (!(row[targetField]||[]).length) row[targetField]=['backend'];
          } else {
            const srcField=columns.find(c=>c.key===sourceCol)?.tfSet;
            const srcTypes=(srcField&&row[srcField])||[];
            row[targetField]=srcTypes.length?[...srcTypes]:['backend'];
            if (srcField) row[srcField]=[];
          }
        }
        row.dirty=true; row.updatedAt=new Date().toISOString();
        RowFactory.updateDerived(row); Storage.save(); KanbanView.render();
      });

      colRows.slice(0,100).forEach(row=>{
        let borderCls='';
        if(row.blockingDependency)borderCls='card-blocking';
        else if(row.riskFlags&&row.riskFlags.length)borderCls='card-risky';
        else if(row.dirty)borderCls='card-dirty';
        if(row.isDone)borderCls+=' card-done';
        const types=(col.tfGet?row[col.tfGet]:[])||[];

        const card=document.createElement('div');
        card.className=`kanban-card ${borderCls}`;
        card.draggable=true;
        card.dataset.rowId=row.id;
        card.innerHTML=`
          <div class="kanban-card-team">${row.team}</div>
          <div class="kanban-card-epic">${Utils.truncate(row.epic,40)}</div>
          <div class="kanban-card-task"><div class="tasks-cell">${RH.jiraTagsHtml(row.tasks)}</div></div>
          <div class="kanban-card-meta">
            ${RH.scopeChip(row.scopeStatus)}
            ${types.length?RH.workTypeChips(types):''}
            ${row.role?`<span class="chip chip-indigo">${Utils.truncate(row.role,20)}</span>`:''}
            ${row.blockingDependency?`<span class="chip chip-red">🚧${row.blockingDeadline?' до '+row.blockingDeadline:''}</span>`:''}
            ${RH.riskBadges(row.riskFlags)}${RH.dirtyBadge(row.dirty)}${RH.doneBadge(row.isDone)}
          </div>`;
        card.addEventListener('dragstart',e=>{
          KanbanView._drag={rowId:row.id,sourceCol:col.key};
          card.classList.add('dragging'); e.dataTransfer.effectAllowed='move';
        });
        card.addEventListener('dragend',()=>card.classList.remove('dragging'));
        body.appendChild(card);
      });
      if (colRows.length>100) { const more=document.createElement('div'); more.style.cssText='padding:8px;font-size:11px;color:var(--text-4)'; more.textContent=`...ещё ${colRows.length-100}`; body.appendChild(more); }
      colEl.appendChild(body); board.appendChild(colEl);
    });
  },
};

// ============================================================
// TIMELINE VIEW
// ============================================================
const TimelineView = {
  render() {
    if (state.timelineMode==='detailed') TimelineView.renderDetailed();
    else TimelineView.renderSummary();
  },
  _stages() {
    return [
      {key:'backlog',  label:'Бэклог',    dates:'',            stageCls:'stage-backlog',  filter:r=>r.isUnassigned,  tf:null},
      {key:'r120',     label:'1.20',       dates:'20.04–17.05', stageCls:'stage-r120',     filter:r=>r.hasRelease120, tf:'release120Types'},
      {key:'r121',     label:'1.21',       dates:'18.05–14.06', stageCls:'stage-r121',     filter:r=>r.hasRelease121, tf:'release121Types'},
      {key:'r122',     label:'1.22',       dates:'15.06–14.07', stageCls:'stage-r122',     filter:r=>r.hasRelease122, tf:'release122Types'},
      {key:'overtime', label:'OT',         dates:'Овертайм',    stageCls:'stage-overtime', filter:r=>r.hasOvertime,   tf:'overtimeTypes'},
    ];
  },
  _wtColors:{
    'backend':'#3b82f6','frontend':'#22c55e','тестирование':'#a855f7',
    'аналитика':'#f97316','бизнес аналитика':'#fb923c','внедрение':'#06b6d4',
    'миграция данных':'#84cc16','стабилизация':'#64748b','хотфикс':'#ef4444',
  },
  renderSummary() {
    const filtered=FilterEngine.getFiltered();
    const stages=TimelineView._stages();
    const stageData=stages.map(s=>{
      const rows=filtered.filter(s.filter), count=rows.length;
      const wtMap={},scMap={'Да':0,'Нет':0,'Требует подтверждения':0},doneCount=rows.filter(r=>r.isDone).length;
      rows.forEach(r=>{if(s.tf)(r[s.tf]||[]).forEach(t=>{wtMap[t]=(wtMap[t]||0)+1;});if(r.scopeStatus in scMap)scMap[r.scopeStatus]++;});
      return{...s,count,wtMap,scMap,doneCount};
    });
    const maxC=Math.max(...stageData.map(s=>s.count),1);
    const allWt=Utils.unique(stageData.flatMap(s=>Object.keys(s.wtMap)));
    const wc=TimelineView._wtColors;

    const countSection=`<div class="timeline-section"><div class="timeline-section-title">Количество задач по стадиям</div>
      <div class="timeline-stages">${stageData.map(s=>`
        <div class="timeline-stage">
          <div class="timeline-stage-header ${s.stageCls}">${s.label}<br><span style="font-size:10px;font-weight:400">${s.dates}</span></div>
          <div class="timeline-stage-body">
            <div class="timeline-stat">${s.count}</div>
            <div class="timeline-stat-sub">задач${s.doneCount?` / ${s.doneCount} ✅`:''}</div>
            <div style="height:6px;background:var(--border-light);border-radius:3px;margin-top:8px;overflow:hidden">
              <div class="${s.stageCls}" style="height:100%;width:${s.count/maxC*100}%;background:currentColor;border-radius:3px"></div>
            </div>
          </div></div>`).join('')}</div></div>`;

    const wtSection=allWt.length?`<div class="timeline-section"><div class="timeline-section-title">По типу работ</div>
      ${stageData.map(s=>{const tot=Object.values(s.wtMap).reduce((a,b)=>a+b,0)||1;
        return`<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
          <div style="width:120px;font-size:11px;font-weight:600;color:var(--text-3);text-align:right;flex-shrink:0">${s.label}</div>
          <div class="timeline-bar-wrap" style="flex:1">${allWt.map(wt=>{const c=s.wtMap[wt]||0;if(!c)return'';return`<div class="timeline-bar-seg" title="${wt}:${c}" style="width:${c/tot*100}%;background:${wc[wt]||'#888'}"></div>`;}).join('')}</div>
          <div style="width:30px;font-size:11px;color:var(--text-3)">${s.count}</div></div>`;}).join('')}
      <div class="timeline-legend">${allWt.map(wt=>`<div class="legend-item"><div class="legend-dot" style="background:${wc[wt]||'#888'}"></div>${wt}</div>`).join('')}</div></div>`:'' ;

    const scopeSection=`<div class="timeline-section"><div class="timeline-section-title">По статусу Scope</div>
      ${stageData.map(s=>{const tot=s.count||1;
        return`<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
          <div style="width:120px;font-size:11px;font-weight:600;color:var(--text-3);text-align:right;flex-shrink:0">${s.label}</div>
          <div class="timeline-bar-wrap" style="flex:1">
            ${[['Да','#059669'],['Нет','#9ca3af'],['Требует подтверждения','#d97706']].map(([sc,cl])=>{const c=s.scMap[sc]||0;if(!c)return'';return`<div class="timeline-bar-seg" title="${sc}:${c}" style="width:${c/tot*100}%;background:${cl}"></div>`;}).join('')}
          </div>
          <div style="width:30px;font-size:11px;color:var(--text-3)">${s.count}</div></div>`;}).join('')}
      <div class="timeline-legend"><div class="legend-item"><div class="legend-dot" style="background:#059669"></div>Да</div><div class="legend-item"><div class="legend-dot" style="background:#9ca3af"></div>Нет</div><div class="legend-item"><div class="legend-dot" style="background:#d97706"></div>Треб.</div></div></div>`;

    document.getElementById('timeline-wrap').innerHTML=countSection+wtSection+scopeSection;
  },
  renderDetailed() {
    const filtered=FilterEngine.getFiltered();
    const stages=TimelineView._stages();
    const teams=Utils.unique(filtered.map(r=>r.team));
    const wc=TimelineView._wtColors;
    if (!teams.length) { document.getElementById('timeline-wrap').innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>'; return; }

    const html=stages.map(stage=>{
      const stageRows=filtered.filter(stage.filter);
      const maxTeamCount=Math.max(...teams.map(t=>stageRows.filter(r=>r.team===t).length),1);
      const teamRows=teams.map(team=>{
        const tr=stageRows.filter(r=>r.team===team), cnt=tr.length;
        if(!cnt)return`<div class="timeline-team-row"><div class="timeline-team-label">${Utils.truncate(team,18)}</div><div class="timeline-team-bars"><div class="timeline-team-bar-cell"><div class="timeline-team-bar-inner"><div style="width:100%;background:var(--border-light);height:100%"></div></div></div></div><div class="timeline-team-count">—</div></div>`;
        // Work type breakdown
        const wtMap={}; if(stage.tf)tr.forEach(r=>(r[stage.tf]||[]).forEach(t=>{wtMap[t]=(wtMap[t]||0)+1;}));
        const tot=Object.values(wtMap).reduce((a,b)=>a+b,0)||1;
        const segs=Object.entries(wtMap).map(([wt,c])=>`<div class="timeline-bar-seg" title="${wt}:${c}" style="width:${c/tot*100}%;background:${wc[wt]||'#888'}"></div>`).join('');
        const done=tr.filter(r=>r.isDone).length;
        const barW=cnt/maxTeamCount*100;
        return`<div class="timeline-team-row">
          <div class="timeline-team-label">${Utils.truncate(team,18)}</div>
          <div class="timeline-team-bars"><div class="timeline-team-bar-cell" style="position:relative">
            <div style="width:${barW}%;min-width:${cnt?'4px':'0'}">
              <div class="timeline-team-bar-inner">${segs||`<div style="width:100%;background:#d1d5db;height:100%"></div>`}</div>
            </div>
          </div></div>
          <div class="timeline-team-count">${cnt}${done?` / ${done}✅`:''}</div></div>`;
      }).join('');
      return`<div class="timeline-section"><div class="timeline-section-title" style="display:flex;gap:8px;align-items:center">
        <span class="chip ${stage.stageCls}" style="font-size:13px;padding:4px 10px">${stage.label}</span>
        ${stage.dates} — ${stageRows.length} задач
      </div>${teamRows||'<div style="color:var(--text-3);font-size:12px">Нет задач в этой стадии</div>'}</div>`;
    }).join('');
    document.getElementById('timeline-wrap').innerHTML=html;
  },
};

// ============================================================
// PODLOZHKA VIEW (read-only)
// ============================================================
const PodlozhkaView = {
  render() {
    const filtered=FilterEngine.getFiltered();
    const groupBy=state.podlozhkaGroup;
    const badge=document.getElementById('podlozhka-badge');
    badge.textContent=`${filtered.length} задач`;
    const wrap=document.getElementById('podlozhka-wrap');
    if (!filtered.length) { wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📂</div><div class="empty-title">Нет данных</div></div>'; return; }

    // Group rows
    let groups={};
    if (groupBy==='none') { groups={'Все задачи':filtered}; }
    else {
      filtered.forEach(r=>{
        const key=groupBy==='team'?r.team:groupBy==='epic'?r.epic:groupBy==='scope'?r.scopeStatus||'—':'—';
        if (!groups[key||'—']) groups[key||'—']=[];
        groups[key||'—'].push(r);
      });
    }

    const tableHtml=(rows)=>`<div style="overflow-x:auto"><table class="podlozhka-table">
      <thead><tr><th>Эпик</th><th>Задачи</th><th>Scope</th><th>Релизы</th><th>Тип работ</th><th>Роль</th><th>Риски</th><th>Блокер</th><th>Сделано</th><th>Комментарий</th></tr></thead>
      <tbody>${rows.map(r=>{
        const allTypes=[...r.release120Types,...r.release121Types,...r.release122Types,...r.overtimeTypes];
        const riskCls=r.riskFlags&&r.riskFlags.length?' pod-risky':'';
        const doneCls=r.isDone?' pod-done':'';
        return`<tr class="${riskCls}${doneCls}">
          <td style="font-weight:600;min-width:140px">${r.epic||'—'}</td>
          <td style="min-width:200px"><div class="pod-tasks">${RH.jiraTagsHtml(r.tasks)}</div></td>
          <td>${RH.scopeChip(r.scopeStatus)}</td>
          <td><div class="pod-release-chips">${RH.releaseChips(r)}</div></td>
          <td>${allTypes.length?RH.workTypeChips(allTypes):'—'}</td>
          <td>${r.role?`<span class="chip chip-indigo">${Utils.truncate(r.role,20)}</span>`:'—'}</td>
          <td>${RH.riskBadges(r.riskFlags)||'—'}</td>
          <td>${r.blockingDependency?`<span class="chip chip-red">🚧${r.blockingDeadline?' '+r.blockingDeadline:''}</span>`:'—'}</td>
          <td>${r.isDone?`<span class="chip chip-done">✅${r.doneDate?' '+r.doneDate:''}</span>`:'—'}</td>
          <td style="max-width:200px;color:var(--text-3)">${Utils.truncate(r.comment,60)||'—'}</td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;

    wrap.innerHTML=Object.entries(groups).map(([groupKey,rows])=>{
      const doneCount=rows.filter(r=>r.isDone).length;
      const blockers=rows.filter(r=>r.blockingDependency).length;
      const risky=rows.filter(r=>r.riskFlags&&r.riskFlags.length).length;
      return`<div class="podlozhka-group">
        <div class="podlozhka-group-header">
          <div class="podlozhka-group-title">${groupKey}</div>
          <div class="podlozhka-group-meta">
            <span>${rows.length} задач</span>
            ${doneCount?`<span>✅ ${doneCount}</span>`:''}
            ${blockers?`<span>🚧 ${blockers}</span>`:''}
            ${risky?`<span>⚠ ${risky}</span>`:''}
          </div>
        </div>
        ${tableHtml(rows)}</div>`;
    }).join('');
  },
};

// ============================================================
// DIAGNOSTICS VIEW
// ============================================================
const DiagnosticsView = {
  render() {
    const d=state.diagnostics;
    const wrap=document.getElementById('diagnostics-wrap');
    const g=[['Источник данных',(d.sources||[]).join(', ')||'—'],['Всего строк',d.registryCount||0],['Из CSV',d.csvImportCount||0],['Из localStorage',d.localStorageCount||0]];
    const sheetsCard=d.sheets&&d.sheets.length?`<div class="diag-card"><div class="diag-card-header">Листы XLSX</div><div class="diag-card-body">${d.sheets.map(s=>`<div class="diag-row"><span class="diag-key">${s}</span><span class="diag-val">${(d.rowsPerSheet||{})[s]??'—'} строк</span></div>`).join('')}</div></div>`:'';
    const colCards=d.sheets&&d.sheets.length?d.sheets.map(s=>{
      const det=d.detectedColumns?d.detectedColumns[s]:{}, miss=d.missingColumns?d.missingColumns[s]:[];
      return`<div class="diag-card"><div class="diag-card-header">Колонки: ${s}</div><div class="diag-card-body">
        <div class="diag-col-list">${Object.entries(det||{}).map(([f,i])=>`<span class="diag-col-item" title="${i.originalHeader}">${f}[${i.index}]</span>`).join('')||'—'}</div>
        ${miss&&miss.length?`<div style="margin-top:8px"><div class="diag-col-list">${miss.map(f=>`<span class="diag-col-item diag-col-missing">${f}</span>`).join('')}</div></div>`:''}
      </div></div>`;
    }).join(''):'';
    const warns=d.warnings&&d.warnings.length?`<div class="diag-card"><div class="diag-card-header">Предупреждения</div><div class="diag-card-body">${d.warnings.map(w=>`<div class="diag-warning">${w}</div>`).join('')}</div></div>`:'';
    wrap.innerHTML=`<div class="diag-card"><div class="diag-card-header">Общая информация</div><div class="diag-card-body">${g.map(([k,v])=>`<div class="diag-row"><span class="diag-key">${k}</span><span class="diag-val">${v}</span></div>`).join('')}</div></div>${sheetsCard}${colCards}${warns}`;
  },
};

// ============================================================
// FILTERS UI
// ============================================================
const FiltersUI = {
  init() {
    const bind=(id,key,bool)=>document.getElementById(id).addEventListener(bool?'change':'change',e=>{ state.filters[key]=bool?e.target.checked:e.target.value; App.refreshCurrentSection(); });
    bind('filter-search','search'); bind('filter-team','team'); bind('filter-scope','scope');
    bind('filter-release','release'); bind('filter-worktype','workType'); bind('filter-role','role');
    bind('filter-blocking','onlyBlocking',true); bind('filter-dirty','onlyDirty',true);
    bind('filter-risky','onlyRisky',true); bind('filter-done','onlyDone',true);
    document.getElementById('filter-search').addEventListener('input',e=>{ state.filters.search=e.target.value.trim(); App.refreshCurrentSection(); });
    document.getElementById('btn-reset-filters').addEventListener('click',()=>FiltersUI.reset());
    document.querySelectorAll('.preset-btn[data-preset]').forEach(btn=>btn.addEventListener('click',()=>FiltersUI.applyPreset(btn.dataset.preset)));
  },
  applyPreset(preset) {
    document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('active'));
    if (preset==='reset') { state.filters.preset=null; state.filters.onlyBlocking=state.filters.onlyDirty=state.filters.onlyRisky=state.filters.onlyDone=false; state.filters.scope=state.filters.release=''; FiltersUI.syncUI(); App.refreshCurrentSection(); return; }
    state.filters.preset=preset;
    document.querySelector(`.preset-btn[data-preset="${preset}"]`).classList.add('active');
    state.filters.onlyBlocking=state.filters.onlyDirty=state.filters.onlyRisky=state.filters.onlyDone=false; state.filters.scope=state.filters.release='';
    if (preset==='critical') state.filters.onlyRisky=true;
    else if (preset==='no-release') state.filters.release='none';
    else if (preset==='needs-confirm') state.filters.scope='Требует подтверждения';
    else if (preset==='has-blocker') state.filters.onlyBlocking=true;
    else if (preset==='overtime') state.filters.release='overtime';
    else if (preset==='my-changes') state.filters.onlyDirty=true;
    else if (preset==='done') state.filters.onlyDone=true;
    FiltersUI.syncUI(); App.refreshCurrentSection();
  },
  syncUI() {
    document.getElementById('filter-scope').value=state.filters.scope||'';
    document.getElementById('filter-release').value=state.filters.release||'';
    ['blocking','dirty','risky','done'].forEach(k=>{
      const fk='only'+k.charAt(0).toUpperCase()+k.slice(1);
      document.getElementById(`filter-${k}`).checked=state.filters[fk];
      document.getElementById(`toggle-${k}`).classList.toggle('active',state.filters[fk]);
    });
  },
  reset() {
    state.filters={search:'',team:'',scope:'',release:'',workType:'',role:'',onlyBlocking:false,onlyDirty:false,onlyRisky:false,onlyDone:false,preset:null};
    document.getElementById('filter-search').value=''; document.getElementById('filter-team').value='';
    document.getElementById('filter-scope').value=''; document.getElementById('filter-release').value='';
    document.getElementById('filter-worktype').value=''; document.getElementById('filter-role').value='';
    document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('active'));
    FiltersUI.syncUI(); App.refreshCurrentSection();
  },
  populateDropdowns() {
    const teamSel=document.getElementById('filter-team'), cur1=teamSel.value;
    teamSel.innerHTML='<option value="">Все</option>'+FilterEngine.getTeams().map(t=>`<option value="${t}"${cur1===t?' selected':''}>${t}</option>`).join('');
    const wtSel=document.getElementById('filter-worktype'), cur2=wtSel.value;
    wtSel.innerHTML='<option value="">Все</option>'+FilterEngine.getWorkTypes().map(t=>`<option value="${t}"${cur2===t?' selected':''}>${t}</option>`).join('');
    const roleSel=document.getElementById('filter-role'), cur3=roleSel.value;
    roleSel.innerHTML='<option value="">Все</option>'+FilterEngine.getRoles().map(r=>`<option value="${r}"${cur3===r?' selected':''}>${r}</option>`).join('');
  },
};

// ============================================================
// NAV
// ============================================================
const Nav = {
  init() {
    document.querySelectorAll('.nav-item[data-section]').forEach(btn=>{
      btn.addEventListener('click',()=>Nav.goTo(btn.dataset.section));
    });
  },
  goTo(section) {
    state.activeSection=section;
    document.querySelectorAll('.nav-item').forEach(b=>b.classList.remove('active'));
    const ab=document.querySelector(`.nav-item[data-section="${section}"]`); if(ab)ab.classList.add('active');
    document.querySelectorAll('.app-section').forEach(s=>s.classList.add('hidden'));
    const el=document.getElementById(`section-${section}`); if(el)el.classList.remove('hidden');
    App.renderSection(section);
  },
};

// ============================================================
// APP
// ============================================================
const App = {
  init() {
    Storage.loadSettings();
    RegistryView.applyRowHeight();
    SidebarUI.init();
    Nav.init();
    FiltersUI.init();
    App.bindImports();
    App.bindExport();
    App.bindClear();
    App.bindSave();
    App.bindAddRow();
    App.bindColToggle();
    App.bindRegistrySettings();
    App.bindGanttModes();
    App.bindTimelineModes();
    App.bindColOrderReset();
    App.bindPodlozhkaGroup();

    const saved=Storage.load();
    if (saved&&saved.rows&&saved.rows.length>0) {
      const meta=document.getElementById('modal-restore-meta');
      meta.textContent=`Сохранено ${saved.rows.length} строк от ${new Date(saved.savedAt).toLocaleString('ru')}.`;
      document.getElementById('modal-restore').classList.remove('hidden');
      document.getElementById('btn-restore-yes').onclick=()=>{
        Storage.restore(saved); RiskEngine.computeAll();
        RegistryView.applyRowHeight();
        document.getElementById('modal-restore').classList.add('hidden');
        App.populateFilterDropdowns(); App.renderSection('dashboard'); App.updateTopbarBadge();
      };
      document.getElementById('btn-restore-no').onclick=()=>{ Storage.clear(); document.getElementById('modal-restore').classList.add('hidden'); App.renderSection('dashboard'); };
    } else { App.renderSection('dashboard'); }
  },
  bindImports() {
    document.getElementById('input-xlsx').addEventListener('change',e=>{
      const f=e.target.files[0]; if(!f)return;
      const r=new FileReader(); r.onload=ev=>{ XLSXImporter.import(new Uint8Array(ev.target.result)); App.populateFilterDropdowns(); e.target.value=''; }; r.readAsArrayBuffer(f);
    });
    document.getElementById('input-csv').addEventListener('change',e=>{
      const f=e.target.files[0]; if(!f)return;
      const r=new FileReader(); r.onload=ev=>{ CSV.import(ev.target.result); App.populateFilterDropdowns(); e.target.value=''; }; r.readAsText(f,'utf-8');
    });
  },
  bindExport() { document.getElementById('btn-export-csv').addEventListener('click',()=>{ if(!state.rows.length){alert('Нет данных');return;}CSV.export(); }); },
  bindClear() {
    document.getElementById('btn-clear-storage').addEventListener('click',()=>{
      if (confirm('Очистить все данные и настройки?')) {
        Storage.clear(); state.rows=[]; state.diagnostics={sources:[],sheets:[],rowsPerSheet:{},detectedColumns:{},missingColumns:{},warnings:[],registryCount:0,csvImportCount:0,localStorageCount:0};
        App.populateFilterDropdowns(); App.refreshAll(); App.updateTopbarBadge();
      }
    });
  },
  bindSave() { document.getElementById('btn-save').addEventListener('click',()=>forceSave()); },
  bindAddRow() { document.getElementById('btn-add-row').addEventListener('click',()=>RegistryView.addRow()); },
  bindColToggle() {
    document.getElementById('btn-toggle-cols').addEventListener('click',()=>{
      const p=document.getElementById('col-toggle-panel'); p.classList.toggle('hidden'); if(!p.classList.contains('hidden'))RegistryView.renderColTogglePanel();
    });
  },
  bindRegistrySettings() {
    document.getElementById('btn-registry-settings').addEventListener('click',()=>{
      const p=document.getElementById('registry-settings-panel');
      p.classList.toggle('hidden');
      if (!p.classList.contains('hidden')) RegistryView.renderSettingsPanel();
    });
  },
  bindColOrderReset() {
    document.getElementById('btn-reset-col-order').addEventListener('click',()=>{
      state.colOrder=REGISTRY_COLS.map(c=>c.key); state.colWidths={}; Storage.save(); RegistryView.render();
    });
  },
  bindGanttModes() {
    document.getElementById('gantt-mode-compact').addEventListener('click',()=>{ state.ganttMode='compact'; document.getElementById('gantt-mode-compact').classList.add('active'); document.getElementById('gantt-mode-detailed').classList.remove('active'); GanttView.renderChart(); });
    document.getElementById('gantt-mode-detailed').addEventListener('click',()=>{ state.ganttMode='detailed'; document.getElementById('gantt-mode-detailed').classList.add('active'); document.getElementById('gantt-mode-compact').classList.remove('active'); GanttView.renderChart(); });
  },
  bindTimelineModes() {
    document.getElementById('timeline-mode-summary').addEventListener('click',()=>{ state.timelineMode='summary'; document.getElementById('timeline-mode-summary').classList.add('active'); document.getElementById('timeline-mode-detailed').classList.remove('active'); if(state.activeSection==='timeline')TimelineView.render(); });
    document.getElementById('timeline-mode-detailed').addEventListener('click',()=>{ state.timelineMode='detailed'; document.getElementById('timeline-mode-detailed').classList.add('active'); document.getElementById('timeline-mode-summary').classList.remove('active'); if(state.activeSection==='timeline')TimelineView.render(); });
  },
  bindPodlozhkaGroup() {
    document.getElementById('podlozhka-group').addEventListener('change',e=>{ state.podlozhkaGroup=e.target.value; if(state.activeSection==='podlozhka')PodlozhkaView.render(); });
  },
  populateFilterDropdowns() { FiltersUI.populateDropdowns(); },
  renderSection(s) {
    if(s==='dashboard')DashboardView.render();
    else if(s==='registry')RegistryView.render();
    else if(s==='gantt')GanttView.render();
    else if(s==='kanban')KanbanView.render();
    else if(s==='timeline')TimelineView.render();
    else if(s==='podlozhka')PodlozhkaView.render();
    else if(s==='diagnostics')DiagnosticsView.render();
  },
  refreshAll() { App.renderSection(state.activeSection); },
  refreshCurrentSection() { App.renderSection(state.activeSection); },
  refreshDashboardIfActive() { if(state.activeSection==='dashboard')DashboardView.render(); },
  updateTopbarBadge() {
    const b=document.getElementById('topbar-row-count');
    if(state.rows.length){b.textContent=state.rows.length+' строк';b.classList.remove('hidden');}else b.classList.add('hidden');
  },
};

document.addEventListener('DOMContentLoaded',()=>App.init());
