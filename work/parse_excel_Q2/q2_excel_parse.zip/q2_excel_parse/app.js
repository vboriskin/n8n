'use strict';
/* ============================================================
   Q2 PLAN ANALYZER — app.js
   ============================================================ */

// ============================================================
// CONSTANTS
// ============================================================
const STORAGE_KEY = 'q2_plan_analyzer_v2';

const RELEASE_WINDOWS = {
  r120: { label: 'Релиз 1.20', short: '1.20', dates: '20.04–17.05', cls: 'gantt-bar-r120', win: 'gantt-window-r120', stageCls: 'stage-r120' },
  r121: { label: 'Релиз 1.21', short: '1.21', dates: '18.05–14.06', cls: 'gantt-bar-r121', win: 'gantt-window-r121', stageCls: 'stage-r121' },
  r122: { label: 'Релиз 1.22', short: '1.22', dates: '15.06–14.07', cls: 'gantt-bar-r122', win: 'gantt-window-r122', stageCls: 'stage-r122' },
  overtime: { label: 'Овертайм', short: 'OT', dates: '', cls: 'gantt-bar-overtime', win: 'gantt-window-overtime', stageCls: 'stage-overtime' },
};

const WORK_TYPES = [
  'backend', 'frontend', 'тестирование', 'аналитика',
  'бизнес аналитика', 'внедрение', 'миграция данных', 'стабилизация', 'хотфикс'
];

const SCOPE_OPTIONS = ['Да', 'Нет', 'Требует подтверждения'];

const RISK_FLAGS = {
  CONFIRMATION_IN_RELEASE: 'Подтверждение, но уже в релизе',
  IN_SCOPE_WITHOUT_RELEASE: 'В scope, но без релиза',
  BLOCKING_NEAR_RELEASE: 'Блокер в ближайшем релизе',
};

const LEGACY_WORK_TYPE_MAP = {
  'разработка': 'backend',
  'разработка backend': 'backend',
  'backend': 'backend',
  'frontend': 'frontend',
  'аналитика': 'аналитика',
  'тестирование': 'тестирование',
  'внедрение': 'внедрение',
  'бизнес аналитика': 'бизнес аналитика',
  'миграция данных': 'миграция данных',
  'стабилизация': 'стабилизация',
  'хотфикс': 'хотфикс',
};

const WT_CLS = {
  'backend': 'wt-backend',
  'frontend': 'wt-frontend',
  'тестирование': 'wt-testing',
  'аналитика': 'wt-analytics',
  'бизнес аналитика': 'wt-analytics',
};

// Registry columns definition
const REGISTRY_COLS = [
  { key: 'team',              label: 'Команда',        type: 'text',        visible: true,  width: 100 },
  { key: 'category',          label: 'Категория',      type: 'text',        visible: true,  width: 110 },
  { key: 'epic',              label: 'Эпик',           type: 'text',        visible: true,  width: 150 },
  { key: 'tasks',             label: 'Задачи',         type: 'text',        visible: true,  width: 220 },
  { key: 'scopeStatus',       label: 'Scope',          type: 'scope',       visible: true,  width: 130 },
  { key: 'release120Types',   label: '1.20',           type: 'multiselect', visible: true,  width: 160 },
  { key: 'release121Types',   label: '1.21',           type: 'multiselect', visible: true,  width: 160 },
  { key: 'release122Types',   label: '1.22',           type: 'multiselect', visible: true,  width: 160 },
  { key: 'overtimeTypes',     label: 'Овертайм',       type: 'multiselect', visible: true,  width: 160 },
  { key: 'role',              label: 'Роль',           type: 'text',        visible: true,  width: 100 },
  { key: 'blockingDependency',label: 'Блокер',         type: 'checkbox',    visible: true,  width: 60  },
  { key: 'blockingDeadline',  label: 'Deadline',       type: 'date',        visible: true,  width: 110 },
  { key: 'backend',           label: 'Backend SP',     type: 'number',      visible: false, width: 80  },
  { key: 'frontend',          label: 'Frontend SP',    type: 'number',      visible: false, width: 80  },
  { key: 'analytics_estimate',label: 'Аналитика SP',  type: 'number',      visible: false, width: 80  },
  { key: 'testing_estimate',  label: 'Тестир. SP',     type: 'number',      visible: false, width: 80  },
  { key: 'total_estimate',    label: 'Оценка SP',      type: 'number',      visible: false, width: 80  },
  { key: 'risks',             label: 'Риски',          type: 'text',        visible: false, width: 180 },
  { key: 'taskComment',       label: 'Коммент.',       type: 'text',        visible: false, width: 180 },
  { key: 'teamDependency',    label: 'Зависимость',    type: 'text',        visible: false, width: 150 },
  { key: 'comment',           label: 'Комментарий',    type: 'text',        visible: false, width: 180 },
  { key: 'sourceSheet',       label: 'Лист',           type: 'readonly',    visible: false, width: 100 },
];

// ============================================================
// STATE
// ============================================================
const state = {
  rows: [],
  filters: {
    search: '',
    team: '',
    scope: '',
    release: '',
    workType: '',
    role: '',
    onlyBlocking: false,
    onlyDirty: false,
    onlyRisky: false,
    preset: null,
  },
  activeSection: 'dashboard',
  diagnostics: {
    sources: [],
    sheets: [],
    rowsPerSheet: {},
    detectedColumns: {},
    missingColumns: {},
    warnings: [],
    registryCount: 0,
    csvImportCount: 0,
    localStorageCount: 0,
  },
  sort: { col: null, dir: 'asc' },
  ganttMode: 'compact',
  colVisibility: {},
  _idCounter: 1,
};

// Populate colVisibility from REGISTRY_COLS defaults
REGISTRY_COLS.forEach(c => { state.colVisibility[c.key] = c.visible; });

// ============================================================
// ID GENERATOR
// ============================================================
function nextId() {
  return 'r_' + (state._idCounter++).toString(36) + '_' + Date.now().toString(36);
}

// ============================================================
// UTILITIES
// ============================================================
const Utils = {
  normalizeHeader(h) {
    if (h == null) return '';
    return String(h)
      .replace(/\r?\n/g, ' ')
      .replace(/\u00a0/g, ' ')
      .replace(/[\u200b\u200c\u200d\ufeff]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  },

  mapHeader(normalized) {
    if (normalized === 'категория') return 'category';
    if (normalized === 'эпик') return 'epic';
    if (normalized === 'оценка') return 'estimation_legacy';
    if (normalized === 'задачи') return 'tasks';
    if (normalized === 'коммент к задачам') return 'task_comment';
    if (normalized === 'зависимость от команд') return 'team_dependency';
    if (normalized === 'риски') return 'risks';
    if (normalized.includes('релиз 1.20')) return 'release120';
    if (normalized.includes('релиз 1.21')) return 'release121';
    if (normalized.includes('релиз 1.22')) return 'release122';
    if (normalized.includes('входит в скоуп')) return 'scope';
    if (normalized === 'комментарий') return 'comment';
    return null;
  },

  parseLegacyReleaseValue(raw) {
    if (!raw) return [];
    const str = String(raw).trim();
    if (!str || str === '-' || str.toLowerCase() === 'нет' || str === '0') return [];
    const lower = str.toLowerCase();

    // If it's just a truthy marker with no detail
    const truthy = ['+', 'да', 'yes', '1', 'x', '✓', '✔'];
    if (truthy.includes(lower)) return ['backend'];

    const parts = str.split(/[,;\n\/]+/).map(p => p.trim().toLowerCase()).filter(Boolean);
    const result = [];
    for (const part of parts) {
      const mapped = LEGACY_WORK_TYPE_MAP[part];
      if (mapped) {
        result.push(mapped);
      } else if (truthy.includes(part)) {
        result.push('backend');
      }
    }
    return [...new Set(result.filter(Boolean))];
  },

  parseMultiselectCSV(raw) {
    if (!raw) return [];
    return String(raw).split('|').map(s => s.trim()).filter(Boolean);
  },

  serializeMultiselectCSV(arr) {
    if (!Array.isArray(arr)) return '';
    return arr.join('|');
  },

  scopeFromRaw(raw) {
    if (!raw) return '';
    const s = String(raw).trim().toLowerCase();
    if (s === 'да' || s === 'yes' || s === '+' || s === '1') return 'Да';
    if (s === 'нет' || s === 'no' || s === '-' || s === '0') return 'Нет';
    if (s.includes('подтвержд') || s.includes('требует')) return 'Требует подтверждения';
    if (s) return s.charAt(0).toUpperCase() + s.slice(1);
    return '';
  },

  escapeCSV(val) {
    if (val == null) return '';
    const s = String(val);
    if (s.includes(',') || s.includes('"') || s.includes('\n') || s.includes('\r')) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  },

  parseCSVLine(line) {
    const result = [];
    let cur = '';
    let inQuote = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQuote) {
        if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (ch === '"') { inQuote = false; }
        else { cur += ch; }
      } else {
        if (ch === '"') { inQuote = true; }
        else if (ch === ',') { result.push(cur); cur = ''; }
        else { cur += ch; }
      }
    }
    result.push(cur);
    return result;
  },

  parseFullCSV(text) {
    // Handle multiline quoted fields
    const lines = [];
    let cur = '';
    let inQuote = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (inQuote) {
        if (ch === '"' && text[i + 1] === '"') { cur += '"'; i++; }
        else if (ch === '"') { inQuote = false; cur += ch; }
        else { cur += ch; }
      } else {
        if (ch === '"') { inQuote = true; cur += ch; }
        else if (ch === '\n') { lines.push(cur); cur = ''; }
        else if (ch === '\r' && text[i + 1] === '\n') { lines.push(cur); cur = ''; i++; }
        else if (ch === '\r') { lines.push(cur); cur = ''; }
        else { cur += ch; }
      }
    }
    if (cur) lines.push(cur);
    return lines.map(l => Utils.parseCSVLine(l));
  },

  today() {
    return new Date().toISOString().slice(0, 10);
  },

  truncate(s, n) {
    if (!s) return '';
    s = String(s);
    return s.length > n ? s.slice(0, n) + '…' : s;
  },

  unique(arr) {
    return [...new Set(arr.filter(Boolean))].sort();
  },
};

// ============================================================
// ROW FACTORY & DERIVED FIELDS
// ============================================================
const RowFactory = {
  create(overrides = {}) {
    const now = new Date().toISOString();
    const row = {
      id: nextId(),
      sourceType: '',
      sourceSheet: '',
      team: '',
      category: '',
      epic: '',
      backend: '',
      frontend: '',
      analytics_estimate: '',
      testing_estimate: '',
      total_estimate: '',
      tasks: '',
      taskComment: '',
      teamDependency: '',
      risks: '',
      release120Raw: '',
      release121Raw: '',
      release122Raw: '',
      overtimeRaw: '',
      release120Types: [],
      release121Types: [],
      release122Types: [],
      overtimeTypes: [],
      hasRelease120: false,
      hasRelease121: false,
      hasRelease122: false,
      hasOvertime: false,
      isUnassigned: true,
      scopeStatus: '',
      role: '',
      blockingDependency: false,
      blockingDeadline: '',
      comment: '',
      dirty: true,
      riskFlags: [],
      createdAt: now,
      updatedAt: now,
    };
    Object.assign(row, overrides);
    RowFactory.updateDerived(row);
    return row;
  },

  updateDerived(row) {
    row.hasRelease120 = row.release120Types && row.release120Types.length > 0;
    row.hasRelease121 = row.release121Types && row.release121Types.length > 0;
    row.hasRelease122 = row.release122Types && row.release122Types.length > 0;
    row.hasOvertime   = row.overtimeTypes   && row.overtimeTypes.length   > 0;
    row.isUnassigned  = !row.hasRelease120 && !row.hasRelease121 && !row.hasRelease122 && !row.hasOvertime;
    // Regenerate raw strings
    row.release120Raw = row.release120Types.join(', ');
    row.release121Raw = row.release121Types.join(', ');
    row.release122Raw = row.release122Types.join(', ');
    row.overtimeRaw   = row.overtimeTypes.join(', ');
    // Compute risk flags
    RiskEngine.computeFlags(row);
  },
};

// ============================================================
// RISK ENGINE
// ============================================================
const RiskEngine = {
  computeFlags(row) {
    const flags = [];
    const inAnyRelease = row.hasRelease120 || row.hasRelease121 || row.hasRelease122 || row.hasOvertime;

    // 1. Scope = "Требует подтверждения" AND already in some release
    if (row.scopeStatus === 'Требует подтверждения' && inAnyRelease) {
      flags.push('CONFIRMATION_IN_RELEASE');
    }

    // 2. Scope = "Да" AND no release assigned
    if (row.scopeStatus === 'Да' && row.isUnassigned) {
      flags.push('IN_SCOPE_WITHOUT_RELEASE');
    }

    // 3. Blocking dependency AND in release 1.20 or 1.21
    if (row.blockingDependency && (row.hasRelease120 || row.hasRelease121)) {
      flags.push('BLOCKING_NEAR_RELEASE');
    }

    row.riskFlags = flags;
  },

  computeAll() {
    state.rows.forEach(r => RiskEngine.computeFlags(r));
  },
};

// ============================================================
// XLSX IMPORTER
// ============================================================
const XLSXImporter = {
  import(buffer) {
    if (typeof XLSX === 'undefined') {
      alert('Библиотека xlsx.full.min.js не найдена.\nПоложите файл в папку libs/ и обновите страницу.');
      return;
    }
    const wb = XLSX.read(buffer, { type: 'array' });
    const newRows = [];
    const diag = {
      sources: ['xlsx'],
      sheets: wb.SheetNames.slice(),
      rowsPerSheet: {},
      detectedColumns: {},
      missingColumns: {},
      warnings: [],
    };

    wb.SheetNames.forEach(sheetName => {
      const ws = wb.Sheets[sheetName];
      const raw = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '', raw: false });
      if (!raw || raw.length < 2) {
        diag.warnings.push(`Лист "${sheetName}": меньше 2 строк, пропускаем`);
        diag.rowsPerSheet[sheetName] = 0;
        return;
      }

      // Find header row: search first row that contains a recognizable column
      let headerRowIdx = 0;
      for (let i = 0; i < Math.min(5, raw.length); i++) {
        const mapped = raw[i].some(h => {
          const n = Utils.normalizeHeader(h);
          return Utils.mapHeader(n) !== null;
        });
        if (mapped) { headerRowIdx = i; break; }
      }

      const headerRow = raw[headerRowIdx];
      const colMap = {}; // fieldName -> colIndex
      const mappedIndices = {};

      headerRow.forEach((h, i) => {
        const n = Utils.normalizeHeader(h);
        const field = Utils.mapHeader(n);
        if (field) {
          colMap[field] = i;
          mappedIndices[field] = { index: i, originalHeader: String(h).trim() };
        }
      });

      diag.detectedColumns[sheetName] = mappedIndices;

      // Required columns
      const required = ['tasks'];
      const missing = required.filter(k => !(k in colMap));
      if (missing.length) {
        diag.missingColumns[sheetName] = missing;
        diag.warnings.push(`Лист "${sheetName}": не найдены колонки: ${missing.join(', ')}`);
      }

      let count = 0;
      for (let ri = headerRowIdx + 1; ri < raw.length; ri++) {
        const cells = raw[ri];
        // Skip completely empty rows
        if (cells.every(c => !String(c).trim())) continue;

        const get = (field) => {
          const idx = colMap[field];
          if (idx == null) return '';
          return String(cells[idx] || '').trim();
        };

        const r120raw = get('release120');
        const r121raw = get('release121');
        const r122raw = get('release122');
        const scopeRaw = get('scope');

        const row = RowFactory.create({
          sourceType: 'xlsx',
          sourceSheet: sheetName,
          team: sheetName,
          category: get('category'),
          epic: get('epic'),
          total_estimate: get('estimation_legacy'),
          tasks: get('tasks'),
          taskComment: get('task_comment'),
          teamDependency: get('team_dependency'),
          risks: get('risks'),
          release120Raw: r120raw,
          release121Raw: r121raw,
          release122Raw: r122raw,
          release120Types: Utils.parseLegacyReleaseValue(r120raw),
          release121Types: Utils.parseLegacyReleaseValue(r121raw),
          release122Types: [],  // 1.22 is a new field
          overtimeTypes: [],
          scopeStatus: Utils.scopeFromRaw(scopeRaw),
          comment: get('comment'),
          dirty: false,
        });

        newRows.push(row);
        count++;
      }

      diag.rowsPerSheet[sheetName] = count;
    });

    state.rows = newRows;
    state.diagnostics = { ...state.diagnostics, ...diag, registryCount: newRows.length };
    RiskEngine.computeAll();
    Storage.save();
    App.refreshAll();
    App.updateTopbarBadge();
  },
};

// ============================================================
// CSV IMPORT / EXPORT
// ============================================================
const CSV = {
  COLUMNS: [
    'id','sourceType','sourceSheet','team','category','epic',
    'backend','frontend','analytics_estimate','testing_estimate','total_estimate',
    'tasks','taskComment','teamDependency','risks',
    'release120Types','release121Types','release122Types','overtimeTypes',
    'scopeStatus','role',
    'blockingDependency','blockingDeadline',
    'comment','dirty','createdAt','updatedAt',
  ],

  export() {
    const bom = '\uFEFF'; // UTF-8 BOM for Excel
    const header = CSV.COLUMNS.join(',');
    const rows = state.rows.map(row => {
      return CSV.COLUMNS.map(col => {
        let val = row[col];
        if (Array.isArray(val)) val = Utils.serializeMultiselectCSV(val);
        if (typeof val === 'boolean') val = val ? 'true' : 'false';
        return Utils.escapeCSV(val == null ? '' : val);
      }).join(',');
    });
    const content = bom + header + '\n' + rows.join('\n');
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `q2_plan_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  },

  import(text) {
    // Remove BOM
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    const allRows = Utils.parseFullCSV(text);
    if (allRows.length < 2) { alert('CSV пустой'); return; }

    const headers = allRows[0].map(h => h.trim());
    const newRows = [];
    let count = 0;

    for (let i = 1; i < allRows.length; i++) {
      const cells = allRows[i];
      if (cells.every(c => !c.trim())) continue;
      const obj = {};
      headers.forEach((h, idx) => {
        obj[h] = cells[idx] !== undefined ? cells[idx] : '';
      });

      // Deserialize
      const multiselectFields = ['release120Types','release121Types','release122Types','overtimeTypes'];
      multiselectFields.forEach(f => {
        obj[f] = Utils.parseMultiselectCSV(obj[f]);
      });
      obj.blockingDependency = obj.blockingDependency === 'true';
      obj.dirty = obj.dirty === 'true';

      const row = RowFactory.create({
        ...obj,
        id: obj.id || nextId(),
      });
      newRows.push(row);
      count++;
    }

    state.rows = newRows;
    state.diagnostics.csvImportCount = count;
    state.diagnostics.sources = ['csv'];
    RiskEngine.computeAll();
    Storage.save();
    App.refreshAll();
    App.updateTopbarBadge();
  },
};

// ============================================================
// LOCAL STORAGE
// ============================================================
const Storage = {
  _timer: null,

  save() {
    clearTimeout(Storage._timer);
    Storage._timer = setTimeout(() => {
      try {
        const data = {
          rows: state.rows,
          savedAt: new Date().toISOString(),
          version: 2,
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      } catch(e) {
        console.warn('localStorage save failed', e);
      }
    }, 400);
  },

  load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch(e) {
      return null;
    }
  },

  clear() {
    localStorage.removeItem(STORAGE_KEY);
  },

  restore(data) {
    state.rows = (data.rows || []).map(r => {
      // Ensure arrays
      ['release120Types','release121Types','release122Types','overtimeTypes'].forEach(f => {
        if (!Array.isArray(r[f])) r[f] = Utils.parseMultiselectCSV(r[f] || '');
      });
      if (typeof r.blockingDependency !== 'boolean') r.blockingDependency = r.blockingDependency === 'true';
      if (typeof r.dirty !== 'boolean') r.dirty = r.dirty === 'true';
      RowFactory.updateDerived(r);
      return r;
    });
    state.diagnostics.localStorageCount = state.rows.length;
    state.diagnostics.registryCount = state.rows.length;
    state.diagnostics.sources = ['localStorage'];
  },
};

// ============================================================
// FILTER ENGINE
// ============================================================
const FilterEngine = {
  getFiltered() {
    const f = state.filters;
    return state.rows.filter(row => {
      // Text search
      if (f.search) {
        const q = f.search.toLowerCase();
        const haystack = [row.team, row.category, row.epic, row.tasks, row.taskComment, row.comment, row.role]
          .join(' ').toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      // Team
      if (f.team && row.team !== f.team) return false;
      // Scope
      if (f.scope && row.scopeStatus !== f.scope) return false;
      // Release
      if (f.release) {
        if (f.release === '1.20' && !row.hasRelease120) return false;
        if (f.release === '1.21' && !row.hasRelease121) return false;
        if (f.release === '1.22' && !row.hasRelease122) return false;
        if (f.release === 'overtime' && !row.hasOvertime) return false;
        if (f.release === 'none' && !row.isUnassigned) return false;
      }
      // Work type
      if (f.workType) {
        const allTypes = [
          ...row.release120Types, ...row.release121Types,
          ...row.release122Types, ...row.overtimeTypes,
        ];
        if (!allTypes.includes(f.workType)) return false;
      }
      // Role
      if (f.role && row.role !== f.role) return false;
      // Toggles
      if (f.onlyBlocking && !row.blockingDependency) return false;
      if (f.onlyDirty    && !row.dirty) return false;
      if (f.onlyRisky    && (!row.riskFlags || !row.riskFlags.length)) return false;

      return true;
    });
  },

  getTeams() {
    return Utils.unique(state.rows.map(r => r.team));
  },

  getWorkTypes() {
    const all = [];
    state.rows.forEach(r => {
      all.push(...r.release120Types, ...r.release121Types, ...r.release122Types, ...r.overtimeTypes);
    });
    return Utils.unique(all);
  },

  getRoles() {
    return Utils.unique(state.rows.map(r => r.role).filter(Boolean));
  },
};

// ============================================================
// RENDER HELPERS
// ============================================================
const RH = {
  scopeChip(status) {
    if (!status) return '<span class="chip chip-gray">—</span>';
    const map = {
      'Да': 'chip chip-green',
      'Нет': 'chip chip-gray',
      'Требует подтверждения': 'chip chip-yellow',
    };
    const cls = map[status] || 'chip chip-gray';
    const short = status === 'Требует подтверждения' ? 'Треб. подтв.' : status;
    return `<span class="${cls}">${short}</span>`;
  },

  workTypeChips(types) {
    if (!types || !types.length) return '<span class="text-muted text-sm">—</span>';
    return types.map(t => {
      const cls = WT_CLS[t] || 'wt-other';
      return `<span class="wt-tag ${cls}">${t}</span>`;
    }).join('');
  },

  riskBadges(flags) {
    if (!flags || !flags.length) return '';
    return flags.map(f => {
      const label = RISK_FLAGS[f] || f;
      const cls = f === 'BLOCKING_NEAR_RELEASE' ? 'risk-badge risk-badge-danger' : 'risk-badge';
      return `<span class="${cls}" title="${label}">⚠</span>`;
    }).join('');
  },

  dirtyBadge(dirty) {
    return dirty ? '<span class="chip chip-dirty">✎ Изм.</span>' : '';
  },

  yesNo(val) {
    return val ? '✓' : '';
  },
};

// ============================================================
// MULTISELECT COMPONENT
// ============================================================
const Multiselect = {
  _openDropdown: null,

  create(rowId, fieldName, currentValues, onChange) {
    const container = document.createElement('div');
    container.className = 'ms-container';

    const display = document.createElement('div');
    display.className = 'ms-display';

    const chipsWrap = document.createElement('span');
    chipsWrap.className = 'ms-chips-wrap';

    function renderChips() {
      chipsWrap.innerHTML = '';
      if (!currentValues || !currentValues.length) {
        const ph = document.createElement('span');
        ph.className = 'ms-placeholder';
        ph.textContent = 'Выбрать...';
        chipsWrap.appendChild(ph);
      } else {
        currentValues.forEach(v => {
          const chip = document.createElement('span');
          chip.className = 'ms-chip';
          chip.textContent = v;
          chipsWrap.appendChild(chip);
        });
      }
    }
    renderChips();

    const arrow = document.createElement('span');
    arrow.className = 'ms-arrow';
    arrow.textContent = '▾';

    display.appendChild(chipsWrap);
    display.appendChild(arrow);

    const dropdown = document.createElement('div');
    dropdown.className = 'ms-dropdown hidden';

    WORK_TYPES.forEach(opt => {
      const label = document.createElement('label');
      label.className = 'ms-option';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = opt;
      cb.checked = (currentValues || []).includes(opt);
      cb.addEventListener('change', () => {
        if (cb.checked) {
          if (!currentValues.includes(opt)) currentValues.push(opt);
        } else {
          const idx = currentValues.indexOf(opt);
          if (idx > -1) currentValues.splice(idx, 1);
        }
        renderChips();
        if (onChange) onChange(currentValues.slice());
      });
      label.appendChild(cb);
      label.appendChild(document.createTextNode(' ' + opt));
      dropdown.appendChild(label);
    });

    display.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = !dropdown.classList.contains('hidden');
      // Close any other open dropdown
      if (Multiselect._openDropdown && Multiselect._openDropdown !== dropdown) {
        Multiselect._openDropdown.classList.add('hidden');
        const prevDisplay = Multiselect._openDropdown.previousSibling;
        if (prevDisplay) prevDisplay.classList.remove('open');
      }
      if (isOpen) {
        dropdown.classList.add('hidden');
        display.classList.remove('open');
        Multiselect._openDropdown = null;
      } else {
        dropdown.classList.remove('hidden');
        display.classList.add('open');
        Multiselect._openDropdown = dropdown;
      }
    });

    container.appendChild(display);
    container.appendChild(dropdown);

    return container;
  },

  closeAll() {
    document.querySelectorAll('.ms-dropdown').forEach(d => d.classList.add('hidden'));
    document.querySelectorAll('.ms-display').forEach(d => d.classList.remove('open'));
    Multiselect._openDropdown = null;
  },
};

// Close multiselects on outside click
document.addEventListener('click', () => Multiselect.closeAll());

// ============================================================
// DASHBOARD VIEW
// ============================================================
const DashboardView = {
  render() {
    const rows = FilterEngine.getFiltered();
    DashboardView.renderKPIs(rows);
    DashboardView.renderRisksPanel(rows);
    DashboardView.renderReleaseBreakdown(rows);
    DashboardView.renderTeamsSummary(rows);
    DashboardView.renderNoReleaseTable(rows);
    DashboardView.renderNeedsConfirmTable(rows);
  },

  renderKPIs(rows) {
    const total = rows.length;
    const inScope = rows.filter(r => r.scopeStatus === 'Да').length;
    const outScope = rows.filter(r => r.scopeStatus === 'Нет').length;
    const needsConfirm = rows.filter(r => r.scopeStatus === 'Требует подтверждения').length;
    const inR120 = rows.filter(r => r.hasRelease120).length;
    const inR121 = rows.filter(r => r.hasRelease121).length;
    const inR122 = rows.filter(r => r.hasRelease122).length;
    const inOT  = rows.filter(r => r.hasOvertime).length;
    const noRel = rows.filter(r => r.isUnassigned).length;
    const blocking = rows.filter(r => r.blockingDependency).length;
    const risky = rows.filter(r => r.riskFlags && r.riskFlags.length > 0).length;
    const dirty = rows.filter(r => r.dirty).length;

    const kpis = [
      { label: 'Всего задач',       value: total,        cls: '' },
      { label: 'В scope (Да)',       value: inScope,      cls: 'kpi-green' },
      { label: 'Вне scope (Нет)',    value: outScope,     cls: 'kpi-gray' },
      { label: 'Требует подтв.',     value: needsConfirm, cls: 'kpi-yellow' },
      { label: 'В релизе 1.20',      value: inR120,       cls: 'kpi-blue' },
      { label: 'В релизе 1.21',      value: inR121,       cls: 'kpi-blue' },
      { label: 'В релизе 1.22',      value: inR122,       cls: 'kpi-blue' },
      { label: 'В овертайме',        value: inOT,         cls: 'kpi-red' },
      { label: 'Без релиза',         value: noRel,        cls: 'kpi-yellow' },
      { label: 'Блокирующих зав.',   value: blocking,     cls: 'kpi-red' },
      { label: 'Строк с рисками',    value: risky,        cls: risky > 0 ? 'kpi-red' : 'kpi-gray' },
      { label: 'Изменённых строк',   value: dirty,        cls: dirty > 0 ? 'kpi-purple' : 'kpi-gray' },
    ];

    const el = document.getElementById('dashboard-kpi');
    el.innerHTML = kpis.map(k => `
      <div class="kpi-card ${k.cls}">
        <div class="kpi-label">${k.label}</div>
        <div class="kpi-value">${k.value}</div>
      </div>
    `).join('');
  },

  renderRisksPanel(rows) {
    const byFlag = {};
    rows.forEach(r => {
      (r.riskFlags || []).forEach(f => {
        byFlag[f] = (byFlag[f] || 0) + 1;
      });
    });

    const el = document.getElementById('risks-panel');
    if (Object.keys(byFlag).length === 0) {
      el.innerHTML = `
        <div class="risks-panel-title">Риски внимания</div>
        <div class="text-muted text-sm">Нет активных рисков</div>`;
      return;
    }

    const items = Object.entries(byFlag).map(([flag, count]) => `
      <div class="risk-counter">
        <div class="risk-counter-value">${count}</div>
        <div class="risk-counter-label">${RISK_FLAGS[flag] || flag}</div>
      </div>
    `).join('');

    el.innerHTML = `
      <div class="risks-panel-title">Риски внимания</div>
      <div class="risks-panel-items">${items}</div>`;
  },

  renderReleaseBreakdown(rows) {
    const releases = [
      { key: 'r120', field: 'hasRelease120', typesField: 'release120Types' },
      { key: 'r121', field: 'hasRelease121', typesField: 'release121Types' },
      { key: 'r122', field: 'hasRelease122', typesField: 'release122Types' },
      { key: 'overtime', field: 'hasOvertime', typesField: 'overtimeTypes' },
    ];

    const el = document.getElementById('release-breakdown');
    el.innerHTML = releases.map(rel => {
      const rw = RELEASE_WINDOWS[rel.key];
      const relRows = rows.filter(r => r[rel.field]);
      const count = relRows.length;

      // Work type breakdown
      const wtMap = {};
      relRows.forEach(r => {
        (r[rel.typesField] || []).forEach(t => {
          wtMap[t] = (wtMap[t] || 0) + 1;
        });
      });

      // Scope breakdown
      const scopeMap = { 'Да': 0, 'Нет': 0, 'Требует подтверждения': 0, '': 0 };
      relRows.forEach(r => { scopeMap[r.scopeStatus] = (scopeMap[r.scopeStatus] || 0) + 1; });

      const wtRows = Object.entries(wtMap).slice(0, 4).map(([t, c]) =>
        `<div class="mini-breakdown-row">
           <span class="mini-breakdown-label">${t}</span>
           <span class="mini-breakdown-val">${c}</span>
         </div>`
      ).join('');

      return `
        <div class="release-card">
          <div class="release-card-header">
            <div class="release-card-title">${rw.label}</div>
            <div class="release-card-dates">${rw.dates}</div>
          </div>
          <div class="release-card-count">${count} задач</div>
          <div class="mini-breakdown">
            <div class="mini-breakdown-row">
              <span class="mini-breakdown-label">В scope (Да)</span>
              <span class="mini-breakdown-val">${scopeMap['Да'] || 0}</span>
            </div>
            <div class="mini-breakdown-row">
              <span class="mini-breakdown-label">Требует подтв.</span>
              <span class="mini-breakdown-val">${scopeMap['Требует подтверждения'] || 0}</span>
            </div>
            ${wtRows}
          </div>
        </div>`;
    }).join('');
  },

  renderTeamsSummary(rows) {
    const teams = Utils.unique(rows.map(r => r.team));
    if (!teams.length) { document.getElementById('teams-summary-wrap').innerHTML = ''; return; }

    const cols = ['Всего','Да','Нет','Треб.','1.20','1.21','1.22','OT','Без рел.','Блокер','Риски','Изм.'];
    const header = `<tr><th>Команда</th>${cols.map(c => `<th>${c}</th>`).join('')}</tr>`;

    const body = teams.map(team => {
      const tr = rows.filter(r => r.team === team);
      const cells = [
        tr.length,
        tr.filter(r => r.scopeStatus === 'Да').length,
        tr.filter(r => r.scopeStatus === 'Нет').length,
        tr.filter(r => r.scopeStatus === 'Требует подтверждения').length,
        tr.filter(r => r.hasRelease120).length,
        tr.filter(r => r.hasRelease121).length,
        tr.filter(r => r.hasRelease122).length,
        tr.filter(r => r.hasOvertime).length,
        tr.filter(r => r.isUnassigned).length,
        tr.filter(r => r.blockingDependency).length,
        tr.filter(r => r.riskFlags && r.riskFlags.length).length,
        tr.filter(r => r.dirty).length,
      ];
      return `<tr><td><strong>${team}</strong></td>${cells.map(c => `<td class="cell-number">${c || '—'}</td>`).join('')}</tr>`;
    }).join('');

    document.getElementById('teams-summary-wrap').innerHTML = `
      <div class="data-table-wrap">
        <div class="data-table-title">📊 Сводка по командам</div>
        <div style="overflow-x:auto">
          <table class="data-table">
            <thead>${header}</thead>
            <tbody>${body}</tbody>
          </table>
        </div>
      </div>`;
  },

  renderNoReleaseTable(rows) {
    const noRel = rows.filter(r => r.isUnassigned);
    const el = document.getElementById('no-release-wrap');

    if (!noRel.length) {
      el.innerHTML = `<div class="data-table-wrap"><div class="data-table-title">📭 Без релиза</div><div style="padding:20px;color:var(--text-3);font-size:12px;">Все задачи назначены на релизы</div></div>`;
      return;
    }

    const rows_html = noRel.slice(0, 50).map(r => `
      <tr>
        <td>${Utils.truncate(r.team, 16)}</td>
        <td>${Utils.truncate(r.epic, 24)}</td>
        <td>${Utils.truncate(r.tasks, 40)}</td>
        <td>${RH.scopeChip(r.scopeStatus)}</td>
        <td>${RH.riskBadges(r.riskFlags)}</td>
      </tr>`).join('');

    el.innerHTML = `
      <div class="data-table-wrap">
        <div class="data-table-title">📭 Без релиза <span class="count-badge">${noRel.length}</span></div>
        <div style="overflow-x:auto;max-height:320px;overflow-y:auto">
          <table class="data-table">
            <thead><tr><th>Команда</th><th>Эпик</th><th>Задача</th><th>Scope</th><th>Риски</th></tr></thead>
            <tbody>${rows_html}</tbody>
          </table>
        </div>
      </div>`;
  },

  renderNeedsConfirmTable(rows) {
    const nc = rows.filter(r => r.scopeStatus === 'Требует подтверждения');
    const el = document.getElementById('needs-confirm-wrap');

    if (!nc.length) {
      el.innerHTML = `<div class="data-table-wrap"><div class="data-table-title">⚠ Требует подтверждения</div><div style="padding:20px;color:var(--text-3);font-size:12px;">Нет задач без подтверждения</div></div>`;
      return;
    }

    const rows_html = nc.slice(0, 50).map(r => `
      <tr>
        <td>${Utils.truncate(r.team, 16)}</td>
        <td>${Utils.truncate(r.epic, 24)}</td>
        <td>${Utils.truncate(r.tasks, 40)}</td>
        <td>${RH.workTypeChips([...r.release120Types, ...r.release121Types, ...r.release122Types, ...r.overtimeTypes].slice(0,3))}</td>
        <td>${RH.riskBadges(r.riskFlags)}</td>
      </tr>`).join('');

    el.innerHTML = `
      <div class="data-table-wrap">
        <div class="data-table-title">⚠ Требует подтверждения <span class="count-badge">${nc.length}</span></div>
        <div style="overflow-x:auto;max-height:320px;overflow-y:auto">
          <table class="data-table">
            <thead><tr><th>Команда</th><th>Эпик</th><th>Задача</th><th>Тип работ</th><th>Риски</th></tr></thead>
            <tbody>${rows_html}</tbody>
          </table>
        </div>
      </div>`;
  },
};

// ============================================================
// REGISTRY VIEW
// ============================================================
const RegistryView = {
  render() {
    const filtered = FilterEngine.getFiltered();
    const sorted = RegistryView.applySorting(filtered);

    const table = document.getElementById('registry-table');
    const empty = document.getElementById('registry-empty');
    const badge = document.getElementById('registry-count-badge');

    badge.textContent = `${sorted.length} / ${state.rows.length}`;

    if (!sorted.length) {
      table.classList.add('hidden');
      empty.classList.remove('hidden');
      return;
    }
    table.classList.remove('hidden');
    empty.classList.add('hidden');

    RegistryView.renderHeader();
    RegistryView.renderBody(sorted);
  },

  applySorting(rows) {
    const { col, dir } = state.sort;
    if (!col) return rows;
    return [...rows].sort((a, b) => {
      let va = a[col]; let vb = b[col];
      if (va == null) va = ''; if (vb == null) vb = '';
      if (Array.isArray(va)) va = va.join(',');
      if (Array.isArray(vb)) vb = vb.join(',');
      const cmp = String(va).localeCompare(String(vb), 'ru', { numeric: true });
      return dir === 'asc' ? cmp : -cmp;
    });
  },

  renderHeader() {
    const thead = document.getElementById('registry-thead');
    const visibleCols = REGISTRY_COLS.filter(c => state.colVisibility[c.key] !== false);

    const ths = visibleCols.map(col => {
      const sortCls = state.sort.col === col.key
        ? (state.sort.dir === 'asc' ? 'sort-asc' : 'sort-desc') : '';
      return `<th class="${sortCls}" data-sortcol="${col.key}" style="min-width:${col.width || 100}px">${col.label}</th>`;
    });

    thead.innerHTML = `<tr>
      <th class="th-num">#</th>
      ${ths.join('')}
      <th style="min-width:60px">Риски</th>
      <th style="min-width:50px">Дейст.</th>
    </tr>`;

    thead.querySelectorAll('[data-sortcol]').forEach(th => {
      th.addEventListener('click', () => {
        const col = th.dataset.sortcol;
        if (state.sort.col === col) {
          state.sort.dir = state.sort.dir === 'asc' ? 'desc' : 'asc';
        } else {
          state.sort.col = col;
          state.sort.dir = 'asc';
        }
        RegistryView.render();
      });
    });
  },

  renderBody(rows) {
    const tbody = document.getElementById('registry-tbody');
    tbody.innerHTML = '';

    const visibleCols = REGISTRY_COLS.filter(c => state.colVisibility[c.key] !== false);

    rows.forEach((row, idx) => {
      const tr = document.createElement('tr');
      tr.dataset.rowId = row.id;
      if (row.dirty) tr.classList.add('row-dirty');
      if (row.riskFlags && row.riskFlags.length) tr.classList.add('row-risky');

      // Row number
      const tdNum = document.createElement('td');
      tdNum.className = 'td-num';
      tdNum.textContent = idx + 1;
      tr.appendChild(tdNum);

      // Visible columns
      visibleCols.forEach(col => {
        const td = document.createElement('td');
        td.dataset.col = col.key;
        RegistryView.renderCell(td, row, col);
        tr.appendChild(td);
      });

      // Risk flags column
      const tdRisk = document.createElement('td');
      tdRisk.innerHTML = RH.riskBadges(row.riskFlags) + RH.dirtyBadge(row.dirty);
      tr.appendChild(tdRisk);

      // Actions column
      const tdAct = document.createElement('td');
      const delBtn = document.createElement('button');
      delBtn.className = 'row-act-btn';
      delBtn.title = 'Удалить строку';
      delBtn.innerHTML = '✕';
      delBtn.addEventListener('click', () => RegistryView.deleteRow(row.id));
      tdAct.appendChild(delBtn);
      tr.appendChild(tdAct);

      tbody.appendChild(tr);
    });
  },

  renderCell(td, row, col) {
    const val = row[col.key];

    if (col.type === 'readonly') {
      td.innerHTML = `<span class="cell-text" style="pointer-events:none">${Utils.truncate(String(val || ''), 30)}</span>`;
      return;
    }

    if (col.type === 'multiselect') {
      const currentValues = Array.isArray(val) ? val : [];
      const ms = Multiselect.create(row.id, col.key, currentValues, (newVals) => {
        row[col.key] = newVals;
        row.dirty = true;
        row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row);
        Storage.save();
        App.refreshDashboardIfActive();
      });
      td.appendChild(ms);
      return;
    }

    if (col.type === 'scope') {
      const sel = document.createElement('select');
      sel.className = 'cell-select';
      ['', ...SCOPE_OPTIONS].forEach(opt => {
        const o = document.createElement('option');
        o.value = opt; o.textContent = opt || '—';
        if (val === opt) o.selected = true;
        sel.appendChild(o);
      });
      sel.addEventListener('change', () => {
        row[col.key] = sel.value;
        row.dirty = true;
        row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row);
        const tr = sel.closest('tr');
        if (tr) {
          tr.classList.toggle('row-risky', !!(row.riskFlags && row.riskFlags.length));
          // Update risk cell
          const tds = tr.querySelectorAll('td');
          const riskTd = tds[tds.length - 2];
          if (riskTd) riskTd.innerHTML = RH.riskBadges(row.riskFlags) + RH.dirtyBadge(row.dirty);
        }
        Storage.save();
        App.refreshDashboardIfActive();
      });
      td.appendChild(sel);
      return;
    }

    if (col.type === 'checkbox') {
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = !!val;
      cb.style.cursor = 'pointer';
      cb.addEventListener('change', () => {
        row[col.key] = cb.checked;
        row.dirty = true;
        row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row);
        // Enable/disable deadline field
        const tr = cb.closest('tr');
        if (tr) {
          const deadlineTd = tr.querySelector('[data-col="blockingDeadline"]');
          if (deadlineTd) {
            const inp = deadlineTd.querySelector('input');
            if (inp) inp.disabled = !cb.checked;
          }
          const tds = tr.querySelectorAll('td');
          const riskTd = tds[tds.length - 2];
          if (riskTd) riskTd.innerHTML = RH.riskBadges(row.riskFlags) + RH.dirtyBadge(row.dirty);
        }
        Storage.save();
        App.refreshDashboardIfActive();
      });
      td.appendChild(cb);
      return;
    }

    if (col.type === 'date') {
      const inp = document.createElement('input');
      inp.type = 'date';
      inp.className = 'cell-input';
      inp.value = val || '';
      inp.disabled = !row.blockingDependency;
      inp.addEventListener('change', () => {
        row[col.key] = inp.value;
        row.dirty = true;
        row.updatedAt = new Date().toISOString();
        Storage.save();
      });
      td.appendChild(inp);
      return;
    }

    if (col.type === 'number') {
      const inp = document.createElement('input');
      inp.type = 'number';
      inp.className = 'cell-input cell-number';
      inp.value = val || '';
      inp.min = 0;
      inp.style.width = '70px';
      inp.addEventListener('change', () => {
        row[col.key] = inp.value;
        row.dirty = true;
        row.updatedAt = new Date().toISOString();
        Storage.save();
      });
      td.appendChild(inp);
      return;
    }

    // Default: text
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.className = 'cell-input';
    inp.value = val || '';
    inp.style.width = '100%';
    inp.addEventListener('change', () => {
      row[col.key] = inp.value.trim();
      row.dirty = true;
      row.updatedAt = new Date().toISOString();
      RowFactory.updateDerived(row);
      // Update filter dropdowns with new values
      App.populateFilterDropdowns();
      Storage.save();
      App.refreshDashboardIfActive();
    });
    td.appendChild(inp);
  },

  deleteRow(id) {
    state.rows = state.rows.filter(r => r.id !== id);
    Storage.save();
    RegistryView.render();
    App.updateTopbarBadge();
    App.refreshDashboardIfActive();
  },

  addRow() {
    const row = RowFactory.create({ dirty: true, sourceType: 'manual' });
    state.rows.unshift(row);
    Storage.save();
    RegistryView.render();
    App.updateTopbarBadge();
  },

  renderColTogglePanel() {
    const panel = document.getElementById('col-toggle-panel');
    panel.innerHTML = REGISTRY_COLS.map(col => `
      <label class="col-toggle-item">
        <input type="checkbox" data-col="${col.key}" ${state.colVisibility[col.key] !== false ? 'checked' : ''}>
        ${col.label}
      </label>
    `).join('');

    panel.querySelectorAll('input[data-col]').forEach(cb => {
      cb.addEventListener('change', () => {
        state.colVisibility[cb.dataset.col] = cb.checked;
        RegistryView.render();
      });
    });
  },
};

// ============================================================
// GANTT VIEW
// ============================================================
const GanttView = {
  filters: { team: '', scope: '', onlyBlocking: false, onlyNoRelease: false, onlyRisky: false, onlyDirty: false },

  render() {
    GanttView.renderFilters();
    GanttView.renderChart();
  },

  renderFilters() {
    const el = document.getElementById('gantt-filters');
    const teams = FilterEngine.getTeams();
    el.innerHTML = `
      <div class="filter-group">
        <label class="filter-label">Команда</label>
        <select id="gantt-filter-team" class="filter-select">
          <option value="">Все</option>
          ${teams.map(t => `<option value="${t}" ${GanttView.filters.team === t ? 'selected' : ''}>${t}</option>`).join('')}
        </select>
      </div>
      <div class="filter-group">
        <label class="filter-label">Scope</label>
        <select id="gantt-filter-scope" class="filter-select">
          <option value="">Все</option>
          ${SCOPE_OPTIONS.map(s => `<option value="${s}" ${GanttView.filters.scope === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </div>
      <label class="toggle-chip">
        <input type="checkbox" id="gantt-filter-blocking" ${GanttView.filters.onlyBlocking ? 'checked' : ''}> Только блокеры
      </label>
      <label class="toggle-chip">
        <input type="checkbox" id="gantt-filter-norelease" ${GanttView.filters.onlyNoRelease ? 'checked' : ''}> Только без релиза
      </label>
      <label class="toggle-chip">
        <input type="checkbox" id="gantt-filter-risky" ${GanttView.filters.onlyRisky ? 'checked' : ''}> Только рисковые
      </label>
      <label class="toggle-chip">
        <input type="checkbox" id="gantt-filter-dirty" ${GanttView.filters.onlyDirty ? 'checked' : ''}> Только изменённые
      </label>`;

    el.querySelector('#gantt-filter-team').addEventListener('change', e => { GanttView.filters.team = e.target.value; GanttView.renderChart(); });
    el.querySelector('#gantt-filter-scope').addEventListener('change', e => { GanttView.filters.scope = e.target.value; GanttView.renderChart(); });
    el.querySelector('#gantt-filter-blocking').addEventListener('change', e => { GanttView.filters.onlyBlocking = e.target.checked; GanttView.renderChart(); });
    el.querySelector('#gantt-filter-norelease').addEventListener('change', e => { GanttView.filters.onlyNoRelease = e.target.checked; GanttView.renderChart(); });
    el.querySelector('#gantt-filter-risky').addEventListener('change', e => { GanttView.filters.onlyRisky = e.target.checked; GanttView.renderChart(); });
    el.querySelector('#gantt-filter-dirty').addEventListener('change', e => { GanttView.filters.onlyDirty = e.target.checked; GanttView.renderChart(); });
  },

  getGanttRows() {
    let rows = FilterEngine.getFiltered();
    const f = GanttView.filters;
    if (f.team) rows = rows.filter(r => r.team === f.team);
    if (f.scope) rows = rows.filter(r => r.scopeStatus === f.scope);
    if (f.onlyBlocking) rows = rows.filter(r => r.blockingDependency);
    if (f.onlyNoRelease) rows = rows.filter(r => r.isUnassigned);
    if (f.onlyRisky) rows = rows.filter(r => r.riskFlags && r.riskFlags.length);
    if (f.onlyDirty) rows = rows.filter(r => r.dirty);
    return rows;
  },

  renderChart() {
    const wrap = document.getElementById('gantt-wrap');
    const rows = GanttView.getGanttRows();
    const mode = state.ganttMode;

    if (!rows.length) {
      wrap.innerHTML = '<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных для отображения</div></div>';
      return;
    }

    const cols = [
      { key: 'backlog',   label: 'Бэклог', sub: '', cls: 'gantt-window-backlog' },
      { key: 'r120',      label: '1.20', sub: '20.04–17.05', cls: 'gantt-window-r120' },
      { key: 'r121',      label: '1.21', sub: '18.05–14.06', cls: 'gantt-window-r121' },
      { key: 'r122',      label: '1.22', sub: '15.06–14.07', cls: 'gantt-window-r122' },
      { key: 'overtime',  label: 'OT', sub: 'Овертайм', cls: 'gantt-window-overtime' },
    ];

    const labelWidth = 220;
    const colWidth = 160;
    const totalWidth = labelWidth + cols.length * colWidth;

    const gridTemplate = `${labelWidth}px repeat(${cols.length}, ${colWidth}px)`;

    const headerHtml = `
      <div class="gantt-header" style="display:grid;grid-template-columns:${gridTemplate}">
        <div class="gantt-header-label">Команда / Задача</div>
        ${cols.map(c => `
          <div class="gantt-header-col">
            <div>${c.label}</div>
            <div style="font-size:10px;font-weight:400;color:var(--text-4)">${c.sub}</div>
          </div>`).join('')}
      </div>`;

    let bodyHtml = '';

    if (mode === 'compact') {
      // Group by team
      const teams = Utils.unique(rows.map(r => r.team));
      teams.forEach(team => {
        const teamRows = rows.filter(r => r.team === team);
        const cells = cols.map(col => {
          if (col.key === 'backlog') {
            const count = teamRows.filter(r => r.isUnassigned).length;
            return `<div class="gantt-cell ${col.cls}">${count > 0 ? `<div class="gantt-bar gantt-bar-backlog">${count}</div>` : ''}</div>`;
          }
          const fieldMap = { r120: 'hasRelease120', r121: 'hasRelease121', r122: 'hasRelease122', overtime: 'hasOvertime' };
          const typeField = { r120: 'release120Types', r121: 'release121Types', r122: 'release122Types', overtime: 'overtimeTypes' };
          const count = teamRows.filter(r => r[fieldMap[col.key]]).length;
          const types = {};
          teamRows.forEach(r => { (r[typeField[col.key]] || []).forEach(t => { types[t] = (types[t]||0)+1; }); });
          const barCls = RELEASE_WINDOWS[col.key] ? RELEASE_WINDOWS[col.key].cls : '';
          return `<div class="gantt-cell ${col.cls}">${count > 0 ? `<div class="gantt-bar ${barCls}">${count} задач</div>` : ''}</div>`;
        });
        bodyHtml += `
          <div class="gantt-row" style="display:grid;grid-template-columns:${gridTemplate}">
            <div class="gantt-row-label">
              <div class="gantt-row-label-name">${team}</div>
              <div class="gantt-row-label-sub">${teamRows.length} задач</div>
            </div>
            ${cells.join('')}
          </div>`;
      });
    } else {
      // Detailed: one row per task
      rows.slice(0, 200).forEach(row => {
        const cells = cols.map(col => {
          if (col.key === 'backlog') {
            return `<div class="gantt-cell ${col.cls}">${row.isUnassigned ? `<div class="gantt-bar gantt-bar-backlog" title="${row.tasks}">•</div>` : ''}</div>`;
          }
          const fieldMap = { r120: 'hasRelease120', r121: 'hasRelease121', r122: 'hasRelease122', overtime: 'hasOvertime' };
          const typeField = { r120: 'release120Types', r121: 'release121Types', r122: 'release122Types', overtime: 'overtimeTypes' };
          const has = row[fieldMap[col.key]];
          const barCls = RELEASE_WINDOWS[col.key] ? RELEASE_WINDOWS[col.key].cls : '';
          const types = row[typeField[col.key]] || [];
          return `<div class="gantt-cell ${col.cls}">${has ? `<div class="gantt-bar ${barCls}" title="${types.join(', ')}">${types.slice(0,2).join(', ') || '•'}</div>` : ''}</div>`;
        });
        const riskBadges = RH.riskBadges(row.riskFlags);
        bodyHtml += `
          <div class="gantt-row" style="display:grid;grid-template-columns:${gridTemplate}">
            <div class="gantt-row-label">
              <div class="gantt-row-label-name" title="${row.tasks}">${RH.dirtyBadge(row.dirty)} ${riskBadges} ${Utils.truncate(row.epic || row.tasks, 28)}</div>
              <div class="gantt-row-label-sub">${row.team}</div>
            </div>
            ${cells.join('')}
          </div>`;
      });
      if (rows.length > 200) {
        bodyHtml += `<div style="padding:8px 14px;font-size:11px;color:var(--text-4)">...ещё ${rows.length - 200} строк. Используйте фильтры для сужения.</div>`;
      }
    }

    const legendHtml = `
      <div class="gantt-legend">
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:var(--text-3)"></div> Бэклог</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#4f46e5"></div> 1.20</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#059669"></div> 1.21</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#d97706"></div> 1.22</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:var(--danger)"></div> Овертайм</div>
      </div>`;

    wrap.innerHTML = `<div class="gantt-container">${headerHtml}<div>${bodyHtml}</div>${legendHtml}</div>`;
  },
};

// ============================================================
// KANBAN VIEW
// ============================================================
const KanbanView = {
  render() {
    const filtered = FilterEngine.getFiltered();
    const board = document.getElementById('kanban-board');

    const columns = [
      { key: 'backlog',   label: 'Без релиза', filter: r => r.isUnassigned,   cls: '' },
      { key: 'r120',      label: 'Релиз 1.20', filter: r => r.hasRelease120,  cls: '' },
      { key: 'r121',      label: 'Релиз 1.21', filter: r => r.hasRelease121,  cls: '' },
      { key: 'r122',      label: 'Релиз 1.22', filter: r => r.hasRelease122,  cls: '' },
      { key: 'overtime',  label: 'Овертайм',   filter: r => r.hasOvertime,    cls: '' },
    ];

    board.innerHTML = columns.map(col => {
      const colRows = filtered.filter(col.filter);
      const cards = colRows.slice(0, 100).map(row => {
        let borderCls = '';
        if (row.blockingDependency) borderCls = 'card-blocking';
        else if (row.riskFlags && row.riskFlags.length) borderCls = 'card-risky';
        else if (row.dirty) borderCls = 'card-dirty';

        const typeField = { r120: 'release120Types', r121: 'release121Types', r122: 'release122Types', overtime: 'overtimeTypes' };
        const types = row[typeField[col.key]] || [];

        return `
          <div class="kanban-card ${borderCls}">
            <div class="kanban-card-team">${row.team}</div>
            <div class="kanban-card-epic">${Utils.truncate(row.epic, 40)}</div>
            <div class="kanban-card-task">${Utils.truncate(row.tasks, 80)}</div>
            <div class="kanban-card-meta">
              ${RH.scopeChip(row.scopeStatus)}
              ${types.length ? RH.workTypeChips(types) : ''}
              ${row.role ? `<span class="chip chip-indigo">${row.role}</span>` : ''}
              ${row.blockingDependency ? `<span class="chip chip-red" title="${row.blockingDeadline ? 'До: ' + row.blockingDeadline : ''}">🚧 Блокер</span>` : ''}
              ${RH.riskBadges(row.riskFlags)}
              ${RH.dirtyBadge(row.dirty)}
            </div>
          </div>`;
      }).join('');

      const overflow = colRows.length > 100
        ? `<div style="padding:8px;font-size:11px;color:var(--text-4)">...ещё ${colRows.length - 100}</div>`
        : '';

      return `
        <div class="kanban-col">
          <div class="kanban-col-header">
            <span>${col.label}</span>
            <span class="kanban-col-header-badge">${colRows.length}</span>
          </div>
          <div class="kanban-col-body">
            ${cards || '<div style="padding:12px;font-size:12px;color:var(--text-4)">Нет задач</div>'}
            ${overflow}
          </div>
        </div>`;
    }).join('');
  },
};

// ============================================================
// TIMELINE VIEW
// ============================================================
const TimelineView = {
  render() {
    const filtered = FilterEngine.getFiltered();
    const wrap = document.getElementById('timeline-wrap');

    const stages = [
      { key: 'backlog',  label: 'Бэклог',    dates: '',           stageCls: 'stage-backlog',  filter: r => r.isUnassigned },
      { key: 'r120',     label: 'Релиз 1.20', dates: '20.04–17.05', stageCls: 'stage-r120',   filter: r => r.hasRelease120 },
      { key: 'r121',     label: 'Релиз 1.21', dates: '18.05–14.06', stageCls: 'stage-r121',   filter: r => r.hasRelease121 },
      { key: 'r122',     label: 'Релиз 1.22', dates: '15.06–14.07', stageCls: 'stage-r122',   filter: r => r.hasRelease122 },
      { key: 'overtime', label: 'Овертайм',   dates: '',           stageCls: 'stage-overtime', filter: r => r.hasOvertime },
    ];

    const stageData = stages.map(s => {
      const rows = filtered.filter(s.filter);
      const count = rows.length;
      const wtMap = {};
      const typeField = { r120: 'release120Types', r121: 'release121Types', r122: 'release122Types', overtime: 'overtimeTypes', backlog: null };
      rows.forEach(r => {
        const tf = typeField[s.key];
        if (tf) {
          (r[tf] || []).forEach(t => { wtMap[t] = (wtMap[t]||0)+1; });
        }
      });
      const scopeCount = { 'Да': 0, 'Нет': 0, 'Требует подтверждения': 0 };
      rows.forEach(r => { if (r.scopeStatus in scopeCount) scopeCount[r.scopeStatus]++; });
      return { ...s, count, wtMap, scopeCount, rows };
    });

    const maxCount = Math.max(...stageData.map(s => s.count), 1);

    // Build work type color map
    const wtColors = {
      'backend': '#3b82f6',
      'frontend': '#22c55e',
      'тестирование': '#a855f7',
      'аналитика': '#f97316',
      'бизнес аналитика': '#f97316',
      'внедрение': '#06b6d4',
      'миграция данных': '#84cc16',
      'стабилизация': '#64748b',
      'хотфикс': '#ef4444',
    };

    // Task count section
    const countBarsSVG = stageData.map(s => {
      const pct = s.count / maxCount * 100;
      return `
        <div class="timeline-stage">
          <div class="timeline-stage-header ${s.stageCls}">
            ${s.label}<br><span style="font-size:10px;font-weight:400">${s.dates}</span>
          </div>
          <div class="timeline-stage-body">
            <div class="timeline-stat" style="color:var(--text-2)">${s.count}</div>
            <div class="timeline-stat-sub">задач</div>
            <div style="height:6px;background:var(--border-light);border-radius:3px;margin-top:8px;overflow:hidden">
              <div style="height:100%;width:${pct}%;background:currentColor;border-radius:3px;transition:width .3s" class="${s.stageCls}"></div>
            </div>
          </div>
        </div>`;
    }).join('');

    // Work type bars
    const allWtKeys = Utils.unique(stageData.flatMap(s => Object.keys(s.wtMap)));
    const wtSection = allWtKeys.length ? `
      <div class="timeline-section">
        <div class="timeline-section-title">По типу работ</div>
        ${stageData.map(s => {
          const total = Object.values(s.wtMap).reduce((a,b)=>a+b,0) || 1;
          const segs = allWtKeys.map(wt => {
            const c = s.wtMap[wt] || 0;
            if (!c) return '';
            const pct = c / total * 100;
            const color = wtColors[wt] || '#888';
            return `<div class="timeline-bar-seg" title="${wt}: ${c}" style="width:${pct}%;background:${color}"></div>`;
          }).join('');
          return `
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
              <div style="width:120px;font-size:11px;font-weight:600;color:var(--text-3);text-align:right;flex-shrink:0">${s.label}</div>
              <div class="timeline-bar-wrap" style="flex:1">${segs || `<div style="height:100%;width:100%;background:var(--border-light)"></div>`}</div>
              <div style="width:30px;font-size:11px;color:var(--text-3)">${s.count}</div>
            </div>`;
        }).join('')}
        <div class="timeline-legend">
          ${allWtKeys.map(wt => `<div class="legend-item"><div class="legend-dot" style="background:${wtColors[wt]||'#888'}"></div>${wt}</div>`).join('')}
        </div>
      </div>` : '';

    // Scope section
    const scopeSection = `
      <div class="timeline-section">
        <div class="timeline-section-title">По статусу Scope</div>
        ${stageData.map(s => {
          const total = s.count || 1;
          const scSegs = [
            { label: 'Да', color: '#059669' },
            { label: 'Нет', color: '#9ca3af' },
            { label: 'Требует подтверждения', color: '#d97706' },
          ].map(sc => {
            const c = s.scopeCount[sc.label] || 0;
            if (!c) return '';
            const pct = c / total * 100;
            return `<div class="timeline-bar-seg" title="${sc.label}: ${c}" style="width:${pct}%;background:${sc.color}"></div>`;
          }).join('');
          return `
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
              <div style="width:120px;font-size:11px;font-weight:600;color:var(--text-3);text-align:right;flex-shrink:0">${s.label}</div>
              <div class="timeline-bar-wrap" style="flex:1">${scSegs || `<div style="height:100%;width:100%;background:var(--border-light)"></div>`}</div>
              <div style="width:30px;font-size:11px;color:var(--text-3)">${s.count}</div>
            </div>`;
        }).join('')}
        <div class="timeline-legend">
          <div class="legend-item"><div class="legend-dot" style="background:#059669"></div>Да</div>
          <div class="legend-item"><div class="legend-dot" style="background:#9ca3af"></div>Нет</div>
          <div class="legend-item"><div class="legend-dot" style="background:#d97706"></div>Требует подтв.</div>
        </div>
      </div>`;

    wrap.innerHTML = `
      <div class="timeline-section">
        <div class="timeline-section-title">Количество задач по стадиям</div>
        <div class="timeline-stages">${countBarsSVG}</div>
      </div>
      ${wtSection}
      ${scopeSection}`;
  },
};

// ============================================================
// DIAGNOSTICS VIEW
// ============================================================
const DiagnosticsView = {
  render() {
    const d = state.diagnostics;
    const wrap = document.getElementById('diagnostics-wrap');

    // General card
    const generalRows = [
      ['Источник данных', (d.sources || []).join(', ') || '—'],
      ['Всего строк в реестре', d.registryCount || 0],
      ['Строк из CSV-импорта', d.csvImportCount || 0],
      ['Строк из localStorage', d.localStorageCount || 0],
    ];

    const sheetsCard = d.sheets && d.sheets.length ? `
      <div class="diag-card">
        <div class="diag-card-header">Листы XLSX</div>
        <div class="diag-card-body">
          ${d.sheets.map(s => {
            const cnt = (d.rowsPerSheet || {})[s];
            return `<div class="diag-row">
              <span class="diag-key">${s}</span>
              <span class="diag-val">${cnt != null ? cnt + ' строк' : '—'}</span>
            </div>`;
          }).join('')}
        </div>
      </div>` : '';

    const colCards = d.sheets && d.sheets.length ? d.sheets.map(s => {
      const detected = d.detectedColumns ? d.detectedColumns[s] : {};
      const missing = d.missingColumns ? d.missingColumns[s] : [];
      const detectedHtml = Object.entries(detected || {}).map(([field, info]) =>
        `<span class="diag-col-item" title="idx: ${info.index}, header: ${info.originalHeader}">${field} [${info.index}]</span>`
      ).join('');
      const missingHtml = (missing || []).map(f => `<span class="diag-col-item diag-col-missing">${f}</span>`).join('');
      return `
        <div class="diag-card">
          <div class="diag-card-header">Колонки: ${s}</div>
          <div class="diag-card-body">
            <div class="diag-row"><span class="diag-key">Обнаружено</span></div>
            <div class="diag-col-list">${detectedHtml || '—'}</div>
            ${missing && missing.length ? `<div style="margin-top:8px"><div class="diag-row"><span class="diag-key" style="color:var(--danger)">Не найдено</span></div><div class="diag-col-list">${missingHtml}</div></div>` : ''}
          </div>
        </div>`;
    }).join('') : '';

    const warningsCard = d.warnings && d.warnings.length ? `
      <div class="diag-card">
        <div class="diag-card-header">⚠ Предупреждения</div>
        <div class="diag-card-body">
          ${d.warnings.map(w => `<div class="diag-warning">${w}</div>`).join('')}
        </div>
      </div>` : '';

    wrap.innerHTML = `
      <div class="diag-card">
        <div class="diag-card-header">Общая информация</div>
        <div class="diag-card-body">
          ${generalRows.map(([k, v]) => `<div class="diag-row"><span class="diag-key">${k}</span><span class="diag-val">${v}</span></div>`).join('')}
        </div>
      </div>
      ${sheetsCard}
      ${colCards}
      ${warningsCard}
      <div class="diag-card">
        <div class="diag-card-header">Маппинг заголовков</div>
        <div class="diag-card-body" style="font-size:12px">
          <div class="diag-row"><span class="diag-key">категория</span><span class="diag-val">→ category</span></div>
          <div class="diag-row"><span class="diag-key">эпик</span><span class="diag-val">→ epic</span></div>
          <div class="diag-row"><span class="diag-key">оценка</span><span class="diag-val">→ total_estimate (legacy)</span></div>
          <div class="diag-row"><span class="diag-key">задачи</span><span class="diag-val">→ tasks</span></div>
          <div class="diag-row"><span class="diag-key">коммент к задачам</span><span class="diag-val">→ taskComment</span></div>
          <div class="diag-row"><span class="diag-key">зависимость от команд</span><span class="diag-val">→ teamDependency</span></div>
          <div class="diag-row"><span class="diag-key">риски</span><span class="diag-val">→ risks</span></div>
          <div class="diag-row"><span class="diag-key">содержит "релиз 1.20"</span><span class="diag-val">→ release120Types</span></div>
          <div class="diag-row"><span class="diag-key">содержит "релиз 1.21"</span><span class="diag-val">→ release121Types</span></div>
          <div class="diag-row"><span class="diag-key">содержит "релиз 1.22"</span><span class="diag-val">→ release122Types (новое)</span></div>
          <div class="diag-row"><span class="diag-key">содержит "входит в скоуп"</span><span class="diag-val">→ scopeStatus</span></div>
          <div class="diag-row"><span class="diag-key">комментарий</span><span class="diag-val">→ comment</span></div>
        </div>
      </div>`;
  },
};

// ============================================================
// GLOBAL FILTERS UI
// ============================================================
const FiltersUI = {
  init() {
    document.getElementById('filter-search').addEventListener('input', e => {
      state.filters.search = e.target.value.trim();
      App.refreshCurrentSection();
    });
    document.getElementById('filter-team').addEventListener('change', e => {
      state.filters.team = e.target.value;
      App.refreshCurrentSection();
    });
    document.getElementById('filter-scope').addEventListener('change', e => {
      state.filters.scope = e.target.value;
      App.refreshCurrentSection();
    });
    document.getElementById('filter-release').addEventListener('change', e => {
      state.filters.release = e.target.value;
      App.refreshCurrentSection();
    });
    document.getElementById('filter-worktype').addEventListener('change', e => {
      state.filters.workType = e.target.value;
      App.refreshCurrentSection();
    });
    document.getElementById('filter-role').addEventListener('change', e => {
      state.filters.role = e.target.value;
      App.refreshCurrentSection();
    });
    document.getElementById('filter-blocking').addEventListener('change', e => {
      state.filters.onlyBlocking = e.target.checked;
      document.getElementById('toggle-blocking').classList.toggle('active', e.target.checked);
      App.refreshCurrentSection();
    });
    document.getElementById('filter-dirty').addEventListener('change', e => {
      state.filters.onlyDirty = e.target.checked;
      document.getElementById('toggle-dirty').classList.toggle('active', e.target.checked);
      App.refreshCurrentSection();
    });
    document.getElementById('filter-risky').addEventListener('change', e => {
      state.filters.onlyRisky = e.target.checked;
      document.getElementById('toggle-risky').classList.toggle('active', e.target.checked);
      App.refreshCurrentSection();
    });
    document.getElementById('btn-reset-filters').addEventListener('click', () => {
      FiltersUI.reset();
    });

    // Presets
    document.querySelectorAll('.preset-btn[data-preset]').forEach(btn => {
      btn.addEventListener('click', () => {
        const preset = btn.dataset.preset;
        FiltersUI.applyPreset(preset);
      });
    });
  },

  applyPreset(preset) {
    // Deactivate all presets first
    document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));

    if (preset === 'reset') {
      state.filters.preset = null;
      state.filters.onlyBlocking = false;
      state.filters.onlyDirty = false;
      state.filters.onlyRisky = false;
      state.filters.scope = '';
      state.filters.release = '';
      FiltersUI.syncUI();
      App.refreshCurrentSection();
      return;
    }

    state.filters.preset = preset;
    document.querySelector(`.preset-btn[data-preset="${preset}"]`).classList.add('active');

    // Reset overlay preset fields
    state.filters.onlyBlocking = false;
    state.filters.onlyDirty = false;
    state.filters.onlyRisky = false;
    state.filters.scope = '';
    state.filters.release = '';

    switch (preset) {
      case 'critical':     state.filters.onlyRisky = true;    break;
      case 'no-release':   state.filters.release = 'none';    break;
      case 'needs-confirm': state.filters.scope = 'Требует подтверждения'; break;
      case 'has-blocker':  state.filters.onlyBlocking = true; break;
      case 'overtime':     state.filters.release = 'overtime'; break;
      case 'my-changes':   state.filters.onlyDirty = true;    break;
    }

    FiltersUI.syncUI();
    App.refreshCurrentSection();
  },

  syncUI() {
    document.getElementById('filter-scope').value = state.filters.scope || '';
    document.getElementById('filter-release').value = state.filters.release || '';
    document.getElementById('filter-blocking').checked = state.filters.onlyBlocking;
    document.getElementById('filter-dirty').checked = state.filters.onlyDirty;
    document.getElementById('filter-risky').checked = state.filters.onlyRisky;
    document.getElementById('toggle-blocking').classList.toggle('active', state.filters.onlyBlocking);
    document.getElementById('toggle-dirty').classList.toggle('active', state.filters.onlyDirty);
    document.getElementById('toggle-risky').classList.toggle('active', state.filters.onlyRisky);
  },

  reset() {
    state.filters = {
      search: '', team: '', scope: '', release: '',
      workType: '', role: '',
      onlyBlocking: false, onlyDirty: false, onlyRisky: false,
      preset: null,
    };
    document.getElementById('filter-search').value = '';
    document.getElementById('filter-team').value = '';
    document.getElementById('filter-scope').value = '';
    document.getElementById('filter-release').value = '';
    document.getElementById('filter-worktype').value = '';
    document.getElementById('filter-role').value = '';
    FiltersUI.syncUI();
    document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
    App.refreshCurrentSection();
  },

  populateDropdowns() {
    const teams = FilterEngine.getTeams();
    const wts = FilterEngine.getWorkTypes();
    const roles = FilterEngine.getRoles();

    const teamSel = document.getElementById('filter-team');
    const curTeam = teamSel.value;
    teamSel.innerHTML = '<option value="">Все</option>' + teams.map(t => `<option value="${t}" ${curTeam===t?'selected':''}>${t}</option>`).join('');

    const wtSel = document.getElementById('filter-worktype');
    const curWt = wtSel.value;
    wtSel.innerHTML = '<option value="">Все</option>' + wts.map(t => `<option value="${t}" ${curWt===t?'selected':''}>${t}</option>`).join('');

    const roleSel = document.getElementById('filter-role');
    const curRole = roleSel.value;
    roleSel.innerHTML = '<option value="">Все</option>' + roles.map(r => `<option value="${r}" ${curRole===r?'selected':''}>${r}</option>`).join('');
  },
};

// ============================================================
// NAVIGATION
// ============================================================
const Nav = {
  init() {
    document.querySelectorAll('.nav-item[data-section]').forEach(btn => {
      btn.addEventListener('click', () => {
        const section = btn.dataset.section;
        Nav.goTo(section);
      });
    });
  },

  goTo(section) {
    state.activeSection = section;

    // Update nav
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    const activeBtn = document.querySelector(`.nav-item[data-section="${section}"]`);
    if (activeBtn) activeBtn.classList.add('active');

    // Show section
    document.querySelectorAll('.app-section').forEach(s => s.classList.add('hidden'));
    const el = document.getElementById(`section-${section}`);
    if (el) el.classList.remove('hidden');

    // Render section
    App.renderSection(section);
  },
};

// ============================================================
// MAIN APP
// ============================================================
const App = {
  init() {
    Nav.init();
    FiltersUI.init();
    App.bindImports();
    App.bindExport();
    App.bindClear();
    App.bindAddRow();
    App.bindColToggle();
    App.bindGanttModes();

    // Check localStorage
    const saved = Storage.load();
    if (saved && saved.rows && saved.rows.length > 0) {
      const meta = document.getElementById('modal-restore-meta');
      meta.textContent = `Сохранено ${saved.rows.length} строк от ${new Date(saved.savedAt).toLocaleString('ru')}.`;
      document.getElementById('modal-restore').classList.remove('hidden');

      document.getElementById('btn-restore-yes').onclick = () => {
        Storage.restore(saved);
        RiskEngine.computeAll();
        document.getElementById('modal-restore').classList.add('hidden');
        App.populateFilterDropdowns();
        App.renderSection('dashboard');
        App.updateTopbarBadge();
      };

      document.getElementById('btn-restore-no').onclick = () => {
        Storage.clear();
        document.getElementById('modal-restore').classList.add('hidden');
        App.renderSection('dashboard');
      };
    } else {
      App.renderSection('dashboard');
    }
  },

  bindImports() {
    document.getElementById('input-xlsx').addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => {
        const data = new Uint8Array(ev.target.result);
        XLSXImporter.import(data);
        App.populateFilterDropdowns();
        e.target.value = '';
      };
      reader.readAsArrayBuffer(file);
    });

    document.getElementById('input-csv').addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => {
        CSV.import(ev.target.result);
        App.populateFilterDropdowns();
        e.target.value = '';
      };
      reader.readAsText(file, 'utf-8');
    });
  },

  bindExport() {
    document.getElementById('btn-export-csv').addEventListener('click', () => {
      if (!state.rows.length) { alert('Нет данных для экспорта'); return; }
      CSV.export();
    });
  },

  bindClear() {
    document.getElementById('btn-clear-storage').addEventListener('click', () => {
      if (confirm('Очистить все локальные данные? Это удалит все строки и изменения.')) {
        Storage.clear();
        state.rows = [];
        state.diagnostics = {
          sources: [], sheets: [], rowsPerSheet: {}, detectedColumns: {}, missingColumns: {}, warnings: [],
          registryCount: 0, csvImportCount: 0, localStorageCount: 0,
        };
        App.populateFilterDropdowns();
        App.refreshAll();
        App.updateTopbarBadge();
      }
    });
  },

  bindAddRow() {
    document.getElementById('btn-add-row').addEventListener('click', () => {
      RegistryView.addRow();
    });
  },

  bindColToggle() {
    document.getElementById('btn-toggle-cols').addEventListener('click', () => {
      const panel = document.getElementById('col-toggle-panel');
      panel.classList.toggle('hidden');
      if (!panel.classList.contains('hidden')) {
        RegistryView.renderColTogglePanel();
      }
    });
  },

  bindGanttModes() {
    document.getElementById('gantt-mode-compact').addEventListener('click', () => {
      state.ganttMode = 'compact';
      document.getElementById('gantt-mode-compact').classList.add('active');
      document.getElementById('gantt-mode-detailed').classList.remove('active');
      GanttView.renderChart();
    });
    document.getElementById('gantt-mode-detailed').addEventListener('click', () => {
      state.ganttMode = 'detailed';
      document.getElementById('gantt-mode-detailed').classList.add('active');
      document.getElementById('gantt-mode-compact').classList.remove('active');
      GanttView.renderChart();
    });
  },

  populateFilterDropdowns() {
    FiltersUI.populateDropdowns();
  },

  renderSection(section) {
    switch (section) {
      case 'dashboard':    DashboardView.render();    break;
      case 'registry':     RegistryView.render();     break;
      case 'gantt':        GanttView.render();         break;
      case 'kanban':       KanbanView.render();        break;
      case 'timeline':     TimelineView.render();      break;
      case 'diagnostics':  DiagnosticsView.render();   break;
    }
  },

  refreshAll() {
    App.renderSection(state.activeSection);
  },

  refreshCurrentSection() {
    App.renderSection(state.activeSection);
  },

  refreshDashboardIfActive() {
    if (state.activeSection === 'dashboard') DashboardView.render();
  },

  updateTopbarBadge() {
    const badge = document.getElementById('topbar-row-count');
    if (state.rows.length > 0) {
      badge.textContent = state.rows.length + ' строк';
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  },
};

// ============================================================
// BOOT
// ============================================================
document.addEventListener('DOMContentLoaded', () => App.init());
