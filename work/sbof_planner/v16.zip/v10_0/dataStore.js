'use strict';
/* ============================================================
   DATA STORE — v8_0 ES module
   ============================================================ */

import { state, notify, syncColumnSettings, getAllCols } from './state.js';
import { RowFactory, EmployeeFactory } from './rowFactory.js';
import { RiskEngine } from './riskEngine.js';
import { FilterEngine } from './filters.js';
import { Utils, nextId } from './utils.js';
import { STORAGE_KEY, STORAGE_KEYS, SETTINGS_KEY, SETTINGS_KEYS } from './constants.js';

// ============================================================
// LOCAL STORAGE
// ============================================================
export const Storage = {
  _t: null,
  save() {
    clearTimeout(Storage._t);
    state._dataVersion++;
    Storage._t=setTimeout(()=>{
      syncColumnSettings();
      try {
        localStorage.setItem(STORAGE_KEY,JSON.stringify({rows:state.rows,employees:state.employees,savedAt:new Date().toISOString(),version:3}));
      } catch(e){
        if (e && e.name === 'QuotaExceededError') window.showToast?.('Память браузера заполнена — экспортируйте данные в CSV', 'error', 4200);
      }
      try {
        localStorage.setItem(SETTINGS_KEY,JSON.stringify({
          colOrder:state.colOrder,colWidths:state.colWidths,colVisibility:state.colVisibility,
          sidebarCollapsed:state.sidebarCollapsed,pinnedCols:state.pinnedCols,rowHeight:state.rowHeight,
          colLabels:state.colLabels,customCols:state.customCols,colTypes:state.colTypes,
          epicDeps:state.epicDeps,ganttMode:state.ganttMode,ganttEpicsWell:state.ganttEpicsWell,
          podlozhkaMode:state.podlozhkaMode,summaryMode:state.summaryMode,presetsCollapsed:state.presetsCollapsed,
          theme:state.theme,
          gantt2Zoom:state.gantt2Zoom,gantt2ShowDeps:state.gantt2ShowDeps,gantt2Team:state.gantt2Team,
        }));
      } catch(e){
        if (e && e.name === 'QuotaExceededError') window.showToast?.('Не удалось сохранить настройки: переполнен localStorage', 'error', 4200);
      }
    },400);
  },
  saveSetting(k,v) { state[k]=v; Storage.save(); },
  load() {
    for (const key of STORAGE_KEYS) {
      try {
        const raw=localStorage.getItem(key);
        if (!raw) continue;
        const parsed=JSON.parse(raw);
        if (parsed && Array.isArray(parsed.rows)) return parsed;
      } catch(e){}
    }
    return null;
  },
  loadSettings() {
    let s=null;
    for (const key of SETTINGS_KEYS) {
      try {
        const raw=localStorage.getItem(key);
        if (!raw) continue;
        s=JSON.parse(raw);
        if (s) break;
      } catch(e){}
    }
    if (!s) return;
    if (s.colOrder) state.colOrder=s.colOrder;
    if (s.colWidths) state.colWidths=s.colWidths;
    if (s.colVisibility) state.colVisibility=s.colVisibility;
    if (Object.prototype.hasOwnProperty.call(s,'sidebarCollapsed')) state.sidebarCollapsed=s.sidebarCollapsed;
    if (s.pinnedCols) state.pinnedCols=s.pinnedCols;
    if (Object.prototype.hasOwnProperty.call(s,'rowHeight')) state.rowHeight=s.rowHeight;
    if (s.colLabels) state.colLabels=s.colLabels;
    if (s.colTypes) state.colTypes=s.colTypes;
    if (s.customCols) state.customCols=s.customCols;
    if (s.epicDeps) state.epicDeps=s.epicDeps;
    if (s.ganttMode) state.ganttMode=s.ganttMode;
    if (s.ganttEpicsWell) state.ganttEpicsWell=s.ganttEpicsWell;
    if (s.podlozhkaMode) state.podlozhkaMode=s.podlozhkaMode;
    if (s.summaryMode) state.summaryMode=s.summaryMode;
    if (Object.prototype.hasOwnProperty.call(s,'presetsCollapsed')) state.presetsCollapsed=s.presetsCollapsed;
    if (s.theme) state.theme=s.theme;
    if (Object.prototype.hasOwnProperty.call(s,'gantt2Zoom')) state.gantt2Zoom=s.gantt2Zoom;
    if (Object.prototype.hasOwnProperty.call(s,'gantt2ShowDeps')) state.gantt2ShowDeps=s.gantt2ShowDeps;
    if (s.gantt2Team) state.gantt2Team=s.gantt2Team;
    syncColumnSettings();
  },
  clear() {
    STORAGE_KEYS.forEach(k=>localStorage.removeItem(k));
    SETTINGS_KEYS.forEach(k=>localStorage.removeItem(k));
  },
  restore(data) {
    state.rows=(data.rows||[]).map(r=>{
      ['release120Types','release121Types','release122Types','overtimeTypes'].forEach(f=>{
        if (!Array.isArray(r[f])) r[f]=Utils.parsePipe(r[f]||'');
      });
      if (typeof r.blockingDependency!=='boolean') r.blockingDependency=r.blockingDependency==='true';
      if (typeof r.isDone!=='boolean') r.isDone=r.isDone==='true';
      if (typeof r.dirty!=='boolean') r.dirty=r.dirty==='true';
      RowFactory.updateDerived(r);
      return r;
    });
    state.employees=(data.employees||[]).map(e=>EmployeeFactory.create(e));
    state.diagnostics.localStorageCount=state.rows.length;
    state.diagnostics.registryCount=state.rows.length;
    state.diagnostics.sources=['localStorage'];
  },
};

// ============================================================
// CSV IMPORT / EXPORT
// ============================================================
export const CSV = {
  COLS: [
    'id','sourceType','sourceSheet','team','category','epic',
    'backend','frontend','analytics_estimate','testing_estimate','total_estimate',
    'tasks','taskComment','teamDependency','risks',
    'release120Types','release121Types','release122Types','overtimeTypes',
    'scopeStatus','role','blockingDependency','blockingDeadline',
    'isDone','doneDate','comment','tags','dirty','createdAt','updatedAt',
    'workPeriodStart','workPeriodEnd','assignee','rowColor',
    // Integration fields
    'jiraKey','jiraStatus','jiraAssignee','jiraUpdatedAt',
    'prUrl','prStatus','prUpdatedAt',
    'docUrl','docTitle',
  ],
  SETTINGS_MARKER: '__Q2SETTINGS__',

  async export() {
    const bom='\uFEFF';
    const customKeys=state.customCols.map(c=>c.key);
    const allCols=[...CSV.COLS,...customKeys];
    const header=allCols.join(',');
    const rowToLine=(row)=>allCols.map(col=>{
      let v=row[col];
      if (Array.isArray(v)) v=Utils.serializePipe(v);
      if (typeof v==='boolean') v=v?'true':'false';
      return Utils.escapeCSV(v==null?'':v);
    }).join(',');
    // Append settings
    const settings={
      colOrder:state.colOrder, colWidths:state.colWidths, colVisibility:state.colVisibility,
      pinnedCols:state.pinnedCols, rowHeight:state.rowHeight, colLabels:state.colLabels,
      customCols:state.customCols, colTypes:state.colTypes, epicDeps:state.epicDeps,
      ganttMode:state.ganttMode, ganttEpicsWell:state.ganttEpicsWell,
      podlozhkaMode:state.podlozhkaMode, summaryMode:state.summaryMode, presetsCollapsed:state.presetsCollapsed,
      theme:state.theme,
      gantt2Zoom:state.gantt2Zoom, gantt2ShowDeps:state.gantt2ShowDeps, gantt2Team:state.gantt2Team,
    };
    const settingsRow=CSV.SETTINGS_MARKER+','+Utils.escapeCSV(JSON.stringify(settings));
    const onProgress=(done,total)=>{
      if (total>=2500 && done>0 && done%2000===0) window.showToast?.(`Экспорт CSV: ${done}/${total}`, 'success', 900);
    };
    let blob;
    if (window.CSVStreamExporter && typeof window.CSVStreamExporter.buildBlob === 'function') {
      blob=await window.CSVStreamExporter.buildBlob({
        bom,
        header,
        rows: state.rows,
        rowToLine,
        tailLines: [settingsRow],
        batchSize: 700,
        onProgress,
      });
    } else {
      const parts=[bom, header, '\n'];
      for (let i=0;i<state.rows.length;i++) {
        parts.push(rowToLine(state.rows[i]), '\n');
        if ((i+1)%700===0) await Utils.yieldToBrowser();
      }
      parts.push(settingsRow, '\n');
      blob=new Blob(parts,{type:'text/csv;charset=utf-8;'});
    }
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a'); a.href=url; a.download=`q2_plan_${new Date().toISOString().slice(0,10)}.csv`; a.click();
    URL.revokeObjectURL(url);
    if (state.rows.length>=2500) window.showToast?.(`CSV экспортирован: ${state.rows.length} строк`);
  },

  import(text) {
    if (text.charCodeAt(0)===0xFEFF) text=text.slice(1);
    const allRows=Utils.parseFullCSV(text);
    if (allRows.length<2) { alert('CSV пустой'); return; }
    window.HistoryManager?.checkpoint('импорт CSV');
    const headers=allRows[0].map(h=>h.trim());
    const newRows=[]; let count=0;
    for (let i=1;i<allRows.length;i++) {
      const cells=allRows[i];
      if (cells.every(c=>!c.trim())) continue;
      if (cells[0]===CSV.SETTINGS_MARKER) {
        try {
          const s=JSON.parse(cells[1]);
          if (s.colOrder) state.colOrder=s.colOrder;
          if (s.colWidths) state.colWidths=s.colWidths;
          if (s.colVisibility) state.colVisibility=s.colVisibility;
          if (s.pinnedCols) state.pinnedCols=s.pinnedCols;
          if (Object.prototype.hasOwnProperty.call(s,'rowHeight')) state.rowHeight=s.rowHeight;
          if (s.colLabels) state.colLabels=s.colLabels;
          if (s.colTypes) state.colTypes=s.colTypes;
          if (s.customCols) state.customCols=s.customCols;
          if (s.epicDeps) state.epicDeps=s.epicDeps;
          if (s.ganttMode) state.ganttMode=s.ganttMode;
          if (s.ganttEpicsWell) state.ganttEpicsWell=s.ganttEpicsWell;
          if (s.podlozhkaMode) state.podlozhkaMode=s.podlozhkaMode;
          if (s.summaryMode) state.summaryMode=s.summaryMode;
          if (Object.prototype.hasOwnProperty.call(s,'presetsCollapsed')) state.presetsCollapsed=s.presetsCollapsed;
          if (s.theme) state.theme=s.theme;
          if (Object.prototype.hasOwnProperty.call(s,'gantt2Zoom')) state.gantt2Zoom=s.gantt2Zoom;
          if (Object.prototype.hasOwnProperty.call(s,'gantt2ShowDeps')) state.gantt2ShowDeps=s.gantt2ShowDeps;
          if (s.gantt2Team) state.gantt2Team=s.gantt2Team;
          syncColumnSettings();
          if (window.App?.applyPresetsCollapsed) window.App.applyPresetsCollapsed();
          if (window.ThemeUI?.apply) window.ThemeUI.apply();
        } catch(e) {}
        continue;
      }
      const obj={};
      headers.forEach((h,idx)=>{ obj[h]=cells[idx]!==undefined?cells[idx]:''; });
      ['release120Types','release121Types','release122Types','overtimeTypes'].forEach(f=>{
        obj[f]=Utils.parsePipe(obj[f]);
      });
      obj.blockingDependency=obj.blockingDependency==='true';
      obj.isDone=obj.isDone==='true';
      obj.dirty=obj.dirty==='true';
      const row=RowFactory.create({...obj, id:obj.id||nextId()});
      newRows.push(row); count++;
    }
    state.rows=newRows;
    state.diagnostics.csvImportCount=count; state.diagnostics.sources=['csv'];
    RiskEngine.computeAll(); Storage.save(); notify('import-csv');
    setTimeout(()=>{ if(state.activeSection==='registry') window.RegistryView?.autoFitColWidths(); }, 120);
  },

  importUpdate(text) {
    if (text.charCodeAt(0)===0xFEFF) text=text.slice(1);
    const allRows=Utils.parseFullCSV(text);
    if (allRows.length<2) { alert('CSV пустой'); return; }
    const headers=allRows[0].map(h=>h.trim()).filter(Boolean);
    if (!headers.length) { alert('Нет заголовков в CSV'); return; }

    const boolKeys=new Set(['blockingDependency','isDone','dirty']);
    const pipeKeys=new Set(['release120Types','release121Types','release122Types','overtimeTypes']);
    const skipKeys=new Set([CSV.SETTINGS_MARKER]);
    const keyOf=(r)=>[r.team,r.epic,r.tasks].map(v=>String(v||'').trim().toLowerCase()).join('||');

    const byId=new Map(state.rows.map(r=>[String(r.id),r]));
    const byKey=new Map();
    state.rows.forEach(r=>{
      const k=keyOf(r);
      if(!byKey.has(k)) byKey.set(k,[]);
      byKey.get(k).push(r);
    });

    const staged=[];
    let parsed=0, matched=0, changed=0, unchanged=0, notFound=0;

    for (let i=1;i<allRows.length;i++) {
      const cells=allRows[i];
      if (!cells || cells.every(c=>!String(c||'').trim())) continue;
      if (cells[0]===CSV.SETTINGS_MARKER) continue;
      parsed++;

      const obj={};
      headers.forEach((h,idx)=>{ obj[h]=cells[idx]!==undefined?cells[idx]:''; });
      const id=String(obj.id||'').trim();
      let row=id&&byId.has(id)?byId.get(id):null;
      if(!row){
        const k=keyOf(obj);
        const pool=byKey.get(k)||[];
        row=pool.length?pool[0]:null;
      }
      if(!row){ notFound++; continue; }
      matched++;

      const changes={};
      headers.forEach(h=>{
        if (!h || skipKeys.has(h) || h==='id') return;
        if (!Object.prototype.hasOwnProperty.call(row,h)) return;
        let incoming=obj[h];
        let current=row[h];

        if (pipeKeys.has(h)) {
          incoming=Utils.parsePipe(incoming);
          current=Array.isArray(current)?current:Utils.parsePipe(current);
          if (incoming.join('|')!==current.join('|')) changes[h]=incoming;
          return;
        }
        if (boolKeys.has(h)) {
          incoming=Utils.toBool(incoming,false);
          current=Utils.toBool(current,false);
          if (incoming!==current) changes[h]=incoming;
          return;
        }
        incoming=String(incoming==null?'':incoming).trim();
        current=String(current==null?'':current).trim();
        if (incoming!==current) changes[h]=incoming;
      });

      const changeKeys=Object.keys(changes);
      if (!changeKeys.length) { unchanged++; continue; }
      changed++;
      staged.push({ row, changes, changeKeys });
    }

    if (!matched) { alert('Не найдено совпадающих строк для обновления. Нужны id или совпадение team+epic+tasks.'); return; }
    if (!changed) { alert(`Совпадения найдены (${matched}), но изменений нет.`); return; }
    window.HistoryManager?.checkpoint('CSV update');

    const preview = `Найдено строк: ${parsed}\nСовпало: ${matched}\nИз них изменится: ${changed}\nБез изменений: ${unchanged}\nНе найдено: ${notFound}\n\nПрименить обновление только изменённых полей?`;
    if (!confirm(preview)) return;

    staged.forEach(({row,changes})=>{
      Object.entries(changes).forEach(([k,v])=>{ row[k]=v; });
      row.dirty=true;
      row.updatedAt=new Date().toISOString();
      RowFactory.updateDerived(row);
    });
    RiskEngine.computeAll();
    Storage.save();
    notify('import-csv-update');
    window.showToast?.(`CSV update: обновлено ${changed} строк`);
  },
};

// ============================================================
// XLSX IMPORTER
// ============================================================
export const XLSXImporter = {
  import(buffer) {
    if (typeof window.XLSX==='undefined') { alert('Положите libs/xlsx.full.min.js рядом с index.html'); return; }
    window.HistoryManager?.checkpoint('импорт XLSX');
    const wb = window.XLSX.read(buffer, {type:'array'});
    const newRows=[], diag={sources:['xlsx'],sheets:wb.SheetNames.slice(),rowsPerSheet:{},detectedColumns:{},missingColumns:{},warnings:[]};
    wb.SheetNames.forEach(sheetName => {
      const ws = wb.Sheets[sheetName];
      const raw = window.XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:false});
      if (!raw||raw.length<2) { diag.warnings.push(`Лист "${sheetName}": < 2 строк`); diag.rowsPerSheet[sheetName]=0; return; }
      let headerIdx=0;
      for (let i=0;i<Math.min(6,raw.length);i++) {
        if (raw[i].some(h=>Utils.mapHeader(Utils.normalizeHeader(h))!==null)) { headerIdx=i; break; }
      }
      const headerRow=raw[headerIdx], colMap={}, mapped={};
      headerRow.forEach((h,i) => {
        const n=Utils.normalizeHeader(h), f=Utils.mapHeader(n);
        if (f) { colMap[f]=i; mapped[f]={index:i,originalHeader:String(h).trim()}; }
      });
      diag.detectedColumns[sheetName]=mapped;
      const missing=['tasks'].filter(k=>!(k in colMap));
      if (missing.length) { diag.missingColumns[sheetName]=missing; diag.warnings.push(`Лист "${sheetName}": не найдены: ${missing.join(', ')}`); }
      const get=(f,cells)=>{ const i=colMap[f]; return i==null?'':String(cells[i]||'').trim(); };
      let cnt=0;
      for (let ri=headerIdx+1;ri<raw.length;ri++) {
        const cells=raw[ri];
        if (cells.every(c=>!String(c).trim())) continue;
        const r120=get('release120',cells), r121=get('release121',cells), scope=get('scope',cells);
        const period=Utils.parseDateRange(get('work_period',cells));
        const row=RowFactory.create({
          sourceType:'xlsx', sourceSheet:sheetName, team:sheetName,
          category:get('category',cells), tags:get('tags',cells), epic:get('epic',cells),
          total_estimate:get('estimation_legacy',cells),
          tasks:get('tasks',cells), taskComment:get('task_comment',cells),
          teamDependency:get('team_dependency',cells), risks:get('risks',cells),
          release120Raw:r120, release121Raw:r121,
          release120Types:Utils.parseLegacyRelease(r120), release121Types:Utils.parseLegacyRelease(r121),
          release122Types:[], overtimeTypes:[],
          scopeStatus:Utils.scopeFromRaw(scope), role:get('role',cells), assignee:get('assignee',cells),
          workPeriodStart:period.start, workPeriodEnd:period.end,
          comment:get('comment',cells), dirty:false,
        });
        newRows.push(row); cnt++;
      }
      diag.rowsPerSheet[sheetName]=cnt;
    });
    state.rows=newRows;
    state.diagnostics={...state.diagnostics,...diag,registryCount:newRows.length};
    RiskEngine.computeAll(); Storage.save(); notify('import-xlsx');
    // Auto-fit columns to new content
    setTimeout(()=>{ if(state.activeSection==='registry') window.RegistryView?.autoFitColWidths(); }, 120);
  },
};

// ============================================================
// BULK ACTIONS
// ============================================================
export function applyBulkAction(rowIds, actionType, payload={}) {
  const ids = new Set(rowIds);
  const targets = state.rows.filter(r => ids.has(r.id));
  if (!targets.length) return;
  window.HistoryManager?.checkpoint(`bulk:${actionType}`);
  targets.forEach(row => {
    switch (actionType) {
      case 'assign_release': {
        const rel = payload.release;
        if (rel === '120') { row.release120Types = payload.types||['backend']; }
        else if (rel === '121') { row.release121Types = payload.types||['backend']; }
        else if (rel === '122') { row.release122Types = payload.types||['backend']; }
        else if (rel === 'ot')  { row.overtimeTypes = payload.types||['backend']; }
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row); RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
      case 'clear_release': {
        row.release120Types=[]; row.release121Types=[]; row.release122Types=[]; row.overtimeTypes=[];
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row); RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
      case 'set_scope': {
        row.scopeStatus = payload.scope||'Да';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row); RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
      case 'set_assignee': {
        if (payload.assignee) { row.assignee = payload.assignee; row.dirty = true; row.updatedAt = new Date().toISOString(); }
        break;
      }
      case 'set_priority': {
        row.priority = payload.priority||'medium';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
      case 'clear_blocker': {
        row.blockingDependency = false; row.blockingDeadline = '';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
      case 'mark_done': {
        row.isDone = payload.done !== false;
        if (row.isDone && !row.doneDate) row.doneDate = new Date().toISOString().slice(0,10);
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
      case 'unmark_done': {
        row.isDone = false; row.doneDate = '';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
      case 'set_done_date': {
        if (payload.date) { row.doneDate = payload.date; row.dirty = true; row.updatedAt = new Date().toISOString(); }
        break;
      }
      case 'set_business_value': {
        row.businessValue = Number(payload.value) || 0;
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
      case 'set_comment': {
        if (payload.append) {
          row.comment = row.comment ? row.comment + '\n' + payload.comment : payload.comment;
        } else {
          row.comment = payload.comment || '';
        }
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
      case 'flag_review': {
        row._reviewFlag = payload.flag !== false;
        row._reviewNote = payload.note || '';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
      case 'unflag_review': {
        row._reviewFlag = false; row._reviewNote = '';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        break;
      }
      case 'add_risk_flag': {
        const flag = payload.flag;
        if (flag && !(row.riskFlags||[]).includes(flag)) {
          row.riskFlags = [...(row.riskFlags||[]), flag];
          row.dirty = true; row.updatedAt = new Date().toISOString();
          RiskEngine.computeRiskScore(row);
        }
        break;
      }
      case 'remove_risk_flags': {
        row.riskFlags = payload.flag ? (row.riskFlags||[]).filter(f=>f!==payload.flag) : [];
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RiskEngine.computeRiskScore(row);
        break;
      }
      case 'set_release_type': {
        const rel = payload.release, types = payload.types||[];
        if (rel === '120') row.release120Types = types;
        else if (rel === '121') row.release121Types = types;
        else if (rel === '122') row.release122Types = types;
        else if (rel === 'ot')  row.overtimeTypes = types;
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row);
        break;
      }
      case 'reset_row': {
        row.blockingDependency = false; row.blockingDeadline = '';
        row._reviewFlag = false; row._reviewNote = '';
        row.riskFlags = []; row.priority = 'medium'; row.businessValue = 0;
        row.isDone = false; row.doneDate = '';
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RiskEngine.computeFlags(row); RiskEngine.computeRiskScore(row);
        break;
      }
    }
  });
  // Log action
  const logEntry = {
    id: Date.now() + Math.random(),
    type: actionType,
    label: payload._label || actionType,
    count: targets.length,
    at: new Date().toISOString(),
    simMode: state.simMode,
  };
  state.actionLog.unshift(logEntry);
  if (state.actionLog.length > 200) state.actionLog.length = 200;

  if (state.simMode) {
    window.showToast?.(`[Симуляция] ${actionType} применено к ${targets.length} задачам`, 'info');
  } else {
    Storage.save();
    window.showToast?.(`Применено к ${targets.length} задачам`, 'success');
  }
  notify('bulk-action');
  window.ActionLayer?.renderLog?.();
}

export function autoAssignRelease(release, overwrite=false) {
  const candidates = state.rows.filter(r => {
    if (r.isDone) return false;
    const hasRelease = r.release120Types?.length || r.release121Types?.length || r.release122Types?.length || r.overtimeTypes?.length;
    return overwrite || !hasRelease;
  });
  if (!candidates.length) return 0;
  const types = ['backend'];
  applyBulkAction(candidates.map(r=>r.id), 'assign_release', { release, types, _label:`Авто-назначение в ${release}` });
  return candidates.length;
}

export function normalizeAssignees() {
  window.HistoryManager?.checkpoint('normalize_assignees');
  let count = 0;
  state.rows.forEach(row => {
    const raw = row.assignee || '';
    const norm = raw.trim().replace(/\s+/g,' ');
    if (norm !== raw) { row.assignee = norm; row.dirty = true; count++; }
  });
  if (count && !state.simMode) Storage.save();
  return count;
}

export function batchRiskRecompute() {
  state.rows.forEach(r => { RiskEngine.computeFlags(r); RiskEngine.computeRiskScore(r); });
  if (!state.simMode) Storage.save();
  return state.rows.length;
}

export function exportSelectedCSV(rowIds) {
  const ids = new Set(rowIds);
  const rows = rowIds.length ? state.rows.filter(r => ids.has(r.id)) : state.rows;
  const cols = getAllCols().filter(c => c.visible);
  const escape = v => `"${String(v??'').replace(/"/g,'""')}"`;
  const header = cols.map(c => escape(c.label)).join(',');
  const lines = rows.map(r => cols.map(c => escape(r[c.key]??'')).join(','));
  const csv = [header, ...lines].join('\n');
  const blob = new Blob(['\ufeff'+csv], {type:'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download=`q2_actions_export_${Date.now()}.csv`; a.click();
  URL.revokeObjectURL(url);
  return rows.length;
}
