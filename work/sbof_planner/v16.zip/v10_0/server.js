// Static server + LLM proxy (Node built-ins only)
// Usage: node server.js [port]
'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = parseInt(process.argv[2], 10) || 8080;
const ROOT = __dirname;
const DEFAULT_GIGACHAT_BASE = process.env.GIGACHAT_API_BASE || 'https://gigachat.devices.sberbank.ru/api/v1';
const SERVER_ACCESS_TOKEN = process.env.GIGACHAT_ACCESS_TOKEN || '';
const MAX_BODY = 8 * 1024 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.csv': 'text/csv; charset=utf-8',
};

function writeJson(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

function readBody(req, limitBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limitBytes) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
    req.on('error', reject);
  });
}

function buildChatEndpoint(base) {
  const normalized = String(base || DEFAULT_GIGACHAT_BASE).replace(/\/+$/, '');
  if (normalized.endsWith('/chat/completions')) return normalized;
  if (normalized.endsWith('/v1')) return `${normalized}/chat/completions`;
  if (normalized.endsWith('/api')) return `${normalized}/v1/chat/completions`;
  return `${normalized}/chat/completions`;
}

// ============================================================
// GIGACHAT OAUTH — token cache + exchange
// ============================================================
const GIGACHAT_OAUTH_URL = process.env.GIGACHAT_OAUTH_URL
  || 'https://ngw.devices.sberbank.ru:9443/api/v2/oauth';
const GIGACHAT_SCOPE = process.env.GIGACHAT_SCOPE || 'GIGACHAT_API_PERS';

// In-memory token cache — scoped to clientId so multiple configs can coexist
const _tokenCache = new Map(); // clientId → { token, expiresAt }

/**
 * Returns a valid GigaChat Bearer token.
 * Fetches a new one from OAuth if missing or within 90s of expiry.
 * Never logs the secret.
 */
async function gigachatGetToken(clientId, clientSecret) {
  const cacheKey = clientId;
  const cached = _tokenCache.get(cacheKey);
  const now = Date.now();
  if (cached && cached.token && cached.expiresAt - now > 90_000) {
    return cached.token;
  }

  // Build Basic auth: base64(clientId:clientSecret)
  const cred = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  // Unique request ID required by GigaChat OAuth
  const rqUID = [8,4,4,4,12].map(n => [...Array(n)].map(() => Math.floor(Math.random()*16).toString(16)).join('')).join('-');

  return new Promise((resolve, reject) => {
    const oauthUrl = new URL(GIGACHAT_OAUTH_URL);
    const body = `scope=${encodeURIComponent(GIGACHAT_SCOPE)}`;
    const opts = {
      method: 'POST',
      protocol: oauthUrl.protocol,
      hostname: oauthUrl.hostname,
      port: oauthUrl.port || 443,
      path: oauthUrl.pathname + (oauthUrl.search || ''),
      headers: {
        'Authorization': `Basic ${cred}`,
        'RqUID': rqUID,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
        'Accept': 'application/json',
      },
      // GigaChat OAuth endpoint uses Sberbank internal CA — allow insecure for on-prem
      rejectUnauthorized: false,
    };
    const req = https.request(opts, (res) => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf-8');
        if (res.statusCode >= 400) {
          return reject(new Error(`GigaChat OAuth ${res.statusCode}: ${text.slice(0, 200)}`));
        }
        let parsed;
        try { parsed = JSON.parse(text); } catch(_) { return reject(new Error('GigaChat OAuth: invalid JSON')); }
        const token = parsed.access_token;
        if (!token) return reject(new Error('GigaChat OAuth: no access_token in response'));
        // expires_at is ms since epoch (GigaChat v2 API)
        const expiresAt = typeof parsed.expires_at === 'number'
          ? parsed.expires_at
          : (Date.now() + 29 * 60 * 1000); // fallback: 29 min
        _tokenCache.set(cacheKey, { token, expiresAt });
        resolve(token);
      });
    });
    req.setTimeout(12000, () => req.destroy(new Error('GigaChat OAuth timeout')));
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function forwardSSEOrChunk(upstreamRes, clientRes) {
  clientRes.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  clientRes.write('event: meta\ndata: {"ok":true}\n\n');
  upstreamRes.on('data', (chunk) => {
    clientRes.write(chunk);
  });
  upstreamRes.on('end', () => {
    clientRes.write('data: [DONE]\n\n');
    clientRes.end();
  });
}

function proxyChat(req, res) {
  readBody(req, MAX_BODY).then(async (raw) => {
    const body = raw ? JSON.parse(raw) : {};
    const clientId     = String(body.clientId     || '').trim();
    const clientSecret = String(body.clientSecret || '').trim();
    let   token        = String(body.token        || '').trim() || SERVER_ACCESS_TOKEN;

    // ── GigaChat OAuth: exchange clientId+clientSecret for Bearer token ──
    if (clientId && clientSecret) {
      try {
        token = await gigachatGetToken(clientId, clientSecret);
      } catch (e) {
        writeJson(res, 502, { error: 'GigaChat OAuth failed: ' + e.message });
        return;
      }
    }

    if (!token) {
      writeJson(res, 400, { error: 'Нет токена. Укажите token или пару clientId + clientSecret в настройках LLM.' });
      return;
    }

    const endpoint = buildChatEndpoint(body.apiBaseUrl || DEFAULT_GIGACHAT_BASE);
    const endpointUrl = new URL(endpoint);
    const payload = {
      model: body.model || 'GigaChat-2',
      messages: Array.isArray(body.messages) ? body.messages : [],
      stream: body.stream !== false,
      temperature: Number.isFinite(Number(body.temperature)) ? Number(body.temperature) : 0.2,
      max_tokens: Number.isFinite(Number(body.max_tokens)) ? Number(body.max_tokens) : 900,
    };

    // ── Perform the upstream chat request (with one 401-retry) ──
    const doRequest = (bearerToken, retryOnUnauth) => {
      const payloadRaw = JSON.stringify(payload);
      const transport = endpointUrl.protocol === 'http:' ? http : https;
      const upstreamReq = transport.request({
        protocol: endpointUrl.protocol,
        hostname: endpointUrl.hostname,
        port: endpointUrl.port || (endpointUrl.protocol === 'http:' ? 80 : 443),
        path: endpointUrl.pathname + endpointUrl.search,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${bearerToken}`,
          Accept: payload.stream ? 'text/event-stream' : 'application/json',
          'Content-Length': Buffer.byteLength(payloadRaw),
        },
        // Allow Sberbank internal CA (same as OAuth call)
        rejectUnauthorized: false,
      }, (upstreamRes) => {
        const status = upstreamRes.statusCode || 500;
        const upstreamType = (upstreamRes.headers['content-type'] || '').toLowerCase();

        if (status === 401 && retryOnUnauth && clientId && clientSecret) {
          // Consume upstream body then refresh token and retry once
          upstreamRes.resume();
          _tokenCache.delete(clientId); // invalidate cached token
          gigachatGetToken(clientId, clientSecret)
            .then(newTok => doRequest(newTok, false))
            .catch(e => { if (!res.writableEnded) writeJson(res, 502, { error: 'GigaChat token refresh failed: ' + e.message }); });
          return;
        }

        if (status >= 400) {
          const errChunks = [];
          upstreamRes.on('data', (chunk) => errChunks.push(chunk));
          upstreamRes.on('end', () => {
            const errText = Buffer.concat(errChunks).toString('utf-8');
            const parsed = (() => { try { return JSON.parse(errText); } catch (_) { return null; } })();
            if (!res.writableEnded) writeJson(res, status, {
              error: 'GigaChat upstream error',
              status,
              details: parsed || errText || 'Unknown upstream error',
            });
          });
          return;
        }

        if (payload.stream) {
          if (upstreamType.includes('text/event-stream') || upstreamType.includes('stream') || upstreamType.includes('json')) {
            forwardSSEOrChunk(upstreamRes, res);
          } else {
            const chunks = [];
            upstreamRes.on('data', (chunk) => chunks.push(chunk));
            upstreamRes.on('end', () => {
              const text = Buffer.concat(chunks).toString('utf-8');
              if (res.writableEnded) return;
              res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive' });
              res.write(`data: ${text}\n\n`);
              res.write('data: [DONE]\n\n');
              res.end();
            });
          }
        } else {
          if (!res.writableEnded) {
            res.writeHead(200, { 'Content-Type': upstreamType || 'application/json; charset=utf-8' });
            upstreamRes.pipe(res);
          }
        }
      });

      req.on('close', () => { if (!res.writableEnded) upstreamReq.destroy(new Error('Client disconnected')); });
      upstreamReq.on('error', (err) => {
        if (res.writableEnded) return;
        writeJson(res, 502, { error: 'Proxy request failed', details: String(err && err.message ? err.message : err) });
      });
      upstreamReq.write(payloadRaw);
      upstreamReq.end();
    };

    doRequest(token, true);

  }).catch((err) => {
    writeJson(res, /Payload too large/.test(String(err)) ? 413 : 400, {
      error: 'Invalid request body',
      details: String(err && err.message ? err.message : err),
    });
  });
}

// ============================================================
// JIRA PULSE — config + proxy
// ============================================================
const JIRA_CONFIG_FILE = path.join(ROOT, 'jira_config.json');
const JIRA_DEFAULT_CONFIG = {
  jiraBaseUrl: '', jiraToken: '',
  areas: [],                       // [{ name, projectKey }] — used by JiraPulse
  bitbucketBaseUrl: '', bitbucketToken: '',
  confluenceBaseUrl: '', confluenceToken: '',
  allowInsecureTls: false,         // global TLS flag (used by JiraPulse)
  staleDays: 3, noMovementDays: 2,
};

function jiraReadConfig() {
  try { return { ...JIRA_DEFAULT_CONFIG, ...JSON.parse(fs.readFileSync(JIRA_CONFIG_FILE, 'utf8')) }; }
  catch(_) { return { ...JIRA_DEFAULT_CONFIG }; }
}
function jiraWriteConfig(patch) {
  const next = { ...jiraReadConfig(), ...patch };
  fs.writeFileSync(JIRA_CONFIG_FILE, JSON.stringify(next, null, 2), 'utf8');
  return next;
}
function jiraSanitizeAreas(areas) {
  if (!Array.isArray(areas)) return [];
  const seen = new Set(), out = [];
  for (const a of areas) {
    const pk = String(a.projectKey||'').trim(), nm = String(a.name||pk||'').trim();
    if (!pk || seen.has(pk)) continue;
    seen.add(pk); out.push({ name:nm, projectKey:pk });
  }
  return out;
}
function jiraSanitizeConfig(cfg) {
  return {
    jiraBaseUrl:       cfg.jiraBaseUrl||'',
    areas:             jiraSanitizeAreas(cfg.areas),
    bitbucketBaseUrl:  cfg.bitbucketBaseUrl||'',
    confluenceBaseUrl: cfg.confluenceBaseUrl||'',
    allowInsecureTls:  !!cfg.allowInsecureTls,
    staleDays:         cfg.staleDays??3,
    noMovementDays:    cfg.noMovementDays??2,
    hasJiraToken:      !!cfg.jiraToken,
    hasBitbucketToken: !!cfg.bitbucketToken,
    hasConfluenceToken:!!cfg.confluenceToken,
  };
}

function jiraForward({ targetUrl, method='GET', headers={}, body=null, allowInsecureTls=false, timeoutMs=25000 }) {
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(targetUrl); } catch(e) { return reject(new Error('Bad URL: '+targetUrl)); }
    const lib = parsed.protocol==='https:' ? https : http;
    const opts = {
      method, hostname: parsed.hostname,
      port: parsed.port||(parsed.protocol==='https:'?443:80),
      path: parsed.pathname+(parsed.search||''),
      headers: { Accept:'application/json', 'User-Agent':'sbof-planner/1.0', ...headers },
      rejectUnauthorized: !allowInsecureTls,
    };
    const r = lib.request(opts, (resp) => {
      const chunks = [];
      resp.on('data', c=>chunks.push(c));
      resp.on('end', ()=>resolve({ status:resp.statusCode||0, headers:resp.headers, text:Buffer.concat(chunks).toString('utf8') }));
    });
    r.setTimeout(timeoutMs, ()=>r.destroy(new Error('Timeout '+parsed.hostname)));
    r.on('error', reject);
    if (body!=null) {
      const pl = typeof body==='string'?body:JSON.stringify(body);
      r.setHeader('Content-Type','application/json'); r.setHeader('Content-Length',Buffer.byteLength(pl)); r.write(pl);
    }
    r.end();
  });
}
function jiraParseResp(resp, label) {
  if (resp.status<200||resp.status>=300) {
    let msg=`${label} ${resp.status}`;
    try { const j=JSON.parse(resp.text); if(j.errorMessages?.length) msg+=': '+j.errorMessages.join('; '); else if(j.message) msg+=': '+j.message; } catch(_){}
    const e=new Error(msg); e.status=resp.status; throw e;
  }
  if (!resp.text) return {};
  return JSON.parse(resp.text);
}
function jiraSleep(ms) { return new Promise(r=>setTimeout(r,ms)); }
async function jiraRequest(cfg, method, apiPath, body, maxRetries=4) {
  const target = cfg.jiraBaseUrl.replace(/\/+$/,'')+apiPath;
  const tls = !!cfg.allowInsecureTls;
  const authH = cfg.jiraToken?.includes(':')
    ? 'Basic ' + Buffer.from(cfg.jiraToken).toString('base64')
    : 'Bearer ' + cfg.jiraToken;
  let delay=2000;
  for (let i=0; i<=maxRetries; i++) {
    const resp = await jiraForward({ targetUrl:target, method, headers:{ Authorization: authH }, body:body??null, allowInsecureTls:tls });
    if (resp.status===429) {
      if (i===maxRetries) throw Object.assign(new Error('Jira 429 rate limit'), {status:429});
      const wait = parseInt(resp.headers['retry-after']||'0',10);
      await jiraSleep(wait>0?wait*1000:delay); delay=Math.min(delay*2,30000); continue;
    }
    return jiraParseResp(resp, 'Jira');
  }
}
async function jiraSearchAll(cfg, jql, fields, expand, hardCap=2000) {
  const out=[]; let startAt=0;
  while(true) {
    const data = await jiraRequest(cfg,'POST','/rest/api/2/search',{ jql, startAt, maxResults:100, fields, expand });
    const issues = data.issues||[];
    out.push(...issues);
    if (issues.length<100 || out.length>=(data.total||out.length) || startAt>hardCap) break;
    startAt+=issues.length;
  }
  return out;
}
function jiraPLimit(concurrency, tasks) {
  return new Promise((resolve) => {
    const results=new Array(tasks.length); let i=0, done=0, running=0;
    const next=()=>{
      while(running<concurrency&&i<tasks.length) {
        const idx=i++; running++;
        Promise.resolve().then(()=>tasks[idx]()).then(r=>{results[idx]=r;},e=>{results[idx]={__error:e.message};})
          .then(()=>{ running--; done++; if(done===tasks.length) resolve(results); else next(); });
      }
    };
    if(!tasks.length) resolve([]); else next();
  });
}
const JIRA_FIELDS=['summary','description','status','assignee','reporter','updated','created','priority','issuetype','labels','duedate','timetracking','timeoriginalestimate','aggregatetimespent','worklog','comment','parent','subtasks','resolution','resolutiondate'];

async function jiraBuildAreaReport(cfg, area) {
  let sprintIssues,recentIssues,inProgressIssues,backlogIssues;
  try {
    const pk=area.projectKey;
    [sprintIssues,recentIssues,inProgressIssues,backlogIssues] = await Promise.all([
      jiraSearchAll(cfg,`project="${pk}" AND sprint in openSprints()`,JIRA_FIELDS,['changelog']),
      jiraSearchAll(cfg,`project="${pk}" AND updated >= -3d`,JIRA_FIELDS,['changelog']),
      jiraSearchAll(cfg,`project="${pk}" AND statusCategory = "In Progress"`,JIRA_FIELDS,['changelog']),
      jiraSearchAll(cfg,`project="${pk}" AND statusCategory != Done AND (sprint is EMPTY OR sprint not in openSprints())`,JIRA_FIELDS,['changelog']),
    ]);
  } catch(e) {
    return { name:area.name, projectKey:area.projectKey, issues:[], sprintKeys:[], inProgressKeys:[], backlogKeys:[], devStatus:{}, error:e.message };
  }
  const byKey=new Map();
  for (const arr of [sprintIssues,recentIssues,inProgressIssues,backlogIssues]) for(const it of arr) byKey.set(it.key,it);
  return {
    name:area.name, projectKey:area.projectKey,
    issues:Array.from(byKey.values()),
    sprintKeys:sprintIssues.map(i=>i.key),
    inProgressKeys:inProgressIssues.map(i=>i.key),
    backlogKeys:backlogIssues.map(i=>i.key),
    devStatus:{}, error:null,
  };
}

async function jiraBuildReport(cfg) {
  const areas=jiraSanitizeAreas(cfg.areas);
  if (!cfg.jiraBaseUrl||!cfg.jiraToken) throw Object.assign(new Error('Jira URL или токен не заданы'),{status:400});
  if (!areas.length) throw Object.assign(new Error('Не задано ни одного пространства'),{status:400});
  const staleDays=Number(cfg.staleDays)||3, noMovementDays=Number(cfg.noMovementDays)||2;
  const areaReports = await jiraPLimit(2, areas.map(a=>()=>jiraBuildAreaReport(cfg,a)));
  const now=new Date(), yesterday=new Date(now); yesterday.setHours(0,0,0,0); yesterday.setDate(yesterday.getDate()-1);
  const today=new Date(now); today.setHours(0,0,0,0);
  const dayBefore=new Date(yesterday); dayBefore.setDate(dayBefore.getDate()-1);
  return {
    generatedAt:now.toISOString(),
    yesterdayRange:{ from:yesterday.toISOString(), to:today.toISOString() },
    dayBeforeYesterdayRange:{ from:dayBefore.toISOString(), to:yesterday.toISOString() },
    last48hRange:{ from:new Date(Date.now()-48*3600000).toISOString(), to:now.toISOString() },
    staleDays, noMovementDays, areas:areaReports, bitbucket:null, confluence:null,
  };
}

async function handleJiraApi(req, res, pathname) {
  try {
    if (pathname==='/api/jira/config' && req.method==='GET') {
      return writeJson(res, 200, jiraSanitizeConfig(jiraReadConfig()));
    }
    if (pathname==='/api/jira/config' && req.method==='POST') {
      const raw = await readBody(req, 512*1024);
      const body = raw ? JSON.parse(raw) : {};
      const patch = {};
      for (const k of ['jiraBaseUrl', 'bitbucketBaseUrl', 'confluenceBaseUrl']) {
        if (typeof body[k]==='string') patch[k]=body[k].trim();
      }
      if (Array.isArray(body.areas)) patch.areas=jiraSanitizeAreas(body.areas);
      if (typeof body.allowInsecureTls==='boolean') patch.allowInsecureTls=body.allowInsecureTls;
      if (typeof body.staleDays==='number') patch.staleDays=body.staleDays;
      if (typeof body.noMovementDays==='number') patch.noMovementDays=body.noMovementDays;
      if (typeof body.jiraToken==='string'&&body.jiraToken) patch.jiraToken=body.jiraToken;
      if (typeof body.bitbucketToken==='string'&&body.bitbucketToken) patch.bitbucketToken=body.bitbucketToken;
      if (typeof body.confluenceToken==='string'&&body.confluenceToken) patch.confluenceToken=body.confluenceToken;
      const next = jiraWriteConfig(patch);
      return writeJson(res, 200, jiraSanitizeConfig(next));
    }
    if (pathname==='/api/jira/verify' && req.method==='POST') {
      const cfg=jiraReadConfig();
      if (!cfg.jiraBaseUrl||!cfg.jiraToken) return writeJson(res,400,{ok:false,error:'Нет jiraBaseUrl или токена'});
      const me = await jiraRequest(cfg,'GET','/rest/api/2/myself',null);
      return writeJson(res,200,{ok:true,who:me.displayName||me.name||'?'});
    }
    if (pathname==='/api/jira/report' && req.method==='POST') {
      const cfg=jiraReadConfig();
      const report = await jiraBuildReport(cfg);
      return writeJson(res, 200, report);
    }
    writeJson(res, 404, { error: 'Неизвестный Jira API метод' });
  } catch(e) {
    const status = (e.status&&e.status>=400&&e.status<600)?e.status:500;
    writeJson(res, status, { error: e.message||String(e) });
  }
}

// ============================================================
// INTEGRATIONS API — Jira issue, Bitbucket PR, Confluence search
// ============================================================
async function handleIntegrationsApi(req, res, pathname) {
  if (req.method !== 'POST') { writeJson(res, 405, { error: 'Method not allowed' }); return; }
  try {
    const raw = await readBody(req, 256 * 1024);
    const body = raw ? JSON.parse(raw) : {};
    const cfg  = jiraReadConfig();

    // ── helpers ──────────────────────────────────────────────
    const tls = !!cfg.allowInsecureTls;
    // Smart auth: if token contains ':', use Basic base64(token); otherwise Bearer
    function makeAuthHeader(token) {
      if (!token) return '';
      return token.includes(':')
        ? 'Basic ' + Buffer.from(token).toString('base64')
        : 'Bearer ' + token;
    }

    // ── /api/integrations/jira-issue ─────────────────────────
    if (pathname === '/api/integrations/jira-issue') {
      const key = String(body.key || '').trim();
      if (!key) { writeJson(res, 400, { error: 'Missing key' }); return; }
      if (!cfg.jiraBaseUrl || !cfg.jiraToken) { writeJson(res, 400, { error: 'Jira не настроена' }); return; }
      const issue = await jiraRequest(cfg, 'GET', `/rest/api/2/issue/${encodeURIComponent(key)}?fields=status,assignee,updated`);
      writeJson(res, 200, {
        key,
        status:    issue.fields?.status?.name || '',
        assignee:  issue.fields?.assignee?.displayName || '',
        updatedAt: issue.fields?.updated || '',
      });
      return;
    }

    // ── /api/integrations/bitbucket-prs ──────────────────────
    if (pathname === '/api/integrations/bitbucket-prs') {
      const jiraKey = String(body.jiraKey || '').trim();
      if (!jiraKey) { writeJson(res, 400, { error: 'Missing jiraKey' }); return; }
      if (!cfg.bitbucketBaseUrl || !cfg.bitbucketToken) { writeJson(res, 400, { error: 'Bitbucket не настроен' }); return; }
      const base       = cfg.bitbucketBaseUrl.replace(/\/+$/, '');
      const authHeader = makeAuthHeader(cfg.bitbucketToken);
      const prs = [];
      try {
        const searchUrl = `${base}/pullrequests?q=title~"${encodeURIComponent(jiraKey)}"&pagelen=10`;
        const resp = await jiraForward({
          targetUrl: searchUrl, method: 'GET',
          headers: { Authorization: authHeader },
          allowInsecureTls: tls,
        });
        if (resp.status < 300) {
          const data = JSON.parse(resp.text);
          (data.values || []).forEach(pr => {
            prs.push({
              url:       pr.links?.html?.href || '',
              status:    (pr.state || '').toLowerCase(),
              title:     pr.title || '',
              updatedAt: pr.updated_on || '',
              reviewers: (pr.reviewers || []).length,
            });
          });
        }
      } catch(_) {}
      writeJson(res, 200, { prs, jiraKey });
      return;
    }

    // ── /api/integrations/confluence-search ──────────────────
    if (pathname === '/api/integrations/confluence-search') {
      const query = String(body.query || '').trim();
      if (!query) { writeJson(res, 400, { error: 'Missing query' }); return; }
      if (!cfg.confluenceBaseUrl || !cfg.confluenceToken) { writeJson(res, 400, { error: 'Confluence не настроена' }); return; }
      const base  = cfg.confluenceBaseUrl.replace(/\/+$/, '');
      const searchUrl  = `${base}/rest/api/content?type=page&title=${encodeURIComponent(query)}&limit=5`;
      const resp = await jiraForward({
        targetUrl: searchUrl, method: 'GET',
        headers: { Authorization: makeAuthHeader(cfg.confluenceToken) },
        allowInsecureTls: tls,
      });
      const pages = [];
      if (resp.status < 300) {
        const data = JSON.parse(resp.text);
        (data.results || []).forEach(p => {
          const webLink = p._links?.base && p._links?.webui ? p._links.base + p._links.webui : '';
          pages.push({ title: p.title || '', url: webLink });
        });
      }
      writeJson(res, 200, { pages, query });
      return;
    }

    // ── /api/integrations/verify-bitbucket ───────────────────
    if (pathname === '/api/integrations/verify-bitbucket') {
      if (!cfg.bitbucketBaseUrl || !cfg.bitbucketToken) { writeJson(res, 200, { ok: false, error: 'Bitbucket не настроен' }); return; }
      const base   = cfg.bitbucketBaseUrl.replace(/\/+$/, '');
      const authH  = makeAuthHeader(cfg.bitbucketToken);
      const fwd    = url => jiraForward({ targetUrl: url, method: 'GET', headers: { Authorization: authH }, allowInsecureTls: tls });
      // Try Bitbucket Server first (/rest/api/1.0/profile/recent/repos),
      // then fall back to Bitbucket Cloud (/user)
      let who = '?';
      let ok  = false;
      const serverResp = await fwd(`${base}/rest/api/1.0/profile/recent/repos?limit=1`).catch(()=>null);
      if (serverResp && serverResp.status < 300) {
        ok = true; // Server — no user name from this endpoint, just confirms auth works
      } else if (serverResp && serverResp.status === 401) {
        writeJson(res, 200, { ok: false, error: 'Неверный токен (401)' }); return;
      } else {
        // Fallback: Bitbucket Cloud
        const cloudResp = await fwd(`${base}/user`).catch(()=>null);
        if (cloudResp && cloudResp.status < 300) {
          const d = JSON.parse(cloudResp.text || '{}');
          who = d.display_name || d.username || '?';
          ok  = true;
        } else if (cloudResp && cloudResp.status === 401) {
          writeJson(res, 200, { ok: false, error: 'Неверный токен (401)' }); return;
        } else {
          writeJson(res, 200, { ok: false, error: `HTTP ${cloudResp?.status ?? 'нет ответа'} — проверьте Base URL` }); return;
        }
      }
      writeJson(res, 200, { ok, who });
      return;
    }

    // ── /api/integrations/verify-confluence ──────────────────
    if (pathname === '/api/integrations/verify-confluence') {
      if (!cfg.confluenceBaseUrl || !cfg.confluenceToken) { writeJson(res, 200, { ok: false, error: 'Confluence не настроена' }); return; }
      const base = cfg.confluenceBaseUrl.replace(/\/+$/, '');
      const resp = await jiraForward({ targetUrl: `${base}/rest/api/user/current`, method: 'GET', headers: { Authorization: makeAuthHeader(cfg.confluenceToken) }, allowInsecureTls: tls });
      if (resp.status < 300) {
        const d = JSON.parse(resp.text);
        writeJson(res, 200, { ok: true, who: d.displayName || d.username || '?' });
      } else { writeJson(res, 200, { ok: false, error: `HTTP ${resp.status}` }); }
      return;
    }

    writeJson(res, 404, { error: 'Unknown integrations endpoint' });
  } catch(e) {
    writeJson(res, 500, { error: e.message || String(e) });
  }
}

function serveStatic(req, res) {
  let urlPath = req.url.split('?')[0];
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.join(ROOT, urlPath);

  if (!path.resolve(filePath).startsWith(ROOT + path.sep) && path.resolve(filePath) !== ROOT) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Forbidden');
    return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(`Not Found: ${urlPath}`);
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Server Error');
      }
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  const pathname = req.url.split('?')[0];
  if (req.method === 'POST' && pathname === '/api/llm/chat') {
    proxyChat(req, res); return;
  }
  if (pathname.startsWith('/api/jira/')) {
    handleJiraApi(req, res, pathname); return;
  }
  if (pathname.startsWith('/api/integrations/')) {
    handleIntegrationsApi(req, res, pathname); return;
  }
  serveStatic(req, res);
});

let currentPort = PORT;
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    const next = currentPort + 1;
    if (next <= PORT + 9) {
      currentPort = next;
      server.listen(currentPort, '127.0.0.1');
    } else {
      console.error(`Порты ${PORT}–${PORT + 9} заняты. Освободи порт или задай другой: node server.js 9090`);
      process.exit(1);
    }
  } else {
    throw err;
  }
});

server.listen(PORT, '127.0.0.1', () => {
  const actualPort = server.address().port;
  // Machine-readable marker so launch.js knows the real port.
  console.log(`LISTENING:${actualPort}`);
  console.log(`SBOF Planner — http://localhost:${actualPort}`);
  console.log('Ctrl+C to stop');
});
