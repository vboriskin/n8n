'use strict';
/* ============================================================
   GANTT VIEW + GANTT V2 — v8_0 ES module
   ============================================================ */

import { state } from '../state.js';
import { FilterEngine } from '../filters.js';
import { Utils } from '../utils.js';
import { RowFactory } from '../rowFactory.js';
import { RiskEngine } from '../riskEngine.js';
import { Storage } from '../dataStore.js';
import {
  SCOPE_OPTIONS, RELEASE_WINDOWS, GANTT_RELEASE_WINDOWS,
  GANTT_TIMELINE_START, GANTT_TIMELINE_END, GANTT_DAY_PX,
  GANTT_RELEASE_BOUNDS, PHASE_ORDER, PHASE_COLORS, PHASE_SHORT,
  WORK_TYPES,
} from '../constants.js';
import { RH } from './renderHelpers.js';

export const GanttView = {
  gf:{ team:'',scope:'',onlyBlocking:false,onlyNoRelease:false,onlyRisky:false },
  _cancelTransientInteractions: null,
  _clearTransientInteractions() {
    if (typeof GanttView._cancelTransientInteractions === 'function') {
      try { GanttView._cancelTransientInteractions(); } catch(_) {}
    }
    GanttView._cancelTransientInteractions = null;
  },
  render() { GanttView.renderFilters(); GanttView.renderChart(); GanttView.bindFullscreen(); GanttView.bindExpandCollapse(); },
  bindFullscreen() {
    const btn = document.getElementById('btn-gantt-fullscreen');
    if (!btn || btn._gdtFsBound) return;
    btn._gdtFsBound = true;
    const section = document.getElementById('section-gantt');
    const toggle = () => {
      const on = section.classList.toggle('gdt-fullscreen');
      btn.textContent = on ? '✕ Выйти' : '⛶';
      btn.title = on ? 'Выйти из полного экрана' : 'Полный экран';
      GanttView._dtColWidths = {};
      GanttView.renderChart();
    };
    btn.addEventListener('click', toggle);
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && section.classList.contains('gdt-fullscreen')) toggle();
    });
  },
  bindExpandCollapse() {
    const btn = document.getElementById('btn-gantt-expand-all');
    if (!btn || btn._gdtEcBound) return;
    btn._gdtEcBound = true;
    btn.addEventListener('click', () => {
      const teamKey = t => t.replace(/[^a-zA-Zа-яА-Я0-9]/g, '_');
      const allTks  = [...new Set(GanttView.getRows().map(r => teamKey(r.team)))];
      const anyVisible = allTks.some(tk => !GanttView._dtHiddenTeams?.has(tk));
      if (!GanttView._dtHiddenTeams) GanttView._dtHiddenTeams = new Set();
      if (anyVisible) allTks.forEach(tk => GanttView._dtHiddenTeams.add(tk));
      else            GanttView._dtHiddenTeams.clear();
      GanttView.renderChart();
    });
  },
  renderFilters() {
    const el = document.getElementById('gantt-filters');
    if (el) { el.innerHTML = ''; el.style.display = 'none'; }
  },
  getRows() {
    let rows=FilterEngine.getFiltered(); const f=GanttView.gf;
    if(f.team)rows=rows.filter(r=>r.team===f.team);
    if(f.scope)rows=rows.filter(r=>r.scopeStatus===f.scope);
    if(f.onlyBlocking)rows=rows.filter(r=>r.blockingDependency);
    if(f.onlyNoRelease)rows=rows.filter(r=>r.isUnassigned);
    if(f.onlyRisky)rows=rows.filter(r=>r.riskFlags&&r.riskFlags.length);
    return rows;
  },
  renderChart() {
    GanttView._clearTransientInteractions();
    if (GanttView._docTipListener) {
      document.removeEventListener('mousemove', GanttView._docTipListener);
      GanttView._docTipListener = null;
    }
    document.querySelectorAll('.gep-tooltip,.gtx-tooltip').forEach(t => t.remove());
    if (state.ganttMode==='epics') { GanttView.renderEpics(); return; }
    if (state.ganttMode==='arrows') { GanttView.renderArrows(); return; }
    if (state.ganttMode==='ultra') { GanttView.renderUltra(); return; }
    if (state.ganttMode==='arrowsNew') {
      const ganttWrap=document.getElementById('gantt-wrap');
      const g2Wrap=document.getElementById('gantt2-wrap');
      if (ganttWrap) ganttWrap.style.display='none';
      if (g2Wrap) { g2Wrap.classList.remove('hidden'); g2Wrap.style.display=''; }
      GanttV2.syncControls();
      GanttV2.renderChart();
      return;
    }
    const wrap=document.getElementById('gantt-wrap');
    // Ensure gantt-wrap is visible and gantt2-wrap is hidden in non-arrowsNew modes
    if (wrap) { wrap.style.display=''; }
    const g2WrapOther=document.getElementById('gantt2-wrap');
    if (g2WrapOther) { g2WrapOther.classList.add('hidden'); g2WrapOther.style.display='none'; }
    const rows=GanttView.getRows();
    if (!rows.length){wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>';return;}
    const cols=[
      {key:'backlog',label:'Бэклог',sub:'',cls:'gantt-window-backlog'},
      {key:'r120',label:'1.20',sub:'20.04–17.05',cls:'gantt-window-r120'},
      {key:'r121',label:'1.21',sub:'18.05–14.06',cls:'gantt-window-r121'},
      {key:'r122',label:'1.22',sub:'15.06–14.07',cls:'gantt-window-r122'},
      {key:'overtime',label:'OT',sub:'Овертайм',cls:'gantt-window-overtime'},
    ];
    const wrapW=Math.max(960,wrap.clientWidth||0);
    const lw=Math.max(220,Math.min(300,Math.round(wrapW*0.18)));
    const minCw=140;
    const cw=Math.max(minCw,Math.floor((wrapW-lw)/cols.length));
    const gt=`${lw}px repeat(${cols.length},${cw}px)`;
    const hasMap={backlog:'isUnassigned',r120:'hasRelease120',r121:'hasRelease121',r122:'hasRelease122',overtime:'hasOvertime'};
    const tfMap={r120:'release120Types',r121:'release121Types',r122:'release122Types',overtime:'overtimeTypes'};
    const header=`<div class="gantt-header" style="display:grid;grid-template-columns:${gt}">
      <div class="gantt-header-label">Команда / Задача</div>
      ${cols.map(c=>`<div class="gantt-header-col">${c.label}${c.sub?`<br><span class="gantt-col-date">${c.sub}</span>`:''}</div>`).join('')}
    </div>`;

    let body='';
    if (state.ganttMode==='compact') {
      Utils.unique(rows.map(r=>r.team)).forEach(team=>{
        const tr=rows.filter(r=>r.team===team);
        const cells=cols.map(col=>{
          const cnt=tr.filter(r=>r[hasMap[col.key]]).length;
          const barCls=RELEASE_WINDOWS[col.key]?RELEASE_WINDOWS[col.key].barCls:'gantt-bar-backlog';
          return `<div class="gantt-cell ${col.cls}">${cnt?`<div class="gantt-bar ${barCls}">${cnt} задач</div>`:''}</div>`;
        });
        body+=`<div class="gantt-row" style="display:grid;grid-template-columns:${gt}">
          <div class="gantt-row-label"><div class="gantt-row-label-name">${team}</div><div class="gantt-row-label-sub">${tr.length} задач</div></div>
          ${cells.join('')}</div>`;
      });
    } else if (state.ganttMode==='detailedTasks') {
      GanttView.renderDetailedTasks(rows, wrap, cols);
      return;
    } else {
      // Detailed with team "wells"
      const teams=Utils.unique(rows.map(r=>r.team));
      teams.forEach(team=>{
        const teamRows=rows.filter(r=>r.team===team);
        body+=`<div class="gantt-team-header" style="display:grid;grid-template-columns:${gt}">
          <div class="gantt-team-header-cell">▾ ${team} <span class="team-count">${teamRows.length} задач</span></div>
          ${cols.map(col=>{
            const cnt=teamRows.filter(r=>r[hasMap[col.key]]).length;
            return `<div class="gantt-team-header-cell" style="font-weight:400;color:var(--text-3)">${cnt||''}</div>`;
          }).join('')}
        </div>`;
        teamRows.forEach(row=>{
          const cells=cols.map(col=>{
            const has=row[hasMap[col.key]];
            const barCls=RELEASE_WINDOWS[col.key]?RELEASE_WINDOWS[col.key].barCls:'gantt-bar-backlog';
            const types=(tfMap[col.key]?row[tfMap[col.key]]:[])||[];
            return `<div class="gantt-cell ${col.cls}">${has?`<div class="gantt-bar ${barCls}" title="${types.join(', ')}">${types.slice(0,2).join(',')||'•'}</div>`:''}</div>`;
          });
          body+=`<div class="gantt-row" style="display:grid;grid-template-columns:${gt}">
            <div class="gantt-row-label">
              <div class="gantt-row-label-name">${RH.riskBadges(row.riskFlags)} ${Utils.truncate(row.epic||row.tasks,30)}</div>
            </div>${cells.join('')}</div>`;
        });
      });
    }

    const legend=`<div class="gantt-legend">
      ${[['#6b7280','Бэклог'],['#4f46e5','1.20'],['#059669','1.21'],['#d97706','1.22'],['#dc2626','OT']].map(([c,l])=>`<div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:${c}"></div>${l}</div>`).join('')}
    </div>`;
    wrap.innerHTML=`<div class="gantt-container">${header}<div>${body}</div>${legend}</div>`;
  },
  renderDetailedTasks(rows, wrap, cols) {
    /* ---- helpers ---- */
    const esc = Utils.escapeHtml;
    const toTags = v => String(v||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
    const wtEmoji = wt => {
      const x = String(wt||'').trim().toLowerCase();
      if (!x) return '🧩';
      if (x.includes('бизнес аналит')) return '📈';
      if (x.includes('аналит')) return '📊';
      if (x.includes('backend')||x.includes('бэкенд')||x.includes('разработ')) return '💻';
      if (x.includes('frontend')||x.includes('фронт')) return '🖥️';
      if (x.includes('qa')||x.includes('тест')) return '🧪';
      if (x.includes('внедр')) return '🚀';
      if (x.includes('миграц')) return '🗃️';
      if (x.includes('стабилиз')) return '🧯';
      if (x.includes('хотфикс')||x.includes('hotfix')) return '🚑';
      if (x.includes('интеграц')) return '🔌';
      if (x.includes('документ')) return '📝';
      return '🧩';
    };

    /* ---- field maps ---- */
    const hasMap    = {backlog:'isUnassigned',r120:'hasRelease120',r121:'hasRelease121',r122:'hasRelease122',overtime:'hasOvertime'};
    const tfMap     = {backlog:'backlogTypes',r120:'release120Types',r121:'release121Types',r122:'release122Types',overtime:'overtimeTypes'};
    const colKeyMap = {backlog:'backlogTypes',r120:'release120Types',r121:'release121Types',r122:'release122Types',overtime:'overtimeTypes'};

    /* ---- per-column widths (persisted across re-renders) ---- */
    if (!GanttView._dtColWidths) GanttView._dtColWidths = {};
    if (!GanttView._dtHiddenTeams) GanttView._dtHiddenTeams = new Set();
    const wrapW      = Math.max(960, wrap.clientWidth || 0);
    const lwDefault  = Math.max(220, Math.min(420, Math.round(wrapW * 0.18)));
    // '_label' key stores user-resized label-column width
    if (!GanttView._dtColWidths['_label']) GanttView._dtColWidths['_label'] = lwDefault;
    const getLW      = () => GanttView._dtColWidths['_label'] || lwDefault;
    const defaultCw  = Math.max(140, Math.floor((wrapW - getLW()) / cols.length));
    const getW       = key => GanttView._dtColWidths[key] || defaultCw;
    const makeGT     = () => getLW() + 'px ' + cols.map(c => getW(c.key) + 'px').join(' ');

    /* ---- build HTML body ---- */
    let body = '';
    const teams   = Utils.unique(rows.map(r => r.team));
    const teamKey = t => t.replace(/[^a-zA-Zа-яА-Я0-9]/g,'_');

    teams.forEach(team => {
      const teamRows = rows.filter(r => r.team === team);
      const tk       = teamKey(team);
      const isHidden = GanttView._dtHiddenTeams.has(tk);

      body += `<div class="gantt-team-header gdt-grid-row" data-team-key="${esc(tk)}" style="display:grid;grid-template-columns:${makeGT()}">
        <div class="gantt-team-header-cell gdt-team-label">
          <button class="gantt-team-vis-btn" data-team-key="${esc(tk)}" title="Скрыть/показать строки команды">${isHidden?'▸':'▾'}</button>
          <strong class="gdt-team-name">${esc(team||'—')}</strong>
          <span class="team-count">${teamRows.length} задач</span>
        </div>
        ${cols.map(col => {
          const cnt = teamRows.filter(r => r[hasMap[col.key]]).length;
          return `<div class="gantt-team-header-cell" style="font-weight:400;color:var(--text-3)">${cnt||''}</div>`;
        }).join('')}
      </div>`;

      teamRows.forEach(row => {
        const epicText     = Utils.truncate(row.epic||row.tasks||'(без эпика)', 42);
        const cats         = toTags(row.category);
        const catHtml      = cats.length
          ? cats.slice(0,3).map(cat=>`<span class="chip chip-indigo">${esc(Utils.truncate(cat,16))}</span>`).join('')
          : '<span class="text-muted text-xs">без категории</span>';
        const assignees    = toTags(row.assignee);
        const hasAssignee  = assignees.length > 0;
        const assigneeText = hasAssignee ? assignees.join(', ') : 'без исполнителя';
        const noAssignee   = !hasAssignee ? '<span class="gantt-no-assignee" title="Исполнитель не назначен">⚠</span>' : '';
        const dp = row.donePills || {}; // per-pill done map: "${colKey}__${wt}" → true
        const pillDone = (colKey, wt) => !!dp[`${colKey}__${wt}`];
        // Labels for ghost-marker (kept in sync with NEXT_RELEASE/COL_LABEL below)
        const _GHOST_COL_LABEL = { backlog:'Бэклог', r120:'1.20', r121:'1.21', r122:'1.22', overtime:'OT' };
        const arrowsBySrc = {};
        (row.ganttArrows || []).forEach(a => {
          if (!arrowsBySrc[a.srcCol]) arrowsBySrc[a.srcCol] = [];
          arrowsBySrc[a.srcCol].push(a);
        });

        const cells = cols.map(col => {
          // Ghost markers: types that left this cell to another column
          const ghosts = (arrowsBySrc[col.key] || []).map(a => {
            const dstLabel = _GHOST_COL_LABEL[a.dstCol] || a.dstCol;
            return `<span class="gantt-type-pill gantt-pill-ghost" data-wt="${esc(a.wt)}" data-row-id="${esc(row.id)}" data-src-col="${esc(col.key)}" data-dst-col="${esc(a.dstCol)}" title="Перенесено в ${esc(dstLabel)}">↗ ${esc(Utils.truncate(a.wt,10))}</span>`;
          }).join('');

          /* ---- backlog cell: always show "+", pills from backlogTypes ---- */
          if (col.key === 'backlog') {
            const bTypes = (row.backlogTypes || []);
            const shown  = bTypes.slice(0, 4);
            const more   = bTypes.length - shown.length;
            const pills  = shown.map(t => {
              const dc = pillDone('backlog', t) ? ' gdt-pill-done' : '';
              return `<span class="gantt-type-pill${dc}" draggable="true"
                data-wt="${esc(t)}" data-row-id="${esc(row.id)}" data-src-col="backlog"
                title="${esc(t)}">${wtEmoji(t)} ${esc(Utils.truncate(t,12))}</span>`;
            }).join('');
            const moreHtml = more > 0 ? `<span class="gantt-type-pill">+${more}</span>` : '';
            const inner = (pills || ghosts) ? `<div class="gantt-bar-multi" data-row-id="${esc(row.id)}" data-src-col="backlog">${pills}${moreHtml}${ghosts}</div>` : '';
            return `<div class="gantt-cell gantt-window-backlog" data-col="backlog" data-row-id="${esc(row.id)}">
              ${inner}
              <button class="gdt-add-type-btn" data-row-id="${esc(row.id)}" title="Добавить тип задачи">+</button>
            </div>`;
          }
          /* ---- release / overtime cells ---- */
          const has   = row[hasMap[col.key]];
          const types = (row[tfMap[col.key]] || []);
          const shown = types.slice(0, 4);
          const more  = types.length - shown.length;
          const pills = shown.map(t => {
            const dc = pillDone(col.key, t) ? ' gdt-pill-done' : '';
            return `<span class="gantt-type-pill${dc}" draggable="true"
              data-wt="${esc(t)}" data-row-id="${esc(row.id)}" data-src-col="${esc(col.key)}"
              title="${esc(t)} — ${esc(assigneeText)}">${wtEmoji(t)} ${esc(Utils.truncate(t,12))}</span>`;
          }).join('');
          const fallback = `<span class="gantt-type-pill" draggable="true"
            data-wt="задача" data-row-id="${esc(row.id)}" data-src-col="${esc(col.key)}">🧩 задача</span>`;
          const moreHtml = more > 0 ? `<span class="gantt-type-pill">+${more}</span>` : '';
          const inner = (has || ghosts)
            ? `<div class="gantt-bar-multi" data-row-id="${esc(row.id)}" data-src-col="${esc(col.key)}">${has ? (pills||fallback) : ''}${moreHtml}${ghosts}</div>`
            : '';
          return `<div class="gantt-cell ${col.cls}" data-col="${esc(col.key)}" data-row-id="${esc(row.id)}">
            ${inner}
          </div>`;
        });

        body += `<div class="gantt-row gdt-grid-row" data-team-key="${esc(tk)}" style="display:${isHidden?'none':'grid'};grid-template-columns:${makeGT()}">
          <div class="gantt-row-label">
            <div class="gantt-row-label-name">${RH.riskBadges(row.riskFlags)} ${noAssignee} ${esc(epicText)}</div>
            <div class="gantt-row-label-sub">${catHtml}</div>
          </div>${cells.join('')}</div>`;
      });
    });

    /* ---- header with resize handles ---- */
    const gt = makeGT();
    const headerCols =
      `<div class="gantt-header-label" style="position:relative">Эпик / Категория
        <div class="gdt-resize-handle" data-col-key="_label" title="Потяните чтобы изменить ширину столбца задач"></div>
      </div>` +
      cols.map(c =>
        `<div class="gantt-header-col" style="position:relative">
          ${esc(c.label)}${c.sub?`<br><span class="gantt-col-date">${esc(c.sub)}</span>`:''}
          <div class="gdt-resize-handle" data-col-key="${esc(c.key)}" title="Потяните чтобы изменить ширину"></div>
        </div>`
      ).join('');
    const header = `<div class="gantt-header gdt-header gdt-grid-row" style="display:grid;grid-template-columns:${gt}">${headerCols}</div>`;
    const legend = `<div class="gantt-legend">
      ${[['#6b7280','Бэклог'],['#4f46e5','1.20'],['#059669','1.21'],['#d97706','1.22'],['#dc2626','OT']].map(([c,l])=>`<div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:${c}"></div>${l}</div>`).join('')}
    </div>`;

    wrap.innerHTML = `<div class="gantt-container gdt-container">${header}<div class="gantt-body">${body}</div>${legend}</div>`;
    wrap.style.overflow = 'visible';

    /* update expand/collapse-all button icon */
    const ecBtn = document.getElementById('btn-gantt-expand-all');
    if (ecBtn) {
      const anyVisible = teams.some(t => !GanttView._dtHiddenTeams?.has(teamKey(t)));
      ecBtn.textContent = anyVisible ? '⊟' : '⊞';
      ecBtn.title       = anyVisible ? 'Свернуть все команды' : 'Развернуть все команды';
    }

    /* ---- helper: update all grid rows to new column widths ---- */
    const updateAllGrids = () => {
      const newGT = makeGT();
      wrap.querySelectorAll('.gdt-grid-row').forEach(el => { el.style.gridTemplateColumns = newGT; });
    };

    /* ---- team visibility toggle — use style.display to override inline display:grid ---- */
    wrap.querySelectorAll('.gantt-team-vis-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const tk2 = btn.dataset.teamKey;
        const nowHidden = !GanttView._dtHiddenTeams.has(tk2);
        if (nowHidden) GanttView._dtHiddenTeams.add(tk2);
        else           GanttView._dtHiddenTeams.delete(tk2);
        wrap.querySelectorAll('.gantt-row').forEach(rowEl => {
          if (rowEl.dataset.teamKey === tk2) rowEl.style.display = nowHidden ? 'none' : 'grid';
        });
        btn.textContent = nowHidden ? '▸' : '▾';
      });
    });

    /* ---- Fix 1.1 + 1.2: per-pill drag-and-drop with merge semantics ---- */
    wrap.querySelectorAll('.gantt-type-pill[draggable]').forEach(pill => {
      pill.addEventListener('dragstart', e => {
        e.stopPropagation();
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('rowId',  pill.dataset.rowId);
        e.dataTransfer.setData('srcCol', pill.dataset.srcCol);
        e.dataTransfer.setData('wt',     pill.dataset.wt);
        pill.style.opacity = '.4';
      });
      pill.addEventListener('dragend', () => { pill.style.opacity = ''; });
    });
    wrap.querySelectorAll('.gantt-cell[data-col]').forEach(cell => {
      cell.addEventListener('dragover',  e => { e.preventDefault(); cell.classList.add('gantt-cell-dragover'); });
      cell.addEventListener('dragleave', ()  => cell.classList.remove('gantt-cell-dragover'));
      cell.addEventListener('drop', e => {
        e.preventDefault();
        cell.classList.remove('gantt-cell-dragover');
        const rowId  = e.dataTransfer.getData('rowId');
        const srcCol = e.dataTransfer.getData('srcCol');
        const wt     = e.dataTransfer.getData('wt');
        const dstCol = cell.dataset.col;
        if (!rowId || !wt || srcCol === dstCol) return;
        const row = state.rows.find(r => r.id === rowId);
        if (!row) return;
        const srcField = colKeyMap[srcCol];
        const dstField = colKeyMap[dstCol];
        window.HistoryManager?.checkpoint('перенос задачи в Гант');
        /* remove this specific wt from source column */
        if (srcField && Array.isArray(row[srcField])) {
          row[srcField] = row[srcField].filter(t => t !== wt);
        }
        /* merge into destination column (Fix 1.1 — don't overwrite) */
        if (dstField) {
          const existing = Array.isArray(row[dstField]) ? row[dstField] : [];
          if (!existing.includes(wt)) existing.push(wt);
          row[dstField] = existing;
        }
        row.dirty = true; row.updatedAt = new Date().toISOString();
        RowFactory.updateDerived(row);
        Storage.save();
        GanttView.renderChart();
      });
    });

    /* ---- backlog "+" picker ---- */
    const removeAddPicker = () => document.getElementById('gdt-add-picker')?.remove();
    wrap.querySelectorAll('.gdt-add-type-btn').forEach(plusBtn => {
      plusBtn.addEventListener('click', e => {
        e.stopPropagation();
        removeAddPicker();
        const rowId = plusBtn.dataset.rowId;
        const row   = state.rows.find(r => r.id === rowId);
        if (!row) return;

        /* collect all unique types from the whole dataset (do not filter by what's already in this row) */
        const allDataTypes = new Set(WORK_TYPES);
        state.rows.forEach(r => {
          (r.release120Types||[]).forEach(t=>allDataTypes.add(t));
          (r.release121Types||[]).forEach(t=>allDataTypes.add(t));
          (r.release122Types||[]).forEach(t=>allDataTypes.add(t));
          (r.overtimeTypes||[]).forEach(t=>allDataTypes.add(t));
          (r.backlogTypes||[]).forEach(t=>allDataTypes.add(t));
        });

        /* mark already-added types but show ALL */
        const inWells = new Set([
          ...(row.release120Types||[]),
          ...(row.release121Types||[]),
          ...(row.release122Types||[]),
          ...(row.overtimeTypes||[]),
          ...(row.backlogTypes||[]),
        ]);
        const available = [...allDataTypes].filter(Boolean).sort((a,b)=>a.localeCompare(b,'ru'));

        if (!available.length) {
          window.showToast?.('В системе нет типов задач', 'info', 1800);
          return;
        }

        const picker = document.createElement('div');
        picker.id = 'gdt-add-picker';
        picker.className = 'gdt-add-picker';
        const rect = plusBtn.getBoundingClientRect();
        const px = Math.min(rect.left, window.innerWidth  - 220);
        const py = Math.min(rect.bottom + 4, window.innerHeight - 260);
        picker.style.cssText = `position:fixed;top:${py}px;left:${px}px;z-index:9999`;
        picker.innerHTML = `
          <div class="gdt-add-picker-title">Выберите тип задачи</div>
          <div class="gdt-add-picker-list">
            ${available.map(t => {
              const already = inWells.has(t);
              return `<label class="gdt-add-picker-item${already?' gdt-add-picker-item-used':''}" title="${already?'Уже добавлен в эту строку':''}">
                <input type="checkbox" value="${esc(t)}"${already?' disabled':''}>
                ${wtEmoji(t)} ${esc(t)}${already?' <span class="gdt-add-picker-used-badge">уже добавлен</span>':''}
              </label>`;
            }).join('')}
          </div>
          <div class="gdt-add-picker-footer">
            <button class="btn btn-sm btn-primary gdt-add-picker-ok">Добавить</button>
            <button class="btn btn-sm btn-outline gdt-add-picker-cancel">Отмена</button>
          </div>`;
        document.body.appendChild(picker);

        picker.querySelector('.gdt-add-picker-ok').addEventListener('click', () => {
          const selected = [...picker.querySelectorAll('input:checked')].map(cb => cb.value);
          if (!selected.length) { removeAddPicker(); return; }
          window.HistoryManager?.checkpoint('добавить тип в бэклог');
          if (!Array.isArray(row.backlogTypes)) row.backlogTypes = [];
          selected.forEach(t => { if (!row.backlogTypes.includes(t)) row.backlogTypes.push(t); });
          row.dirty = true; row.updatedAt = new Date().toISOString();
          RowFactory.updateDerived(row);
          Storage.save();
          removeAddPicker();
          GanttView.renderChart();
        });
        picker.querySelector('.gdt-add-picker-cancel').addEventListener('click', removeAddPicker);

        const onOutside = ev => {
          if (!picker.contains(ev.target) && ev.target !== plusBtn) {
            removeAddPicker();
            document.removeEventListener('click', onOutside, true);
          }
        };
        setTimeout(() => document.addEventListener('click', onOutside, true), 0);
      });
    });

    /* ---- Fix 1.7 + label column: resize handles ---- */
    wrap.querySelectorAll('.gdt-resize-handle').forEach(handle => {
      handle.addEventListener('mousedown', e => {
        e.preventDefault();
        const colKey  = handle.dataset.colKey;
        const isLabel = colKey === '_label';
        const startX  = e.clientX;
        const startW  = isLabel ? getLW() : getW(colKey);
        const minW    = isLabel ? 140 : 80;
        const maxW    = isLabel ? 600 : 600;
        document.body.style.cursor = 'col-resize';
        const onMove = ev => {
          const newW = Math.max(minW, Math.min(maxW, startW + ev.clientX - startX));
          GanttView._dtColWidths[colKey] = newW;
          updateAllGrids();
        };
        const onUp = () => {
          document.body.style.cursor = '';
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup',   onUp);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup',   onUp);
      });
    });

    /* ---- context menu: per-pill done + перенос в след релиз ---- */
    const NEXT_RELEASE  = { backlog:'r120', r120:'r121', r121:'r122', r122:'overtime' };
    const COL_LABEL     = { backlog:'Бэклог', r120:'1.20', r121:'1.21', r122:'1.22', overtime:'OT' };

    const removeCtxMenu = () => document.getElementById('gdt-ctx-menu')?.remove();
    wrap.addEventListener('contextmenu', e => {
      const pill = e.target.closest('.gantt-type-pill[data-wt][data-row-id]');
      if (!pill) return;
      e.preventDefault();
      removeCtxMenu();
      const rowId  = pill.dataset.rowId;
      const wt     = pill.dataset.wt;
      const srcCol = pill.dataset.srcCol;
      if (!rowId || !wt || wt === 'задача') return;
      const row = state.rows.find(r => r.id === rowId);
      if (!row) return;
      if (!row.donePills)   row.donePills   = {};
      if (!row.ganttArrows) row.ganttArrows = [];

      const doneKey = `${srcCol}__${wt}`;
      const isDone  = !!row.donePills[doneKey];
      const label   = Utils.escapeHtml(Utils.truncate(wt, 18));
      const nextCol = NEXT_RELEASE[srcCol];
      const nextLabel = nextCol ? COL_LABEL[nextCol] : null;

      const menu = document.createElement('div');
      menu.id = 'gdt-ctx-menu';
      menu.className = 'gdt-ctx-menu';
      const mx = Math.min(e.clientX, window.innerWidth  - 220);
      const my = Math.min(e.clientY, window.innerHeight - 120);
      menu.style.cssText = `position:fixed;top:${my}px;left:${mx}px;z-index:9999`;
      menu.innerHTML = `
        <div class="gdt-ctx-label">${label}</div>
        ${isDone
          ? `<div class="gdt-ctx-item" data-action="undone">↩ Вернуть в работу</div>`
          : `<div class="gdt-ctx-item" data-action="done">✓ Завершить</div>`}
        ${nextLabel
          ? `<div class="gdt-ctx-item gdt-ctx-item-move" data-action="move-next">
               <span class="gdt-ctx-move-arrow">→</span> Перенести в <b>${nextLabel}</b>
             </div>`
          : `<div class="gdt-ctx-item gdt-ctx-item-disabled">→ Последний релиз</div>`}`;
      document.body.appendChild(menu);

      menu.addEventListener('click', ev => {
        const action = ev.target.closest('[data-action]')?.dataset.action;
        if (!action) return;

        if (action === 'done' || action === 'undone') {
          window.HistoryManager?.checkpoint(action === 'done' ? `завершить ${wt}` : `вернуть ${wt}`);
          if (!row.donePills) row.donePills = {};
          if (action === 'done') row.donePills[doneKey] = true;
          else                   delete row.donePills[doneKey];
          row.dirty = true;
          Storage.save();
          removeCtxMenu();
          GanttView.renderChart();
          return;
        }

        if (action === 'move-next' && nextCol) {
          const srcField = colKeyMap[srcCol];
          const dstField = colKeyMap[nextCol];
          window.HistoryManager?.checkpoint(`перенести ${wt}: ${COL_LABEL[srcCol]} → ${COL_LABEL[nextCol]}`);

          /* move the pill */
          if (srcField && Array.isArray(row[srcField])) {
            row[srcField] = row[srcField].filter(t => t !== wt);
          }
          if (dstField) {
            const existing = Array.isArray(row[dstField]) ? row[dstField] : [];
            if (!existing.includes(wt)) existing.push(wt);
            row[dstField] = existing;
          }

          /* record arrow (keep only latest move per wt) */
          if (!Array.isArray(row.ganttArrows)) row.ganttArrows = [];
          row.ganttArrows = row.ganttArrows.filter(a => a.wt !== wt);
          row.ganttArrows.push({ wt, srcCol, dstCol: nextCol });

          row.dirty = true; row.updatedAt = new Date().toISOString();
          RowFactory.updateDerived(row);
          Storage.save();
          removeCtxMenu();
          GanttView.renderChart();
        }
      });

      const onOutside = ev => {
        if (!menu.contains(ev.target)) { removeCtxMenu(); document.removeEventListener('click', onOutside, true); }
      };
      setTimeout(() => document.addEventListener('click', onOutside, true), 0);
    });

    /* draw postpone arrows after layout is settled */
    requestAnimationFrame(() => GanttView.drawPostponeArrows(wrap));
  },
  drawPostponeArrows(wrap) {
    const container = wrap.querySelector('.gdt-container');
    if (!container) return;
    /* remove stale SVG */
    container.querySelector('.gdt-arrows-svg')?.remove();

    /* collect all recorded arrows from visible rows */
    const arrows = [];
    state.rows.forEach(row => {
      if (!row.ganttArrows?.length) return;
      row.ganttArrows.forEach(a => {
        const srcCell = wrap.querySelector(`.gantt-cell[data-col="${a.srcCol}"][data-row-id="${row.id}"]`);
        const dstCell = wrap.querySelector(`.gantt-cell[data-col="${a.dstCol}"][data-row-id="${row.id}"]`);
        if (srcCell && dstCell) arrows.push({ srcCell, dstCell, wt: a.wt });
      });
    });
    if (!arrows.length) return;

    const sw = Math.max(container.scrollWidth,  container.clientWidth);
    const sh = Math.max(container.scrollHeight, container.clientHeight);
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.className  = 'gdt-arrows-svg';
    svg.setAttribute('width',  sw);
    svg.setAttribute('height', sh);
    svg.style.cssText = 'position:absolute;top:0;left:0;pointer-events:none;z-index:6;overflow:visible';

    /* single reusable arrowhead marker */
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    defs.innerHTML = `
      <marker id="gdt-ah" markerWidth="9" markerHeight="7" refX="8" refY="3.5" orient="auto">
        <polygon points="0 0, 9 3.5, 0 7" fill="#ef4444" opacity=".9"/>
      </marker>`;
    svg.appendChild(defs);

    const cRect = container.getBoundingClientRect();
    const scX   = container.scrollLeft;
    const scY   = container.scrollTop;

    arrows.forEach(({ srcCell, dstCell, wt }) => {
      const sR = srcCell.getBoundingClientRect();
      const dR = dstCell.getBoundingClientRect();
      if (!sR.width || !dR.width) return;

      /* positions relative to container + scroll offset */
      const sx = sR.right  - cRect.left + scX - 6;
      const sy = sR.top    + sR.height * 0.55 - cRect.top + scY;
      const dx = dR.left   - cRect.left + scX + 6;
      const dy = dR.top    + dR.height * 0.55 - cRect.top + scY;
      const drop = 24; /* bezier arc drops this many px below row center */

      /* curved dashed red path */
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d',
        `M ${sx} ${sy} C ${sx+50} ${sy+drop} ${dx-50} ${dy+drop} ${dx} ${dy}`);
      path.setAttribute('stroke',           '#ef4444');
      path.setAttribute('stroke-width',     '2');
      path.setAttribute('stroke-dasharray', '7,3');
      path.setAttribute('fill',             'none');
      path.setAttribute('marker-end',       'url(#gdt-ah)');
      path.setAttribute('opacity',          '0.85');
      svg.appendChild(path);

      /* small label at the arc's lowest point */
      const lx = (sx + dx) / 2;
      const ly = Math.max(sy, dy) + drop + 13;
      const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      const shortWt = wt.length > 12 ? wt.slice(0, 11) + '…' : wt;
      const tw = shortWt.length * 6 + 10;
      bg.setAttribute('x',      String(lx - tw / 2));
      bg.setAttribute('y',      String(ly - 11));
      bg.setAttribute('width',  String(tw));
      bg.setAttribute('height', '14');
      bg.setAttribute('rx',     '4');
      bg.setAttribute('fill',   '#fef2f2');
      bg.setAttribute('stroke', '#ef4444');
      bg.setAttribute('stroke-width', '1');
      bg.setAttribute('opacity', '0.92');
      svg.appendChild(bg);

      const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      text.setAttribute('x',           String(lx));
      text.setAttribute('y',           String(ly));
      text.setAttribute('text-anchor', 'middle');
      text.setAttribute('font-size',   '9.5');
      text.setAttribute('fill',        '#b91c1c');
      text.setAttribute('font-family', 'system-ui, sans-serif');
      text.setAttribute('font-weight', '700');
      text.textContent = shortWt;
      svg.appendChild(text);
    });

    container.style.position = 'relative';
    container.appendChild(svg);
  },
  renderArrows() {
    const wrap=document.getElementById('gantt-wrap');
    const rows=GanttView.getRows();
    if (!rows.length) {
      wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>';
      return;
    }

    if (typeof GanttView._arrowsShowLines !== 'boolean') GanttView._arrowsShowLines=true;
    document.querySelectorAll('.gep-tooltip,.gtx-tooltip').forEach(t=>t.remove());

    const esc=Utils.escapeHtml;
    const toTags=v=>String(v||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
    const toDate=v=>{ if(!v) return null; const d=new Date(v); if(Number.isNaN(d.getTime())) return null; return new Date(d.getFullYear(),d.getMonth(),d.getDate()); };

    const hasEpicData=rows.some(r=>String(r.epic||'').trim());
    const epicMap={};
    rows.forEach(r=>{
      const key=hasEpicData
        ? (String(r.epic||'').trim()||'(без эпика)')
        : (String(r.category||r.tasks||'').trim()||'(без эпика)');
      if(!epicMap[key]) epicMap[key]=[];
      epicMap[key].push(r);
    });

    const epics=Object.keys(epicMap).sort((a,b)=>a.localeCompare(b,'ru'));
    const epicInfo={};
    epics.forEach(name=>{
      const erows=epicMap[name];
      const categories=new Set();
      const assignees=new Set();
      const roles=new Set();
      const phases={};
      let start=null,end=null;
      erows.forEach(r=>{
        toTags(r.category).forEach(x=>categories.add(x));
        toTags(r.assignee).forEach(x=>assignees.add(x));
        toTags(r.role).forEach(x=>roles.add(x));
        const pushPhase=(key,wtList,s,e)=>{
          if(!wtList.length||!s||!e) return;
          if(!phases[key]) phases[key]={types:new Set(),start:s,end:e};
          wtList.forEach(w=>phases[key].types.add(w));
          if (s<phases[key].start) phases[key].start=s;
          if (e>phases[key].end) phases[key].end=e;
          if (!start||s<start) start=s;
          if (!end||e>end) end=e;
        };
        if (r.hasRelease120) pushPhase('r120',Array.isArray(r.release120Types)?r.release120Types:[],new Date(GANTT_RELEASE_BOUNDS.r120[0]),new Date(GANTT_RELEASE_BOUNDS.r120[1]));
        if (r.hasRelease121) pushPhase('r121',Array.isArray(r.release121Types)?r.release121Types:[],new Date(GANTT_RELEASE_BOUNDS.r121[0]),new Date(GANTT_RELEASE_BOUNDS.r121[1]));
        if (r.hasRelease122) pushPhase('r122',Array.isArray(r.release122Types)?r.release122Types:[],new Date(GANTT_RELEASE_BOUNDS.r122[0]),new Date(GANTT_RELEASE_BOUNDS.r122[1]));
        if (r.hasOvertime) {
          const s=toDate(r.workPeriodStart), e=toDate(r.workPeriodEnd);
          pushPhase('ot',Array.isArray(r.overtimeTypes)?r.overtimeTypes:[],s,e);
        }
      });
      epicInfo[name]={
        categories:[...categories].sort((a,b)=>a.localeCompare(b,'ru')),
        assignees:[...assignees].sort((a,b)=>a.localeCompare(b,'ru')),
        roles:[...roles].sort((a,b)=>a.localeCompare(b,'ru')),
        phases,
        start,end,
        count:erows.length,
        blocking:erows.some(r=>!!r.blockingDependency),
      };
    });

    const sorted=[...epics].sort((a,b)=>{
      const ia=epicInfo[a], ib=epicInfo[b];
      if (ia.start && ib.start && ia.start.getTime()!==ib.start.getTime()) return ia.start-ib.start;
      if (ia.start && !ib.start) return -1;
      if (!ia.start && ib.start) return 1;
      return a.localeCompare(b,'ru');
    });

    let minBound=null,maxBound=null;
    sorted.forEach(name=>{
      const i=epicInfo[name];
      if (i.start && (!minBound||i.start<minBound)) minBound=i.start;
      if (i.end && (!maxBound||i.end>maxBound)) maxBound=i.end;
    });
    if (!minBound||!maxBound) { minBound=new Date(GANTT_TIMELINE_START); maxBound=new Date(GANTT_TIMELINE_END); }
    const spanDays=Math.ceil((maxBound.getTime()-minBound.getTime())/86400000);
    if (spanDays>280) {
      minBound=new Date(GANTT_TIMELINE_START);
      maxBound=new Date(GANTT_TIMELINE_END.getFullYear(), GANTT_TIMELINE_END.getMonth()+2, 0);
    }

    const tStartDate=new Date(minBound.getFullYear(),minBound.getMonth(),1);
    const tEndDate=new Date(maxBound.getFullYear(),maxBound.getMonth()+1,1);
    const timelineLastDay=new Date(tEndDate.getTime()-86400000);
    const totalDays=Math.max(1,Math.ceil((tEndDate.getTime()-tStartDate.getTime())/86400000));
    const wrapW=Math.max(1120,wrap.clientWidth||0);
    const LEFT_W=Math.max(320,Math.min(470,Math.round(wrapW*0.34)));
    const fitW=Math.max(860,wrapW-LEFT_W-4);
    const rawW=Math.round(totalDays*6);
    const totalW=Math.max(fitW,Math.min(rawW,5600));
    const dayPx=totalW/totalDays;
    const dayOffset=d=>Math.max(0,Math.round((d.getTime()-tStartDate.getTime())/86400000*dayPx));
    const dayWidth=(a,b)=>Math.max(12,Math.round(((b.getTime()-a.getTime())/86400000+1)*dayPx));

    let monthHeader='';
    for(let d=new Date(tStartDate); d<tEndDate; d=new Date(d.getFullYear(),d.getMonth()+1,1)){
      const next=new Date(d.getFullYear(),d.getMonth()+1,1);
      const x=dayOffset(d), w=Math.max(1,dayOffset(next)-x);
      monthHeader+=`<div class="gtx-month-cell" style="left:${x}px;width:${w}px">${esc(d.toLocaleString('ru',{month:'short',year:'2-digit'}))}</div>`;
    }

    const relDefs=[
      {key:'r120',label:'1.20',color:'rgba(79,70,229,.06)'},
      {key:'r121',label:'1.21',color:'rgba(5,150,105,.06)'},
      {key:'r122',label:'1.22',color:'rgba(217,119,6,.06)'},
    ];
    const relBounds={
      r120:[new Date(GANTT_RELEASE_BOUNDS.r120[0]),new Date(GANTT_RELEASE_BOUNDS.r120[1])],
      r121:[new Date(GANTT_RELEASE_BOUNDS.r121[0]),new Date(GANTT_RELEASE_BOUNDS.r121[1])],
      r122:[new Date(GANTT_RELEASE_BOUNDS.r122[0]),new Date(GANTT_RELEASE_BOUNDS.r122[1])],
    };
    let bands='';
    relDefs.forEach(rd=>{
      const b=relBounds[rd.key];
      const visS=b[0]<tStartDate?tStartDate:b[0];
      const visE=b[1]>timelineLastDay?timelineLastDay:b[1];
      if (visE<visS) return;
      const x=dayOffset(visS), w=dayWidth(visS,visE);
      bands+=`<div class="gtx-band" style="left:${x}px;width:${w}px;background:${rd.color}"></div>`;
      bands+=`<div class="gtx-band-label" style="left:${x+4}px">${rd.label}</div>`;
    });

    const depItems=Object.entries(state.epicDeps||{})
      .map(([to,from])=>({to:String(to||'').trim(),from:String(from||'').trim()}))
      .filter(d=>d.to&&d.from&&d.to!==d.from&&epicInfo[d.to]&&epicInfo[d.from])
      .map(d=>{
        const src=epicInfo[d.from], dst=epicInfo[d.to];
        return {...d,offtrack:!!(src.end&&dst.start&&dst.start<src.end)};
      })
      .sort((a,b)=>a.to.localeCompare(b.to,'ru'));

    const depFromMap={}; const depToCount={};
    depItems.forEach(d=>{ depFromMap[d.to]=d.from; depToCount[d.from]=(depToCount[d.from]||0)+1; });

    const ROW_H=52;
    const geometry={};
    const rowHtml=sorted.map((name,rowIdx)=>{
      const i=epicInfo[name];
      let bars='';
      let startX=Number.POSITIVE_INFINITY;
      let endX=Number.NEGATIVE_INFINITY;
      const addBar=(phaseKey,ph)=>{
        if(!ph||!ph.start||!ph.end) return;
        const visS=ph.start<tStartDate?tStartDate:ph.start;
        const visE=ph.end>timelineLastDay?timelineLastDay:ph.end;
        if (visE<visS) return;
        const bx=dayOffset(visS), bw=dayWidth(visS,visE);
        if (bx<startX) startX=bx;
        if (bx+bw>endX) endX=bx+bw;
        const ordered=PHASE_ORDER.filter(p=>ph.types.has(p));
        const leftovers=[...ph.types].filter(t=>!ordered.includes(t));
        const all=[...ordered,...leftovers];
        const segBase=Math.max(1,Math.floor(bw/Math.max(1,all.length)));
        let segs='',left=0;
        all.forEach((wt,idx)=>{
          const sw=idx===all.length-1?Math.max(1,bw-left):segBase;
          segs+=`<span class="gtx-seg" style="left:${left}px;width:${sw}px;background:${PHASE_COLORS[wt]||'#6b7280'}">${sw>=36?(PHASE_SHORT[wt]||Utils.truncate(wt,10)):''}</span>`;
          left+=sw;
        });
        bars+=`<div class="gtx-bar${i.blocking?' gtx-bar-blocking':''}" style="left:${bx}px;width:${bw}px">${segs}</div>`;
      };
      addBar('r120',i.phases.r120);
      addBar('r121',i.phases.r121);
      addBar('r122',i.phases.r122);
      addBar('ot',i.phases.ot);
      if (!Number.isFinite(startX)) {
        startX=6;
        endX=Math.min(totalW-6,startX+Math.round(10*dayPx));
        bars=`<div class="gtx-bar" style="left:${startX}px;width:${Math.max(14,endX-startX)}px"><span class="gtx-seg" style="left:0;width:100%;background:#94a3b8">BL</span></div>`;
      }

      const y=rowIdx*ROW_H+ROW_H/2;
      geometry[name]={startX,endX,top:rowIdx*ROW_H,midY:y,startDate:i.start,endDate:i.end};
      const inDep=depFromMap[name]||'';
      const depOut=depToCount[name]||0;
      const cats=i.categories.slice(0,2).map(c=>`<span class="chip chip-indigo">${esc(Utils.truncate(c,16))}</span>`).join('');
      const assigneeText=i.assignees.slice(0,2).join(', ')||'—';
      const handleX=Math.max(12,Math.min(totalW-12,endX-10));
      return `<div class="gar-row${i.blocking?' gar-row-blocking':''}" style="height:${ROW_H}px" data-epic="${esc(name)}">
        <div class="gar-left" style="width:${LEFT_W}px">
          <div class="gar-title">${esc(Utils.truncate(name,60))}</div>
          <div class="gar-meta">${cats||'<span class="text-muted text-xs">без категории</span>'}<span class="chip chip-gray">${esc(Utils.truncate(assigneeText,26))}</span>${inDep?`<span class="chip chip-purple">← ${esc(Utils.truncate(inDep,14))}</span>`:''}${depOut?`<span class="chip chip-blue">→ ${depOut}</span>`:''}</div>
        </div>
        <div class="gar-time" style="width:${totalW}px">
          <div class="gar-time-inner" style="width:${totalW}px">
            ${bars}
            <button class="gar-handle" data-epic="${esc(name)}" style="left:${handleX}px" aria-label="Создать связь">◎</button>
          </div>
        </div>
      </div>`;
    }).join('');

    const routePath=(src,dst,idx)=>{
      const sx=LEFT_W+src.endX+2;
      const sy=src.midY;
      const tx=LEFT_W+dst.startX-8;
      const ty=dst.midY;
      const syTop=src.top+8;
      const tyTop=dst.top+8;
      const bendX=Math.max(sx+18,tx+18,LEFT_W+Math.max(src.endX,dst.startX)+24+(idx%4)*10);
      return `M${sx},${sy} L${sx},${syTop} L${bendX},${syTop} L${bendX},${tyTop} L${tx},${tyTop} L${tx},${ty}`;
    };
    const depPaths=depItems.map((d,idx)=>{
      const src=geometry[d.from], dst=geometry[d.to];
      if(!src||!dst) return '';
      const stroke=d.offtrack?'#dc2626':'#6366f1';
      const marker=d.offtrack?'url(#gar-arr-red)':'url(#gar-arr-indigo)';
      return `<path d="${routePath(src,dst,idx)}" stroke="${stroke}" stroke-width="${d.offtrack?2.2:1.8}" stroke-linecap="round" stroke-linejoin="round" fill="none" marker-end="${marker}" opacity=".92"/>`;
    }).join('');

    wrap.innerHTML=`<div class="gar-shell" style="--gar-left:${LEFT_W}px">
      <div class="gar-toolbar">
        <span class="gtx-pill">Эпиков: ${sorted.length}</span>
        <span class="gtx-pill">Связей: ${depItems.length}</span>
        <span class="gtx-pill${depItems.some(x=>x.offtrack)?' gtx-pill-danger':''}">Конфликтов: ${depItems.filter(x=>x.offtrack).length}</span>
        <label class="gtx-lines-toggle"><input type="checkbox" id="gar-show-lines"${GanttView._arrowsShowLines?' checked':''}> Показать стрелки</label>
        <span class="gar-hint">Тяните ◎ с эпика-источника на строку целевого эпика (FS-зависимость).</span>
      </div>
      <div class="gtx-shell">
        <div class="gtx-grid" style="min-width:${LEFT_W+totalW}px">
          <div class="gtx-head">
            <div class="gtx-head-epic" style="width:${LEFT_W}px">Эпик / Категория / Исполнитель</div>
            <div class="gtx-head-time" style="width:${totalW}px"><div class="gtx-month-track" style="width:${totalW}px">${monthHeader}</div></div>
          </div>
          <div class="gtx-body" style="height:${sorted.length*ROW_H}px">
            <div class="gtx-time-bands" style="left:${LEFT_W}px;width:${totalW}px;height:${sorted.length*ROW_H}px">${bands}</div>
            <div class="gar-rows">${rowHtml}</div>
            <svg class="gar-dep-svg" style="width:${LEFT_W+totalW}px;height:${sorted.length*ROW_H}px" viewBox="0 0 ${LEFT_W+totalW} ${sorted.length*ROW_H}">
              <defs>
                <marker id="gar-arr-indigo" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto"><path d="M0,0 L0,7 L7,3.5 z" fill="#4f46e5"/></marker>
                <marker id="gar-arr-red" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto"><path d="M0,0 L0,7 L7,3.5 z" fill="#dc2626"/></marker>
              </defs>
              ${GanttView._arrowsShowLines?depPaths:''}
            </svg>
          </div>
        </div>
      </div>
      <div class="gar-links-list">
        ${depItems.length?depItems.map(d=>`<span class="gar-link-pill${d.offtrack?' offtrack':''}">
          <button class="gar-link-focus" data-from="${esc(d.from)}" data-to="${esc(d.to)}">${esc(Utils.truncate(d.from,18))} → ${esc(Utils.truncate(d.to,18))}</button>
          <button class="gar-link-remove" data-to="${esc(d.to)}" title="Удалить связь">×</button>
        </span>`).join(''):'<span class="text-muted text-sm">Связей пока нет</span>'}
      </div>
    </div>`;

    const refresh=()=>{ Storage.save(); GanttView.renderChart(); };
    const showLines=wrap.querySelector('#gar-show-lines');
    if (showLines) showLines.addEventListener('change',e=>{ GanttView._arrowsShowLines=!!e.target.checked; GanttView.renderChart(); });
    wrap.querySelectorAll('.gar-link-remove').forEach(btn=>btn.addEventListener('click',e=>{
      e.preventDefault(); e.stopPropagation();
      const to=btn.dataset.to||'';
      if (to&&state.epicDeps[to]) { delete state.epicDeps[to]; refresh(); }
    }));
    wrap.querySelectorAll('.gar-link-focus').forEach(btn=>btn.addEventListener('click',e=>{
      e.preventDefault();
      const to=btn.dataset.to||'';
      const row=wrap.querySelector(`.gar-row[data-epic="${CSS.escape(to)}"]`);
      if (row&&row.scrollIntoView) row.scrollIntoView({block:'center',behavior:'smooth'});
      row&&row.classList.add('gar-row-drop');
      setTimeout(()=>row&&row.classList.remove('gar-row-drop'),900);
    }));

    let drag=null,ghostSvg=null,ghostPath=null,dropRow=null;
    const onBlur=()=>clearDrag();
    const clearDrag=()=>{
      ghostSvg&&ghostSvg.remove();
      dropRow&&dropRow.classList.remove('gar-row-drop');
      drag=null; ghostSvg=null; ghostPath=null; dropRow=null;
      document.removeEventListener('mousemove',onMove);
      document.removeEventListener('mouseup',onUp);
      document.removeEventListener('keydown',onKey);
      window.removeEventListener('blur',onBlur);
    };
    GanttView._cancelTransientInteractions=clearDrag;
    const drawGhost=(x1,y1,x2,y2)=>{
      if(!ghostPath) return;
      const bend=Math.max(x1,x2)+28;
      ghostPath.setAttribute('d',`M${x1},${y1} L${bend},${y1} L${bend},${y2} L${x2},${y2}`);
    };
    const rowAt=(x,y)=>{
      const el=document.elementFromPoint(x,y);
      return el&&el.closest?el.closest('#gantt-wrap .gar-row'):null;
    };
    const onMove=(e)=>{
      if(!drag) return;
      drawGhost(drag.x,drag.y,e.clientX,e.clientY);
      const r=rowAt(e.clientX,e.clientY);
      const valid=r&&r.dataset.epic&&r.dataset.epic!==drag.from?r:null;
      if (dropRow&&dropRow!==valid) dropRow.classList.remove('gar-row-drop');
      if (valid&&dropRow!==valid) valid.classList.add('gar-row-drop');
      dropRow=valid;
    };
    const onUp=(e)=>{
      if(!drag) return;
      const r=rowAt(e.clientX,e.clientY);
      const to=r?(r.dataset.epic||''):'';
      const from=drag.from;
      clearDrag();
      if (!to||!from||to===from) return;
      state.epicDeps[to]=from;
      refresh();
      window.showToast?.(`Связь создана: ${to} зависит от ${from}`);
    };
    const onKey=e=>{ if(e.key==='Escape') clearDrag(); };

    wrap.querySelectorAll('.gar-handle').forEach(btn=>btn.addEventListener('mousedown',e=>{
      e.preventDefault(); e.stopPropagation();
      clearDrag();
      const row=btn.closest('.gar-row');
      if(!row) return;
      drag={from:row.dataset.epic,x:e.clientX,y:e.clientY};
      const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
      svg.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:9800;';
      const p=document.createElementNS('http://www.w3.org/2000/svg','path');
      p.setAttribute('stroke','#4f46e5');
      p.setAttribute('stroke-width','2');
      p.setAttribute('stroke-dasharray','6 4');
      p.setAttribute('stroke-linecap','round');
      p.setAttribute('stroke-linejoin','round');
      p.setAttribute('fill','none');
      svg.appendChild(p);
      document.body.appendChild(svg);
      ghostSvg=svg; ghostPath=p;
      drawGhost(e.clientX,e.clientY,e.clientX,e.clientY);
      document.addEventListener('mousemove',onMove);
      document.addEventListener('mouseup',onUp);
      document.addEventListener('keydown',onKey);
      window.addEventListener('blur',onBlur);
    }));
  },

  renderUltra() {
    const wrap=document.getElementById('gantt-wrap');
    const rows=GanttView.getRows();
    if (!rows.length) { wrap.innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>'; return; }

    const esc=Utils.escapeHtml;
    const toDate=v=>{ if(!v) return null; const d=new Date(v); if(Number.isNaN(d.getTime())) return null; return new Date(d.getFullYear(),d.getMonth(),d.getDate()); };

    let minBound=null,maxBound=null;
    rows.forEach(r=>{
      const dates=[];
      if(r.hasRelease120) dates.push(new Date(GANTT_RELEASE_BOUNDS.r120[0]), new Date(GANTT_RELEASE_BOUNDS.r120[1]));
      if(r.hasRelease121) dates.push(new Date(GANTT_RELEASE_BOUNDS.r121[0]), new Date(GANTT_RELEASE_BOUNDS.r121[1]));
      if(r.hasRelease122) dates.push(new Date(GANTT_RELEASE_BOUNDS.r122[0]), new Date(GANTT_RELEASE_BOUNDS.r122[1]));
      if(r.hasOvertime){
        const s=toDate(r.workPeriodStart), e=toDate(r.workPeriodEnd);
        if(s) dates.push(s);
        if(e) dates.push(e);
      }
      dates.forEach(d=>{
        if(!minBound||d<minBound) minBound=d;
        if(!maxBound||d>maxBound) maxBound=d;
      });
    });
    if (!minBound||!maxBound) { minBound=new Date(GANTT_TIMELINE_START); maxBound=new Date(GANTT_TIMELINE_END); }
    const spanDays=Math.ceil((maxBound.getTime()-minBound.getTime())/86400000);
    if (spanDays>280) {
      minBound=new Date(GANTT_TIMELINE_START);
      maxBound=new Date(GANTT_TIMELINE_END.getFullYear(), GANTT_TIMELINE_END.getMonth()+2, 0);
    }
    const tStartDate=new Date(minBound.getFullYear(),minBound.getMonth(),1);
    const tEndDate=new Date(maxBound.getFullYear(),maxBound.getMonth()+1,1);
    const totalDays=Math.max(1,Math.ceil((tEndDate.getTime()-tStartDate.getTime())/86400000));
    const wrapW=Math.max(1100,wrap.clientWidth||0);
    const LEFT_W=Math.max(360,Math.min(520,Math.round(wrapW*0.34)));
    const fitW=Math.max(840,wrapW-LEFT_W-4);
    const rawW=Math.round(totalDays*GANTT_DAY_PX);
    const totalW=Math.max(fitW,Math.min(rawW,5200));
    const dayPx=totalW/totalDays;
    const dayOffset=d=>Math.max(0,Math.round((d.getTime()-tStartDate.getTime())/86400000*dayPx));
    const dayWidth=(a,b)=>Math.max(10,Math.round(((b.getTime()-a.getTime())/86400000+1)*dayPx));

    let monthHeader='';
    for(let d=new Date(tStartDate); d<tEndDate; d=new Date(d.getFullYear(),d.getMonth()+1,1)){
      const next=new Date(d.getFullYear(),d.getMonth()+1,1);
      const x=dayOffset(d), w=Math.max(1,dayOffset(next)-x);
      monthHeader+=`<div class="gtx-month-cell" style="left:${x}px;width:${w}px">${esc(d.toLocaleString('ru',{month:'short',year:'2-digit'}))}</div>`;
    }

    const sorted=[...rows].sort((a,b)=>{
      const ca=String(a.team||'')+String(a.epic||'')+String(a.tasks||'');
      const cb=String(b.team||'')+String(b.epic||'')+String(b.tasks||'');
      return ca.localeCompare(cb,'ru');
    });

    const relDefs=[
      {key:'r120', label:'1.20', start:new Date(GANTT_RELEASE_BOUNDS.r120[0]), end:new Date(GANTT_RELEASE_BOUNDS.r120[1]), field:'release120Types'},
      {key:'r121', label:'1.21', start:new Date(GANTT_RELEASE_BOUNDS.r121[0]), end:new Date(GANTT_RELEASE_BOUNDS.r121[1]), field:'release121Types'},
      {key:'r122', label:'1.22', start:new Date(GANTT_RELEASE_BOUNDS.r122[0]), end:new Date(GANTT_RELEASE_BOUNDS.r122[1]), field:'release122Types'},
      {key:'ot', label:'OT', start:null, end:null, field:'overtimeTypes'},
    ];
    const relBg={r120:'rgba(79,70,229,.06)',r121:'rgba(5,150,105,.06)',r122:'rgba(217,119,6,.06)',ot:'rgba(220,38,38,.06)'};

    let bands='';
    relDefs.forEach(rd=>{
      if(!rd.start||!rd.end) return;
      const visS=rd.start<tStartDate?tStartDate:rd.start;
      const visE=rd.end>new Date(tEndDate.getTime()-86400000)?new Date(tEndDate.getTime()-86400000):rd.end;
      if(visE<visS) return;
      const x=dayOffset(visS), w=dayWidth(visS,visE);
      bands+=`<div class="gtx-band" style="left:${x}px;width:${w}px;background:${relBg[rd.key]}"></div>`;
      bands+=`<div class="gtx-band-label" style="left:${x+4}px">${rd.label}</div>`;
    });

    const timelineLastDay=new Date(tEndDate.getTime()-86400000);
    const ROW_H=52;
    let firstBarX=Number.POSITIVE_INFINITY;
    const rowHtml=sorted.map(r=>{
      let bars='';
      relDefs.forEach(rd=>{
        const types=Array.isArray(r[rd.field])?r[rd.field]:[];
        if(!types.length) return;
        let s=rd.start,e=rd.end;
        if(rd.key==='ot'){
          s=toDate(r.workPeriodStart); e=toDate(r.workPeriodEnd);
          if(!s||!e) return;
        }
        const visS=s<tStartDate?tStartDate:s;
        const visE=e>timelineLastDay?timelineLastDay:e;
        if (visE<visS) return;
        const bx=dayOffset(visS), bw=dayWidth(visS,visE);
        if (bx<firstBarX) firstBarX=bx;
        const ordered=PHASE_ORDER.filter(p=>types.includes(p));
        const leftovers=types.filter(t=>!ordered.includes(t));
        const phaseList=[...ordered,...leftovers];
        const segBase=Math.max(1,Math.floor(bw/Math.max(1,phaseList.length)));
        let segs='', left=0;
        phaseList.forEach((wt,i)=>{
          const sw=i===phaseList.length-1?Math.max(1,bw-left):segBase;
          segs+=`<span class="gtx-seg" style="left:${left}px;width:${sw}px;background:${PHASE_COLORS[wt]||'#6b7280'}">${sw>=34?(PHASE_SHORT[wt]||Utils.truncate(wt,10)):''}</span>`;
          left+=sw;
        });
        bars+=`<div class="gtx-bar${r.blockingDependency?' gtx-bar-blocking':''}" style="left:${bx}px;width:${bw}px">${segs}</div>`;
      });
      if(!bars && r.isUnassigned){
        const bEnd=new Date(tStartDate.getTime()+Math.min(9,totalDays-1)*86400000);
        bars=`<div class="gtx-bar" style="left:4px;width:${dayWidth(tStartDate,bEnd)}px"><span class="gtx-seg" style="left:0;width:100%;background:#94a3b8">BL</span></div>`;
        firstBarX=Math.min(firstBarX,4);
      }
      const period=r.workPeriodStart&&r.workPeriodEnd?`${r.workPeriodStart} — ${r.workPeriodEnd}`:'—';
      const rowLabel=Utils.truncate(r.epic||r.tasks||'(без эпика)',60);
      return `<div class="gtx-row${r.blockingDependency?' gtx-row-blocking':''}" style="height:${ROW_H}px" title="Исполнитель: ${esc(r.assignee||'—')}&#10;Период: ${esc(period)}">
        <div class="gtx-epic-cell" style="width:${LEFT_W}px">
          <div class="gtx-epic-name">${esc(rowLabel)}</div>
          <div class="gtx-epic-meta">
            <span class="chip chip-gray">${esc(Utils.truncate(r.team||'—',18))}</span>
            ${r.role?`<span class="chip chip-indigo">${esc(Utils.truncate(r.role,20))}</span>`:''}
            ${r.assignee?`<span class="chip chip-blue">${esc(Utils.truncate(r.assignee,22))}</span>`:''}
            ${RH.riskBadges(r.riskFlags)||''}
            ${RH.doneBadge(r.isDone)}
          </div>
        </div>
        <div class="gtx-time-cell" style="width:${totalW}px"><div class="gtx-time-inner" style="width:${totalW}px">${bars}</div></div>
      </div>`;
    }).join('');

    wrap.innerHTML=`<div class="gtx-shell" style="--gtx-left:${LEFT_W}px;--gtx-dep:0px">
      <div class="gtx-grid" style="min-width:${LEFT_W+totalW}px">
        <div class="gtx-head">
          <div class="gtx-head-epic" style="width:${LEFT_W}px">Команда / Эпик / Исполнитель</div>
          <div class="gtx-head-time" style="width:${totalW}px"><div class="gtx-month-track" style="width:${totalW}px">${monthHeader}</div></div>
        </div>
        <div class="gtx-body" style="height:${sorted.length*ROW_H}px">
          <div class="gtx-time-bands" style="left:${LEFT_W}px;width:${totalW}px;height:${sorted.length*ROW_H}px">${bands}</div>
          <div class="gtx-rows">${rowHtml}</div>
        </div>
      </div>
      <div class="gantt-legend">
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#4f46e5"></div>1.20</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#059669"></div>1.21</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#d97706"></div>1.22</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#dc2626"></div>Овертайм</div>
        <div class="gantt-legend-item"><div class="gantt-legend-dot" style="background:#dc2626"></div>Толстая рамка = блокер</div>
      </div>
    </div>`;
    const shell=wrap.querySelector('.gtx-shell');
    if (shell && Number.isFinite(firstBarX)) shell.scrollLeft=Math.max(0,firstBarX-60);
  },

  renderEpics() {
    const wrap = document.getElementById('gantt-wrap');
    document.querySelectorAll('.gep-tooltip,.gtx-tooltip').forEach(t => t.remove());
    const rows = GanttView.getRows();
    if (!rows.length) {
      wrap.innerHTML = '<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Нет данных</div></div>';
      return;
    }

    if (typeof GanttView._epicsShowLines !== 'boolean') GanttView._epicsShowLines = true;

    const esc = Utils.escapeHtml;
    const toPipeList = (v) => {
      if (Array.isArray(v)) return v.map(x => String(x).trim()).filter(Boolean);
      return String(v || '').split('|').map(x => x.trim()).filter(Boolean);
    };
    const toDate = (v) => {
      if (!v) return null;
      const d = new Date(v);
      if (Number.isNaN(d.getTime())) return null;
      return new Date(d.getFullYear(), d.getMonth(), d.getDate());
    };
    const addDays = (d, n) => new Date(d.getTime() + n * 86400000);
    const fmtIso = (d) => d ? d.toISOString().slice(0, 10) : '';

    const hasEpicData = rows.some(r => String(r.epic || '').trim());
    const epicMap = {};
    rows.forEach(row => {
      const key = hasEpicData ? (String(row.epic || '').trim() || '(без эпика)') : (String(row.category || row.tasks || '').trim() || '(без эпика)');
      if (!epicMap[key]) epicMap[key] = [];
      epicMap[key].push(row);
    });
    const epics = Object.keys(epicMap).sort((a, b) => a.localeCompare(b, 'ru'));

    const epicInfo = {};
    epics.forEach(name => {
      const erows = epicMap[name];
      const phases = {};
      const assignees = new Set();
      const roles = new Set();
      const periodStarts = [];
      const periodEnds = [];

      erows.forEach(r => {
        toPipeList(r.assignee).forEach(v => assignees.add(v));
        toPipeList(r.role).forEach(v => roles.add(v));
        const ws = toDate(r.workPeriodStart);
        const we = toDate(r.workPeriodEnd);
        if (ws) periodStarts.push(ws);
        if (we) periodEnds.push(we);

        GANTT_RELEASE_WINDOWS.forEach(rw => {
          const types = toPipeList(r[rw.tf]);
          if (!types.length) return;
          if (!phases[rw.key]) phases[rw.key] = { types: new Set(), startOverride: null, endOverride: null };
          types.forEach(t => phases[rw.key].types.add(t));
        });
      });

      if (phases.ot) {
        const otStart = periodStarts.length ? new Date(Math.min(...periodStarts.map(d => d.getTime()))) : null;
        const otEnd = periodEnds.length ? new Date(Math.max(...periodEnds.map(d => d.getTime()))) : null;
        if (otStart) phases.ot.startOverride = otStart;
        if (otEnd) phases.ot.endOverride = otEnd;
      }

      const phaseBoundsLocal = (rwKey) => {
        const rw = GANTT_RELEASE_WINDOWS.find(x => x.key === rwKey);
        const ph = phases[rwKey];
        if (!rw || !ph) return null;
        const start = rwKey === 'ot' ? ph.startOverride : rw.start;
        const end = rwKey === 'ot' ? ph.endOverride : rw.end;
        if (!start || !end) return null;
        return { start, end };
      };

      let epicStart = null;
      let epicEnd = null;
      GANTT_RELEASE_WINDOWS.forEach(rw => {
        const b = phaseBoundsLocal(rw.key);
        if (!b) return;
        if (!epicStart || b.start < epicStart) epicStart = b.start;
        if (!epicEnd || b.end > epicEnd) epicEnd = b.end;
      });

      const periodStart = periodStarts.length ? new Date(Math.min(...periodStarts.map(d => d.getTime()))) : null;
      const periodEnd = periodEnds.length ? new Date(Math.max(...periodEnds.map(d => d.getTime()))) : null;
      const periodText = periodStart && periodEnd ? `${fmtIso(periodStart)} — ${fmtIso(periodEnd)}` : (periodStart ? fmtIso(periodStart) : (periodEnd ? fmtIso(periodEnd) : '—'));

      epicInfo[name] = {
        phases,
        start: epicStart,
        end: epicEnd,
        hasBlocking: erows.some(r => !!r.blockingDependency),
        assignees: [...assignees].sort((a, b) => a.localeCompare(b, 'ru')),
        roles: [...roles].sort((a, b) => a.localeCompare(b, 'ru')),
        periodText,
        count: erows.length,
      };
    });

    const depItems = Object.entries(state.epicDeps || {})
      .map(([targetEpic, sourceEpic]) => ({ targetEpic: String(targetEpic || '').trim(), sourceEpic: String(sourceEpic || '').trim() }))
      .filter(d => d.targetEpic && d.sourceEpic && d.targetEpic !== d.sourceEpic && epicInfo[d.targetEpic] && epicInfo[d.sourceEpic])
      .map(d => {
        const sourceInfo = epicInfo[d.sourceEpic];
        const targetInfo = epicInfo[d.targetEpic];
        const offTrack = !!(sourceInfo.end && targetInfo.start && targetInfo.start < sourceInfo.end);
        return { ...d, offTrack };
      })
      .sort((a, b) => (a.targetEpic.localeCompare(b.targetEpic, 'ru') || a.sourceEpic.localeCompare(b.sourceEpic, 'ru')));

    const incomingFromMap = {};
    const outgoingToMap = {};
    const incomingOffTrackMap = {};
    depItems.forEach(d => {
      incomingFromMap[d.targetEpic] = d.sourceEpic;
      incomingOffTrackMap[d.targetEpic] = d.offTrack;
      if (!outgoingToMap[d.sourceEpic]) outgoingToMap[d.sourceEpic] = [];
      outgoingToMap[d.sourceEpic].push(d.targetEpic);
    });
    const offTrackCount = depItems.filter(d => d.offTrack).length;

    const groupBy = state.ganttEpicsWell;
    let groups = [];
    if (groupBy === 'role' || groupBy === 'assignee') {
      const groupMap = {};
      epics.forEach(name => {
        const src = groupBy === 'role' ? epicInfo[name].roles : epicInfo[name].assignees;
        const key = src.length ? src.join(', ') : (groupBy === 'role' ? '(без роли)' : '(без исполнителя)');
        if (!groupMap[key]) groupMap[key] = [];
        groupMap[key].push(name);
      });
      groups = Object.entries(groupMap)
        .sort((a, b) => a[0].localeCompare(b[0], 'ru'))
        .map(([label, eps]) => ({ label, epics: eps.sort((a, b) => a.localeCompare(b, 'ru')) }));
    } else {
      groups = [{ label: null, epics }];
    }

    let minBound = null;
    let maxBound = null;
    epics.forEach(name => {
      const info = epicInfo[name];
      if (info.start && (!minBound || info.start < minBound)) minBound = info.start;
      if (info.end && (!maxBound || info.end > maxBound)) maxBound = info.end;
    });
    if (!minBound || !maxBound) {
      minBound = new Date(GANTT_TIMELINE_START);
      maxBound = new Date(GANTT_TIMELINE_END);
    }
    const tStartDate = new Date(minBound.getFullYear(), minBound.getMonth(), 1);
    const tEndDate = new Date(maxBound.getFullYear(), maxBound.getMonth() + 1, 1);
    const tStartMs = tStartDate.getTime();
    const tEndMs = tEndDate.getTime();
    const totalDays = Math.max(1, Math.ceil((tEndMs - tStartMs) / 86400000));

    const wrapW = Math.max(1000, wrap.clientWidth || 0);
    const LEFT_W = Math.max(250, Math.min(360, Math.round(wrapW * 0.24)));
    const DEP_W = 84;
    const timelineMinW = Math.round(totalDays * GANTT_DAY_PX);
    const totalW = Math.max(timelineMinW, wrapW - LEFT_W - DEP_W - 6);
    const dayPx = totalW / totalDays;

    const dayOffset = (date) => Math.max(0, Math.min(totalW, Math.round((date.getTime() - tStartMs) / 86400000 * dayPx)));
    const dayWidth = (d1, d2) => {
      const span = Math.max(0, Math.round((d2.getTime() - d1.getTime()) / 86400000));
      return Math.max(10, Math.round((span + 1) * dayPx));
    };

    let monthHeaderHtml = '';
    for (let d = new Date(tStartDate); d < tEndDate; d = new Date(d.getFullYear(), d.getMonth() + 1, 1)) {
      const next = new Date(d.getFullYear(), d.getMonth() + 1, 1);
      const x = dayOffset(d);
      const w = Math.max(1, dayOffset(next) - x);
      monthHeaderHtml += `<div class="gtx-month-cell" style="left:${x}px;width:${w}px">${esc(d.toLocaleString('ru', { month: 'short', year: '2-digit' }))}</div>`;
    }

    const ROW_H = 42;
    const GROUP_H = 28;
    let rowsHtml = '';
    let topOffset = 0;
    const epicGeometry = {};

    const phaseBounds = (ph, rw) => {
      if (!ph) return null;
      const start = rw.key === 'ot' ? ph.startOverride : rw.start;
      const end = rw.key === 'ot' ? ph.endOverride : rw.end;
      if (!start || !end) return null;
      return { start, end };
    };

    groups.forEach(group => {
      if (group.label !== null) {
        rowsHtml += `<div class="gtx-group-row" style="height:${GROUP_H}px">
          <div class="gtx-group-cell" style="width:${LEFT_W}px">${esc(group.label)}</div>
          <div class="gtx-group-dep" style="width:${DEP_W}px"></div>
          <div class="gtx-group-time" style="width:${totalW}px"></div>
        </div>`;
        topOffset += GROUP_H;
      }

      group.epics.forEach(epicName => {
        const info = epicInfo[epicName];
        const assigneeText = info.assignees.join(', ') || '—';
        const depFrom = incomingFromMap[epicName] || '';
        const depOut = (outgoingToMap[epicName] || []).length;
        const incomingOffTrack = !!incomingOffTrackMap[epicName];

        let barsHtml = '';
        let rowBarLeft = Number.POSITIVE_INFINITY;
        let rowBarRight = Number.NEGATIVE_INFINITY;

        GANTT_RELEASE_WINDOWS.forEach(rw => {
          const ph = info.phases[rw.key];
          const b = phaseBounds(ph, rw);
          if (!b) return;
          const bx = dayOffset(b.start);
          const bw = dayWidth(b.start, b.end);
          rowBarLeft = Math.min(rowBarLeft, bx);
          rowBarRight = Math.max(rowBarRight, bx + bw);

          const ordered = PHASE_ORDER.filter(p => ph.types.has(p));
          const leftovers = [...ph.types].filter(p => !ordered.includes(p));
          const phaseList = [...ordered, ...leftovers];
          if (!phaseList.length) phaseList.push('backend');

          let segLeft = 0;
          const segBase = Math.max(1, Math.floor(bw / phaseList.length));
          let segs = '';
          phaseList.forEach((wt, i) => {
            const sw = i === phaseList.length - 1 ? Math.max(1, bw - segLeft) : segBase;
            const label = sw >= 34 ? (PHASE_SHORT[wt] || Utils.truncate(wt, 9)) : '';
            segs += `<span class="gtx-seg" style="left:${segLeft}px;width:${sw}px;background:${PHASE_COLORS[wt] || '#6b7280'}">${esc(label)}</span>`;
            segLeft += sw;
          });
          barsHtml += `<div class="gtx-bar${info.hasBlocking ? ' gtx-bar-blocking' : ''}" style="left:${bx}px;width:${bw}px">${segs}</div>`;
        });

        if (!Number.isFinite(rowBarLeft)) {
          rowBarLeft = 8;
          rowBarRight = 8;
        }
        const hasBars = rowBarRight > rowBarLeft + 2;
        const handleX = Math.max(10, Math.min(totalW - 10, rowBarLeft + 10));
        const linkHandleHtml = `<button class="gtx-link-handle${hasBars ? '' : ' gtx-link-handle-empty'}" data-epic="${esc(epicName)}" style="left:${handleX}px" title="Протяните ◎ на другую задачу, чтобы создать зависимость">◎</button>`;

        const inChip = depFrom
          ? `<span class="gtx-chip gtx-chip-in${incomingOffTrack ? ' gtx-chip-off' : ''}" title="Зависит от ${esc(depFrom)}">← ${esc(Utils.truncate(depFrom, 14))}<button class="gtx-chip-remove" data-dep-remove="${esc(epicName)}" title="Удалить зависимость">×</button></span>`
          : '';
        const outChip = depOut ? `<span class="gtx-chip gtx-chip-out" title="Исходящих зависимостей: ${depOut}">→ ${depOut}</span>` : '';
        const warnChip = incomingOffTrack ? `<span class="gtx-chip gtx-chip-warn" title="Сроки в конфликте">Конфликт</span>` : '';

        const rowCls = ['gtx-row', info.hasBlocking ? 'gtx-row-blocking' : '', incomingOffTrack ? 'gtx-row-offtrack' : ''].filter(Boolean).join(' ');
        rowsHtml += `<div class="${rowCls}" style="height:${ROW_H}px" data-epic="${esc(epicName)}" title="Исполнитель: ${esc(assigneeText)}&#10;Период: ${esc(info.periodText)}">
          <div class="gtx-epic-cell" style="width:${LEFT_W}px">
            <div class="gtx-epic-name" title="${esc(epicName)}">${esc(epicName)}</div>
            <div class="gtx-epic-meta">${inChip}${outChip}${warnChip}<span class="gtx-count">${info.count}</span></div>
          </div>
          <div class="gtx-dep-cell" style="width:${DEP_W}px"></div>
          <div class="gtx-time-cell" style="width:${totalW}px">
            <div class="gtx-time-inner" style="width:${totalW}px">
              ${barsHtml}
              ${linkHandleHtml}
            </div>
          </div>
        </div>`;

        epicGeometry[epicName] = { y: topOffset + ROW_H / 2 };
        topOffset += ROW_H;
      });
    });

    const containerH = topOffset;
    const lastTimelineDay = addDays(tEndDate, -1);
    const bandColors = {
      r120: 'rgba(79,70,229,.06)',
      r121: 'rgba(5,150,105,.06)',
      r122: 'rgba(217,119,6,.06)',
      ot: 'rgba(220,38,38,.06)',
    };
    let bandsHtml = '';
    GANTT_RELEASE_WINDOWS.forEach(rw => {
      if (!rw.start || !rw.end) return;
      const visStart = rw.start < tStartDate ? tStartDate : rw.start;
      const visEnd = rw.end > lastTimelineDay ? lastTimelineDay : rw.end;
      if (visEnd < visStart) return;
      const x = dayOffset(visStart);
      const w = dayWidth(visStart, visEnd);
      bandsHtml += `<div class="gtx-band" style="left:${x}px;width:${w}px;background:${bandColors[rw.key] || 'transparent'}"></div>`;
      bandsHtml += `<div class="gtx-band-label" style="left:${x + 5}px">${esc(rw.label)}</div>`;
    });

    const laneCount = Math.max(2, Math.floor((DEP_W - 18) / 8));
    const depPaths = depItems.map((d, idx) => {
      const src = epicGeometry[d.sourceEpic];
      const dst = epicGeometry[d.targetEpic];
      if (!src || !dst) return '';
      const laneX = LEFT_W + 8 + (idx % laneCount) * 8;
      const xStart = LEFT_W + DEP_W - 5;
      const xEnd = LEFT_W + DEP_W - 12;
      const stroke = d.offTrack ? '#dc2626' : '#6366f1';
      const marker = d.offTrack ? 'url(#gtx-arr-red)' : 'url(#gtx-arr-indigo)';
      return `<path d="M${xStart},${src.y} L${laneX},${src.y} L${laneX},${dst.y} L${xEnd},${dst.y}" stroke="${stroke}" stroke-width="${d.offTrack ? 2.1 : 1.7}" stroke-linecap="round" stroke-linejoin="round" fill="none" marker-end="${marker}" opacity=".9"/>`;
    }).join('');

    const depsListHtml = depItems.length
      ? depItems.map(d => `<div class="gtx-dep-item${d.offTrack ? ' offtrack' : ''}">
          <button class="gtx-dep-focus" data-dep-focus-from="${esc(d.sourceEpic)}" data-dep-focus-to="${esc(d.targetEpic)}">${esc(Utils.truncate(d.sourceEpic, 18))} → ${esc(Utils.truncate(d.targetEpic, 18))}</button>
          ${d.offTrack ? '<span class="gtx-dep-state">конфликт</span>' : ''}
          <button class="gtx-dep-remove" data-dep-remove="${esc(d.targetEpic)}" title="Удалить зависимость">×</button>
        </div>`).join('')
      : '<span class="text-muted text-sm">Пока нет зависимостей. Протяните ◎ с одной задачи на другую.</span>';

    wrap.innerHTML = `<div class="gtx-shell" style="--gtx-left:${LEFT_W}px;--gtx-dep:${DEP_W}px">
      <div class="gtx-deps-panel">
        <div class="gtx-deps-summary">
          <span class="gtx-pill">Связей: ${depItems.length}</span>
          <span class="gtx-pill${offTrackCount ? ' gtx-pill-danger' : ''}">Конфликтов: ${offTrackCount}</span>
        </div>
        <label class="gtx-lines-toggle"><input type="checkbox" id="gtx-show-lines"${GanttView._epicsShowLines ? ' checked' : ''}> Линии связей</label>
        <div class="gtx-deps-hint">Протяните ◎ с задачи на задачу. Сроки задач не меняются автоматически.</div>
        <div class="gtx-deps-list">${depsListHtml}</div>
      </div>

      <div class="gtx-grid" style="min-width:${LEFT_W + DEP_W + totalW}px">
        <div class="gtx-head">
          <div class="gtx-head-epic" style="width:${LEFT_W}px">Эпик</div>
          <div class="gtx-head-dep" style="width:${DEP_W}px">Связи</div>
          <div class="gtx-head-time" style="width:${totalW}px">
            <div class="gtx-month-track" style="width:${totalW}px">${monthHeaderHtml}</div>
          </div>
        </div>
        <div class="gtx-body" style="height:${containerH}px">
          <div class="gtx-time-bands" style="left:${LEFT_W + DEP_W}px;width:${totalW}px;height:${containerH}px">${bandsHtml}</div>
          <div class="gtx-rows">${rowsHtml}</div>
          <svg class="gtx-dep-svg" style="width:${LEFT_W + DEP_W + totalW}px;height:${containerH}px" viewBox="0 0 ${LEFT_W + DEP_W + totalW} ${containerH}">
            <defs>
              <marker id="gtx-arr-indigo" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto"><path d="M0,0 L0,7 L7,3.5 z" fill="#4f46e5"/></marker>
              <marker id="gtx-arr-red" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto"><path d="M0,0 L0,7 L7,3.5 z" fill="#dc2626"/></marker>
            </defs>
            ${GanttView._epicsShowLines ? depPaths : ''}
          </svg>
        </div>
      </div>
    </div>`;

    const showLinesInput = wrap.querySelector('#gtx-show-lines');
    if (showLinesInput) {
      showLinesInput.addEventListener('change', (e) => {
        GanttView._epicsShowLines = !!e.target.checked;
        GanttView.renderChart();
      });
    }

    wrap.querySelectorAll('[data-dep-remove]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const toEpic = btn.dataset.depRemove || '';
        if (!toEpic || !state.epicDeps[toEpic]) return;
        delete state.epicDeps[toEpic];
        Storage.save();
        GanttView.renderChart();
      });
    });

    wrap.querySelectorAll('[data-dep-focus-from][data-dep-focus-to]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const from = btn.dataset.depFocusFrom || '';
        const to = btn.dataset.depFocusTo || '';
        const allRows = [...wrap.querySelectorAll('.gtx-row')];
        const fromRow = allRows.find(r => r.dataset.epic === from);
        const toRow = allRows.find(r => r.dataset.epic === to);
        allRows.forEach(r => r.classList.remove('gtx-row-focus'));
        if (fromRow) fromRow.classList.add('gtx-row-focus');
        if (toRow) toRow.classList.add('gtx-row-focus');
        if (toRow && toRow.scrollIntoView) toRow.scrollIntoView({ block: 'center', behavior: 'smooth' });
        setTimeout(() => allRows.forEach(r => r.classList.remove('gtx-row-focus')), 1400);
      });
    });

    let depDrag = null;
    let depGhostSvg = null;
    let depGhostPath = null;
    let depDropRow = null;

    const onBlur = () => clearDepDrag();
    const clearDepDrag = () => {
      if (depGhostSvg) depGhostSvg.remove();
      if (depDropRow) depDropRow.classList.remove('gtx-row-drop');
      depDrag = null;
      depGhostSvg = null;
      depGhostPath = null;
      depDropRow = null;
      document.removeEventListener('mousemove', onDepMouseMove);
      document.removeEventListener('mouseup', onDepMouseUp);
      document.removeEventListener('keydown', onDepKeyDown);
      window.removeEventListener('blur', onBlur);
    };
    GanttView._cancelTransientInteractions=clearDepDrag;
    const getRowAtPoint = (x, y) => {
      const el = document.elementFromPoint(x, y);
      if (!el || !el.closest) return null;
      return el.closest('#gantt-wrap .gtx-row');
    };
    const drawGhost = (x1, y1, x2, y2) => {
      if (!depGhostPath) return;
      const elbowX = Math.min(window.innerWidth - 10, Math.max(x1, x2) + 36);
      depGhostPath.setAttribute('d', `M${x1},${y1} L${elbowX},${y1} L${elbowX},${y2} L${x2},${y2}`);
    };
    const onDepMouseMove = (e) => {
      if (!depDrag) return;
      drawGhost(depDrag.x1, depDrag.y1, e.clientX, e.clientY);
      const row = getRowAtPoint(e.clientX, e.clientY);
      const valid = row && row.dataset.epic && row.dataset.epic !== depDrag.fromEpic ? row : null;
      if (depDropRow && depDropRow !== valid) depDropRow.classList.remove('gtx-row-drop');
      if (valid && depDropRow !== valid) valid.classList.add('gtx-row-drop');
      depDropRow = valid;
    };
    const onDepMouseUp = (e) => {
      if (!depDrag) return;
      const row = getRowAtPoint(e.clientX, e.clientY);
      const targetEpic = row ? (row.dataset.epic || '') : '';
      const fromEpic = depDrag.fromEpic;
      clearDepDrag();
      if (!targetEpic || !fromEpic || targetEpic === fromEpic) return;
      state.epicDeps[targetEpic] = fromEpic;
      Storage.save();
      GanttView.renderChart();
      window.showToast?.(`Связь: ${targetEpic} зависит от ${fromEpic}`);
    };
    const onDepKeyDown = (e) => {
      if (e.key === 'Escape') clearDepDrag();
    };

    wrap.querySelectorAll('.gtx-link-handle').forEach(handle => {
      handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        clearDepDrag();
        const row = handle.closest('.gtx-row');
        if (!row) return;
        depDrag = { fromEpic: row.dataset.epic, x1: e.clientX, y1: e.clientY };

        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('class', 'gtx-link-ghost');
        svg.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:9800;';
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('stroke', '#4f46e5');
        path.setAttribute('stroke-width', '2');
        path.setAttribute('stroke-linecap', 'round');
        path.setAttribute('stroke-linejoin', 'round');
        path.setAttribute('stroke-dasharray', '6 4');
        path.setAttribute('fill', 'none');
        path.setAttribute('opacity', '0.9');
        svg.appendChild(path);
        document.body.appendChild(svg);
        depGhostSvg = svg;
        depGhostPath = path;
        drawGhost(e.clientX, e.clientY, e.clientX, e.clientY);

        document.addEventListener('mousemove', onDepMouseMove);
        document.addEventListener('mouseup', onDepMouseUp);
        document.addEventListener('keydown', onDepKeyDown);
        window.addEventListener('blur', onBlur);
      });
    });
  },
};

// ============================================================
// GANTT V2 (ISO Week gantt)
// ============================================================
function g2ISOWeek(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

export const GanttV2 = {
  syncControls() {
    const zoomEl = document.getElementById('g2-zoom');
    const teamEl = document.getElementById('g2-team');
    const depsEl = document.getElementById('g2-show-deps');
    if (zoomEl) zoomEl.value = state.gantt2Zoom || 'week';
    if (depsEl) depsEl.checked = !!state.gantt2ShowDeps;
    if (teamEl) {
      const teams = [...new Set(state.rows.map(r => r.team).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'ru'));
      teamEl.innerHTML = '<option value="">Все</option>' + teams.map(t => `<option value="${t}"${state.gantt2Team === t ? ' selected' : ''}>${t}</option>`).join('');
    }
  },
  renderChart() {
    const wrap = document.getElementById('gantt2-wrap');
    if (!wrap) return;
    const zoom = state.gantt2Zoom || 'week';
    const showDeps = !!state.gantt2ShowDeps;
    const teamFilter = state.gantt2Team || '';

    let rows = FilterEngine.getFiltered();
    if (teamFilter) rows = rows.filter(r => r.team === teamFilter);

    if (!rows.length) {
      wrap.innerHTML = '<div class="empty-state"><div class="empty-icon">📅</div><div class="empty-title">Нет данных для Gantt v2</div></div>';
      return;
    }

    const esc = Utils.escapeHtml;
    const toDate = v => {
      if (!v) return null;
      const d = new Date(v);
      return Number.isNaN(d.getTime()) ? null : new Date(d.getFullYear(), d.getMonth(), d.getDate());
    };

    const relDefs = [
      { key: 'r120', label: '1.20', start: new Date(GANTT_RELEASE_BOUNDS.r120[0]), end: new Date(GANTT_RELEASE_BOUNDS.r120[1]), field: 'release120Types', color: '#4f46e5' },
      { key: 'r121', label: '1.21', start: new Date(GANTT_RELEASE_BOUNDS.r121[0]), end: new Date(GANTT_RELEASE_BOUNDS.r121[1]), field: 'release121Types', color: '#059669' },
      { key: 'r122', label: '1.22', start: new Date(GANTT_RELEASE_BOUNDS.r122[0]), end: new Date(GANTT_RELEASE_BOUNDS.r122[1]), field: 'release122Types', color: '#d97706' },
      { key: 'ot',  label: 'OT',   start: null,                                    end: null,                                    field: 'overtimeTypes',   color: '#dc2626' },
    ];

    let tStart = new Date(GANTT_RELEASE_BOUNDS.r120[0]);
    let tEnd = new Date(GANTT_RELEASE_BOUNDS.r122[1]);
    rows.forEach(r => {
      const s = toDate(r.workPeriodStart), e = toDate(r.workPeriodEnd);
      if (s && s < tStart) tStart = s;
      if (e && e > tEnd) tEnd = e;
    });
    tStart = new Date(tStart.getFullYear(), tStart.getMonth(), 1);
    tEnd = new Date(tEnd.getFullYear(), tEnd.getMonth() + 1, 1);

    // Build time columns
    const cols = [];
    if (zoom === 'week') {
      for (let d = new Date(tStart); d < tEnd; ) {
        const weekNum = g2ISOWeek(d);
        const year = d.getFullYear();
        const start = new Date(d);
        const next = new Date(d.getTime() + 7 * 86400000);
        cols.push({ label: `W${weekNum}`, start, end: next, key: `${year}W${String(weekNum).padStart(2,'0')}` });
        d = next;
      }
    } else {
      for (let d = new Date(tStart); d < tEnd; d = new Date(d.getFullYear(), d.getMonth() + 1, 1)) {
        const next = new Date(d.getFullYear(), d.getMonth() + 1, 1);
        cols.push({ label: d.toLocaleString('ru', { month: 'short' }), start: new Date(d), end: next, key: `${d.getFullYear()}-${d.getMonth()}` });
      }
    }

    const totalMs = tEnd.getTime() - tStart.getTime();
    const colPct = cols.length ? 100 / cols.length : 0;
    const LEFT_W = 260;
    const COL_W = Math.max(32, Math.floor((Math.max(900, wrap.clientWidth || 0) - LEFT_W) / cols.length));
    const totalW = cols.length * COL_W;

    const timeX = (date) => {
      const ms = date.getTime() - tStart.getTime();
      return Math.round(ms / totalMs * totalW);
    };
    const timeW = (s, e) => Math.max(4, timeX(e) - timeX(s));

    let headerHtml = `<div class="g2-head" style="margin-left:${LEFT_W}px;width:${totalW}px">`;
    cols.forEach(c => {
      headerHtml += `<div class="g2-col-label" style="width:${COL_W}px">${esc(c.label)}</div>`;
    });
    headerHtml += '</div>';

    const epicMap = {};
    rows.forEach(r => {
      const key = String(r.epic || r.tasks || '').trim() || '(без эпика)';
      if (!epicMap[key]) epicMap[key] = [];
      epicMap[key].push(r);
    });

    const epicGeometry = {};
    let rowIdx = 0;
    const ROW_H = 36;
    let rowsHtml = '';

    Object.entries(epicMap).sort(([a], [b]) => a.localeCompare(b, 'ru')).forEach(([epicName, epicRows]) => {
      let barsHtml = '';
      const rowY = rowIdx * ROW_H;

      relDefs.forEach(rd => {
        const hasRows = epicRows.filter(r => r[rd.field] && (r[rd.field] || []).length);
        if (!hasRows.length) return;
        let s = rd.start, e = rd.end;
        if (rd.key === 'ot') {
          const starts = epicRows.map(r => toDate(r.workPeriodStart)).filter(Boolean);
          const ends = epicRows.map(r => toDate(r.workPeriodEnd)).filter(Boolean);
          if (!starts.length || !ends.length) return;
          s = new Date(Math.min(...starts.map(d => d.getTime())));
          e = new Date(Math.max(...ends.map(d => d.getTime())));
        }
        if (!s || !e) return;
        const visS = s < tStart ? tStart : s;
        const visE = e > tEnd ? tEnd : e;
        if (visE <= visS) return;
        const bx = timeX(visS), bw = timeW(visS, visE);
        barsHtml += `<div class="g2-bar" style="left:${bx}px;width:${bw}px;background:${rd.color}" title="${esc(epicName)}: ${rd.label}"></div>`;
        epicGeometry[epicName] = { y: rowY + ROW_H / 2 };
      });

      rowsHtml += `<div class="g2-row" style="height:${ROW_H}px" data-epic="${esc(epicName)}">
        <div class="g2-label" style="width:${LEFT_W}px">${esc(Utils.truncate(epicName, 36))}</div>
        <div class="g2-timeline" style="width:${totalW}px">${barsHtml}</div>
      </div>`;
      rowIdx++;
    });

    let depSvg = '';
    if (showDeps) {
      const deps = Object.entries(state.epicDeps || {});
      const paths = deps.map(([to, from]) => {
        const sg = epicGeometry[from];
        const dg = epicGeometry[to];
        if (!sg || !dg) return '';
        const sx = LEFT_W + totalW;
        const dx = LEFT_W;
        const stroke = '#6366f1';
        return `<path d="M${sx},${sg.y} L${sx + 20},${sg.y} L${sx + 20},${dg.y} L${dx},${dg.y}" stroke="${stroke}" stroke-width="1.6" stroke-linecap="round" fill="none" opacity=".7" marker-end="url(#g2-arr)"/>`;
      }).join('');
      if (paths) {
        depSvg = `<svg class="g2-dep-svg" style="position:absolute;top:0;left:0;width:${LEFT_W+totalW+40}px;height:${rowIdx*ROW_H}px;pointer-events:none;overflow:visible">
          <defs><marker id="g2-arr" markerWidth="6" markerHeight="6" refX="5.5" refY="3" orient="auto"><path d="M0,0 L0,6 L6,3 z" fill="#6366f1"/></marker></defs>
          ${paths}
        </svg>`;
      }
    }

    // Band overlays
    let bandsHtml = '';
    relDefs.forEach(rd => {
      if (!rd.start || !rd.end) return;
      const visS = rd.start < tStart ? tStart : rd.start;
      const visE = rd.end > tEnd ? tEnd : rd.end;
      if (visE <= visS) return;
      const bx = timeX(visS), bw = timeW(visS, visE);
      const alpha = '0d';
      bandsHtml += `<div class="g2-band" style="left:${LEFT_W + bx}px;width:${bw}px;background:${rd.color}${alpha}" title="${rd.label}"></div>`;
    });

    wrap.innerHTML = `<div class="g2-shell">
      ${headerHtml}
      <div class="g2-body" style="position:relative">
        ${bandsHtml}
        ${rowsHtml}
        ${depSvg}
      </div>
    </div>`;
  },
};
