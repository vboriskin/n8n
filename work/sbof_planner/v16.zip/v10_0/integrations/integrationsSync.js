'use strict';
/* ============================================================
   INTEGRATIONS SYNC — v10_0
   Fetches Jira / Bitbucket / Confluence data for rows.
   Updates row fields via proxy endpoints.
   Never mutates rows directly — returns update objects.
   Caller applies to state.rows and calls notify().
   ============================================================ */

import { loadSettingsRaw, saveSettings } from './integrationsStore.js';

/* ── proxy call helper ────────────────────────────────────── */
async function proxyPost(endpoint, body) {
  const res = await fetch(endpoint, {
    method: 'POST',
    signal: AbortSignal.timeout(15000),
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

/* ── Jira: sync a single row ──────────────────────────────── */
export async function syncJiraRow(row) {
  const key = String(row.jiraKey || '').trim();
  if (!key) return null;
  try {
    const data = await proxyPost('/api/integrations/jira-issue', { key });
    return {
      id:           row.id,
      jiraStatus:   data.status   || '',
      jiraAssignee: data.assignee || '',
      jiraUpdatedAt:data.updatedAt|| '',
    };
  } catch(e) {
    console.warn('[IntSync] Jira issue fetch failed:', key, e.message);
    return null;
  }
}

/* ── Bitbucket: sync a single row ─────────────────────────── */
export async function syncBitbucketRow(row) {
  const key = String(row.jiraKey || '').trim();
  if (!key) return null;
  try {
    const data = await proxyPost('/api/integrations/bitbucket-prs', { jiraKey: key });
    const pr = data.prs?.[0] || null;
    if (!pr) return null;
    return {
      id:         row.id,
      prUrl:      pr.url       || '',
      prStatus:   pr.status    || '',
      prUpdatedAt:pr.updatedAt || '',
    };
  } catch(e) {
    console.warn('[IntSync] Bitbucket PR fetch failed:', key, e.message);
    return null;
  }
}

/* ── Confluence: sync a single row ───────────────────────── */
export async function syncConfluenceRow(row) {
  const key = String(row.jiraKey || row.epic || '').trim();
  if (!key) return null;
  try {
    const data = await proxyPost('/api/integrations/confluence-search', { query: key });
    const page = data.pages?.[0] || null;
    if (!page) return null;
    return {
      id:       row.id,
      docUrl:   page.url   || '',
      docTitle: page.title || '',
    };
  } catch(e) {
    console.warn('[IntSync] Confluence search failed:', key, e.message);
    return null;
  }
}

/* ── Master sync: all rows with jiraKey ───────────────────── */
export async function syncAllRows(rows, { onProgress } = {}) {
  const cfg = loadSettingsRaw();
  const withKey = rows.filter(r => r.jiraKey);
  if (!withKey.length) return { updates: [], skipped: rows.length, noKey: rows.length };

  const updates = [];
  let done = 0;

  for (const row of withKey) {
    const promises = [];
    if (cfg.jiraBaseUrl && cfg.jiraToken)           promises.push(syncJiraRow(row));
    if (cfg.bitbucketBaseUrl && cfg.bitbucketToken) promises.push(syncBitbucketRow(row));
    if (cfg.confluenceBaseUrl && cfg.confluenceToken) promises.push(syncConfluenceRow(row));

    const results = await Promise.all(promises);
    const merged = results
      .filter(Boolean)
      .reduce((acc, upd) => ({ ...acc, ...upd }), { id: row.id });

    if (Object.keys(merged).length > 1) updates.push(merged);

    done++;
    onProgress?.(done, withKey.length);
  }

  saveSettings({ lastSync: new Date().toISOString() });
  return { updates, synced: withKey.length, total: rows.length };
}

/* ── Verify connections (via server endpoints) ────────────── */
export async function verifyJira() {
  const res = await fetch('/api/jira/verify', {
    method: 'POST', signal: AbortSignal.timeout(10000),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: !!data.ok, who: data.who, error: data.error };
}

export async function verifyBitbucket() {
  try {
    const data = await proxyPost('/api/integrations/verify-bitbucket', {});
    return { ok: !!data.ok, error: data.error };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}

export async function verifyConfluence() {
  try {
    const data = await proxyPost('/api/integrations/verify-confluence', {});
    return { ok: !!data.ok, error: data.error };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}
