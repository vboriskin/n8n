'use strict';
/* ============================================================
   CHAT INTENT PARSER — v10_0
   Pure functions — no imports, no side effects.
   ============================================================ */

export const INTENTS = {
  EXECUTIVE_SUMMARY: 'executive_summary',
  RELEASE_OVERVIEW:  'release_overview',
  TEAM_OVERVIEW:     'team_overview',
  MEETING_PREP:      'meeting_prep',
  ASK_PLAN:          'ask_plan',
  FILTER_TASKS:      'filter_tasks',
  RELEASE_NOTES:     'release_notes',
  WHAT_RISKS:        'what_risks',
  OVERLOAD:          'overload',
  REVIEW_MODE:       'review_mode',
  GENERIC:           'generic',
};

const RULES = [
  // Executive summary / CEO update
  {
    intent: INTENTS.EXECUTIVE_SUMMARY,
    patterns: [
      /ceo.?(апдейт|обновление|отчёт|отчет|update)/i,
      /сводк[аи]/i,
      /краткий.?(статус|отчёт|отчет)/i,
      /краткая.?сводка/i,
      /краткий.?обзор/i,
      /общий.?(статус|обзор|итог)/i,
      /итог.{0,10}(релиз|sprint|спринт)/i,
      /что.{0,15}(происходит|сейчас|статус)/i,
      /executive.?summary/i,
      /сводка.{0,15}статус/i,
      /статус.{0,15}проект/i,
    ],
    extract: () => ({}),
  },
  // Release notes generation
  {
    intent: INTENTS.RELEASE_NOTES,
    patterns: [
      /release.?notes?/i,
      /заметки.{0,10}(релиз|выпуск)/i,
      /что.{0,10}(вышло|готово|сделано).{0,10}(в|по|для).{0,10}(релиз|1\.\d)/i,
      /список.{0,15}(готов|сделан)/i,
      /changelog/i,
    ],
    extract: (text) => {
      const m = text.match(/1\.(20|21|22)/);
      return { release: m ? `r1${m[1]}` : null };
    },
  },
  // Release overview
  {
    intent: INTENTS.RELEASE_OVERVIEW,
    patterns: [
      /релиз[уаеёя]?\s*1\.(20|21|22)/i,
      /1\.(20|21|22)/i,
      /по\s*1\.(20|21|22)/i,
      /окно\s*1\.(20|21|22)/i,
      /sprint\s*1\.(20|21|22)/i,
      /(что|задач[иа]).{0,15}(в|на)\s*1\.(20|21|22)/i,
      /овертайм.{0,20}(задач|статус|что)/i,
      /(backlog|бэклог).{0,20}(что|задач|статус)/i,
    ],
    extract: (text) => {
      const m = text.match(/1\.(20|21|22)/);
      if (m) return { release: `r1${m[1]}` };
      if (/овертайм/i.test(text)) return { release: 'overtime' };
      if (/backlog|бэклог/i.test(text)) return { release: 'backlog' };
      return {};
    },
  },
  // Team overview
  {
    intent: INTENTS.TEAM_OVERVIEW,
    patterns: [
      /команд[аы].{0,30}(статус|загрузк|блокер|риск)/i,
      /(загрузк|нагрузк).{0,20}команд/i,
      /(статус|обзор).{0,20}команд/i,
      /у\s+команд/i,
      /топ.{0,10}команд/i,
    ],
    extract: (text) => {
      // Try to extract specific team name if mentioned
      const teamMatch = text.match(/команд[аы]?\s+[«"']?([А-ЯЁA-Z][а-яёa-z]+(?:\s+[А-ЯЁA-Za-z][а-яёa-z]*)*)[»"']?/i);
      return { team: teamMatch ? teamMatch[1].trim() : null };
    },
  },
  // Meeting prep
  {
    intent: INTENTS.MEETING_PREP,
    patterns: [
      /встреч[уаи]/i,
      /митинг/i,
      /совещани[ея]/i,
      /груминг/i,
      /демо/i,
      /ретро/i,
      /sprint.?review/i,
      /подготовк[аи].{0,20}(к|для)/i,
      /подготовь.{0,20}(встреч|митинг|совещ|повестк)/i,
      /повестк[аи]/i,
      /agenda/i,
    ],
    extract: (text) => {
      const types = [];
      if (/груминг/i.test(text)) types.push('grooming');
      if (/демо/i.test(text)) types.push('demo');
      if (/ретро/i.test(text)) types.push('retro');
      if (/sprint.?review/i.test(text)) types.push('sprint_review');
      if (/встреч|митинг|совещани/i.test(text)) types.push('meeting');
      return { meetingType: types[0] || 'meeting' };
    },
  },
  // Overload / capacity  (must be BEFORE what_risks and team_overview)
  {
    intent: INTENTS.OVERLOAD,
    patterns: [
      /перегруз/i,
      /загрузк.{0,15}(исполнит|сотрудник)/i,
      /нагрузк.{0,15}(исполнит|сотрудник)/i,
      /капасити/i,
      /capacity/i,
      /кто.{0,20}(перегруж|занят|загружен)/i,
      /у кого.{0,20}(много|больше всего)/i,
    ],
    extract: () => ({}),
  },
  // Filter tasks  (must be BEFORE what_risks to avoid "задачи с блокерами" misclassification)
  {
    intent: INTENTS.FILTER_TASKS,
    patterns: [
      /покаж[иы].{0,20}задач/i,
      /отфильтруй/i,
      /найди.{0,20}(задач|строк)/i,
      /задачи.{0,10}(где|которые|с|без|со)/i,
      /задачи\s+(команд|блокер|риск|без\s*релиз)/i,
      /задачи\s*с\s*(блокер|риск)/i,
    ],
    extract: (text) => {
      const params = {};
      const teamM = text.match(/команд[аы]?\s+[«"']?([А-ЯЁ][а-яё]+)/i);
      if (teamM) params.team = teamM[1];
      if (/блокер/i.test(text)) params.onlyBlocking = true;
      if (/риск/i.test(text)) params.onlyRisky = true;
      if (/сделан|готов/i.test(text)) params.onlyDone = true;
      const relM = text.match(/1\.(20|21|22)/);
      if (relM) params.release = `1.${relM[1]}`;
      return params;
    },
  },
  // What risks
  {
    intent: INTENTS.WHAT_RISKS,
    patterns: [
      /риск/i,
      /блокер/i,
      /проблем/i,
      /угроз/i,
      /тревожн/i,
      /что.{0,15}(плохо|не так|опасн|критично)/i,
      /сигнал/i,
    ],
    extract: () => ({}),
  },
  // Action plan
  {
    intent: INTENTS.ASK_PLAN,
    patterns: [
      /план.{0,20}(действий|работ|задач)/i,
      /что.{0,20}(сделать|нужно|надо|приоритет)/i,
      /с чего.{0,20}начат/i,
      /action.?plan/i,
      /приоритет.{0,20}(задач|работ)/i,
      /рекоменд/i,
    ],
    extract: () => ({}),
  },
  // Review mode
  {
    intent: INTENTS.REVIEW_MODE,
    patterns: [
      /режим.{0,15}(ceo|dm|риск|lead|тимлид)/i,
      /обзор.{0,15}(ceo|руководител|менеджер)/i,
      /глаза.{0,15}(ceo|dm|риск)/i,
      /как.{0,20}(ceo|менеджер|руководитель)/i,
      /посмотри.{0,20}как\s+(ceo|dm|delivery|risk|team\s*lead)/i,
      /с\s+точки\s+зрения\s+(ceo|dm|риск)/i,
    ],
    extract: (text) => {
      if (/ceo/i.test(text)) return { role: 'ceo' };
      if (/dm|delivery/i.test(text)) return { role: 'dm' };
      if (/риск|risk/i.test(text)) return { role: 'risk' };
      if (/lead|тимлид/i.test(text)) return { role: 'lead' };
      return { role: 'ceo' };
    },
  },
];

/**
 * Parse intent from user text.
 * @param {string} text
 * @returns {{ intent: string, confidence: number, params: object }}
 */
export function parseIntent(text) {
  if (!text || typeof text !== 'string') return { intent: INTENTS.GENERIC, confidence: 0, params: {} };
  const t = text.trim();
  for (const rule of RULES) {
    for (const pattern of rule.patterns) {
      if (pattern.test(t)) {
        return {
          intent: rule.intent,
          confidence: 0.85,
          params: rule.extract ? rule.extract(t) : {},
        };
      }
    }
  }
  return { intent: INTENTS.GENERIC, confidence: 0, params: {} };
}

/**
 * Check if intent should be handled by rule engine (no LLM needed).
 */
export function isRuleBased(intent) {
  return [
    INTENTS.EXECUTIVE_SUMMARY,
    INTENTS.RELEASE_OVERVIEW,
    INTENTS.TEAM_OVERVIEW,
    INTENTS.MEETING_PREP,
    INTENTS.RELEASE_NOTES,
    INTENTS.WHAT_RISKS,
    INTENTS.OVERLOAD,
    INTENTS.FILTER_TASKS,
    INTENTS.ASK_PLAN,
    INTENTS.REVIEW_MODE,
  ].includes(intent);
}
