'use strict';
/* ============================================================
   CHAT ACTIONS — v10_0
   Executes structured actions triggered by assistant messages.
   Uses window.App / window.FilterEngine via safe accessors.
   ============================================================ */

import { state, notify } from '../state.js';

/* ── Helpers ─────────────────────────────────────────────── */

function showToast(msg) {
  try { window.showToast?.(msg); } catch(_) {}
}

function navigateTo(section) {
  try {
    if (window.App?.goTo) { window.App.goTo(section); return; }
    // fallback: simulate nav click
    const btn = document.querySelector(`.nav-item[data-section="${section}"]`);
    if (btn) btn.click();
  } catch(_) {}
}

/* ── Action handlers ─────────────────────────────────────── */

function handleNavigate(payload) {
  const section = payload.section || 'dashboard';
  navigateTo(section);
  showToast(`Переход → ${section}`);
}

function handleApplyFilter(payload) {
  try {
    const f = state.filters;
    if (payload.team      !== undefined) f.team      = payload.team;
    if (payload.release   !== undefined) f.release   = payload.release;
    if (payload.workType  !== undefined) f.workType  = payload.workType;
    if (payload.assignee  !== undefined) f.assignee  = payload.assignee;
    if (payload.search    !== undefined) f.search    = payload.search;
    if (payload.onlyBlocking !== undefined) f.onlyBlocking = !!payload.onlyBlocking;
    if (payload.onlyRisky    !== undefined) f.onlyRisky    = !!payload.onlyRisky;
    if (payload.onlyDone     !== undefined) f.onlyDone     = !!payload.onlyDone;
    notify('chat_filter');
    showToast('Фильтры применены');
    // Navigate to registry to show results
    if (!payload.noNavigate) navigateTo('registry');
  } catch (e) {
    showToast('Ошибка применения фильтров: ' + (e.message || e));
  }
}

function handleClearFilters() {
  try {
    const f = state.filters;
    f.search = ''; f.team = ''; f.scope = ''; f.release = '';
    f.workType = ''; f.role = ''; f.assignee = ''; f.tag = '';
    f.onlyBlocking = false; f.onlyRisky = false; f.onlyDone = false; f.preset = null;
    notify('chat_filter_clear');
    showToast('Фильтры сброшены');
  } catch(_) {}
}

function handlePreviewRelease(payload) {
  navigateTo('gantt');
  try {
    // Try switching gantt to detailed view for the requested release
    if (payload.release) {
      const sel = document.getElementById('gantt-mode');
      if (sel) { sel.value = 'detailed'; sel.dispatchEvent(new Event('change')); }
    }
    showToast(`Предпросмотр: Гант → ${payload.release || ''}`);
  } catch(_) {}
}

function handleSendPrompt(payload) {
  // Push a new prompt into the chat input and trigger send
  try {
    const input = document.getElementById('assistant-input');
    if (input && payload.prompt) {
      input.value = payload.prompt;
      input.dispatchEvent(new Event('input'));
      // Dispatch send
      const sendBtn = document.getElementById('assistant-btn-send');
      if (sendBtn && !sendBtn.disabled) sendBtn.click();
    }
  } catch(_) {}
}

function handleSetReviewMode(payload) {
  try {
    const role = payload.role || 'ceo';
    if (state.llm) state.llm.reviewMode = role;
    // Update indicator if present
    const ind = document.getElementById('chat-review-mode-indicator');
    const labels = { ceo: 'CEO', dm: 'Delivery Manager', risk: 'Risk Officer', lead: 'Team Lead' };
    if (ind) ind.textContent = labels[role] || role;
    showToast(`Режим обзора: ${labels[role] || role}`);
  } catch(_) {}
}

function handleCopyText(payload) {
  const text = String(payload.text || '');
  if (!text) return;
  navigator.clipboard?.writeText(text).then(() => showToast('Скопировано'), () => {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); document.body.removeChild(ta); showToast('Скопировано');
  });
}

function handleExportSummary(payload) {
  try {
    const text = String(payload.text || '');
    if (!text) { showToast('Нет текста для экспорта'); return; }
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `planning-summary-${new Date().toISOString().slice(0,10)}.txt`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    showToast('Файл скачан');
  } catch(e) { showToast('Ошибка экспорта'); }
}

/* ── Dispatcher ──────────────────────────────────────────── */

/**
 * Execute a chat action.
 * @param {string} type    - Action type string
 * @param {object} payload - Action payload
 */
export function executeAction(type, payload = {}) {
  switch (type) {
    case 'navigate':        return handleNavigate(payload);
    case 'apply_filter':    return handleApplyFilter(payload);
    case 'clear_filters':   return handleClearFilters();
    case 'preview_release': return handlePreviewRelease(payload);
    case 'send_prompt':     return handleSendPrompt(payload);
    case 'set_review_mode': return handleSetReviewMode(payload);
    case 'copy_text':       return handleCopyText(payload);
    case 'export_summary':  return handleExportSummary(payload);
    default:
      console.warn('[ChatActions] Unknown action type:', type, payload);
  }
}

/**
 * Bind action button clicks on the messages container.
 * Call once during LLMAssistant.bindUI().
 */
export function bindActionClicks(messagesWrap) {
  if (!messagesWrap) return;
  messagesWrap.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action-type]');
    if (!btn) return;
    const type = btn.dataset.actionType || '';
    let payload = {};
    try { payload = JSON.parse(btn.dataset.actionPayload || '{}'); } catch(_) {}
    executeAction(type, payload);
  });

  // Drilldown prompts
  messagesWrap.addEventListener('click', (e) => {
    const btn = e.target.closest('.chat-drilldown-btn');
    if (!btn) return;
    const prompt = btn.dataset.prompt || btn.textContent || '';
    if (prompt) {
      const input = document.getElementById('assistant-input');
      if (input) {
        input.value = prompt;
        input.dispatchEvent(new Event('input'));
        input.focus();
      }
    }
  });
}
