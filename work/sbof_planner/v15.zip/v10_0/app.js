'use strict';
/* ============================================================
   APP.JS — v8_0 main entry point
   Imports all modules; contains orchestrator objects not yet
   extracted: HistoryManager, BulkEditPanel, SimMode, ThemeUI,
   SidebarUI, FiltersUI, LLMAssistant, Nav, App, AppSettings,
   Onboarding, ActionLayer, JiraPulse.
   ============================================================ */

import { state, getAllCols, syncColumnSettings, subscribe, notify, toBool } from './state.js';
import { STORAGE_KEY, SETTINGS_KEY, LLM_SETTINGS_KEY, DEFAULT_LLM_SYSTEM_PROMPT, REGISTRY_COLS, WORK_TYPES, SCOPE_OPTIONS } from './constants.js';
import { Storage, CSV, XLSXImporter, applyBulkAction, autoAssignRelease, normalizeAssignees, batchRiskRecompute, exportSelectedCSV } from './dataStore.js';
import { FilterEngine } from './filters.js';
import { RiskEngine } from './riskEngine.js';
import { Utils, nextId } from './utils.js';
import { RowFactory, EmployeeFactory } from './rowFactory.js';
import { Multiselect } from './components/multiselect.js';
import { DashboardView } from './views/dashboard.js';
import { RegistryView } from './views/registry.js';
import { GanttView, GanttV2 } from './views/gantt.js';
import { KanbanView } from './views/kanban.js';
import { TimelineView, PodlozhkaView } from './views/timeline.js';
import { SummaryView, MetricsView, InsightsView, DiagnosticsView } from './views/metrics.js';
import { EmployeesView } from './views/employees.js';
import { AIView }        from './views/aiView.js';
import { AICeoView }          from './views/aiCeoView.js';
import { IntegrationsView, openIntegrationsSettings } from './views/integrationsView.js';
import { isFirstRun, resetOnboarding } from './onboarding/onboarding.js';
import { initOnboardingUI, showWelcomeScreen, bindWelcomeButtons, updateDemoBanner, showPostLoadInsights } from './onboarding/onboardingUI.js';

// Chat modules (v10_0 Planning Assistant)
import { process as chatProcess, parseLLMResponse } from './chat/chatEngine.js';
import { renderStructuredResponse, renderUserMessage, renderThinking, renderError } from './chat/chatUIRenderer.js';
import { executeAction, bindActionClicks } from './chat/chatActions.js';
import { getQuickPrompts, renderQuickPromptsHTML } from './chat/chatTemplates.js';
import { buildAlerts, renderAlertBar, refreshAlerts, saveAlertBaseline } from './chat/chatAlerts.js';
import { takeSnapshot } from './chat/chatReports.js';

// ── Expose globals for chat modules (avoid circular imports) ──
window.applyBulkAction = applyBulkAction;
window.takeSnapshot    = takeSnapshot;

// ============================================================
// HELPERS
// ============================================================
function computeProgress(rows) {
  const releases = ['120','121','122','ot'];
  const result = {};
  releases.forEach(rel => {
    const key = rel === 'ot' ? 'hasOvertime' : `hasRelease${rel}`;
    const inRel = rows.filter(r => r[key]);
    const done = inRel.filter(r => r.isDone).length;
    result[rel] = { total: inRel.length, done, pct: inRel.length ? Math.round(done/inRel.length*100) : 0 };
  });
  const total = rows.length;
  const done = rows.filter(r => r.isDone).length;
  result.all = { total, done, pct: total ? Math.round(done/total*100) : 0 };
  return result;
}

function computeLoad(rows) {
  const load = {};
  rows.forEach(r => {
    const assignees = String(r.assignee||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
    assignees.forEach(name => {
      if (!load[name]) load[name] = { total:0, r120:0, r121:0, r122:0, ot:0 };
      load[name].total++;
      if (r.hasRelease120) load[name].r120++;
      if (r.hasRelease121) load[name].r121++;
      if (r.hasRelease122) load[name].r122++;
      if (r.hasOvertime)   load[name].ot++;
    });
  });
  return load;
}

function getFilteredRows() { return FilterEngine.getFiltered(); }

function parseLLMCommand(text) {
  const t = text.toLowerCase().trim();
  const rows = FilterEngine.getFiltered();
  if (/назнач|распредел/.test(t) && /без.*релиз|нераспредел|unassigned/.test(t)) {
    const rel = /1\.21/.test(t) ? '121' : /1\.22/.test(t) ? '122' : '120';
    const targets = rows.filter(r => r.isUnassigned && r.scopeStatus === 'Да');
    return { intent: 'assign_unassigned_to_release', targets, payload: { release: rel }, description: `Назначить ${targets.length} нераспределённых задач в релиз 1.${rel}` };
  }
  if (/убер|удал|сним/.test(t) && /риск|блокер/.test(t)) {
    const targets = rows.filter(r => r.blockingDependency);
    return { intent: 'remove_risks', targets, payload: {}, description: `Снять блокер с ${targets.length} задач` };
  }
  if (/перегруж|нагруз/.test(t)) {
    const load = computeLoad(rows);
    const overloaded = Object.entries(load).filter(([,v]) => v.total >= 6).map(([name]) => name);
    return { intent: 'show_overloaded', targets: [], payload: { overloaded }, description: `Перегруженные исполнители: ${overloaded.join(', ') || 'нет'}` };
  }
  return null;
}

// ============================================================
// TOAST / MODAL
// ============================================================
function showToast(msg, type='success', ms=2000) {
  const el=document.getElementById('toast');
  if (!el) return;
  el.textContent=msg; el.className=`toast toast-${type}`;
  el.classList.remove('hidden');
  clearTimeout(showToast._t);
  showToast._t=setTimeout(()=>{
    el.classList.add('toast-out');
    setTimeout(()=>el.classList.add('hidden'),160);
  },ms);
}

function closeModal(el) {
  if (!el || el.classList.contains('hidden')) return;
  el.classList.add('modal-closing');
  setTimeout(() => { el.classList.remove('modal-closing'); el.classList.add('hidden'); }, 140);
}

// ============================================================
// UNDO / REDO
// ============================================================
const HistoryManager = {
  limit: 45,
  undoStack: [],
  redoStack: [],
  _restoring: false,

  _capture() {
    if (window.HistoryModule && typeof window.HistoryModule.buildSnapshot === 'function') {
      return window.HistoryModule.buildSnapshot(state);
    }
    return JSON.parse(JSON.stringify({
      rows: state.rows, employees: state.employees,
      customCols: state.customCols, colOrder: state.colOrder,
      colWidths: state.colWidths, colVisibility: state.colVisibility,
      colLabels: state.colLabels, colTypes: state.colTypes,
      pinnedCols: state.pinnedCols, rowHeight: state.rowHeight,
      sort: state.sort, lastClickedRowId: state.lastClickedRowId,
      epicDeps: state.epicDeps, _idCounter: state._idCounter,
      _dataVersion: state._dataVersion,
    }));
  },

  _fingerprint(snapshot) {
    if (window.HistoryModule && typeof window.HistoryModule.fingerprint === 'function') {
      return window.HistoryModule.fingerprint(snapshot);
    }
    const payload = JSON.stringify(snapshot);
    return payload.length + ':' + payload.slice(0, 180);
  },

  checkpoint(label='edit') {
    if (HistoryManager._restoring) return;
    const snapshot = HistoryManager._capture();
    const fp = HistoryManager._fingerprint(snapshot);
    const prev = HistoryManager.undoStack[HistoryManager.undoStack.length - 1];
    if (prev && prev.fp === fp) return;
    HistoryManager.undoStack.push({ label, fp, snapshot });
    if (HistoryManager.undoStack.length > HistoryManager.limit) HistoryManager.undoStack.shift();
    HistoryManager.redoStack = [];
    HistoryManager.syncButtons();
  },

  _apply(snapshot) {
    HistoryManager._restoring = true;
    try {
      if (window.HistoryModule && typeof window.HistoryModule.applySnapshot === 'function') {
        window.HistoryModule.applySnapshot(state, snapshot);
      } else {
        Object.assign(state, JSON.parse(JSON.stringify(snapshot)));
      }
      syncColumnSettings();
      RegistryView.applyRowHeight();
      FilterEngine.invalidate();
      state.rows.forEach(r => RowFactory.updateDerived(r));
      RiskEngine.computeAll();
      Storage.save();
      App.populateFilterDropdowns();
      App.refreshAll();
      App.updateTopbarBadge();
    } finally {
      HistoryManager._restoring = false;
      HistoryManager.syncButtons();
    }
  },

  undo() {
    if (!HistoryManager.undoStack.length) return;
    const current = HistoryManager._capture();
    const prev = HistoryManager.undoStack.pop();
    HistoryManager.redoStack.push({ label: prev.label, fp: HistoryManager._fingerprint(current), snapshot: current });
    HistoryManager._apply(prev.snapshot);
    showToast('Отменено');
  },

  redo() {
    if (!HistoryManager.redoStack.length) return;
    const current = HistoryManager._capture();
    const next = HistoryManager.redoStack.pop();
    HistoryManager.undoStack.push({ label: next.label, fp: HistoryManager._fingerprint(current), snapshot: current });
    HistoryManager._apply(next.snapshot);
    showToast('Повторено');
  },

  clear() {
    HistoryManager.undoStack = [];
    HistoryManager.redoStack = [];
    HistoryManager.syncButtons();
  },

  syncButtons() {
    const undoBtn = document.getElementById('btn-undo');
    const redoBtn = document.getElementById('btn-redo');
    if (undoBtn) {
      undoBtn.disabled = !HistoryManager.undoStack.length;
      undoBtn.title = HistoryManager.undoStack.length ? `Отменить (${HistoryManager.undoStack[HistoryManager.undoStack.length - 1].label})` : 'Отменить';
    }
    if (redoBtn) {
      redoBtn.disabled = !HistoryManager.redoStack.length;
      redoBtn.title = HistoryManager.redoStack.length ? `Повторить (${HistoryManager.redoStack[HistoryManager.redoStack.length - 1].label})` : 'Повторить';
    }
  },
};

// ============================================================
// FORCE SAVE
// ============================================================
function forceSave() {
  state.rows.forEach(r=>RowFactory.updateDerived(r));
  RiskEngine.computeAll();
  syncColumnSettings();
  state._dataVersion++;
  clearTimeout(Storage._t);
  try {
    localStorage.setItem(STORAGE_KEY,JSON.stringify({rows:state.rows,employees:state.employees,savedAt:new Date().toISOString(),version:3}));
    localStorage.setItem(SETTINGS_KEY,JSON.stringify({
      colOrder:state.colOrder,colWidths:state.colWidths,colVisibility:state.colVisibility,
      sidebarCollapsed:state.sidebarCollapsed,pinnedCols:state.pinnedCols,rowHeight:state.rowHeight,
      colLabels:state.colLabels,customCols:state.customCols,colTypes:state.colTypes,
      epicDeps:state.epicDeps,ganttMode:state.ganttMode,ganttEpicsWell:state.ganttEpicsWell,
      podlozhkaMode:state.podlozhkaMode,summaryMode:state.summaryMode,presetsCollapsed:state.presetsCollapsed,
      theme:state.theme,
      gantt2Zoom:state.gantt2Zoom,gantt2ShowDeps:state.gantt2ShowDeps,gantt2Team:state.gantt2Team,
    }));
  } catch(e){
    if (e && e.name === 'QuotaExceededError') {
      showToast('Сохранение не выполнено: переполнен localStorage', 'error', 4200);
      return;
    }
  }
  App.populateFilterDropdowns();
  App.refreshAll();
  App.updateTopbarBadge();
  showToast('✓ Сохранено и пересчитано');
}


// ============================================================
// BULK EDIT PANEL
// ============================================================
const BulkEditPanel = {
  show() {
    const panel = document.getElementById('bulk-panel');
    if (panel) { panel.classList.remove('hidden'); BulkEditPanel.update(); }
  },
  hide() {
    const panel = document.getElementById('bulk-panel');
    if (panel) panel.classList.add('hidden');
  },
  update() {
    const panel = document.getElementById('bulk-panel');
    if (!panel) return;
    const count = state.bulkSelected.size;
    const countEl = panel.querySelector('#bulk-count');
    if (countEl) countEl.textContent = `Выбрано: ${count}`;
  },
  toggle(rowId, checked) {
    if (checked) state.bulkSelected.add(rowId);
    else state.bulkSelected.delete(rowId);
    if (state.bulkSelected.size > 0) BulkEditPanel.show();
    else BulkEditPanel.hide();
    BulkEditPanel.update();
  },
  selectAll(rows) {
    rows.forEach(r => state.bulkSelected.add(r.id));
    BulkEditPanel.show(); BulkEditPanel.update();
    document.querySelectorAll('.bulk-row-cb').forEach(cb => { cb.checked = true; });
  },
  clearAll() {
    state.bulkSelected.clear(); BulkEditPanel.hide();
    document.querySelectorAll('.bulk-row-cb').forEach(cb => { cb.checked = false; });
    const selectAll = document.getElementById('bulk-select-all');
    if (selectAll) selectAll.checked = false;
  },
  applyFromPanel(actionType) {
    const ids = [...state.bulkSelected];
    if (!ids.length) return;
    let payload = {};
    if (actionType === 'assign_release') {
      const sel = document.getElementById('bulk-release-select');
      payload.release = sel ? sel.value : '120';
    } else if (actionType === 'set_scope') {
      const sel = document.getElementById('bulk-scope-select');
      payload.scope = sel ? sel.value : 'Да';
    } else if (actionType === 'set_priority') {
      const sel = document.getElementById('bulk-priority-select');
      payload.priority = sel ? sel.value : 'medium';
    } else if (actionType === 'set_assignee') {
      const inp = document.getElementById('bulk-assignee-input');
      payload.assignee = inp ? inp.value.trim() : '';
      if (!payload.assignee) return;
    }
    applyBulkAction(ids, actionType, payload);
    BulkEditPanel.clearAll();
  },
  bindUI() {
    const panel = document.getElementById('bulk-panel');
    if (!panel) return;
    panel.querySelector('#bulk-btn-deselect')?.addEventListener('click', () => BulkEditPanel.clearAll());
    panel.querySelector('#bulk-btn-release')?.addEventListener('click', () => BulkEditPanel.applyFromPanel('assign_release'));
    panel.querySelector('#bulk-btn-scope')?.addEventListener('click', () => BulkEditPanel.applyFromPanel('set_scope'));
    panel.querySelector('#bulk-btn-priority')?.addEventListener('click', () => BulkEditPanel.applyFromPanel('set_priority'));
    panel.querySelector('#bulk-btn-assignee')?.addEventListener('click', () => BulkEditPanel.applyFromPanel('set_assignee'));
    panel.querySelector('#bulk-btn-done')?.addEventListener('click', () => { applyBulkAction([...state.bulkSelected], 'mark_done', {done:true}); BulkEditPanel.clearAll(); });
    panel.querySelector('#bulk-btn-clear-release')?.addEventListener('click', () => { applyBulkAction([...state.bulkSelected], 'clear_release', {}); BulkEditPanel.clearAll(); });
    panel.querySelector('#bulk-btn-clear-blocker')?.addEventListener('click', () => { applyBulkAction([...state.bulkSelected], 'clear_blocker', {}); BulkEditPanel.clearAll(); });
  },
};

// ============================================================
// SIMULATION MODE
// ============================================================
const SimMode = {
  toggle() {
    state.simMode = !state.simMode;
    const btn = document.getElementById('btn-sim-mode');
    if (btn) {
      btn.textContent = state.simMode ? '⚡ Симуляция ON' : '⚡ Симуляция';
      btn.classList.toggle('btn-warning', state.simMode);
      btn.classList.toggle('btn-outline', !state.simMode);
    }
    document.body.classList.toggle('sim-mode-active', state.simMode);
    showToast(state.simMode ? 'Режим симуляции включён — изменения не сохраняются' : 'Режим симуляции выключен', state.simMode ? 'warning' : 'info');
  },
};

// ============================================================
// SIDEBAR
// ============================================================
const SidebarUI = {
  init() {
    document.getElementById('sidebar-toggle').addEventListener('click',()=>SidebarUI.toggle());
    if (state.sidebarCollapsed) SidebarUI.apply();
  },
  toggle() {
    state.sidebarCollapsed=!state.sidebarCollapsed;
    SidebarUI.apply();
    Storage.save();
  },
  apply() {
    const sb=document.getElementById('sidebar');
    const bd=document.body;
    if (state.sidebarCollapsed) { sb.classList.add('collapsed'); bd.classList.add('sidebar-collapsed'); }
    else { sb.classList.remove('collapsed'); bd.classList.remove('sidebar-collapsed'); }
  },
};

// ============================================================
// THEME
// ============================================================
const ThemeUI = {
  init() {
    const btn=document.getElementById('btn-theme-toggle');
    if (!btn) return;
    if (!['light','dark'].includes(state.theme)) state.theme='light';
    ThemeUI.apply();
    btn.addEventListener('click',()=>{
      state.theme=state.theme==='dark'?'light':'dark';
      ThemeUI.apply();
      Storage.save();
    });
  },
  apply() {
    const dark=state.theme==='dark';
    document.body.classList.toggle('theme-dark',dark);
    const btn=document.getElementById('btn-theme-toggle');
    if (btn) {
      btn.textContent=dark?'☀️ Светлая':'🌙 Тёмная';
      btn.title=dark?'Переключить на светлую тему':'Переключить на тёмную тему';
    }
  },
};

// ============================================================
// FILTERS UI
// ============================================================
const FiltersUI = {
  init() {
    const bind=(id,key,bool)=>{
      const el=document.getElementById(id);
      if (!el) return;
      el.addEventListener('change',e=>{ state.filters[key]=bool?e.target.checked:e.target.value; App.refreshCurrentSection(); });
    };
    bind('filter-search','search'); bind('filter-team','team'); bind('filter-scope','scope');
    bind('filter-release','release'); bind('filter-worktype','workType'); bind('filter-role','role'); bind('filter-assignee','assignee');
    bind('filter-blocking','onlyBlocking',true);
    bind('filter-risky','onlyRisky',true); bind('filter-done','onlyDone',true);
    if (FiltersUI._searchTimer) clearTimeout(FiltersUI._searchTimer);
    document.getElementById('filter-search').addEventListener('input',e=>{
      const next = e.target.value.trim();
      clearTimeout(FiltersUI._searchTimer);
      FiltersUI._searchTimer = setTimeout(()=>{
        state.filters.search=next;
        App.refreshCurrentSection();
      }, 140);
    });
    document.getElementById('btn-reset-filters').addEventListener('click',()=>FiltersUI.reset());
    document.querySelectorAll('.preset-btn[data-preset]').forEach(btn=>btn.addEventListener('click',()=>FiltersUI.applyPreset(btn.dataset.preset)));
  },
  applyPreset(preset) {
    document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('active'));
    if (preset==='reset') { state.filters.preset=null; state.filters.onlyBlocking=state.filters.onlyRisky=state.filters.onlyDone=false; state.filters.scope=state.filters.release=''; FiltersUI.syncUI(); App.refreshCurrentSection(); return; }
    state.filters.preset=preset;
    const btn=document.querySelector(`.preset-btn[data-preset="${preset}"]`);
    if (btn) btn.classList.add('active');
    state.filters.onlyBlocking=state.filters.onlyRisky=state.filters.onlyDone=false; state.filters.scope=state.filters.release='';
    if (preset==='critical') state.filters.onlyRisky=true;
    else if (preset==='no-release') state.filters.release='none';
    else if (preset==='needs-confirm') state.filters.scope='Требует подтверждения';
    else if (preset==='has-blocker') state.filters.onlyBlocking=true;
    else if (preset==='overtime') state.filters.release='overtime';
    else if (preset==='done') state.filters.onlyDone=true;
    FiltersUI.syncUI(); App.refreshCurrentSection();
  },
  syncUI() {
    document.getElementById('filter-scope').value=state.filters.scope||'';
    document.getElementById('filter-release').value=state.filters.release||'';
    ['blocking','risky','done'].forEach(k=>{
      const fk='only'+k.charAt(0).toUpperCase()+k.slice(1);
      const cb=document.getElementById(`filter-${k}`);
      if (cb) cb.checked=state.filters[fk];
      const tg=document.getElementById(`toggle-${k}`);
      if (tg) tg.classList.toggle('active',state.filters[fk]);
    });
    const roleSel=document.getElementById('filter-role'); if(roleSel) roleSel.value=Array.isArray(state.filters.role)?'':(state.filters.role||'');
    const assigneeSel=document.getElementById('filter-assignee'); if(assigneeSel) assigneeSel.value=Array.isArray(state.filters.assignee)?'':(state.filters.assignee||'');
  },
  reset() {
    state.filters={search:'',team:'',scope:'',release:'',workType:'',role:'',assignee:'',tag:'',onlyBlocking:false,onlyRisky:false,onlyDone:false,preset:null};
    document.getElementById('filter-search').value=''; document.getElementById('filter-team').value='';
    document.getElementById('filter-scope').value=''; document.getElementById('filter-release').value='';
    document.getElementById('filter-worktype').value=''; document.getElementById('filter-role').value='';
    const assigneeSel=document.getElementById('filter-assignee'); if (assigneeSel) assigneeSel.value='';
    document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('active'));
    FiltersUI.syncUI(); FiltersUI.populateDropdowns(); App.refreshCurrentSection();
  },
  populateDropdowns() {
    const teamSel=document.getElementById('filter-team'), cur1=teamSel.value;
    teamSel.innerHTML='<option value="">Все</option>'+FilterEngine.getTeams().map(t=>`<option value="${t}"${cur1===t?' selected':''}>${t}</option>`).join('');
    const wtSel=document.getElementById('filter-worktype'), cur2=wtSel.value;
    wtSel.innerHTML='<option value="">Все</option>'+FilterEngine.getWorkTypes().map(t=>`<option value="${t}"${cur2===t?' selected':''}>${t}</option>`).join('');
    const roleSel=document.getElementById('filter-role'), cur3=Array.isArray(state.filters.role)?'':roleSel.value;
    roleSel.innerHTML='<option value="">Все</option>'+FilterEngine.getRoles().map(r=>`<option value="${r}"${cur3===r?' selected':''}>${r}</option>`).join('');
    const asSel=document.getElementById('filter-assignee');
    if (asSel) {
      const curA=Array.isArray(state.filters.assignee)?'':asSel.value;
      asSel.innerHTML='<option value="">Все</option>'+FilterEngine.getAssignees().map(a=>`<option value="${a}"${curA===a?' selected':''}>${a}</option>`).join('');
    }
    const rpw=document.getElementById('preset-roles-wrap');
    if(rpw){
      const roles=FilterEngine.getRoles();
      const current=Array.isArray(state.filters.role)?state.filters.role:(state.filters.role?[state.filters.role]:[]);
      rpw.innerHTML='';
      const ms=Multiselect.create(current,(vals)=>{
        state.filters.role=vals.length?vals:'';
        document.getElementById('filter-role').value='';
        App.refreshCurrentSection();
      },()=>roles);
      ms.classList.add('preset-ms');
      rpw.appendChild(ms);
    }
    const paw=document.getElementById('preset-assignees-wrap');
    if (paw) {
      const assignees=FilterEngine.getAssignees();
      const current=Array.isArray(state.filters.assignee)?state.filters.assignee:(state.filters.assignee?[state.filters.assignee]:[]);
      paw.innerHTML='';
      const ms=Multiselect.create(current,(vals)=>{
        state.filters.assignee=vals.length?vals:'';
        const baseSel=document.getElementById('filter-assignee'); if (baseSel) baseSel.value='';
        App.refreshCurrentSection();
      },()=>assignees);
      ms.classList.add('preset-ms');
      paw.appendChild(ms);
    }
    const ptw=document.getElementById('preset-tags-wrap');
    if(ptw){
      const tags=[...new Set(state.rows.flatMap(r=>r.tags?String(r.tags).split('|').map(s=>s.trim()).filter(Boolean):[]))].sort();
      const current=Array.isArray(state.filters.tag)?state.filters.tag:(state.filters.tag?[state.filters.tag]:[]);
      ptw.innerHTML='';
      const ms=Multiselect.create(current,(vals)=>{
        state.filters.tag=vals.length?vals:'';
        App.refreshCurrentSection();
      },()=>tags);
      ms.classList.add('preset-ms');
      ptw.appendChild(ms);
    }
  },
};


// ============================================================
// LLM ASSISTANT — helper functions
// ============================================================
function getLLMDefaultSettings() {
  const defaultProxy = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:')
    ? 'http://127.0.0.1:8080' : '';
  return {
    apiMode: 'direct', apiBaseUrl: 'http://localhost:3000/v1', proxyUrl: defaultProxy,
    model: 'GigaChat-2', token: '', temperature: 0.2, maxTokens: 2000,
    systemPrompt: DEFAULT_LLM_SYSTEM_PROMPT, contextMode: 'currentView',
    rowLimit: 150, payloadLimitBytes: 250000, saveToLocal: true,
    tokenSessionOnly: true, customPayload: '',
  };
}

function safeJSONParse(raw, fallback) {
  try { return JSON.parse(raw); } catch (_) { return fallback; }
}

function buildSummaryContextPayload() {
  const rows = state.rows || [];
  const visibleRows = FilterEngine.getFiltered();
  const summary = {
    totalRows: rows.length, visibleRows: visibleRows.length,
    done: rows.filter(r => r.isDone).length,
    blockers: rows.filter(r => r.blockingDependency).length,
    risky: rows.filter(r => (r.riskFlags || []).length > 0).length,
    inScope: rows.filter(r => r.scopeStatus === 'Да').length,
    outScope: rows.filter(r => r.scopeStatus === 'Нет').length,
    needsConfirm: rows.filter(r => r.scopeStatus === 'Требует подтверждения').length,
    noRelease: rows.filter(r => r.isUnassigned).length,
    overtime: rows.filter(r => r.hasOvertime).length,
  };
  const riskCounter = {};
  rows.forEach(r => (r.riskFlags || []).forEach(flag => { riskCounter[flag] = (riskCounter[flag] || 0) + 1; }));
  const releaseDistribution = {
    backlog: rows.filter(r => r.isUnassigned).length,
    '1.20': rows.filter(r => r.hasRelease120).length,
    '1.21': rows.filter(r => r.hasRelease121).length,
    '1.22': rows.filter(r => r.hasRelease122).length,
    overtime: rows.filter(r => r.hasOvertime).length,
  };
  const teamMap = {};
  rows.forEach(r => {
    const t = r.team || '(без команды)';
    if (!teamMap[t]) teamMap[t] = { team: t, total: 0, done: 0, blockers: 0, risky: 0, inScope: 0, noRelease: 0 };
    teamMap[t].total++;
    if (r.isDone) teamMap[t].done++;
    if (r.blockingDependency) teamMap[t].blockers++;
    if ((r.riskFlags || []).length > 0) teamMap[t].risky++;
    if (r.scopeStatus === 'Да') teamMap[t].inScope++;
    if (r.isUnassigned) teamMap[t].noRelease++;
  });
  const teamBreakdown = Object.values(teamMap).sort((a, b) => b.total - a.total);
  const pickRowFields = r => ({
    team: r.team, epic: r.epic, tasks: r.tasks, scopeStatus: r.scopeStatus,
    assignee: r.assignee, release120Types: r.release120Types, release121Types: r.release121Types,
    release122Types: r.release122Types, blockingDeadline: r.blockingDeadline,
    riskFlags: r.riskFlags, workPeriodStart: r.workPeriodStart,
    workPeriodEnd: r.workPeriodEnd, comment: r.comment,
  });
  const topBlockers = rows.filter(r => r.blockingDependency && !r.isDone).slice(0, 20).map(pickRowFields);
  const topRiskyRows = rows.filter(r => (r.riskFlags || []).length > 0 && !r.isDone).slice(0, 20).map(pickRowFields);
  return {
    app: 'SBOF Planner', activeTab: state.activeSection,
    filters: { ...state.filters }, selectedPreset: state.filters.preset || null,
    summary, riskSummary: riskCounter, releaseDistribution,
    teamBreakdown, topBlockers, topRiskyRows, timestamp: new Date().toISOString(),
  };
}

function buildVisibleContextPayload() {
  const base = buildSummaryContextPayload();
  const rows = FilterEngine.getFiltered().map(r => ({
    id: r.id, team: r.team, epic: r.epic, category: r.category, tags: r.tags,
    tasks: r.tasks, scopeStatus: r.scopeStatus,
    release120Types: r.release120Types, release121Types: r.release121Types,
    release122Types: r.release122Types, overtimeTypes: r.overtimeTypes,
    role: r.role, assignee: r.assignee, isDone: r.isDone,
    blockingDependency: r.blockingDependency, riskFlags: r.riskFlags || [],
    workPeriodStart: r.workPeriodStart, workPeriodEnd: r.workPeriodEnd, comment: r.comment,
  }));
  return { ...base, visibleRows: rows };
}

function buildAppContextPayload() {
  const base = buildSummaryContextPayload();
  const rows = state.rows.map(r => ({
    id: r.id, team: r.team, epic: r.epic, category: r.category, tags: r.tags,
    tasks: r.tasks, scopeStatus: r.scopeStatus,
    release120Types: r.release120Types, release121Types: r.release121Types,
    release122Types: r.release122Types, overtimeTypes: r.overtimeTypes,
    role: r.role, assignee: r.assignee, isDone: r.isDone,
    blockingDependency: r.blockingDependency, riskFlags: r.riskFlags || [],
    workPeriodStart: r.workPeriodStart, workPeriodEnd: r.workPeriodEnd, comment: r.comment,
  }));
  return { ...base, rows };
}

function buildCustomContextPayload() {
  const customRaw = String(state.llm?.settings?.customPayload || '').trim();
  if (!customRaw) return { customPayload: null };
  const parsed = safeJSONParse(customRaw, null);
  return parsed ? { customPayload: parsed } : { customPayloadText: customRaw };
}

function truncateForLLM(payload, limits) {
  const rowLimit = Math.max(1, Number(limits?.rowLimit) || 50);
  const payloadLimitBytes = Math.max(1024, Number(limits?.payloadLimitBytes) || 120000);
  const out = safeJSONParse(JSON.stringify(payload || {}), {});
  const trimRows = (key) => { if (Array.isArray(out[key]) && out[key].length > rowLimit) out[key] = out[key].slice(0, rowLimit); };
  trimRows('rows'); trimRows('visibleRows');
  const serialized = JSON.stringify(out);
  if (serialized.length <= payloadLimitBytes) return out;
  const minimize = (row) => ({
    id: row.id, team: row.team, epic: row.epic, tasks: row.tasks,
    scopeStatus: row.scopeStatus, release120Types: row.release120Types,
    release121Types: row.release121Types, release122Types: row.release122Types,
    overtimeTypes: row.overtimeTypes, blockingDependency: row.blockingDependency,
    riskFlags: row.riskFlags, assignee: row.assignee,
  });
  if (Array.isArray(out.rows)) out.rows = out.rows.map(minimize).slice(0, Math.max(10, Math.floor(rowLimit * 0.65)));
  if (Array.isArray(out.visibleRows)) out.visibleRows = out.visibleRows.map(minimize).slice(0, Math.max(10, Math.floor(rowLimit * 0.65)));
  const second = JSON.stringify(out);
  if (second.length <= payloadLimitBytes) return out;
  out.rows = Array.isArray(out.rows) ? out.rows.slice(0, 12) : out.rows;
  out.visibleRows = Array.isArray(out.visibleRows) ? out.visibleRows.slice(0, 12) : out.visibleRows;
  out._truncated = true; out._payloadBytes = second.length; out._payloadLimitBytes = payloadLimitBytes;
  return out;
}

function buildLLMMessages(userMessage, contextOverride) {
  const settings = LLMAssistant.getSettings();
  const contextMode = contextOverride || settings.contextMode || 'currentView';
  let payload;
  if (contextMode === 'none') payload = { contextDisabled: true };
  else if (contextMode === 'summary') payload = buildSummaryContextPayload();
  else if (contextMode === 'currentView') payload = buildVisibleContextPayload();
  else if (contextMode === 'fullRegistry') payload = buildAppContextPayload();
  else payload = buildCustomContextPayload();
  payload = truncateForLLM(payload, { rowLimit: settings.rowLimit, payloadLimitBytes: settings.payloadLimitBytes });
  const systemPrompt = settings.systemPrompt || DEFAULT_LLM_SYSTEM_PROMPT;
  const userBlock = [`Вопрос пользователя: ${userMessage}`, '', `Режим контекста: ${contextMode}`, 'Контекст приложения (JSON):', JSON.stringify(payload, null, 2)].join('\n');
  return [{ role: 'system', content: systemPrompt }, { role: 'user', content: userBlock }];
}

function trimApiHistory(apiHistory, maxMessages) {
  if (!Array.isArray(apiHistory) || apiHistory.length <= maxMessages) return apiHistory;
  const first = apiHistory[0];
  const rest = apiHistory.slice(1);
  return [first, ...rest.slice(-(maxMessages - 1))];
}

function buildApiCallMessages(userMessage, contextOverride) {
  const settings = LLMAssistant.getSettings();
  const systemPrompt = settings.systemPrompt || DEFAULT_LLM_SYSTEM_PROMPT;
  const apiHistory = state.llm?.apiHistory || [];
  const hasHistory = apiHistory.some(m => m.role === 'user');
  if (!hasHistory) return buildLLMMessages(userMessage, contextOverride);
  const MAX_HISTORY = 20;
  const trimmed = trimApiHistory(apiHistory, MAX_HISTORY);
  return [{ role: 'system', content: systemPrompt }, ...trimmed, { role: 'user', content: userMessage }];
}

function extractDeltaFromChunk(obj) {
  if (!obj) return '';
  if (typeof obj === 'string') return obj;
  const c = obj.choices?.[0];
  const v = c?.delta?.content ?? c?.message?.content ?? c?.text ?? obj.delta ?? obj.content ?? obj.output_text ?? obj.result?.choices?.[0]?.delta?.content ?? obj.result?.choices?.[0]?.message?.content ?? '';
  if (Array.isArray(v)) return v.map(x => (typeof x === 'string' ? x : (x?.text || ''))).join('');
  return typeof v === 'string' ? v : '';
}

async function parseStreamResponse(response, onDelta, abortSignal) {
  const contentType = (response.headers.get('content-type') || '').toLowerCase();
  console.log('[LLM] parseStreamResponse start | status:', response.status, '| content-type:', contentType, '| hasBody:', !!response.body);

  if (!response.ok) {
    const errTxt = await response.text().catch(() => '');
    console.error('[LLM] HTTP error:', response.status, response.statusText, '| body:', errTxt.slice(0, 500));
    throw new Error(errTxt || `HTTP ${response.status}`);
  }

  if (!response.body) {
    const data = await response.json().catch(e => { console.warn('[LLM] json parse failed (no body):', e); return {}; });
    const full = extractDeltaFromChunk(data) || data?.choices?.[0]?.message?.content || '';
    console.log('[LLM] no-body path → extracted:', JSON.stringify(full).slice(0, 200));
    if (full) onDelta(full); return;
  }

  if (contentType.includes('application/json')) {
    const raw = await response.text().catch(e => { console.warn('[LLM] text() failed:', e); return ''; });
    console.log('[LLM] json content-type → raw:', raw.slice(0, 500));
    const data = safeJSONParse(raw, {});
    const full = extractDeltaFromChunk(data) || data?.choices?.[0]?.message?.content || '';
    console.log('[LLM] json path → extracted:', JSON.stringify(full).slice(0, 200));
    if (full) onDelta(full); return;
  }

  // SSE stream path
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let totalChunks = 0;
  let totalDelta = 0;
  while (true) {
    if (abortSignal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const { value, done } = await reader.read();
    if (done) {
      console.log('[LLM] stream done | chunks emitted:', totalChunks, '| total delta chars:', totalDelta);
      break;
    }
    buffer += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, idx).trim(); buffer = buffer.slice(idx + 1);
      if (!line) continue;
      // Skip SSE non-data fields
      if (line.startsWith('event:') || line.startsWith('id:') || line.startsWith('retry:') || line.startsWith(':')) {
        console.log('[LLM] SSE field (skipped):', line.slice(0, 80));
        continue;
      }
      let dataLine = line;
      if (line.startsWith('data:')) dataLine = line.slice(5).trim();
      if (!dataLine || dataLine === '[DONE]') { if (dataLine === '[DONE]') console.log('[LLM] [DONE] received'); continue; }
      const parsed = safeJSONParse(dataLine, null);
      if (parsed) {
        const chunk = extractDeltaFromChunk(parsed);
        if (chunk) { onDelta(chunk); totalChunks++; totalDelta += chunk.length; }
        else console.log('[LLM] parsed chunk but extractDelta=empty | keys:', Object.keys(parsed).join(','));
        continue;
      }
      console.warn('[LLM] unparseable line (not JSON, not SSE field):', dataLine.slice(0, 120));
    }
  }
  const tail = buffer.trim();
  if (tail && tail !== '[DONE]' && !tail.startsWith('event:') && !tail.startsWith('id:') && !tail.startsWith('retry:') && !tail.startsWith(':')) {
    console.log('[LLM] tail buffer:', tail.slice(0, 200));
    const parsed = safeJSONParse(tail.startsWith('data:') ? tail.slice(5).trim() : tail, null);
    if (parsed) { const chunk = extractDeltaFromChunk(parsed); if (chunk) onDelta(chunk); }
  }
  if (totalDelta === 0) {
    console.warn('[LLM] ⚠ stream finished but NO delta text was emitted. Possible causes: empty choices[], wrong model response format, or all lines were skipped.');
  }
}

function buildOpenAIChatEndpoint(baseUrlRaw) {
  const baseUrl = String(baseUrlRaw || '').trim().replace(/\/+$/, '');
  if (!baseUrl) return '/v1/chat/completions';
  if (baseUrl.endsWith('/chat/completions')) return baseUrl;
  if (baseUrl.endsWith('/v1')) return `${baseUrl}/chat/completions`;
  return `${baseUrl}/chat/completions`;
}

function buildProxyEndpoint(settings) {
  const customProxyOrigin = String(settings.proxyUrl || '').trim().replace(/\/+$/, '');
  if (customProxyOrigin) return `${customProxyOrigin}/api/llm/chat`;
  if (window.location.protocol === 'file:') throw new Error('Режим file:// не поддерживает /api/llm/chat. Запусти node server.js.');
  return '/api/llm/chat';
}

async function callGigaChatStream(messages, settings, onDelta, abortSignal) {
  const mode = settings.apiMode || 'proxy';
  const baseUrl = String(settings.apiBaseUrl || '').replace(/\/+$/, '');
  const token = LLMAssistant.getToken();
  const payload = { model: settings.model || 'GigaChat-2', temperature: Number(settings.temperature), max_tokens: Math.max(64, Number(settings.maxTokens) || 900), stream: true, messages };

  console.group('[LLM] callGigaChatStream');
  console.log('mode:', mode);
  console.log('model:', payload.model);
  console.log('apiBaseUrl:', baseUrl || '(not set)');
  console.log('token present:', !!token, token ? `(${token.length} chars)` : '');
  console.log('messages count:', messages.length);
  console.log('messages:', messages.map(m => ({ role: m.role, len: m.content?.length })));
  console.groupEnd();

  if (mode === 'direct') {
    const endpoint = buildOpenAIChatEndpoint(baseUrl || 'http://localhost:3000/v1');
    const endpointUrl = new URL(endpoint, window.location.origin);
    const sameOrigin = endpointUrl.origin === window.location.origin;
    console.log('[LLM] direct mode → endpoint:', endpointUrl.toString(), '| sameOrigin:', sameOrigin);
    if (sameOrigin) {
      const res = await fetch(endpointUrl.toString(), { method:'POST', signal:abortSignal, headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})}, body:JSON.stringify(payload) });
      console.log('[LLM] direct response:', res.status, res.statusText, 'content-type:', res.headers.get('content-type'));
      return parseStreamResponse(res, onDelta, abortSignal);
    }
    const proxyEndpoint = buildProxyEndpoint(settings);
    console.log('[LLM] direct→proxy endpoint:', proxyEndpoint);
    const res = await fetch(proxyEndpoint, { method:'POST', signal:abortSignal, headers:{'Content-Type':'application/json'}, body:JSON.stringify({ apiBaseUrl:`${endpointUrl.origin}${endpointUrl.pathname.replace(/\/chat\/completions$/,'')}`, model:payload.model, temperature:payload.temperature, max_tokens:payload.max_tokens, stream:true, messages:payload.messages, token }) });
    console.log('[LLM] proxy response:', res.status, res.statusText, 'content-type:', res.headers.get('content-type'));
    return parseStreamResponse(res, onDelta, abortSignal);
  }
  const proxyEndpoint = buildProxyEndpoint(settings);
  console.log('[LLM] proxy mode → endpoint:', proxyEndpoint);
  const res = await fetch(proxyEndpoint, { method:'POST', signal:abortSignal, headers:{'Content-Type':'application/json'}, body:JSON.stringify({ apiBaseUrl:baseUrl, model:payload.model, temperature:payload.temperature, max_tokens:payload.max_tokens, stream:true, messages:payload.messages, token }) });
  console.log('[LLM] proxy response:', res.status, res.statusText, 'content-type:', res.headers.get('content-type'));
  return parseStreamResponse(res, onDelta, abortSignal);
}

function renderMarkdownLite(raw) {
  const text = String(raw || '').trim();
  if (!text) return '';
  function applyInline(s) {
    return s.replace(/\*\*\*(.+?)\*\*\*/g,'<strong><em>$1</em></strong>').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/__(.+?)__/g,'<strong>$1</strong>').replace(/\*([^*\n]+)\*/g,'<em>$1</em>').replace(/_([^_\n]+)_/g,'<em>$1</em>').replace(/`([^`\n]+)`/g,'<code>$1</code>');
  }
  function processSegment(seg) {
    const lines = Utils.escapeHtml(seg).split('\n');
    const out = []; let inUl=false,inOl=false;
    const closeList=()=>{ if(inUl){out.push('</ul>');inUl=false;} if(inOl){out.push('</ol>');inOl=false;} };
    for (const line of lines) {
      if (/^###\s/.test(line)) { closeList(); out.push(`<h4 class="md-h">${applyInline(line.replace(/^###\s+/,''))}</h4>`); }
      else if (/^##\s/.test(line)) { closeList(); out.push(`<h3 class="md-h">${applyInline(line.replace(/^##\s+/,''))}</h3>`); }
      else if (/^#\s/.test(line)) { closeList(); out.push(`<h3 class="md-h">${applyInline(line.replace(/^#\s+/,''))}</h3>`); }
      else if (/^\s*[-*]\s/.test(line)) { if(!inUl){closeList();out.push('<ul>');inUl=true;} out.push(`<li>${applyInline(line.replace(/^\s*[-*]\s+/,''))}</li>`); }
      else if (/^\s*\d+[.)]\s/.test(line)) { if(!inOl){closeList();out.push('<ol>');inOl=true;} out.push(`<li>${applyInline(line.replace(/^\s*\d+[.)]\s+/,''))}</li>`); }
      else if (line.trim()==='') { closeList(); if(out.length&&out[out.length-1]!=='<br>')out.push('<br>'); }
      else { closeList(); out.push(applyInline(line)+'<br>'); }
    }
    closeList(); return out.join('');
  }
  const segments = text.split(/(```[\w]*\n?[\s\S]*?```)/g);
  const parts = [];
  for (let i=0;i<segments.length;i++) {
    if (i%2===1) { const code=segments[i].replace(/^```[\w]*\n?/,'').replace(/```$/,'').trimEnd(); parts.push(`<pre><code>${Utils.escapeHtml(code)}</code></pre>`); }
    else parts.push(processSegment(segments[i]));
  }
  let result = parts.join('');
  result = result.replace(/(<br>){3,}/g,'<br><br>').replace(/^<br>+/,'').replace(/<br>+$/,'');
  return result;
}


// ============================================================
// LLM ASSISTANT
// ============================================================
const LLMAssistant = {
  CONV_KEY: 'q2_llm_conv_v1',
  init() {
    const defaults = getLLMDefaultSettings();
    const saved = safeJSONParse(localStorage.getItem(LLM_SETTINGS_KEY) || 'null', null);
    const settings = { ...defaults, ...(saved && typeof saved === 'object' ? saved : {}) };
    if (String(settings.apiBaseUrl || '').includes('gigachat.devices.sberbank.ru')) {
      settings.apiBaseUrl = 'http://localhost:3000/v1';
      if (!saved || saved.apiMode === 'proxy') settings.apiMode = 'direct';
    }
    state.llm = { settings, history: [], apiHistory: [], panelOpen: false, panelMinimized: false, isStreaming: false, abortController: null, sessionToken: '', lastUserText: '' };
    LLMAssistant.loadConversation();
    LLMAssistant.bindUI();
    LLMAssistant.syncSettingsUI();
    LLMAssistant.updateContextModeIndicator();
    LLMAssistant.updateQuickPrompts();
    LLMAssistant.renderMessages();
  },
  saveConversation() {
    try {
      const s = LLMAssistant.getSettings();
      if (!s.saveToLocal) { localStorage.removeItem(LLMAssistant.CONV_KEY); return; }
      const data = { history: state.llm.history.filter(m => !m.streaming && !m.thinking), apiHistory: state.llm.apiHistory, savedAt: Date.now() };
      localStorage.setItem(LLMAssistant.CONV_KEY, JSON.stringify(data));
    } catch(_) {}
  },
  loadConversation() {
    try {
      const raw = localStorage.getItem(LLMAssistant.CONV_KEY); if (!raw) return;
      const data = safeJSONParse(raw, null); if (!data || !Array.isArray(data.history)) return;
      if (Date.now() - (data.savedAt || 0) > 86400000) { localStorage.removeItem(LLMAssistant.CONV_KEY); return; }
      state.llm.history = data.history;
      state.llm.apiHistory = Array.isArray(data.apiHistory) ? data.apiHistory : [];
    } catch(_) {}
  },
  getSettings() { return state.llm.settings || getLLMDefaultSettings(); },
  getToken() {
    const settings = LLMAssistant.getSettings();
    if (settings.tokenSessionOnly) return state.llm.sessionToken || '';
    return settings.token || '';
  },
  saveSettingsFromUI() {
    const s = LLMAssistant.getSettings();
    s.apiMode = document.getElementById('llm-api-mode').value || 'proxy';
    s.apiBaseUrl = (document.getElementById('llm-api-base').value || '').trim();
    s.proxyUrl = (document.getElementById('llm-proxy-url').value || '').trim();
    const selVal = document.getElementById('llm-model-select')?.value || '';
    s.model = (selVal === '__custom__'
      ? (document.getElementById('llm-model-custom')?.value || '').trim()
      : selVal
    ) || 'GigaChat-2';
    s.temperature = Math.max(0, Math.min(2, Number(document.getElementById('llm-temperature').value) || 0.2));
    s.maxTokens = Math.max(64, Number(document.getElementById('llm-max-tokens').value) || 900);
    s.systemPrompt = (document.getElementById('llm-system-prompt').value || '').trim() || DEFAULT_LLM_SYSTEM_PROMPT;
    s.contextMode = document.getElementById('llm-context-mode').value || 'summary';
    s.rowLimit = Math.max(1, Number(document.getElementById('llm-row-limit').value) || 80);
    s.payloadLimitBytes = Math.max(1024, Number(document.getElementById('llm-payload-limit').value) || 120000);
    s.customPayload = document.getElementById('llm-custom-payload').value || '';
    s.saveToLocal = !!document.getElementById('llm-save-local').checked;
    s.tokenSessionOnly = !!document.getElementById('llm-token-session-only').checked;
    const inputToken = (document.getElementById('llm-token').value || '').trim();
    if (s.tokenSessionOnly) { state.llm.sessionToken = inputToken; s.token = ''; }
    else { s.token = inputToken; state.llm.sessionToken = ''; }
    if (s.saveToLocal) {
      const persist = { ...s };
      if (persist.tokenSessionOnly) persist.token = '';
      localStorage.setItem(LLM_SETTINGS_KEY, JSON.stringify(persist));
    }
    else localStorage.removeItem(LLM_SETTINGS_KEY);
    LLMAssistant.updateContextModeIndicator();
    showToast('LLM settings сохранены');
  },
  clearSavedSettings() {
    localStorage.removeItem(LLM_SETTINGS_KEY);
    state.llm.settings = getLLMDefaultSettings();
    state.llm.sessionToken = '';
    LLMAssistant.syncSettingsUI();
    LLMAssistant.updateContextModeIndicator();
    showToast('LLM settings очищены');
  },
  syncSettingsUI() {
    const s = LLMAssistant.getSettings();
    const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
    setVal('llm-api-mode', s.apiMode); setVal('llm-api-base', s.apiBaseUrl);
    setVal('llm-proxy-url', s.proxyUrl || '');
    // Model: match against select options, otherwise show custom input
    const modelSel = document.getElementById('llm-model-select');
    const modelCustom = document.getElementById('llm-model-custom');
    if (modelSel && modelCustom) {
      const knownOpt = [...modelSel.options].find(o => o.value === s.model && o.value !== '__custom__');
      if (knownOpt) {
        modelSel.value = s.model;
        modelCustom.classList.add('hidden');
        modelCustom.value = '';
      } else {
        modelSel.value = '__custom__';
        modelCustom.classList.remove('hidden');
        modelCustom.value = s.model || '';
      }
    }
    setVal('llm-temperature', s.temperature); setVal('llm-max-tokens', s.maxTokens);
    setVal('llm-system-prompt', s.systemPrompt || DEFAULT_LLM_SYSTEM_PROMPT);
    setVal('llm-context-mode', s.contextMode); setVal('llm-row-limit', s.rowLimit);
    setVal('llm-payload-limit', s.payloadLimitBytes); setVal('llm-custom-payload', s.customPayload || '');
    const tokenInput = document.getElementById('llm-token');
    if (tokenInput) tokenInput.value = s.tokenSessionOnly ? (state.llm.sessionToken || '') : (s.token || '');
    const saveLocal = document.getElementById('llm-save-local');
    const sessionOnly = document.getElementById('llm-token-session-only');
    if (saveLocal) saveLocal.checked = !!s.saveToLocal;
    if (sessionOnly) sessionOnly.checked = !!s.tokenSessionOnly;
  },
  updateContextModeIndicator() {
    const map = { none:'none', summary:'summary only', currentView:'current view', fullRegistry:'full registry limited', custom:'custom payload' };
    const el = document.getElementById('assistant-context-mode-label');
    if (el) el.textContent = `Контекст: ${map[LLMAssistant.getSettings().contextMode] || 'summary only'}`;
  },
  bindUI() {
    const fab = document.getElementById('assistant-fab');
    const panel = document.getElementById('assistant-panel');
    const settingsModal = document.getElementById('llm-settings-modal');
    const input = document.getElementById('assistant-input');
    const sendBtn = document.getElementById('assistant-btn-send');
    const stopBtn = document.getElementById('assistant-btn-stop');
    const errorEl = document.getElementById('assistant-error');
    const openSettingsModal = () => { LLMAssistant.syncSettingsUI(); settingsModal.classList.remove('hidden'); };
    if (fab) fab.addEventListener('click', () => {
      const willOpen = panel.classList.contains('hidden');
      state.llm.panelOpen = willOpen;
      if (willOpen) { state.llm.panelMinimized = false; panel.classList.remove('hidden','minimized'); fab.classList.add('hidden'); input.focus(); }
      else { panel.classList.add('hidden'); fab.classList.remove('hidden'); errorEl.classList.add('hidden'); }
    });
    document.getElementById('assistant-btn-close').addEventListener('click', () => {
      state.llm.panelOpen = false; panel.classList.add('hidden');
      if (fab) fab.classList.remove('hidden'); errorEl.classList.add('hidden');
    });
    document.getElementById('assistant-btn-minimize').addEventListener('click', () => {
      state.llm.panelMinimized = !state.llm.panelMinimized;
      panel.classList.toggle('minimized', state.llm.panelMinimized);
    });
    document.getElementById('assistant-btn-settings')?.addEventListener('click', openSettingsModal);
    document.getElementById('assistant-btn-clear')?.addEventListener('click', () => LLMAssistant.clearConversation());
    document.getElementById('btn-llm-settings')?.addEventListener('click', openSettingsModal);
    document.getElementById('llm-settings-close').addEventListener('click', () => closeModal(settingsModal));
    settingsModal.addEventListener('click', (e) => { if (e.target === settingsModal) closeModal(settingsModal); });
    document.getElementById('llm-save-settings').addEventListener('click', () => { LLMAssistant.saveSettingsFromUI(); closeModal(settingsModal); });
    document.getElementById('llm-clear-saved').addEventListener('click', () => LLMAssistant.clearSavedSettings());
    document.getElementById('llm-model-select')?.addEventListener('change', e => {
      const custom = document.getElementById('llm-model-custom');
      if (!custom) return;
      if (e.target.value === '__custom__') { custom.classList.remove('hidden'); custom.focus(); }
      else custom.classList.add('hidden');
    });
    sendBtn.addEventListener('click', () => LLMAssistant.sendFromInput());
    stopBtn.addEventListener('click', () => LLMAssistant.stopGeneration());
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); LLMAssistant.sendFromInput(); } });
    input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 180) + 'px'; });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && state.llm?.panelOpen && !settingsModal.classList.contains('hidden')) closeModal(settingsModal);
      else if (e.key === 'Escape' && state.llm?.panelOpen) { state.llm.panelOpen = false; panel.classList.add('hidden'); if (fab) fab.classList.remove('hidden'); errorEl.classList.add('hidden'); }
    });
    const messagesWrap = document.getElementById('assistant-messages');
    if (messagesWrap) {
      // Bind action buttons & drilldown from chatActions module
      bindActionClicks(messagesWrap);

      messagesWrap.addEventListener('click', (e) => {
        // Retry button
        if (e.target.closest('[data-retry]') && state.llm.lastUserText && !state.llm.isStreaming) {
          const lastMsg = state.llm.history[state.llm.history.length - 1];
          if (lastMsg?.isError) state.llm.history.pop();
          const prevMsg = state.llm.history[state.llm.history.length - 1];
          if (prevMsg?.role === 'user' && prevMsg.content === state.llm.lastUserText) state.llm.history.pop();
          input.value = state.llm.lastUserText; input.dispatchEvent(new Event('input')); LLMAssistant.sendFromInput(); return;
        }
        // Copy button
        const copyBtn = e.target.closest('.msg-copy-btn'); if (!copyBtn) return;
        const idx = parseInt(copyBtn.dataset.index ?? '-1', 10);
        const msg = state.llm.history[idx]; if (!msg) return;
        const textToCopy = msg.content || '';
        navigator.clipboard.writeText(textToCopy).then(() => showToast('Скопировано'), () => {
          const ta = document.createElement('textarea'); ta.value = textToCopy; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); showToast('Скопировано');
        });
      });
    }
    // Review mode selector
    const reviewSel = document.getElementById('chat-review-mode-select');
    if (reviewSel) {
      reviewSel.addEventListener('change', () => {
        const role = reviewSel.value;
        if (role) {
          input.value = `Посмотри на данные как ${role === 'ceo' ? 'CEO' : role === 'dm' ? 'Delivery Manager' : role === 'risk' ? 'Risk Officer' : 'Team Lead'}.`;
          input.dispatchEvent(new Event('input'));
          LLMAssistant.sendFromInput();
          reviewSel.value = '';
        }
      });
    }
    const contextLabel = document.getElementById('assistant-context-mode-label');
    if (contextLabel) {
      contextLabel.addEventListener('click', () => {
        const modes = ['currentView','fullRegistry','summary','none'];
        const s = LLMAssistant.getSettings();
        const next = modes[(modes.indexOf(s.contextMode) + 1) % modes.length];
        s.contextMode = next;
        if (s.saveToLocal) { const persist = { ...s }; if (persist.tokenSessionOnly) persist.token = ''; localStorage.setItem(LLM_SETTINGS_KEY, JSON.stringify(persist)); }
        LLMAssistant.updateContextModeIndicator(); showToast(`Режим контекста: ${next}`);
      });
    }
    document.getElementById('assistant-btn-preview').addEventListener('click', () => {
      const s = LLMAssistant.getSettings();
      const payload = LLMAssistant.buildContextPayloadByMode(s.contextMode);
      const clipped = truncateForLLM(payload, { rowLimit: s.rowLimit, payloadLimitBytes: s.payloadLimitBytes });
      const bytes = JSON.stringify(clipped).length;
      const modal = document.getElementById('modal-kpi');
      document.getElementById('modal-kpi-title').textContent = `LLM payload preview (~${Math.round(bytes/1024)}KB)`;
      document.getElementById('modal-kpi-body').innerHTML = `<pre style="white-space:pre-wrap;word-break:break-word">${Utils.escapeHtml(JSON.stringify(clipped, null, 2))}</pre>`;
      modal.classList.remove('hidden');
    });
    document.getElementById('assistant-btn-insert-context').addEventListener('click', () => {
      const s = LLMAssistant.getSettings();
      const clipped = truncateForLLM(LLMAssistant.buildContextPayloadByMode(s.contextMode), { rowLimit: s.rowLimit, payloadLimitBytes: s.payloadLimitBytes });
      const txt = JSON.stringify(clipped, null, 2);
      input.value = input.value ? `${input.value}\n\n${txt}` : txt;
      input.dispatchEvent(new Event('input')); input.focus();
    });
    const quickWrap = document.getElementById('assistant-quick-prompts');
    if (quickWrap) {
      quickWrap.addEventListener('click', (e) => {
        const btn = e.target.closest('.assistant-quick-btn'); if (!btn) return;
        const prompt = btn.dataset.prompt || ''; if (!prompt) return;
        const contextOverride = btn.dataset.context || null;
        input.value = prompt; input.dispatchEvent(new Event('input')); input.focus();
        LLMAssistant.sendFromInput(contextOverride);
      });
    }
    // Quick prompts collapse toggle
    const quickToggle = document.getElementById('assistant-quick-toggle');
    const quickSection = document.getElementById('assistant-quick-wrap');
    const QUICK_COLLAPSED_KEY = 'q2_quick_prompts_collapsed';
    if (quickToggle && quickSection) {
      // Restore saved state
      if (localStorage.getItem(QUICK_COLLAPSED_KEY) === '1') {
        quickSection.classList.add('collapsed');
      }
      quickToggle.addEventListener('click', () => {
        const isNowCollapsed = quickSection.classList.toggle('collapsed');
        localStorage.setItem(QUICK_COLLAPSED_KEY, isNowCollapsed ? '1' : '0');
      });
    }
  },
  getQuickPrompts() {
    // Delegated to chatTemplates module
    return getQuickPrompts();
  },
  updateQuickPrompts() {
    const wrap = document.getElementById('assistant-quick-prompts'); if (!wrap) return;
    const prompts = LLMAssistant.getQuickPrompts();
    wrap.innerHTML = renderQuickPromptsHTML(prompts);
  },
  buildContextPayloadByMode(mode) {
    if (mode === 'none') return { contextDisabled: true };
    if (mode === 'summary') return buildSummaryContextPayload();
    if (mode === 'currentView') return buildVisibleContextPayload();
    if (mode === 'fullRegistry') return buildAppContextPayload();
    return buildCustomContextPayload();
  },
  renderMessages(streamingUpdate) {
    const wrap = document.getElementById('assistant-messages'); if (!wrap) return;
    if (!state.llm.history.length) {
      wrap.innerHTML = `<div class="assistant-msg assistant-msg-assistant">Готов помочь с анализом данных.<br>Выберите типовой вопрос выше или задайте свой.</div>`;
      return;
    }
    // Fast streaming update — patch only last message
    if (streamingUpdate) {
      const lastMsg = state.llm.history[state.llm.history.length - 1];
      const msgEls = wrap.querySelectorAll('.assistant-msg');
      const lastEl = msgEls[msgEls.length - 1];
      if (lastEl && lastMsg && msgEls.length === state.llm.history.length) {
        lastEl.classList.toggle('assistant-msg-streaming', !!lastMsg.streaming);
        const bodyEl = lastEl.querySelector('.msg-body');
        if (bodyEl) {
          if (lastMsg.thinking) {
            bodyEl.innerHTML = '<span class="msg-thinking"><span></span><span></span><span></span></span>';
          } else {
            // Parse partial structured content during streaming
            const partial = parseLLMResponse(lastMsg.content || '');
            const tmpHtml = renderStructuredResponse({ ...partial, streaming: true }, -1, true);
            bodyEl.innerHTML = tmpHtml.match(/<div class="msg-body">([\s\S]*)<\/div>\s*<\/div>/)?.[1] || '';
          }
        }
        wrap.scrollTop = wrap.scrollHeight;
        return;
      }
    }
    // Full re-render
    wrap.innerHTML = state.llm.history.map((msg, idx) => {
      if (msg.role === 'user') return renderUserMessage(msg, idx);
      if (msg.thinking) return renderThinking(idx);
      if (msg.isError) return renderError(msg, idx, !!state.llm.lastUserText);
      // Assistant message — may have structured content
      const structured = msg.structured || parseLLMResponse(msg.content || '');
      return renderStructuredResponse(structured, idx, !!msg.streaming);
    }).join('');
    wrap.scrollTop = wrap.scrollHeight;
  },
  setError(message) {
    const el = document.getElementById('assistant-error'); if (!el) return;
    if (!message) { el.classList.add('hidden'); el.textContent = ''; return; }
    el.textContent = message; el.classList.remove('hidden');
  },
  clearConversation() {
    if (state.llm.isStreaming) return;
    state.llm.history = []; state.llm.apiHistory = []; state.llm.lastUserText = '';
    localStorage.removeItem(LLMAssistant.CONV_KEY);
    LLMAssistant.renderMessages(); LLMAssistant.setPayloadStatus('');
  },
  setPayloadStatus(text) {
    const el = document.getElementById('assistant-payload-status');
    if (el) { el.textContent = text; el.classList.toggle('hidden', !text); }
  },
  async sendFromInput(contextOverride) {
    const input   = document.getElementById('assistant-input');
    const sendBtn = document.getElementById('assistant-btn-send');
    const stopBtn = document.getElementById('assistant-btn-stop');
    const text    = String(input.value || '').trim();
    if (!text || state.llm.isStreaming) return;
    LLMAssistant.setError(''); LLMAssistant.setPayloadStatus('');
    state.llm.lastUserText = text;
    state.llm.history.push({ role: 'user', content: text });
    const assistantMsg = { role: 'assistant', content: '', streaming: true, thinking: true, structured: null };
    state.llm.history.push(assistantMsg);
    input.value = ''; input.style.height = 'auto';
    state.llm.isStreaming = true; sendBtn.disabled = true; stopBtn.classList.remove('hidden');
    LLMAssistant.renderMessages();
    const abortController = new AbortController();
    state.llm.abortController = abortController;

    // ── Step 1: run chat engine intent detection ──────────────
    let handled = false;
    chatProcess(text, {
      onRuleBased: ({ structured }) => {
        handled = true;
        assistantMsg.thinking = false;
        assistantMsg.streaming = false;
        assistantMsg.structured = structured;
        assistantMsg.content = structured.text || '';
        state.llm.apiHistory.push({ role: 'user', content: text });
        state.llm.apiHistory.push({ role: 'assistant', content: assistantMsg.content });
        LLMAssistant.saveConversation();
        state.llm.isStreaming = false;
        sendBtn.disabled = false; stopBtn.classList.add('hidden');
        LLMAssistant.renderMessages();
        LLMAssistant.setPayloadStatus('rule-based · мгновенно');
        // Auto-execute confirm_batch if flagged
        const autoAction = (structured.actions || []).find(a => a.autoExecute);
        if (autoAction) {
          try { executeAction(autoAction.type, autoAction.payload || {}); } catch(_) {}
          LLMAssistant.renderMessages();
        }
      },
      onLLMPrompt: async ({ llmPrompt }) => {
        // LLM path — build messages with structured prompt
        try {
          const messages = buildApiCallMessages(llmPrompt, contextOverride || null);
          const sentUserContent = messages[messages.length - 1].content;
          const payloadBytes = JSON.stringify(messages).length;
          LLMAssistant.setPayloadStatus(`payload: ~${Math.round(payloadBytes / 1024)}KB`);
          await callGigaChatStream(messages, LLMAssistant.getSettings(), (delta) => {
            if (assistantMsg.thinking) assistantMsg.thinking = false;
            assistantMsg.content += delta;
            LLMAssistant.renderMessages(true);
          }, abortController.signal);
          assistantMsg.streaming = false; assistantMsg.thinking = false;
          if (!assistantMsg.content.trim()) {
            console.warn('[LLM] ⚠ assistantMsg.content is empty after stream. Settings snapshot:', {
              apiMode: LLMAssistant.getSettings().apiMode,
              apiBaseUrl: LLMAssistant.getSettings().apiBaseUrl,
              model: LLMAssistant.getSettings().model,
              tokenPresent: !!LLMAssistant.getToken(),
              messagesCount: messages.length,
            });
            assistantMsg.content = 'Ответ пустой. Проверь модель/токен и режим контекста.';
          } else {
            // Parse structured JSON block from LLM response
            assistantMsg.structured = parseLLMResponse(assistantMsg.content);
            state.llm.apiHistory.push({ role: 'user', content: sentUserContent });
            state.llm.apiHistory.push({ role: 'assistant', content: assistantMsg.content });
            LLMAssistant.saveConversation();
          }
        } catch (err) {
          assistantMsg.streaming = false; assistantMsg.thinking = false;
          if (err && err.name === 'AbortError') { assistantMsg.content = assistantMsg.content || 'Генерация остановлена.'; }
          else {
            assistantMsg.isError = true; assistantMsg.content = assistantMsg.content || 'Не удалось получить ответ от LLM.';
            const errStr = String(err?.message || err || 'Ошибка LLM');
            const hint = errStr.includes('token') || errStr.includes('401') ? ' — проверь API-токен в настройках ⚙'
              : (errStr.includes('fetch') || errStr.includes('network') || errStr.includes('Failed')) ? ' — сервер недоступен, проверь URL и запущен ли node server.js' : '';
            LLMAssistant.setError(errStr + hint);
          }
        } finally {
          state.llm.isStreaming = false; state.llm.abortController = null;
          sendBtn.disabled = false; stopBtn.classList.add('hidden');
          LLMAssistant.renderMessages();
        }
      },
    });

    // chatProcess is sync for rule-based; for LLM path onLLMPrompt is async —
    // the `handled` flag lets us know if we need to handle final state.
    if (!handled) {
      // onLLMPrompt took over — nothing more to do here synchronously
    }
  },
  stopGeneration() { if (state.llm.abortController) state.llm.abortController.abort(); },
};


// ============================================================
// NAV
// ============================================================
const Nav = {
  init() {
    document.querySelectorAll('.nav-item[data-section]').forEach(btn=>{
      btn.addEventListener('click',()=>Nav.goTo(btn.dataset.section));
    });
  },
  goTo(section) {
    state.activeSection=section;
    document.querySelectorAll('.nav-item').forEach(b=>b.classList.remove('active'));
    const ab=document.querySelector(`.nav-item[data-section="${section}"]`); if(ab)ab.classList.add('active');
    document.querySelectorAll('.app-section').forEach(s=>s.classList.add('hidden'));
    const el=document.getElementById(`section-${section}`);
    if(el){
      el.classList.remove('hidden'); el.classList.remove('section-enter');
      void el.offsetWidth; el.classList.add('section-enter');
      clearTimeout(Nav._sectionAnimT);
      Nav._sectionAnimT=setTimeout(()=>el.classList.remove('section-enter'),280);
    }
    App.renderSection(section);
  },
};

// ============================================================
// APP SETTINGS
// ============================================================
const NAV_SECTIONS = [
  { key:'dashboard',   label:'Дашборд' },   { key:'registry',    label:'Реестр' },
  { key:'gantt',       label:'Гант' },        { key:'gantt2',      label:'Гант 2.0' },
  { key:'kanban',      label:'Канбан' },      { key:'timeline',    label:'Таймлайн' },
  { key:'podlozhka',   label:'Подложка' },    { key:'employees',   label:'Сотрудники' },
  { key:'summary',     label:'Сводная' },     { key:'metrics',     label:'Метрики' },
  { key:'insights',    label:'Инсайты' },     { key:'diagnostics', label:'Диагностика' },
  { key:'jira-pulse',  label:'Jira Pulse' },  { key:'actions',     label:'Action Layer' },
];
const APP_SETTINGS_KEY = 'sbof_app_settings_v1';

const AppSettings = {
  defaults() { return { hiddenSections: [] }; },
  load() { try { return { ...AppSettings.defaults(), ...JSON.parse(localStorage.getItem(APP_SETTINGS_KEY) || '{}') }; } catch(_) { return AppSettings.defaults(); } },
  save(cfg) { localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(cfg)); },
  apply(cfg) {
    NAV_SECTIONS.forEach(s => {
      const hidden = cfg.hiddenSections.includes(s.key);
      const navBtn = document.querySelector(`.nav-item[data-section="${s.key}"]`);
      if (navBtn) navBtn.classList.toggle('nav-item-hidden', hidden);
    });
  },
  init() {
    const cfg = AppSettings.load(); AppSettings.apply(cfg);
    const openBtn = document.getElementById('btn-app-settings');
    const modal   = document.getElementById('app-settings-modal');
    const closeBtn = document.getElementById('app-settings-close');
    const saveBtn  = document.getElementById('app-settings-save');
    const resetBtn = document.getElementById('app-settings-reset');
    const togglesWrap = document.getElementById('app-settings-nav-toggles');
    if (!openBtn || !modal) return;
    openBtn.addEventListener('click', () => {
      AppSettings.renderToggles(togglesWrap, AppSettings.load());
      modal.querySelectorAll('.app-settings-tab').forEach((t,i) => t.classList.toggle('active', i===0));
      modal.querySelectorAll('.app-settings-tab-content').forEach((c,i) => c.classList.toggle('hidden', i!==0));
      modal.classList.remove('hidden');
    });
    modal.querySelectorAll('.app-settings-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        modal.querySelectorAll('.app-settings-tab').forEach(t => t.classList.remove('active'));
        modal.querySelectorAll('.app-settings-tab-content').forEach(c => c.classList.add('hidden'));
        tab.classList.add('active');
        modal.querySelector(`.app-settings-tab-content[data-tab-content="${tab.dataset.tab}"]`)?.classList.remove('hidden');
      });
    });
    document.getElementById('app-settings-open-llm')?.addEventListener('click', () => { closeModal(modal); document.getElementById('llm-settings-modal')?.classList.remove('hidden'); });
    document.getElementById('app-settings-open-jira')?.addEventListener('click', () => { closeModal(modal); document.getElementById('jp-settings-modal')?.classList.remove('hidden'); });
    closeBtn?.addEventListener('click', () => closeModal(modal));
    modal.addEventListener('click', e => { if (e.target === modal) closeModal(modal); });
    saveBtn?.addEventListener('click', () => {
      const hidden = [];
      togglesWrap.querySelectorAll('input[type=checkbox]').forEach(cb => { if (!cb.checked) hidden.push(cb.dataset.section); });
      const newCfg = { hiddenSections: hidden };
      AppSettings.save(newCfg); AppSettings.apply(newCfg); closeModal(modal); showToast('Настройки сохранены');
    });
    resetBtn?.addEventListener('click', () => {
      localStorage.removeItem(APP_SETTINGS_KEY); AppSettings.apply(AppSettings.defaults());
      AppSettings.renderToggles(togglesWrap, AppSettings.defaults()); showToast('Настройки сброшены');
    });
  },
  renderToggles(wrap, cfg) {
    if (!wrap) return;
    wrap.innerHTML = NAV_SECTIONS.map(s => `<label class="app-settings-toggle-row"><input type="checkbox" data-section="${s.key}" ${cfg.hiddenSections.includes(s.key) ? '' : 'checked'}><span>${s.label}</span></label>`).join('');
  },
};

// ============================================================
// ONBOARDING
// ============================================================
const Onboarding = {
  _step: 0,
  _steps: [
    { section:null,        navKey:null,         selector:'#topbar',                                 title:'1. Шапка',                     text:'Кнопка «Сохранить» пересчитывает риски и сохраняет данные в браузере. Кнопка «Файлы» — импорт XLSX/CSV и экспорт. ⚡ — режим симуляции (без сохранения). ⚙ — настройки.' },
    { section:null,        navKey:null,         selector:'#btn-toggle-filters',                     title:'2. Фильтры',                   text:'Нажмите кнопку «Фильтры» чтобы показать панель фильтров. Фильтруйте по команде, scope, релизу, исполнителю. Пресеты — готовые наборы фильтров.' },
    { section:'dashboard', navKey:'dashboard',  selector:'#dashboard-kpi',                          title:'3. Дашборд — KPI',             text:'KPI-карточки показывают общую статистику: задач в работе, блокеры, риски, процент выполнения. Кликните на карточку для подробностей.' },
    { section:'dashboard', navKey:'dashboard',  selector:'#risks-panel',                            title:'4. Дашборд — Риски',           text:'Панель рисков автоматически выделяет проблемные задачи: без релиза, с подтверждением в релизе, блокеры. Обновляется при каждом сохранении.' },
    { section:'registry',  navKey:'registry',   selector:'#registry-table',                         title:'5. Реестр — таблица',          text:'Таблица всех задач. Кликните ячейку для редактирования. Правый клик по строке — контекстное меню (копировать/удалить). Столбцы можно перетаскивать, закреплять, скрывать.' },
    { section:'registry',  navKey:'registry',   selector:'#section-registry .section-header-actions', title:'6. Реестр — инструменты',   text:'«+ Строка» — добавить строку после выбранной. «Столбцы» — скрыть/показать колонки. ⚙ Настройки — закрепить, переименовать, добавить столбцы. ⛶ — полный экран.' },
    { section:'gantt',     navKey:'gantt',      selector:'.btn-group',                              title:'7. Гант — режимы',             text:'«Детальный по задачам» — строки с типами работ, drag-and-drop между колодцами релизов. «Со стрелками» — расширенный вид с зависимостями между эпиками.' },
    { section:'gantt',     navKey:'gantt',      selector:'#gantt-wrap',                             title:'8. Гант — детали',             text:'Перетаскивайте задачи между колодцами релизов. Нажмите ▾ рядом с командой чтобы свернуть её строки. ⚠ рядом с задачей — исполнитель не назначен.' },
    { section:'kanban',    navKey:'kanban',     selector:'#kanban-board',                           title:'9. Канбан',                    text:'Карточки задач по релизам. Перетащите карточку для смены релиза. Цветная левая полоса: красная — блокер, оранжевая — риск, жёлтая — изменено.' },
    { section:'timeline',  navKey:'timeline',   selector:'#timeline-wrap',                          title:'10. Таймлайн',                 text:'Диаграммы распределения задач по стадиям: количество, типы работ, статусы scope. Два режима: Сводный и Детальный.' },
    { section:'insights',  navKey:'insights',   selector:'#insights-wrap',                          title:'11. Инсайты',                  text:'Автоматический анализ: задачи без релиза, перегруженные релизы, сигналы блокировки. Каждый сигнал ссылается на конкретные задачи.' },
    { section:'jira-pulse',navKey:'jira-pulse', selector:'#section-jira-pulse',                     title:'12. Jira Pulse',               text:'Мониторинг Jira-спринтов в реальном времени. Настройте подключение через ⚙ Настройки → «Jira Pulse». Показывает команды, метрики, инсайты, бэклог.' },
    { section:'dashboard', navKey:null,         selector:'#assistant-fab',                          title:'13. AI-помощник',              text:'Кнопка в правом нижнем углу открывает СБОФ AI-помощника. Задавайте вопросы о данных на русском: «Какие задачи без релиза?», «Что в зоне риска?».' },
  ],
  init() {
    // btn-onboarding is now owned by V11 onboarding (shows welcome screen)
    document.getElementById('onboarding-next')?.addEventListener('click', () => Onboarding.next());
    document.getElementById('onboarding-prev')?.addEventListener('click', () => Onboarding.prev());
    document.getElementById('onboarding-skip')?.addEventListener('click', () => Onboarding.end());
    document.querySelector('.onboarding-backdrop')?.addEventListener('click', () => Onboarding.end());
  },
  start() { Onboarding._step = 0; document.getElementById('onboarding-overlay')?.classList.remove('hidden'); Onboarding.show(0); },
  show(idx) {
    const steps = Onboarding._steps;
    if (idx < 0 || idx >= steps.length) { Onboarding.end(); return; }
    Onboarding._step = idx;
    const step = steps[idx];
    document.getElementById('onboarding-title').textContent = step.title;
    document.getElementById('onboarding-text').textContent  = step.text;
    document.getElementById('onboarding-step-badge').textContent = `${idx + 1} / ${steps.length}`;
    document.getElementById('onboarding-prev').disabled = idx === 0;
    document.getElementById('onboarding-next').textContent = idx === steps.length - 1 ? 'Завершить' : 'Далее →';
    const doHighlight = () => {
      const target = document.querySelector(step.selector); if (!target) return;
      target.scrollIntoView({ block: 'center', behavior: 'instant' });
      requestAnimationFrame(() => requestAnimationFrame(() => { Onboarding._positionHighlight(target); }));
    };
    if (step.section) { Nav.goTo(step.section); setTimeout(doHighlight, 60); } else doHighlight();
  },
  _positionHighlight(target) {
    const highlight = document.getElementById('onboarding-highlight');
    const tooltip   = document.getElementById('onboarding-tooltip');
    if (!highlight || !tooltip) return;
    const r = target.getBoundingClientRect(); const pad = 8;
    const hl = { left: r.left-pad, top: r.top-pad, width: r.width+pad*2, height: r.height+pad*2 };
    highlight.style.left = `${hl.left}px`; highlight.style.top = `${hl.top}px`;
    highlight.style.width = `${hl.width}px`; highlight.style.height = `${hl.height}px`;
    const tipW=320, tipH=200, gap=14;
    let tipTop = hl.top + hl.height + gap;
    if (tipTop + tipH > window.innerHeight - 12) tipTop = hl.top - tipH - gap;
    tipTop = Math.max(12, tipTop);
    const tipLeft = Math.max(12, Math.min(hl.left, window.innerWidth - tipW - 12));
    tooltip.style.left = `${tipLeft}px`; tooltip.style.top = `${tipTop}px`;
  },
  next() { if (Onboarding._step >= Onboarding._steps.length - 1) { Onboarding.end(); return; } Onboarding.show(Onboarding._step + 1); },
  prev() { Onboarding.show(Onboarding._step - 1); },
  end() {
    document.getElementById('onboarding-overlay')?.classList.add('hidden');
    const hl = document.getElementById('onboarding-highlight');
    if (hl) { hl.style.left=''; hl.style.top=''; hl.style.width=''; hl.style.height=''; }
  },
};


// ============================================================
// ACTION LAYER
// ============================================================
const ActionLayer = {
  _activeCat: 'all',

  CATALOG: [
    { id:'assign_release',      cat:'releases', icon:'🗓', name:'Назначить в релиз',       desc:'Привязать задачи к выбранному релизу с типами работ.',    params:[{key:'release',label:'Релиз',type:'select',opts:['120','121','122','ot']},{key:'types',label:'Типы работ',type:'multicheck',opts:['backend','frontend','тестирование','аналитика','бизнес аналитика','внедрение','миграция данных','стабилизация','хотфикс']}] },
    { id:'clear_release',       cat:'releases', icon:'🚫', name:'Снять все релизы',        desc:'Удалить привязку ко всем релизам у выбранных задач.',     params:[] },
    { id:'set_release_type',    cat:'releases', icon:'🔧', name:'Изменить типы работ',     desc:'Переназначить типы работ в конкретном релизе без смены самого релиза.', params:[{key:'release',label:'Релиз',type:'select',opts:['120','121','122','ot']},{key:'types',label:'Новые типы',type:'multicheck',opts:['backend','frontend','тестирование','аналитика','бизнес аналитика','внедрение','миграция данных','стабилизация','хотфикс']}] },
    { id:'auto_assign_release', cat:'releases', icon:'🤖', name:'Авто-распределение',      desc:'Назначить в релиз все задачи без релиза (или все, если overwrite).', params:[{key:'release',label:'Релиз',type:'select',opts:['120','121','122','ot']},{key:'overwrite',label:'Перезаписать существующие',type:'checkbox'}], mass:true },
    { id:'set_scope',           cat:'scope',    icon:'📋', name:'Изменить статус объёма',  desc:'Установить "Да", "Нет" или "Требует подтверждения" у выбранных задач.', params:[{key:'scope',label:'Статус',type:'select',opts:['Да','Нет','Требует подтверждения']}] },
    { id:'mark_done',           cat:'scope',    icon:'✅', name:'Отметить готовыми',       desc:'Поставить флаг "Готово" и зафиксировать дату закрытия.', params:[] },
    { id:'unmark_done',         cat:'scope',    icon:'↩️', name:'Открыть задачи',          desc:'Снять флаг "Готово" с выбранных задач.',                  params:[] },
    { id:'set_done_date',       cat:'scope',    icon:'📅', name:'Задать дату закрытия',    desc:'Вручную установить дату закрытия без изменения статуса.', params:[{key:'date',label:'Дата',type:'date'}] },
    { id:'set_assignee',        cat:'team',     icon:'👤', name:'Назначить исполнителя',   desc:'Переназначить исполнителя у всех выбранных задач.',       params:[{key:'assignee',label:'Исполнитель',type:'assignee'}] },
    { id:'normalize_assignees', cat:'team',     icon:'🔡', name:'Нормализовать имена',     desc:'Привести имена исполнителей к единому регистру (убрать лишние пробелы).', params:[], mass:true },
    { id:'set_priority',        cat:'priority', icon:'⚡', name:'Установить приоритет',    desc:'Назначить приоритет High / Medium / Low у выбранных задач.', params:[{key:'priority',label:'Приоритет',type:'select',opts:['high','medium','low']}] },
    { id:'set_business_value',  cat:'priority', icon:'💎', name:'Задать бизнес-ценность',  desc:'Установить числовой показатель ценности (0–100) для приоритизации.', params:[{key:'value',label:'Ценность (0–100)',type:'number',min:0,max:100}] },
    { id:'clear_blocker',       cat:'risks',    icon:'🛡', name:'Снять блокер',            desc:'Убрать флаг blockingDependency и дату блокирующего дедлайна.', params:[] },
    { id:'add_risk_flag',       cat:'risks',    icon:'🚩', name:'Добавить флаг риска',     desc:'Вручную добавить специфический флаг риска к задачам.',   params:[{key:'flag',label:'Тип риска',type:'select',opts:['IN_SCOPE_WITHOUT_RELEASE','CONFIRMATION_IN_RELEASE','OVERDUE_DEADLINE','CUSTOM_RISK']}] },
    { id:'remove_risk_flags',   cat:'risks',    icon:'🧹', name:'Снять флаги риска',       desc:'Удалить все или конкретный флаг риска у выбранных задач.', params:[{key:'flag',label:'Флаг (пусто = все)',type:'select',opts:['','IN_SCOPE_WITHOUT_RELEASE','CONFIRMATION_IN_RELEASE','OVERDUE_DEADLINE','CUSTOM_RISK']}] },
    { id:'batch_risk_recompute',cat:'risks',    icon:'🔄', name:'Пересчитать риск-скоры',  desc:'Принудительно пересчитать Risk Score для всех задач в реестре.', params:[], mass:true },
    { id:'set_comment',         cat:'markup',   icon:'💬', name:'Добавить заметку',        desc:'Дописать или заменить текстовую заметку у выбранных задач.', params:[{key:'comment',label:'Заметка',type:'textarea'},{key:'append',label:'Добавить (не заменять)',type:'checkbox'}] },
    { id:'flag_review',         cat:'markup',   icon:'🔍', name:'Отметить для ревью',      desc:'Поставить маркер "требует ревью" с опциональной заметкой.', params:[{key:'note',label:'Причина (опционально)',type:'text'}] },
    { id:'unflag_review',       cat:'markup',   icon:'✔️', name:'Снять метку ревью',       desc:'Убрать флаг "требует ревью" с выбранных задач.',          params:[] },
    { id:'reset_row',           cat:'markup',   icon:'♻️', name:'Сбросить к базовому',     desc:'Снять блокеры, флаги риска, ревью и выставить приоритет Medium.', params:[] },
    { id:'export_selected_csv', cat:'export',   icon:'📤', name:'Экспорт в CSV',           desc:'Скачать выбранные (или все отфильтрованные) задачи в CSV-файл.', params:[], mass:true },
  ],

  CAT_LABELS: { all:'Все', releases:'Релизы', scope:'Объём', team:'Команда', priority:'Приоритет', risks:'Риски', markup:'Разметка', export:'Экспорт' },
  CAT_ICONS:  { all:'🎯', releases:'🗓', scope:'📋', team:'👥', priority:'⚡', risks:'🛡', markup:'🏷', export:'📤' },

  _resolveScope(scopeType, criteriaKey, criteriaVal) {
    switch (scopeType) {
      case 'all':      return state.rows.map(r=>r.id);
      case 'filtered': return getFilteredRows().map(r=>r.id);
      case 'selected': return [...state.bulkSelected];
      case 'criteria': return ActionLayer._byCriteria(criteriaKey, criteriaVal);
      default:         return [];
    }
  },
  _byCriteria(key, val) {
    if (!key || val === '') return [];
    return state.rows.filter(r => {
      if (key === 'release') return (r.release120Types?.length&&val==='120')||(r.release121Types?.length&&val==='121')||(r.release122Types?.length&&val==='122')||(r.overtimeTypes?.length&&val==='ot');
      if (key === 'assignee') return (r.assignee||'').toLowerCase().includes(val.toLowerCase());
      if (key === 'scope')    return r.scopeStatus === val;
      if (key === 'priority') return r.priority === val;
      if (key === 'no_release') return !r.release120Types?.length && !r.release121Types?.length && !r.release122Types?.length && !r.overtimeTypes?.length;
      if (key === 'blockers')   return !!r.blockingDependency;
      if (key === 'risky')      return (r.riskScore||0) >= 30;
      if (key === 'review_flag')return !!r._reviewFlag;
      return false;
    }).map(r=>r.id);
  },
  _scopeCount(scopeType, criteriaKey, criteriaVal) { return ActionLayer._resolveScope(scopeType, criteriaKey, criteriaVal).length; },

  runAction(actionDef, scopeType, criteriaKey, criteriaVal, params) {
    const ids = ActionLayer._resolveScope(scopeType, criteriaKey, criteriaVal);
    if (actionDef.id === 'auto_assign_release') {
      const n = autoAssignRelease(params.release, !!params.overwrite);
      state.actionLog.unshift({ id:Date.now(), type:actionDef.id, label:actionDef.name, count:n, at:new Date().toISOString(), simMode:state.simMode });
      if (state.actionLog.length > 200) state.actionLog.length = 200;
      ActionLayer.renderLog(); App.refreshCurrentSection(); return;
    }
    if (actionDef.id === 'normalize_assignees') {
      const n = normalizeAssignees();
      state.actionLog.unshift({ id:Date.now(), type:actionDef.id, label:actionDef.name, count:n, at:new Date().toISOString(), simMode:state.simMode });
      if (state.actionLog.length > 200) state.actionLog.length = 200;
      ActionLayer.renderLog(); App.refreshCurrentSection(); return;
    }
    if (actionDef.id === 'batch_risk_recompute') {
      const n = batchRiskRecompute();
      state.actionLog.unshift({ id:Date.now(), type:actionDef.id, label:actionDef.name, count:n, at:new Date().toISOString(), simMode:state.simMode });
      if (state.actionLog.length > 200) state.actionLog.length = 200;
      ActionLayer.renderLog(); App.refreshCurrentSection(); return;
    }
    if (actionDef.id === 'export_selected_csv') {
      const n = exportSelectedCSV(ids);
      state.actionLog.unshift({ id:Date.now(), type:actionDef.id, label:actionDef.name, count:n, at:new Date().toISOString(), simMode:false });
      if (state.actionLog.length > 200) state.actionLog.length = 200;
      ActionLayer.renderLog(); return;
    }
    if (!ids.length) { showToast('Нет задач в выбранной области.', 'warn'); return; }
    applyBulkAction(ids, actionDef.id, { ...params, _label: actionDef.name });
  },

  render() {
    const el = document.getElementById('al-main'); if (!el) return;
    el.innerHTML = ActionLayer._renderCatalog() + ActionLayer._renderLogPanel();
    ActionLayer._bindCatalog();
  },
  _catFilter() {
    const cats = Object.keys(ActionLayer.CAT_LABELS);
    return `<div class="al-cat-bar">${cats.map(c=>`<button class="al-cat-btn${ActionLayer._activeCat===c?' active':''}" data-cat="${c}">${ActionLayer.CAT_ICONS[c]} ${ActionLayer.CAT_LABELS[c]}</button>`).join('')}</div>`;
  },
  _renderCatalog() {
    const cat = ActionLayer._activeCat;
    const items = cat==='all' ? ActionLayer.CATALOG : ActionLayer.CATALOG.filter(a=>a.cat===cat);
    const cards = items.map(a=>`<div class="al-action-card" data-action="${a.id}"><div class="al-action-icon">${a.icon}</div><div class="al-action-body"><div class="al-action-name">${a.name}</div><div class="al-action-desc">${a.desc}</div><div class="al-action-meta"><span class="al-cat-badge">${ActionLayer.CAT_ICONS[a.cat]} ${ActionLayer.CAT_LABELS[a.cat]}</span>${a.mass?'<span class="al-mass-badge">массовая</span>':''}</div></div><button class="btn btn-sm btn-primary al-run-btn" data-action="${a.id}">Запустить →</button></div>`).join('');
    return `<div class="al-catalog-wrap"><div class="al-catalog-header"><h3 class="al-section-title">Каталог действий</h3>${ActionLayer._catFilter()}</div><div class="al-catalog-grid">${cards}</div></div>`;
  },
  _renderLogPanel() { return `<div class="al-log-wrap"><h3 class="al-section-title">Журнал действий</h3><div id="al-log-list">${ActionLayer._logHTML()}</div></div>`; },
  _logHTML() {
    if (!state.actionLog.length) return '<div class="al-log-empty">Действия ещё не применялись.</div>';
    return state.actionLog.slice(0,50).map(e=>{
      const dt = new Date(e.at).toLocaleString('ru',{hour:'2-digit',minute:'2-digit',day:'2-digit',month:'short'});
      return `<div class="al-log-entry${e.simMode?' al-log-sim':''}"><div class="al-log-meta"><span class="al-log-type">${e.label}</span><span class="al-log-count">${e.count} задач</span></div><div class="al-log-time">${dt}${e.simMode?' · симуляция':''}</div></div>`;
    }).join('');
  },
  renderLog() { const el = document.getElementById('al-log-list'); if (el) el.innerHTML = ActionLayer._logHTML(); },
  _bindCatalog() {
    const wrap = document.getElementById('al-main'); if (!wrap) return;
    wrap.querySelectorAll('.al-cat-btn').forEach(btn=>btn.addEventListener('click',()=>{ ActionLayer._activeCat=btn.dataset.cat; ActionLayer.render(); }));
    wrap.querySelectorAll('.al-run-btn').forEach(btn=>btn.addEventListener('click',e=>{ e.stopPropagation(); const actionDef=ActionLayer.CATALOG.find(a=>a.id===btn.dataset.action); if(actionDef)ActionLayer.openModal(actionDef); }));
    wrap.querySelectorAll('.al-action-card').forEach(card=>card.addEventListener('click',e=>{ if(e.target.closest('.al-run-btn'))return; const actionDef=ActionLayer.CATALOG.find(a=>a.id===card.dataset.action); if(actionDef)ActionLayer.openModal(actionDef); }));
  },
  openModal(actionDef) {
    const modal = document.getElementById('al-modal'); if (!modal) return;
    document.getElementById('al-modal-title').textContent = actionDef.icon + ' ' + actionDef.name;
    document.getElementById('al-modal-desc').textContent = actionDef.desc;
    document.getElementById('al-modal-params').innerHTML = ActionLayer._renderParams(actionDef);
    ActionLayer._bindScopeCounter(actionDef);
    modal.classList.remove('hidden');
    document.getElementById('al-modal-apply').onclick = () => ActionLayer._applyModal(actionDef);
    document.getElementById('al-modal-cancel').onclick = () => modal.classList.add('hidden');
    modal.onclick = e => { if (e.target === modal) modal.classList.add('hidden'); };
  },
  _renderParams(actionDef) {
    const scope = `<div class="al-param-row"><label class="al-param-label">Область применения</label><select id="al-scope-type" class="al-param-select"><option value="all">Все задачи (${state.rows.length})</option><option value="filtered">Отфильтрованные (${getFilteredRows().length})</option><option value="selected">Выбранные в реестре (${state.bulkSelected.size})</option><option value="criteria">По критерию →</option></select></div>
    <div id="al-criteria-row" class="al-param-row al-criteria-row hidden"><label class="al-param-label">Критерий</label><div style="display:flex;gap:6px;align-items:center"><select id="al-criteria-key" class="al-param-select"><option value="no_release">Без релиза</option><option value="blockers">Блокеры</option><option value="risky">Рискованные (score≥30)</option><option value="review_flag">Отмечены для ревью</option><option value="release">Релиз =</option><option value="scope">Статус объёма =</option><option value="priority">Приоритет =</option><option value="assignee">Исполнитель содержит</option></select><input id="al-criteria-val" class="al-param-input" style="width:120px" placeholder="значение"></div></div>
    <div class="al-param-row"><span class="al-scope-preview" id="al-scope-preview">→ задач: —</span></div>`;
    const paramFields = actionDef.params.map(p => {
      if (p.type==='select') return `<div class="al-param-row"><label class="al-param-label">${p.label}</label><select class="al-param-select" name="${p.key}">${p.opts.map(o=>`<option value="${o}">${o}</option>`).join('')}</select></div>`;
      if (p.type==='multicheck') return `<div class="al-param-row"><label class="al-param-label">${p.label}</label><div class="al-multicheck">${p.opts.map(o=>`<label class="al-check-item"><input type="checkbox" name="${p.key}" value="${o}" checked> ${o}</label>`).join('')}</div></div>`;
      if (p.type==='checkbox') return `<div class="al-param-row"><label class="al-param-label">${p.label}</label><input type="checkbox" name="${p.key}" style="width:16px;height:16px;cursor:pointer"></div>`;
      if (p.type==='textarea') return `<div class="al-param-row"><label class="al-param-label">${p.label}</label><textarea class="al-param-textarea" name="${p.key}" rows="3" placeholder="${p.label}"></textarea></div>`;
      if (p.type==='assignee') { const names=[...new Set(state.rows.map(r=>r.assignee).filter(Boolean))].sort(); return `<div class="al-param-row"><label class="al-param-label">${p.label}</label><input class="al-param-input" list="al-assignee-list" name="${p.key}" placeholder="Введите имя"><datalist id="al-assignee-list">${names.map(n=>`<option value="${n}">`).join('')}</datalist></div>`; }
      return `<div class="al-param-row"><label class="al-param-label">${p.label}</label><input class="al-param-input" type="${p.type||'text'}" name="${p.key}" placeholder="${p.label}"${p.min!=null?` min="${p.min}"`:''}${p.max!=null?` max="${p.max}"`:''}></div>`;
    }).join('');
    return scope + paramFields;
  },
  _bindScopeCounter(actionDef) {
    const upd = () => {
      const st=document.getElementById('al-scope-type')?.value||'all';
      const ck=document.getElementById('al-criteria-key')?.value||'';
      const cv=document.getElementById('al-criteria-val')?.value||'';
      const n=ActionLayer._scopeCount(st,ck,cv);
      const el=document.getElementById('al-scope-preview'); if(el)el.textContent=`→ задач: ${n}`;
      const crit=document.getElementById('al-criteria-row'); if(crit)crit.classList.toggle('hidden',st!=='criteria');
    };
    setTimeout(()=>{ document.getElementById('al-scope-type')?.addEventListener('change',upd); document.getElementById('al-criteria-key')?.addEventListener('change',upd); document.getElementById('al-criteria-val')?.addEventListener('input',upd); upd(); },0);
  },
  _applyModal(actionDef) {
    const modal=document.getElementById('al-modal');
    const st=document.getElementById('al-scope-type')?.value||'all';
    const ck=document.getElementById('al-criteria-key')?.value||'';
    const cv=document.getElementById('al-criteria-val')?.value||'';
    const params={};
    modal.querySelectorAll('[name]').forEach(el=>{
      if(el.type==='checkbox'){params[el.name]=el.checked;return;}
      params[el.name]=el.value;
    });
    actionDef.params.filter(p=>p.type==='multicheck').forEach(p=>{
      params[p.key]=[...modal.querySelectorAll(`input[name="${p.key}"]:checked`)].map(e=>e.value);
    });
    modal.classList.add('hidden');
    ActionLayer.runAction(actionDef,st,ck,cv,params);
  },
  init() {
    const close=()=>document.getElementById('al-modal')?.classList.add('hidden');
    document.getElementById('al-modal-cancel')?.addEventListener('click',close);
    document.getElementById('al-modal-cancel2')?.addEventListener('click',close);
  },
};


// ============================================================
// JIRA PULSE
// ============================================================
const JiraPulse = {
  _report:null, _config:null, _loading:false, _activeTab:'people',
  _activeArea:'__all__', _sprintArea:null, _backlogTab:'summary', _backlogArea:'__all__',

  _esc(s){if(s==null)return'';return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));},
  _fmtDt(iso){if(!iso)return'';return new Date(iso).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});},
  _fmtDate(iso){if(!iso)return'';return new Date(iso).toLocaleDateString('ru-RU',{day:'2-digit',month:'2-digit'});},
  _fmtTime(iso){if(!iso)return'';return new Date(iso).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});},
  _daysSince(iso){if(!iso)return null;return Math.floor((Date.now()-new Date(iso).getTime())/86400000);},
  _hrs(sec){if(!sec)return'';const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60);return h&&m?`${h}ч ${m}м`:h?`${h}ч`:`${m}м`;},
  _inRange(iso,range){if(!iso||!range)return false;const t=new Date(iso).getTime();return t>=new Date(range.from).getTime()&&t<new Date(range.to).getTime();},
  _colorFor(s){let h=0;for(let i=0;i<(s||'').length;i++)h=(h*31+s.charCodeAt(i))>>>0;return `hsl(${h%360} 55% 42%)`;},
  _initials(name){if(!name)return'?';const p=String(name).trim().split(/\s+/);return((p[0]?.[0]||'')+(p[1]?.[0]||'')).toUpperCase()||'?';},
  _issueUrl(key){const base=(JiraPulse._config?.jiraBaseUrl||'').replace(/\/+$/,'');return base?`${base}/browse/${key}`:'#';},

  _TERMINAL:['done','closed','resolved','completed','cancel','rejected','uat','готово','закрыт','выполн','отмен','отклон'],
  _INITIAL:['open','to do','todo','backlog','created','new','draft','к выполнению','открыт','новая'],
  _isTerm(name){if(!name)return false;const n=name.toLowerCase();return JiraPulse._TERMINAL.some(h=>n.includes(h));},
  _isInit(name){if(!name)return true;const n=name.toLowerCase();return JiraPulse._INITIAL.some(h=>n.includes(h));},
  _statusCat(issue){return issue.fields?.status?.statusCategory?.key||'new';},
  _statusName(issue){return issue.fields?.status?.name||'';},
  _isWip(issue){
    const c=JiraPulse._statusCat(issue);
    if(c==='done')return false; if(c==='indeterminate')return true;
    const hist=issue.changelog?.histories||[];
    if(hist.some(h=>(h.items||[]).some(i=>i.field==='status')))return true;
    if((issue.fields?.worklog?.worklogs||[]).length)return true;
    if((issue.fields?.comment?.comments||[]).length)return true;
    return false;
  },
  _lastMov(issue){
    const d=[];
    if(issue.fields?.updated)d.push(issue.fields.updated);
    for(const h of issue.changelog?.histories||[])if(h.created)d.push(h.created);
    for(const w of issue.fields?.worklog?.worklogs||[])if(w.started)d.push(w.started);
    for(const c of issue.fields?.comment?.comments||[])if(c.created)d.push(c.created);
    return d.length?d.sort().at(-1):null;
  },
  _assignee(issue){const a=issue.fields?.assignee;if(!a)return null;return{key:a.name||a.accountId||a.displayName,name:a.displayName||a.name||'—',login:a.name||a.accountId||'',email:a.emailAddress||''};},
  _parentKey(issue){return issue.fields?.parent?.key||null;},
  _isSubtask(issue){return !!issue.fields?.issuetype?.subtask||/sub.?task|подзадача/i.test(issue.fields?.issuetype?.name||'');},
  _typeBucket(issue){const t=(issue.fields?.issuetype?.name||'').toLowerCase();if(JiraPulse._isSubtask(issue))return'sub-task';if(/story|история/.test(t))return'story';if(/bug|баг|дефект/.test(t))return'bug';return'task';},
  _typeIcon(t){return{story:'📗',task:'✅',bug:'🐞','sub-task':'↳'}[t]||'•';},
  _typeLabel(t){return{story:'Истории',task:'Задачи',bug:'Баги','sub-task':'Подзадачи'}[t]||t;},
  _matchUser(person,login,email,name){
    if(!person)return false;
    const nm=s=>(s||'').toLowerCase().replace(/^[^\\]+\\/,'');
    const lo=nm(login),em=(email||'').toLowerCase(),na=(name||'').toLowerCase();
    const pl=nm(person.login),pe=(person.email||'').toLowerCase(),pn=(person.name||'').toLowerCase();
    if(lo&&pl&&lo===pl)return true; if(em&&pe&&em===pe)return true; if(na&&pn&&na===pn)return true;
    if(em&&pl){const u=em.split('@')[0];if(u&&u===pl)return true;}
    return false;
  },
  _statusChip(issue){const c=JiraPulse._statusCat(issue),nm=JiraPulse._statusName(issue);const cls=c==='done'?'jp-chip-done':c==='indeterminate'?'jp-chip-wip':'jp-chip-todo';return`<span class="jp-chip ${cls}">${JiraPulse._esc(nm)}</span>`;},
  _prioChip(issue){const p=issue.fields?.priority?.name;if(!p)return'';const cls={'Highest':'jp-prio-highest','High':'jp-prio-high','Medium':'jp-prio-medium','Low':'jp-prio-low','Lowest':'jp-prio-lowest'}[p]||'';return`<span class="jp-chip ${cls}">${JiraPulse._esc(p)}</span>`;},
  _areaChip(area){if(!area)return'';return`<span class="jp-area-chip">${JiraPulse._esc(area.projectKey)}</span>`;},
  _extractActivity(issue,range){
    const out={transitions:[],worklogs:[],commits:[],prs:[],updatesByUser:{},comments:[]};
    for(const h of issue.changelog?.histories||[]){
      if(!JiraPulse._inRange(h.created,range))continue;
      const user=h.author?.name||h.author?.displayName||'—';
      out.updatesByUser[user]=(out.updatesByUser[user]||0)+1;
      for(const it of h.items||[])if(it.field==='status')out.transitions.push({from:it.fromString,to:it.toString,at:h.created,by:user,byName:h.author?.displayName||user});
    }
    for(const w of issue.fields?.worklog?.worklogs||[]){
      if(!JiraPulse._inRange(w.started,range))continue;
      out.worklogs.push({authorLogin:w.author?.name||'',authorName:w.author?.displayName||w.author?.name||'—',timeSpentSeconds:w.timeSpentSeconds||0,started:w.started,comment:typeof w.comment==='string'?w.comment:''});
    }
    for(const c of issue.fields?.comment?.comments||[]){
      if(!JiraPulse._inRange(c.created,range))continue;
      out.comments.push({authorLogin:c.author?.name||'',authorName:c.author?.displayName||c.author?.name||'—',at:c.created,body:typeof c.body==='string'?c.body:''});
    }
    return out;
  },
  _aggregatePeople(areas){
    const report=JiraPulse._report;
    const ranges={yesterday:report.yesterdayRange,dayBefore:report.dayBeforeYesterdayRange,last48h:report.last48hRange};
    const people=new Map();
    const ensure=(a,areaInfo)=>{
      const key=a?a.key:'__unassigned__',name=a?a.name:'Без исполнителя',login=a?a.login:'',email=a?a.email:'';
      if(!people.has(key))people.set(key,{key,name,login,email,areas:new Set(),inProgress:[],doneYesterday:[],doneDayBefore:[],yesterdayItems:[],dayBeforeItems:[],comments48h:[],stale:[],stats:{workSecYesterday:0,workSec48h:0,commits48h:0,prs48h:0}});
      const p=people.get(key); if(areaInfo)p.areas.add(areaInfo.projectKey+'|'+areaInfo.name); return p;
    };
    for(const area of areas){
      const ai={name:area.name,projectKey:area.projectKey};
      for(const issue of area.issues||[]){
        const a=JiraPulse._assignee(issue),p=ensure(a,ai);
        if(JiraPulse._isWip(issue))p.inProgress.push({issue,area:ai});
        const yA=JiraPulse._extractActivity(issue,ranges.yesterday);
        const dA=JiraPulse._extractActivity(issue,ranges.dayBefore);
        const lA=JiraPulse._extractActivity(issue,ranges.last48h);
        const doneTrans=acts=>acts.transitions.filter(t=>JiraPulse._isTerm(t.to));
        const yDone=doneTrans(yA),dDone=doneTrans(dA);
        if(yDone.length)p.doneYesterday.push({issue,area:ai,toStatus:yDone.at(-1).to});
        if(dDone.length)p.doneDayBefore.push({issue,area:ai,toStatus:dDone.at(-1).to});
        const hasYAct=yA.transitions.length||yA.worklogs.length||Object.keys(yA.updatesByUser).length;
        const hasDAct=dA.transitions.length||dA.worklogs.length||Object.keys(dA.updatesByUser).length;
        if(hasYAct)p.yesterdayItems.push({issue,area:ai,ya:yA});
        if(hasDAct)p.dayBeforeItems.push({issue,area:ai,ya:dA});
        p.stats.workSecYesterday+=yA.worklogs.reduce((s,w)=>s+(w.timeSpentSeconds||0),0);
        p.stats.workSec48h+=lA.worklogs.reduce((s,w)=>s+(w.timeSpentSeconds||0),0);
        if(JiraPulse._isWip(issue)){const mv=JiraPulse._lastMov(issue)||issue.fields?.updated;if(mv){const d=JiraPulse._daysSince(mv);if(d!=null&&d>=report.staleDays)p.stale.push({issue,area:ai,daysIdle:d});}}
      }
    }
    const un=people.get('__unassigned__');
    if(un&&!un.inProgress.length&&!un.yesterdayItems.length&&!un.doneYesterday.length)people.delete('__unassigned__');
    const arr=Array.from(people.values()).filter(p=>p.key!=='__unassigned__');
    arr.sort((a,b)=>(b.yesterdayItems.length+b.doneYesterday.length)-(a.yesterdayItems.length+a.doneYesterday.length)||(a.name||'').localeCompare(b.name||'','ru'));
    return{people:arr,unassigned:people.get('__unassigned__')||null};
  },
  _selectedAreas(key){const areas=JiraPulse._report?.areas||[];if(!key||key==='__all__')return areas;return areas.filter(a=>a.projectKey===key);},
  _issueLine(issue,area,extra={}){
    const key=issue.key,summary=issue.fields?.summary||'';
    const right=[];
    if(area)right.push(JiraPulse._areaChip(area));
    right.push(JiraPulse._statusChip(issue));
    const pr=JiraPulse._prioChip(issue);if(pr)right.push(pr);
    if(extra.daysIdle!=null)right.push(`<span class="jp-chip jp-chip-stale">${extra.daysIdle} дн</span>`);
    if(extra.toStatus)right.push(`<span class="jp-chip jp-chip-done">→ ${JiraPulse._esc(extra.toStatus)}</span>`);
    const pk=JiraPulse._parentKey(issue);
    return`<div class="jp-issue"><a class="jp-issue-key" href="${JiraPulse._issueUrl(key)}" target="_blank" rel="noreferrer">${JiraPulse._esc(key)}</a><div class="jp-issue-title">${pk&&JiraPulse._isSubtask(issue)?`<span class="jp-parent">↳ ${JiraPulse._esc(pk)}</span>`:''}<span>${JiraPulse._esc(summary)}</span></div><div class="jp-issue-meta">${right.join(' ')}</div></div>`;
  },
  _renderTypeGroups(issues,mapFn){
    if(!issues.length)return'<div class="jp-empty">Нет задач.</div>';
    const order=['story','task','bug','sub-task'],byType=new Map();
    for(const it of issues){const t=JiraPulse._typeBucket(it);if(!byType.has(t))byType.set(t,[]);byType.get(t).push(it);}
    return order.filter(t=>byType.has(t)).map(t=>`<div class="jp-type-group"><div class="jp-type-header">${JiraPulse._typeIcon(t)} ${JiraPulse._typeLabel(t)} <span class="jp-count">${byType.get(t).length}</span></div>${byType.get(t).map(mapFn).join('')}</div>`).join('');
  },
  _widgetBars(title,data,kind=''){
    if(!data.length)return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div class="jp-empty">Нет данных.</div></div>`;
    const max=Math.max(1,...data.map(d=>d.val));
    return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div>${data.map(d=>`<div class="jp-hbar-row"><div class="jp-hbar-label" title="${JiraPulse._esc(d.name)}">${JiraPulse._esc(d.name)}</div><div class="jp-hbar ${kind}"><span style="width:${(d.val/max*100).toFixed(1)}%"></span></div><div class="jp-hbar-val">${d.val}</div></div>`).join('')}</div>`;
  },
  _widgetHist(title,values,bins){
    if(!values.length)return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div class="jp-empty">Нет данных.</div></div>`;
    const buckets=[];
    for(let i=0;i<bins.length;i++){const lo=bins[i],hi=i+1<bins.length?bins[i+1]:Infinity;const label=hi===Infinity?`${lo}+`:`${lo}–${hi-1}`;buckets.push({name:label+' дн',val:values.filter(v=>v>=lo&&v<hi).length});}
    return JiraPulse._widgetBars(title,buckets,'warn');
  },
  _widgetDonut(title,segments){
    const total=segments.reduce((s,x)=>s+x.value,0);
    if(!total)return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div class="jp-empty">Нет данных.</div></div>`;
    const r=38,c=2*Math.PI*r;let acc=0;
    const rings=segments.map(s=>{const len=(s.value/total)*c,dasharray=`${len} ${c-len}`,rotate=(acc/total)*360-90;acc+=s.value;return`<circle cx="50" cy="50" r="${r}" fill="none" stroke="${s.color}" stroke-width="14" stroke-dasharray="${dasharray}" transform="rotate(${rotate} 50 50)"/>`;}).join('');
    const legend=segments.filter(s=>s.value>0).map(s=>`<div class="jp-donut-leg-item"><span style="background:${s.color}"></span>${JiraPulse._esc(s.label)} — ${s.value} (${Math.round(s.value/total*100)}%)</div>`).join('');
    return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div class="jp-donut-wrap"><svg viewBox="0 0 100 100" width="110" height="110"><circle cx="50" cy="50" r="${r}" fill="none" stroke="var(--border-light)" stroke-width="14"/>${rings}<text x="50" y="54" text-anchor="middle" font-size="13" fill="var(--text-1)">${total}</text></svg><div class="jp-donut-legend">${legend}</div></div></div>`;
  },
  _widgetTwo(title,left,right){
    const cell=(x)=>`<div style="flex:1;text-align:center"><div class="jp-big" style="color:${x.kind==='good'?'#22c55e':x.kind==='bad'?'#ef4444':'var(--accent)'}">${x.value}</div><div class="jp-sub">${JiraPulse._esc(x.label)}</div></div>`;
    return`<div class="jp-widget"><div class="jp-widget-title">${JiraPulse._esc(title)}</div><div style="display:flex;gap:18px;padding-top:8px">${cell(left)}${cell(right)}</div></div>`;
  },
  _insightCard(ins){return`<div class="jp-insight jp-sev-${ins.sev}"><div class="jp-insight-icon">${ins.icon}</div><div class="jp-insight-body"><div class="jp-insight-title">${JiraPulse._esc(ins.title)}</div><div class="jp-insight-desc">${ins.desc||''}</div></div><div class="jp-insight-tag">${JiraPulse._esc(ins.tag||'')}</div></div>`;},
  _statCards(cards){return`<div class="jp-stat-row">${cards.map(c=>`<div class="jp-stat-card jp-stat-${c.kind||''}"><div class="jp-stat-label">${JiraPulse._esc(c.label)}</div><div class="jp-stat-value">${c.value}</div>${c.sub?`<div class="jp-stat-sub">${JiraPulse._esc(c.sub)}</div>`:''}</div>`).join('')}</div>`;},
  _typeBreakdown(issues){
    const types=['story','task','bug','sub-task'],total={done:0,wip:0,todo:0},byType={};
    for(const t of types)byType[t]={done:0,wip:0,todo:0};
    for(const it of issues){const t=JiraPulse._typeBucket(it),cat=JiraPulse._statusCat(it),wip=JiraPulse._isWip(it);const b=cat==='done'?'done':wip?'wip':'todo';byType[t][b]++;total[b]++;}
    const rows=types.filter(t=>byType[t].done+byType[t].wip+byType[t].todo>0).map(t=>{const s=byType[t],sum=s.done+s.wip+s.todo||1,pct=n=>Math.round(n/sum*100);return`<div class="jp-type-row"><div class="jp-type-label">${JiraPulse._typeIcon(t)} ${JiraPulse._typeLabel(t)}</div><div class="jp-seg-bar"><span class="jp-seg-done" style="width:${pct(s.done)}%" title="Готово: ${s.done}"></span><span class="jp-seg-wip" style="width:${pct(s.wip)}%" title="В работе: ${s.wip}"></span><span class="jp-seg-todo" style="width:${pct(s.todo)}%" title="Не взято: ${s.todo}"></span></div><div class="jp-type-counts">✅ ${s.done} · ▶ ${s.wip} · ☐ ${s.todo}</div></div>`;}).join('');
    const legend=`<div class="jp-seg-legend"><span><span class="jp-dot jp-seg-done"></span>Готово</span><span><span class="jp-dot jp-seg-wip"></span>В работе</span><span><span class="jp-dot jp-seg-todo"></span>Не приступали</span></div>`;
    return legend+(rows||'<div class="jp-empty">Нет данных.</div>');
  },
  renderPeople(){
    const areas=JiraPulse._selectedAreas(JiraPulse._activeArea);
    const{people,unassigned}=JiraPulse._aggregatePeople(areas);
    const sorted=[...people].sort((a,b)=>(a.name||'').localeCompare(b.name||'','ru'));
    const cards=sorted.map(p=>JiraPulse._personCard(p)).join('');
    const unCard=unassigned?JiraPulse._personCard(unassigned,true):'';
    return`<div class="jp-people-list">${cards||'<div class="jp-empty-card">Нет участников с активностью.</div>'}${unCard}</div>`;
  },
  _personCard(p,isUnassigned=false){
    const report=JiraPulse._report;
    const badges=[];
    badges.push(`<span class="jp-badge jp-badge-info">в работе: ${p.inProgress.length}</span>`);
    if(p.doneYesterday.length)badges.push(`<span class="jp-badge jp-badge-good">✅ закрыто: ${p.doneYesterday.length}</span>`);
    if(p.stats.workSec48h)badges.push(`<span class="jp-badge">⏱ ${JiraPulse._hrs(p.stats.workSec48h)}</span>`);
    if(p.stale.length)badges.push(`<span class="jp-badge jp-badge-bad">🐌 висит: ${p.stale.length}</span>`);
    const areaList=Array.from(p.areas||[]).map(s=>{const[k]=s.split('|');return`<span class="jp-area-chip">${JiraPulse._esc(k)}</span>`;}).join(' ');
    const buildActList=(items)=>{
      if(!items.length)return'<div class="jp-empty">Без изменений.</div>';
      return JiraPulse._renderTypeGroups(items.map(x=>x.issue),(it)=>{
        const x=items.find(y=>y.issue.key===it.key),a=x?.ya,lines=[];
        for(const t of a?.transitions||[]){const cls=JiraPulse._isTerm(t.to)?'jp-chip-done':'jp-chip-wip';lines.push(`<li>→ <span class="jp-chip ${cls}">${JiraPulse._esc(t.to)}</span> <span class="jp-muted">${JiraPulse._fmtTime(t.at)}</span></li>`);}
        for(const w of a?.worklogs||[])lines.push(`<li>⏱ ${JiraPulse._hrs(w.timeSpentSeconds)}${w.comment?' — '+JiraPulse._esc(w.comment.slice(0,100)):''}</li>`);
        if(!lines.length&&Object.keys(a?.updatesByUser||{}).length)lines.push('<li>✎ правки полей</li>');
        return`<div class="jp-issue"><a class="jp-issue-key" href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a><div class="jp-issue-title"><span>${JiraPulse._esc(it.fields?.summary||'')}</span>${lines.length?`<ul class="jp-act-list">${lines.join('')}</ul>`:''}</div><div class="jp-issue-meta">${x?.area?JiraPulse._areaChip(x.area):''} ${JiraPulse._statusChip(it)}</div></div>`;
      });
    };
    const inProgressBody=JiraPulse._renderTypeGroups(p.inProgress.map(x=>x.issue),(it)=>{
      const x=p.inProgress.find(y=>y.issue.key===it.key);
      const mv=JiraPulse._lastMov(it)||it.fields?.updated,d=JiraPulse._daysSince(mv);
      return JiraPulse._issueLine(it,x?.area,d!=null&&d>=report.staleDays?{daysIdle:d}:{});
    });
    return`<details class="jp-person-card${isUnassigned?' jp-unassigned':''}"><summary class="jp-person-head"><div class="jp-avatar" style="background:${JiraPulse._colorFor(p.key||p.name)}">${JiraPulse._esc(JiraPulse._initials(p.name))}</div><div class="jp-person-id"><div class="jp-person-name">${JiraPulse._esc(p.name)} ${areaList}</div><div class="jp-person-login">${JiraPulse._esc(p.login||'')}</div></div><div class="jp-person-stats">${badges.join('')}</div></summary><details class="jp-section"><summary>В работе сейчас <span class="jp-count">${p.inProgress.length}</span></summary><div class="jp-section-body">${inProgressBody}</div></details><details class="jp-section"><summary>Делал вчера <span class="jp-count">${p.yesterdayItems.length+p.doneYesterday.length}</span></summary><div class="jp-section-body">${buildActList(p.yesterdayItems)}</div></details><details class="jp-section"><summary>Делал позавчера <span class="jp-count">${p.dayBeforeItems.length+p.doneDayBefore.length}</span></summary><div class="jp-section-body">${buildActList(p.dayBeforeItems)}</div></details>${p.stale.length?`<details class="jp-section" open><summary>Висят > ${report.staleDays} дн <span class="jp-count">${p.stale.length}</span></summary><div class="jp-section-body">${p.stale.map(s=>JiraPulse._issueLine(s.issue,s.area,{daysIdle:s.daysIdle})).join('')}</div></details>`:''}</details>`;
  },
  renderSummary(){
    const areas=JiraPulse._selectedAreas(JiraPulse._activeArea);
    if(!areas.length)return'<div class="jp-empty">Нет пространств.</div>';
    const allIssues=areas.flatMap(a=>a.issues||[]);
    const sprintSet=new Set(areas.flatMap(a=>a.sprintKeys||[]));
    const wip=allIssues.filter(JiraPulse._isWip).length;
    const{people}=JiraPulse._aggregatePeople(areas);
    const stale=people.reduce((s,p)=>s+p.stale.length,0);
    const doneY=people.reduce((s,p)=>s+p.doneYesterday.length,0);
    const statC=JiraPulse._statCards([{label:'В активных спринтах',value:[...sprintSet].length,kind:'info',sub:'задач'},{label:'В работе сейчас',value:wip,kind:''},{label:'Висят > N дней',value:stale,kind:'warn',sub:`порог ${JiraPulse._report.staleDays} дн`},{label:'Закрыто вчера',value:doneY,kind:'good'}]);
    const yRows=people.filter(p=>p.yesterdayItems.length||p.doneYesterday.length).slice(0,40).map(p=>{
      const bits=[];if(p.doneYesterday.length)bits.push(`<span class="jp-chip jp-chip-done">✅ ${p.doneYesterday.length}</span>`);
      if(p.stats.workSecYesterday)bits.push(`<span class="jp-chip">⏱ ${JiraPulse._hrs(p.stats.workSecYesterday)}</span>`);
      const seen=new Set(),uniq=[];for(const x of[...p.doneYesterday,...p.yesterdayItems]){if(seen.has(x.issue.key))continue;seen.add(x.issue.key);uniq.push(x);if(uniq.length>=6)break;}
      return`<div class="jp-issue"><div class="jp-issue-key">${JiraPulse._esc(p.name)}</div><div class="jp-issue-title">${uniq.map(x=>`<a class="jp-issue-key" href="${JiraPulse._issueUrl(x.issue.key)}" target="_blank">${JiraPulse._esc(x.issue.key)}</a>`).join(' ')}</div><div class="jp-issue-meta">${bits.join(' ')}</div></div>`;
    }).join('');
    const todayRows=people.filter(p=>p.inProgress.length).slice(0,30).map(p=>{const links=p.inProgress.slice(0,8).map(x=>`<a class="jp-issue-key" href="${JiraPulse._issueUrl(x.issue.key)}" target="_blank">${JiraPulse._esc(x.issue.key)}</a>`).join(' ');return`<div class="jp-issue"><div class="jp-issue-key">${JiraPulse._esc(p.name)}</div><div class="jp-issue-title">${links}</div><div class="jp-issue-meta"><span class="jp-chip">${p.inProgress.length}</span></div></div>`;}).join('');
    return`${statC}<div class="jp-panel"><div class="jp-panel-title">Разбивка по типам</div>${JiraPulse._typeBreakdown(allIssues.filter(it=>sprintSet.has(it.key)))}</div><div class="jp-two-col"><div class="jp-panel"><div class="jp-panel-title">Что делали вчера</div><div>${yRows||'<div class="jp-empty">Вчера тишина.</div>'}</div></div><div class="jp-panel"><div class="jp-panel-title">План на сегодня</div><div>${todayRows||'<div class="jp-empty">Нет задач в работе.</div>'}</div></div></div>`;
  },
  renderSprints(){
    const areas=JiraPulse._report?.areas||[];
    if(!areas.length)return'<div class="jp-empty">Нет пространств.</div>';
    const sub=JiraPulse._sprintArea||areas[0]?.projectKey; JiraPulse._sprintArea=sub;
    const a=areas.find(x=>x.projectKey===sub)||areas[0];
    if(a?.error)return`<div class="jp-error">${JiraPulse._esc(a.error)}</div>`;
    const sprintIssues=(a.issues||[]).filter(it=>(a.sprintKeys||[]).includes(it.key));
    if(!sprintIssues.length)return`<div class="jp-empty-card"><p>В «${JiraPulse._esc(a.name)}» активный спринт не найден.</p></div>`;
    const total=sprintIssues.length,done=sprintIssues.filter(it=>JiraPulse._statusCat(it)==='done').length;
    const wip=sprintIssues.filter(JiraPulse._isWip).length,todo=total-done-wip,pct=Math.round(done/total*100);
    const insights=JiraPulse._sprintInsights(a,sprintIssues);
    return`${JiraPulse._statCards([{label:'Всего',value:total,kind:'info',sub:'в активном спринте'},{label:'Готово',value:done,kind:'good',sub:`${pct}% спринта`},{label:'В работе',value:wip,kind:''},{label:'Не приступали',value:todo,kind:'warn'}])}<div class="jp-panel"><div class="jp-panel-title">Типы задач — ${JiraPulse._esc(a.name)}</div>${JiraPulse._typeBreakdown(sprintIssues)}</div><div class="jp-panel"><div class="jp-panel-title">Инсайты по спринту</div><div class="jp-insights-list">${insights.length?insights.map(JiraPulse._insightCard).join(''):'<div class="jp-empty">Сигналов нет.</div>'}</div></div>`;
  },
  _sprintInsights(a,si){
    const ins=[],total=si.length,done=si.filter(it=>JiraPulse._statusCat(it)==='done').length;
    const wip=si.filter(JiraPulse._isWip).length,todo=total-done-wip;
    if(todo/total>0.5)ins.push({sev:'warn',icon:'⏳',title:`${Math.round(todo/total*100)}% спринта не взято в работу`,desc:'Пора брать или резать scope.',tag:'scope'});
    if(wip/Math.max(1,total-done)>0.5)ins.push({sev:'warn',icon:'🪢',title:`WIP ${wip} из ${total-done} оставшихся (>50%)`,desc:'Слишком много задач в работе.',tag:'wip'});
    const counts=new Map();for(const it of si){const ass=JiraPulse._assignee(it);const k=ass?ass.name:'—';counts.set(k,(counts.get(k)||0)+1);}
    const top=[...counts.entries()].sort((a,b)=>b[1]-a[1])[0];
    if(top&&top[1]/total>0.4&&top[0]!=='—')ins.push({sev:'warn',icon:'🧍',title:`Bus factor: ${JiraPulse._esc(top[0])} — ${top[1]} из ${total}`,desc:'',tag:'риск'});
    const bugs=si.filter(it=>JiraPulse._typeBucket(it)==='bug');
    if(bugs.length/total>0.3)ins.push({sev:'info',icon:'🐞',title:`Доля багов — ${Math.round(bugs.length/total*100)}%`,desc:'',tag:'quality'});
    const inWeek=si.filter(it=>{const d=it.fields?.duedate;if(!d||JiraPulse._statusCat(it)==='done')return false;const t=new Date(d).getTime();return t>Date.now()&&t<Date.now()+7*86400000;});
    if(inWeek.length)ins.push({sev:'warn',icon:'📅',title:`Срок ≤7 дней: ${inWeek.length}`,desc:inWeek.slice(0,6).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', '),tag:'deadline'});
    return ins;
  },
  renderInsights(){const areas=JiraPulse._selectedAreas(JiraPulse._activeArea);const list=JiraPulse._computeInsights(areas);return`<div class="jp-insights-list">${list.map(JiraPulse._insightCard).join('')||'<div class="jp-empty-card">🎉 Явных сигналов нет.</div>'}</div>`;},
  _computeInsights(areas){
    const report=JiraPulse._report,ins=[];
    const{people}=JiraPulse._aggregatePeople(areas);
    const allIssues=areas.flatMap(a=>a.issues||[]);
    const sprintSet=new Set(areas.flatMap(a=>a.sprintKeys||[]));
    const wipIssues=allIssues.filter(JiraPulse._isWip);
    for(const a of areas)if(a.error)ins.push({sev:'bad',icon:'⛔',tag:'error',title:`Ошибка ${a.name}`,desc:JiraPulse._esc(a.error)});
    const staleAll=[];for(const p of people)for(const s of p.stale)staleAll.push({...s,person:p});
    if(staleAll.length)ins.push({sev:'bad',icon:'🐌',tag:'стагнация',title:`Висит > ${report.staleDays} дн: ${staleAll.length}`,desc:staleAll.slice(0,8).map(s=>`<a href="${JiraPulse._issueUrl(s.issue.key)}" target="_blank">${JiraPulse._esc(s.issue.key)}</a> · ${s.daysIdle}дн · ${JiraPulse._esc(s.person.name)}`).join('<br>')});
    const silent=people.filter(p=>p.inProgress.length&&!p.yesterdayItems.length&&!p.doneYesterday.length);
    if(silent.length)ins.push({sev:'warn',icon:'🤫',tag:'тишина',title:`Без активности вчера: ${silent.length} чел.`,desc:silent.slice(0,10).map(p=>JiraPulse._esc(p.name)).join(' · ')});
    const overload=people.filter(p=>p.inProgress.length>3);
    if(overload.length)ins.push({sev:'warn',icon:'🧨',tag:'перегруз',title:`WIP > 3 у ${overload.length} чел.`,desc:overload.map(p=>`${JiraPulse._esc(p.name)} — ${p.inProgress.length}`).join(' · ')});
    const noAssignee=allIssues.filter(it=>!it.fields?.assignee&&sprintSet.has(it.key));
    if(noAssignee.length)ins.push({sev:'warn',icon:'👻',tag:'owner',title:`В спринте без исполнителя: ${noAssignee.length}`,desc:noAssignee.slice(0,8).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', ')});
    const today=new Date();today.setHours(0,0,0,0);
    const overdue=allIssues.filter(it=>{const d=it.fields?.duedate;if(!d||JiraPulse._statusCat(it)==='done')return false;return new Date(d).getTime()<today.getTime();});
    if(overdue.length)ins.push({sev:'bad',icon:'⏰',tag:'срок',title:`Просрочены: ${overdue.length}`,desc:overdue.slice(0,8).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a> (до ${JiraPulse._fmtDate(it.fields.duedate)})`).join('<br>')});
    const hiTodo=allIssues.filter(it=>{const p=(it.fields?.priority?.name||'').toLowerCase();return['highest','high','blocker','critical'].includes(p)&&JiraPulse._statusCat(it)==='new'&&sprintSet.has(it.key);});
    if(hiTodo.length)ins.push({sev:'warn',icon:'🔥',tag:'prio',title:`Высокий приоритет не взят: ${hiTodo.length}`,desc:hiTodo.slice(0,8).map(it=>`<a href="${JiraPulse._issueUrl(it.key)}" target="_blank">${JiraPulse._esc(it.key)}</a>`).join(', ')});
    const doneTotal=people.reduce((s,p)=>s+p.doneYesterday.length,0);
    if(doneTotal){const top=people.filter(p=>p.doneYesterday.length).sort((a,b)=>b.doneYesterday.length-a.doneYesterday.length).slice(0,5);ins.push({sev:'good',icon:'✅',tag:'win',title:`Закрыто вчера: ${doneTotal}`,desc:top.map(p=>`${JiraPulse._esc(p.name)} — ${p.doneYesterday.length}`).join(' · ')});}
    if(!wipIssues.length)ins.push({sev:'info',icon:'📭',tag:'empty',title:'В работе нет задач',desc:'Никто ничего не двигает.'});
    return ins;
  },
  renderMetrics(){
    const areas=JiraPulse._selectedAreas(JiraPulse._activeArea);
    const report=JiraPulse._report;
    const{people}=JiraPulse._aggregatePeople(areas);
    const allIssues=areas.flatMap(a=>a.issues||[]);
    const sprintSet=new Set(areas.flatMap(a=>a.sprintKeys||[]));
    const widgets=[];
    widgets.push(JiraPulse._widgetBars('WIP по людям',people.map(p=>({name:p.name,val:p.inProgress.length})).filter(x=>x.val>0).sort((a,b)=>b.val-a.val).slice(0,12)));
    widgets.push(JiraPulse._widgetBars('Logtime вчера, ч',people.map(p=>({name:p.name,val:Math.round(p.stats.workSecYesterday/360)/10})).filter(x=>x.val>0).sort((a,b)=>b.val-a.val).slice(0,12),'good'));
    const ages=allIssues.filter(JiraPulse._isWip).map(it=>JiraPulse._daysSince(JiraPulse._lastMov(it)||it.fields?.updated)).filter(x=>x!=null);
    widgets.push(JiraPulse._widgetHist('Возраст задач в работе (дн)',ages,[0,1,3,7,14,30]));
    const cats={'To Do':0,'In Progress':0,'Done':0};
    for(const it of allIssues.filter(x=>sprintSet.has(x.key))){const c=JiraPulse._statusCat(it);if(c==='done')cats['Done']++;else if(c==='indeterminate')cats['In Progress']++;else cats['To Do']++;}
    widgets.push(JiraPulse._widgetDonut('Спринт: статусы',[{label:'Done',value:cats['Done'],color:'#22c55e'},{label:'In Progress',value:cats['In Progress'],color:'var(--accent)'},{label:'To Do',value:cats['To Do'],color:'var(--text-3)'}]));
    const prio=new Map();for(const it of allIssues){const p=it.fields?.priority?.name||'—';prio.set(p,(prio.get(p)||0)+1);}
    const prioColors={'Highest':'#ef4444','High':'#f97316','Medium':'#f59e0b','Low':'#94a3b8','Lowest':'#64748b'};
    widgets.push(JiraPulse._widgetDonut('Приоритеты',[...prio.entries()].map(([k,v])=>({label:k,value:v,color:prioColors[k]||'var(--accent)'}))));
    const closedY=allIssues.filter(it=>(it.changelog?.histories||[]).some(h=>JiraPulse._inRange(h.created,report.yesterdayRange)&&(h.items||[]).some(i=>i.field==='status'&&JiraPulse._isTerm(i.toString)))).length;
    const openedY=allIssues.filter(it=>JiraPulse._inRange(it.fields?.created,report.yesterdayRange)).length;
    widgets.push(JiraPulse._widgetTwo('Поток вчера',{label:'Закрыто',value:closedY,kind:'good'},{label:'Открыто',value:openedY,kind:'info'}));
    return`<div class="jp-metrics-grid">${widgets.join('')}</div>`;
  },
  renderBacklog(){
    const areas=(JiraPulse._backlogArea==='__all__'?JiraPulse._report?.areas||[]:(JiraPulse._report?.areas||[]).filter(a=>a.projectKey===JiraPulse._backlogArea));
    const items=areas.flatMap(a=>(a.issues||[]).filter(it=>(a.backlogKeys||[]).includes(it.key)).map(it=>({issue:it,area:{name:a.name,projectKey:a.projectKey}})));
    if(!items.length)return'<div class="jp-empty-card"><p>В бэклоге нет задач. 👌</p></div>';
    const tabs=['summary','metrics','dashboards','insights'].map(t=>`<button class="jp-subtab${JiraPulse._backlogTab===t?' active':''}" data-bltab="${t}">${{summary:'Сводка',metrics:'Метрики',dashboards:'Дашборды',insights:'Инсайты'}[t]}</button>`).join('');
    const allAreas=JiraPulse._report?.areas||[];
    const areaSel=`<select id="jp-bl-area" class="jp-select"><option value="__all__">Все пространства</option>${allAreas.map(a=>`<option value="${JiraPulse._esc(a.projectKey)}"${JiraPulse._backlogArea===a.projectKey?' selected':''}>${JiraPulse._esc(a.name)} [${JiraPulse._esc(a.projectKey)}]</option>`).join('')}</select>`;
    let body='';
    if(JiraPulse._backlogTab==='summary'){
      const total=items.length,noPrio=items.filter(x=>!x.issue.fields?.priority?.name).length;
      const noAss=items.filter(x=>!x.issue.fields?.assignee).length;
      const oldest=items.map(x=>JiraPulse._daysSince(x.issue.fields?.created)).filter(d=>d!=null).sort((a,b)=>b-a)[0]||0;
      const byArea=new Map();for(const x of items){const k=x.area.projectKey;if(!byArea.has(k))byArea.set(k,{area:x.area,count:0});byArea.get(k).count++;}
      const areaRows=[...byArea.values()].sort((a,b)=>b.count-a.count);
      body=`${JiraPulse._statCards([{label:'Всего в бэклоге',value:total,kind:'info'},{label:'Без приоритета',value:noPrio,kind:'warn'},{label:'Без исполнителя',value:noAss,kind:'warn'},{label:'Самая старая',value:oldest,kind:'bad',sub:'дней с создания'}])}<div class="jp-panel"><div class="jp-panel-title">По пространствам</div>${areaRows.map(r=>`<div class="jp-hbar-row"><div class="jp-hbar-label">${JiraPulse._esc(r.area.name)} <span class="jp-area-chip">${JiraPulse._esc(r.area.projectKey)}</span></div><div class="jp-hbar"><span style="width:${(r.count/total*100).toFixed(1)}%"></span></div><div class="jp-hbar-val">${r.count}</div></div>`).join('')}</div><div class="jp-panel"><div class="jp-panel-title">Список (топ-100, по возрасту)</div>${[...items].sort((a,b)=>(JiraPulse._daysSince(b.issue.fields?.created)||0)-(JiraPulse._daysSince(a.issue.fields?.created)||0)).slice(0,100).map(x=>JiraPulse._issueLine(x.issue,x.area,{daysIdle:JiraPulse._daysSince(x.issue.fields?.created)})).join('')}</div>`;
    }else{body='<div class="jp-empty">Переключите вкладку.</div>';}
    return`<div class="jp-bl-controls">${areaSel}<div class="jp-subtabs jp-bl-tabs">${tabs}</div></div>${body}`;
  },
  render(){
    const el=document.getElementById('jp-content'); if(!el)return;
    if(!JiraPulse._report){el.innerHTML=document.getElementById('jp-empty')?.outerHTML||'';return;}
    JiraPulse._renderAreaChips();
    let html='';
    if(JiraPulse._activeTab==='people')html=JiraPulse.renderPeople();
    else if(JiraPulse._activeTab==='summary')html=JiraPulse.renderSummary();
    else if(JiraPulse._activeTab==='sprints')html=JiraPulse.renderSprints();
    else if(JiraPulse._activeTab==='insights')html=JiraPulse.renderInsights();
    else if(JiraPulse._activeTab==='metrics')html=JiraPulse.renderMetrics();
    else if(JiraPulse._activeTab==='backlog')html=JiraPulse.renderBacklog();
    el.innerHTML=`<div class="jp-tab-content">${html}</div>`;
    el.querySelector('#jp-bl-area')?.addEventListener('change',e=>{JiraPulse._backlogArea=e.target.value;JiraPulse.render();});
    el.querySelectorAll('[data-bltab]').forEach(btn=>btn.addEventListener('click',()=>{JiraPulse._backlogTab=btn.dataset.bltab;JiraPulse.render();}));
  },
  _renderAreaChips(){
    const row=document.getElementById('jp-area-row'),chips=document.getElementById('jp-area-chips');
    if(!row||!chips)return;
    const areas=JiraPulse._report?.areas||[];
    if(areas.length<=1){row.classList.add('hidden');return;}
    row.classList.remove('hidden');
    chips.innerHTML=[`<button class="jp-area-filter-btn${JiraPulse._activeArea==='__all__'?' active':''}" data-area="__all__">Все</button>`,...areas.map(a=>`<button class="jp-area-filter-btn${JiraPulse._activeArea===a.projectKey?' active':''}" data-area="${JiraPulse._esc(a.projectKey)}">${JiraPulse._esc(a.name)}</button>`)].join('');
    chips.querySelectorAll('[data-area]').forEach(btn=>btn.addEventListener('click',()=>{JiraPulse._activeArea=btn.dataset.area;JiraPulse.render();}));
  },
  async refresh(){
    if(JiraPulse._loading)return; JiraPulse._loading=true;
    const btn=document.getElementById('jp-btn-refresh');
    if(btn){btn.disabled=true;btn.textContent='⟳ Загрузка…';}
    try{
      const resp=await fetch('/api/jira/report',{method:'POST',headers:{'Content-Type':'application/json'}});
      const data=await resp.json();
      if(!resp.ok)throw new Error(data.error||`HTTP ${resp.status}`);
      JiraPulse._report=data;
      const meta=document.getElementById('jp-meta');
      if(meta){const at=new Date(data.generatedAt);meta.textContent=`обновлено ${at.toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})} · ${data.areas.length} пространств`;}
      JiraPulse.render(); showToast('Jira Pulse обновлён','success');
    }catch(e){
      showToast('Ошибка загрузки Jira: '+e.message,'error',4000);
      const c=document.getElementById('jp-content');
      if(c)c.innerHTML=`<div class="jp-empty-card"><p>Ошибка: ${JiraPulse._esc(e.message)}</p><p style="margin-top:8px;font-size:12px;color:var(--text-3)">Проверьте настройки подключения к Jira.</p></div>`;
    }finally{JiraPulse._loading=false;if(btn){btn.disabled=false;btn.textContent='⟳ Обновить';}}
  },
  async loadConfig(){try{const resp=await fetch('/api/jira/config');if(!resp.ok)return;JiraPulse._config=await resp.json();}catch(_){}},
  _openSettings(){
    const cfg=JiraPulse._config||{};
    document.getElementById('jp-cfg-url').value=cfg.jiraBaseUrl||'';
    document.getElementById('jp-cfg-token').value='';
    document.getElementById('jp-cfg-token').placeholder=cfg.hasJiraToken?'•••••••• (пусто = не менять)':'Введите токен';
    document.getElementById('jp-cfg-bb-url').value=cfg.bitbucketBaseUrl||'';
    document.getElementById('jp-cfg-bb-token').value='';
    document.getElementById('jp-cfg-bb-keys').value=cfg.bitbucketProjectKeys||'';
    document.getElementById('jp-cfg-insecure').checked=!!cfg.allowInsecureTls;
    document.getElementById('jp-cfg-stale').value=cfg.staleDays??3;
    document.getElementById('jp-cfg-nomov').value=cfg.noMovementDays??2;
    JiraPulse._renderAreasEditor(cfg.areas||[]);
    document.getElementById('jp-settings-error').classList.add('hidden');
    document.getElementById('jp-settings-modal').classList.remove('hidden');
  },
  _renderAreasEditor(areas){
    const root=document.getElementById('jp-areas-editor');root.innerHTML='';
    const list=areas.length?areas:[{name:'',projectKey:''}];
    for(const a of list)JiraPulse._addAreaRow(a.name||'',a.projectKey||'');
  },
  _addAreaRow(name='',projectKey=''){
    const root=document.getElementById('jp-areas-editor');
    const row=document.createElement('div');row.className='jp-area-row';
    row.innerHTML=`<input class="form-input jp-area-name" placeholder="Имя (Платежи)" value="${JiraPulse._esc(name)}"><input class="form-input jp-area-key" placeholder="KEY (PAY)" value="${JiraPulse._esc(projectKey)}"><button class="btn btn-ghost btn-sm jp-area-del">✕</button>`;
    row.querySelector('.jp-area-del').addEventListener('click',()=>row.remove());
    root.appendChild(row);
  },
  _collectSettings(){
    const areas=[...document.querySelectorAll('#jp-areas-editor .jp-area-row')].map(row=>({name:row.querySelector('.jp-area-name').value.trim(),projectKey:row.querySelector('.jp-area-key').value.trim()})).filter(a=>a.projectKey);
    const payload={jiraBaseUrl:document.getElementById('jp-cfg-url').value.trim(),areas,bitbucketBaseUrl:document.getElementById('jp-cfg-bb-url').value.trim(),bitbucketProjectKeys:document.getElementById('jp-cfg-bb-keys').value.trim(),allowInsecureTls:document.getElementById('jp-cfg-insecure').checked,staleDays:Number(document.getElementById('jp-cfg-stale').value)||3,noMovementDays:Number(document.getElementById('jp-cfg-nomov').value)||2};
    const t=document.getElementById('jp-cfg-token').value;if(t)payload.jiraToken=t;
    const bt=document.getElementById('jp-cfg-bb-token').value;if(bt)payload.bitbucketToken=bt;
    return payload;
  },
  async _saveSettings(){
    const errEl=document.getElementById('jp-settings-error');errEl.classList.add('hidden');
    try{const resp=await fetch('/api/jira/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(JiraPulse._collectSettings())});const data=await resp.json();if(!resp.ok)throw new Error(data.error);JiraPulse._config=data;document.getElementById('jp-settings-modal').classList.add('hidden');showToast('Настройки Jira сохранены','success');JiraPulse.refresh();}
    catch(e){errEl.textContent='Ошибка: '+e.message;errEl.classList.remove('hidden');}
  },
  async _verifySettings(){
    const errEl=document.getElementById('jp-settings-error');errEl.classList.add('hidden');
    try{await fetch('/api/jira/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(JiraPulse._collectSettings())});const resp=await fetch('/api/jira/verify',{method:'POST',headers:{'Content-Type':'application/json'}});const data=await resp.json();if(!resp.ok)throw new Error(data.error);showToast(`Jira: ${data.who}. Подключение успешно!`,'success',4000);}
    catch(e){errEl.textContent='Ошибка: '+e.message;errEl.classList.remove('hidden');}
  },
  init(){
    document.getElementById('jp-subtabs')?.querySelectorAll('[data-jptab]').forEach(btn=>{btn.addEventListener('click',()=>{JiraPulse._activeTab=btn.dataset.jptab;document.querySelectorAll('#jp-subtabs [data-jptab]').forEach(b=>b.classList.toggle('active',b.dataset.jptab===btn.dataset.jptab));JiraPulse.render();});});
    document.getElementById('jp-btn-refresh')?.addEventListener('click',()=>JiraPulse.refresh());
    document.getElementById('jp-btn-settings')?.addEventListener('click',()=>JiraPulse._openSettings());
    document.getElementById('jp-btn-setup')?.addEventListener('click',()=>JiraPulse._openSettings());
    document.getElementById('jp-settings-close')?.addEventListener('click',()=>document.getElementById('jp-settings-modal').classList.add('hidden'));
    document.getElementById('jp-settings-cancel')?.addEventListener('click',()=>document.getElementById('jp-settings-modal').classList.add('hidden'));
    document.getElementById('jp-btn-save')?.addEventListener('click',()=>JiraPulse._saveSettings());
    document.getElementById('jp-btn-verify')?.addEventListener('click',()=>JiraPulse._verifySettings());
    document.getElementById('jp-add-area')?.addEventListener('click',()=>JiraPulse._addAreaRow());
    document.getElementById('jp-settings-modal')?.addEventListener('click',e=>{if(e.target===document.getElementById('jp-settings-modal'))document.getElementById('jp-settings-modal').classList.add('hidden');});
    JiraPulse.loadConfig();
  },
};


// ============================================================
// APP
// ============================================================
const App = {
  init() {
    Storage.loadSettings();
    syncColumnSettings();
    App.applyPresetsCollapsed();
    RegistryView.applyRowHeight();
    SidebarUI.init();
    ThemeUI.init();
    Nav.init();
    FiltersUI.init();
    App.bindImports();
    App.bindExport();
    App.bindClear();
    App.bindSave();
    App.bindAddRow();
    App.bindUndoRedo();
    App.bindColToggle();
    App.bindRegistrySettings();
    App.bindGanttModes();
    App.bindTimelineModes();
    App.bindPodlozhkaModes();
    App.bindSummaryModes();
    App.bindColOrderReset();
    App.bindPodlozhkaGroup();
    App.bindFullscreenRegistry();
    App.bindFilterToggle();
    App.bindPresetsCollapse();
    App.bindEmployees();
    App.bindGantt2Controls();
    App.bindCrossTabStorageSync();
    App.bindFilesDropdown();
    AppSettings.init();
    Onboarding.init();
    // Integrations topbar button
    document.getElementById('btn-integrations-settings')?.addEventListener('click', () => {
      openIntegrationsSettings('jira');
    });
    // V11 Onboarding
    initOnboardingUI({ goTo: (s) => Nav.goTo(s), showToast, notify });
    bindWelcomeButtons();
    // Override btn-onboarding to show welcome screen (reset + re-show)
    document.getElementById('btn-onboarding')?.addEventListener('click', () => {
      resetOnboarding();
      showWelcomeScreen();
    });
    LLMAssistant.init();
    // Initialise chat alerts & daily snapshot after state is ready
    try { takeSnapshot(); } catch(_) {}
    try { saveAlertBaseline(); } catch(_) {}
    try {
      if (state.llm) state.llm.alerts = buildAlerts();
      // Inject alert bar into chat messages panel on first open
      const fab = document.getElementById('assistant-fab');
      if (fab) {
        const _origClick = fab.onclick;
        document.getElementById('assistant-fab').addEventListener('click', () => {
          requestAnimationFrame(() => {
            const msgWrap = document.getElementById('assistant-messages');
            if (msgWrap && !document.getElementById('chat-alert-bar')) {
              const bar = document.createElement('div');
              bar.innerHTML = renderAlertBar(state.llm?.alerts || []);
              if (bar.firstChild) msgWrap.insertBefore(bar.firstChild, msgWrap.firstChild);
            }
          });
        }, { once: false, capture: false });
      }
    } catch(_) {}
    BulkEditPanel.bindUI();
    App.bindSimMode();
    App.bindInsightActions();
    JiraPulse.init();
    ActionLayer.init();
    document.getElementById('modal-kpi-close').addEventListener('click',()=>closeModal(document.getElementById('modal-kpi')));
    document.getElementById('modal-kpi').addEventListener('click',e=>{if(e.target===document.getElementById('modal-kpi'))closeModal(document.getElementById('modal-kpi'));});

    const saved=Storage.load();
    if(saved&&saved.rows&&saved.rows.length>0){
      const meta=document.getElementById('modal-restore-meta');
      meta.textContent=`Сохранено ${saved.rows.length} строк от ${new Date(saved.savedAt).toLocaleString('ru')}.`;
      document.getElementById('modal-restore').classList.remove('hidden');
      document.getElementById('btn-restore-yes').onclick=()=>{
        Storage.restore(saved); RiskEngine.computeAll();
        HistoryManager.clear();
        RegistryView.applyRowHeight();
        closeModal(document.getElementById('modal-restore'));
        App.populateFilterDropdowns(); App.renderSection('dashboard'); App.updateTopbarBadge();
        updateDemoBanner();
        setTimeout(()=>{ if(state.activeSection==='registry') RegistryView.autoFitColWidths(); },150);
      };
      document.getElementById('btn-restore-no').onclick=()=>{
        Storage.clear(); HistoryManager.clear(); closeModal(document.getElementById('modal-restore'));
        App.renderSection('dashboard');
        if (isFirstRun()) showWelcomeScreen();
      };
    } else {
      App.renderSection('dashboard');
      // Show welcome on first run (no saved data)
      if (isFirstRun()) {
        setTimeout(() => showWelcomeScreen(), 300);
      } else {
        updateDemoBanner();
      }
    }
    App.populateFilterDropdowns();
    App.updateTopbarBadge();
  },
  bindImports() {
    document.getElementById('input-xlsx').addEventListener('change',e=>{
      const f=e.target.files[0]; if(!f)return;
      const r=new FileReader(); r.onload=ev=>{ XLSXImporter.import(new Uint8Array(ev.target.result)); App.populateFilterDropdowns(); e.target.value=''; showPostLoadInsights(state.rows); }; r.readAsArrayBuffer(f);
    });
    document.getElementById('input-csv').addEventListener('change',e=>{
      const f=e.target.files[0]; if(!f)return;
      const r=new FileReader(); r.onload=ev=>{ CSV.import(ev.target.result); App.populateFilterDropdowns(); e.target.value=''; showPostLoadInsights(state.rows); }; r.readAsText(f,'utf-8');
    });
    const csvUpdate=document.getElementById('input-csv-update');
    if(csvUpdate){
      csvUpdate.addEventListener('change',e=>{
        const f=e.target.files[0]; if(!f)return;
        const r=new FileReader();
        r.onload=ev=>{ CSV.importUpdate(ev.target.result); App.populateFilterDropdowns(); e.target.value=''; };
        r.readAsText(f,'utf-8');
      });
    }
  },
  bindExport() {
    document.getElementById('btn-export-csv').addEventListener('click',async()=>{
      if(!state.rows.length){alert('Нет данных');return;}
      try{ await CSV.export(); }
      catch(e){ console.error(e); showToast('Не удалось экспортировать CSV','error',2600); }
    });
  },
  bindClear() {
    document.getElementById('btn-clear-storage').addEventListener('click',()=>{
      if(confirm('Очистить все данные и настройки?')){
        HistoryManager.checkpoint('очистка данных');
        Storage.clear(); state.rows=[]; state.diagnostics={sources:[],sheets:[],rowsPerSheet:{},detectedColumns:{},missingColumns:{},warnings:[],registryCount:0,csvImportCount:0,localStorageCount:0};
        state.employees=[];
        App.populateFilterDropdowns(); App.refreshAll(); App.updateTopbarBadge();
      }
    });
  },
  bindSave() { document.getElementById('btn-save').addEventListener('click',()=>forceSave()); },
  bindAddRow() { document.getElementById('btn-add-row').addEventListener('click',()=>RegistryView.addRow()); },
  bindUndoRedo() {
    const undoBtn=document.getElementById('btn-undo');
    const redoBtn=document.getElementById('btn-redo');
    if(undoBtn) undoBtn.addEventListener('click',()=>HistoryManager.undo());
    if(redoBtn) redoBtn.addEventListener('click',()=>HistoryManager.redo());
    document.addEventListener('keydown',e=>{
      const target=e.target;
      const mod=e.ctrlKey||e.metaKey;
      if(!mod) return;
      const registrySection=document.getElementById('section-registry');
      if(state.activeSection!=='registry'&&!(registrySection&&target instanceof Node&&registrySection.contains(target))) return;
      if(e.key.toLowerCase()==='z'&&!e.shiftKey){e.preventDefault();HistoryManager.undo();return;}
      if((e.key.toLowerCase()==='z'&&e.shiftKey)||e.key.toLowerCase()==='y'){e.preventDefault();HistoryManager.redo();}
    });
    HistoryManager.syncButtons();
  },
  bindColToggle() {
    document.getElementById('btn-toggle-cols').addEventListener('click',()=>{
      const p=document.getElementById('col-toggle-panel'); p.classList.toggle('hidden'); if(!p.classList.contains('hidden'))RegistryView.renderColTogglePanel();
    });
  },
  bindRegistrySettings() {
    document.getElementById('btn-registry-settings').addEventListener('click',()=>{
      const p=document.getElementById('registry-settings-panel');
      p.classList.toggle('hidden');
      if(!p.classList.contains('hidden')) RegistryView.renderSettingsPanel();
    });
  },
  bindColOrderReset() {
    document.getElementById('btn-reset-col-order').addEventListener('click',()=>{
      HistoryManager.checkpoint('сброс порядка столбцов');
      state.colOrder=REGISTRY_COLS.map(c=>c.key);
      state.colWidths={};
      syncColumnSettings();
      Storage.save();
      RegistryView.render();
    });
  },
  bindGanttModes() {
    const legacyModes=new Set(['compact','detailed','epics','arrows','ultra']);
    if(legacyModes.has(state.ganttMode)){
      state.ganttMode=state.ganttMode==='arrows'?'arrowsNew':'detailedTasks';
    }
    if(!['detailedTasks','arrowsNew'].includes(state.ganttMode)) state.ganttMode='detailedTasks';

    const applyModeUi=()=>{
      const dtBtn=document.getElementById('gantt-mode-detailed-tasks');
      const anBtn=document.getElementById('gantt-mode-arrows-new');
      if(dtBtn) dtBtn.classList.toggle('active',state.ganttMode==='detailedTasks');
      if(anBtn) anBtn.classList.toggle('active',state.ganttMode==='arrowsNew');
      const arrowsCtrl=document.getElementById('gantt-arrows-controls');
      if(arrowsCtrl) arrowsCtrl.style.display=state.ganttMode==='arrowsNew'?'flex':'none';
    };
    App.syncGanttModeUi=applyModeUi;
    applyModeUi();

    document.getElementById('gantt-mode-detailed-tasks')?.addEventListener('click',()=>{
      state.ganttMode='detailedTasks';
      applyModeUi();
      Storage.save();
      GanttView.renderChart();
    });
    document.getElementById('gantt-mode-arrows-new')?.addEventListener('click',()=>{
      state.ganttMode='arrowsNew';
      applyModeUi();
      Storage.save();
      GanttView.renderChart();
    });
  },
  bindTimelineModes() {
    const summaryBtn=document.getElementById('timeline-mode-summary');
    const detailedBtn=document.getElementById('timeline-mode-detailed');
    if(!summaryBtn||!detailedBtn) return;
    const sync=()=>{
      summaryBtn.classList.toggle('active',state.timelineMode!=='detailed');
      detailedBtn.classList.toggle('active',state.timelineMode==='detailed');
    };
    summaryBtn.addEventListener('click',()=>{ state.timelineMode='summary'; sync(); if(state.activeSection==='timeline')TimelineView.render(); });
    detailedBtn.addEventListener('click',()=>{ state.timelineMode='detailed'; sync(); if(state.activeSection==='timeline')TimelineView.render(); });
    sync();
  },
  bindSummaryModes() {
    const brief=document.getElementById('summary-mode-brief');
    const superBeautiful=document.getElementById('summary-mode-super-beautiful');
    if(!brief||!superBeautiful) return;
    const sync=()=>{
      brief.classList.toggle('active',state.summaryMode==='brief');
      superBeautiful.classList.toggle('active',state.summaryMode==='superBeautiful');
    };
    brief.addEventListener('click',()=>{
      state.summaryMode='brief';
      Storage.save();
      sync();
      if(state.activeSection==='summary') SummaryView.render();
    });
    superBeautiful.addEventListener('click',()=>{
      state.summaryMode='superBeautiful';
      Storage.save();
      sync();
      if(state.activeSection==='summary') SummaryView.render();
    });
    if(!['brief','superBeautiful'].includes(state.summaryMode)) state.summaryMode='brief';
    sync();
  },
  bindPodlozhkaModes() {
    const summary=document.getElementById('podlozhka-mode-summary');
    const detailed=document.getElementById('podlozhka-mode-detailed');
    if(!summary||!detailed) return;
    const sync=()=>{
      summary.classList.toggle('active',state.podlozhkaMode!=='detailed');
      detailed.classList.toggle('active',state.podlozhkaMode==='detailed');
    };
    summary.addEventListener('click',()=>{
      state.podlozhkaMode='summary';
      Storage.save();
      sync();
      if(state.activeSection==='podlozhka') PodlozhkaView.render();
    });
    detailed.addEventListener('click',()=>{
      state.podlozhkaMode='detailed';
      Storage.save();
      sync();
      if(state.activeSection==='podlozhka') PodlozhkaView.render();
    });
    sync();
  },
  bindPodlozhkaGroup() {
    const sel=document.getElementById('podlozhka-group');
    if(!sel) return;
    sel.value=state.podlozhkaGroup||'team';
    sel.addEventListener('change',e=>{ state.podlozhkaGroup=e.target.value; if(state.activeSection==='podlozhka')PodlozhkaView.render(); });
  },
  bindFullscreenRegistry() {
    const btn=document.getElementById('btn-fullscreen-registry');
    btn.addEventListener('click',()=>{
      document.body.classList.toggle('registry-fullscreen');
      btn.textContent=document.body.classList.contains('registry-fullscreen')?'✕ Выйти':'⛶';
      btn.title=document.body.classList.contains('registry-fullscreen')?'Выйти из полного экрана':'Полный экран';
    });
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('registry-fullscreen')){document.body.classList.remove('registry-fullscreen');btn.textContent='⛶';}});
  },
  bindFilterToggle() {
    const btn=document.getElementById('btn-toggle-filters');
    btn.addEventListener('click',()=>{
      document.body.classList.toggle('filters-hidden');
      btn.textContent=document.body.classList.contains('filters-hidden')?'▼ Фильтры':'▲ Фильтры';
    });
  },
  bindPresetsCollapse() {
    const btn=document.getElementById('btn-toggle-presets');
    if(!btn) return;
    btn.addEventListener('click',()=>{
      state.presetsCollapsed=!state.presetsCollapsed;
      App.applyPresetsCollapsed();
      Storage.save();
    });
  },
  applyPresetsCollapsed() {
    document.body.classList.toggle('presets-collapsed',!!state.presetsCollapsed);
  },
  bindEmployees() {
    const addBtn=document.getElementById('btn-add-employee');
    if(addBtn) addBtn.addEventListener('click',()=>{
      state.employees.push(EmployeeFactory.create({sourceType:'manual'}));
      Storage.save();
      App.populateFilterDropdowns();
      if(state.activeSection==='employees') EmployeesView.render();
      showToast('Сотрудник добавлен');
    });
    const importCsv=document.getElementById('input-employees-csv');
    if(importCsv){
      importCsv.addEventListener('change',e=>{
        const f=e.target.files[0]; if(!f)return;
        const r=new FileReader();
        r.onload=ev=>{ EmployeesView.importCSV(ev.target.result); e.target.value=''; };
        r.readAsText(f,'utf-8');
      });
    }
    const importXlsx=document.getElementById('input-employees-xlsx');
    if(importXlsx){
      importXlsx.addEventListener('change',e=>{
        const f=e.target.files[0]; if(!f)return;
        const r=new FileReader();
        r.onload=ev=>{ EmployeesView.importXLSX(new Uint8Array(ev.target.result)); e.target.value=''; };
        r.readAsArrayBuffer(f);
      });
    }
  },
  bindCrossTabStorageSync() {
    if(App._storageSyncBound) return;
    App._storageSyncBound=true;
    window.addEventListener('storage',(e)=>{
      if(!e||(e.key!==STORAGE_KEY&&e.key!==SETTINGS_KEY)) return;
      showToast('Данные были изменены в другой вкладке. Обновите страницу, чтобы синхронизироваться.','error',3800);
    });
  },
  bindGantt2Controls() {
    const zoomIn=document.getElementById('gantt2-zoom-in');
    const zoomOut=document.getElementById('gantt2-zoom-out');
    const todayBtn=document.getElementById('gantt2-today-btn');
    const teamSel=document.getElementById('gantt2-team-filter');
    const showDeps=document.getElementById('gantt2-show-deps');
    if(zoomIn) zoomIn.addEventListener('click',()=>{ GanttV2.setZoom(GanttV2.getZoom()*1.35); });
    if(zoomOut) zoomOut.addEventListener('click',()=>{ GanttV2.setZoom(GanttV2.getZoom()/1.35); });
    if(todayBtn) todayBtn.addEventListener('click',()=>{
      const scroller=document.querySelector('#gantt2-wrap .g2-scroller');
      const todayLine=scroller&&scroller.querySelector('.g2-today');
      if(scroller&&todayLine){
        const left=parseInt(todayLine.style.left,10)||0;
        scroller.scrollTo({left:Math.max(0,left-200),behavior:'smooth'});
      }
    });
    if(teamSel) teamSel.addEventListener('change',e=>{
      state.gantt2Team=e.target.value;
      Storage.save();
      if(state.activeSection==='gantt'&&state.ganttMode==='arrowsNew') GanttV2.render();
      else if(state.activeSection==='gantt2') GanttV2.render();
    });
    if(showDeps) showDeps.addEventListener('change',e=>{
      state.gantt2ShowDeps=e.target.checked;
      Storage.save();
      if(state.activeSection==='gantt'&&state.ganttMode==='arrowsNew') GanttV2.renderChart();
      else if(state.activeSection==='gantt2') GanttV2.renderChart();
    });
  },
  renderLegend(targetId,items) {
    const el=document.getElementById(targetId);
    if(!el) return;
    if(!items||!items.length){el.innerHTML='';el.style.display='none';return;}
    el.style.display='';
    el.innerHTML=items.map(item=>{
      if(item.color){
        return `<span class="legend-item-inline"><span class="legend-dot" style="background:${item.color}"></span>${Utils.escapeHtml(item.label)}</span>`;
      }
      return `<span class="legend-item-inline">${Utils.escapeHtml(item.label)}</span>`;
    }).join('');
  },
  renderSectionLegends(section) {
    const legendsBySection={
      dashboard:[
        {color:'#4f46e5',label:'Релизы: 1.20 / 1.21 / 1.22'},
        {color:'#dc2626',label:'Красный: блокеры и овертайм'},
        {color:'#f59e0b',label:'Жёлтый: требует подтверждения'},
        {color:'#059669',label:'Зелёный: в scope / сделано'},
      ],
      registry:[],
      gantt:[
        {color:'#4f46e5',label:'Линии зависимостей'},
        {color:'#dc2626',label:'Конфликт зависимости по срокам'},
        {label:'◎ Перетяните с задачи на задачу для связи'},
      ],
      gantt2:[
        {color:'#6366f1',label:'Плавные bezier-стрелки зависимостей'},
        {color:'#dc2626',label:'Красная стрелка: конфликт сроков'},
        {label:'⊕ Тяните с правого края эпика для связи'},
        {label:'Двойной клик по стрелке — удалить связь'},
      ],
      kanban:[
        {color:'#dc2626',label:'Красная рамка: блокер'},
        {color:'#f59e0b',label:'Жёлтая рамка: риск'},
        {color:'#9ca3af',label:'Полупрозрачность: сделано'},
      ],
      timeline:[
        {color:'#4f46e5',label:'Стадии релизов'},
        {color:'#059669',label:'Распределение работ'},
        {color:'#d97706',label:'Статусы scope'},
      ],
      podlozhka:[
        {color:'#dc2626',label:'Рисковые строки'},
        {color:'#059669',label:'Сделанные строки'},
        {label:'Режим «Детализированное» показывает видимые столбцы реестра'},
      ],
      employees:[
        {color:'#4f46e5',label:'Роли и команды как теги'},
        {color:'#dc2626',label:'OT: задачи сотрудника в овертайме'},
        {label:'Кнопка «Задачи» раскрывает связанный список из реестра'},
      ],
      summary:[
        {color:'#4f46e5',label:'Ключевые KPI для CEO'},
        {color:'#059669',label:'Прогресс выполнения'},
        {color:'#dc2626',label:'Точки риска и блокировки'},
      ],
      metrics:[
        {color:'#4f46e5',label:'SLA сроков и зависимостное давление'},
        {color:'#14b8a6',label:'Scope mix и портфель типов работ'},
        {color:'#ef4444',label:'Операционные и качественные сигналы'},
      ],
      insights:[
        {color:'#dc2626',label:'High: критический сигнал'},
        {color:'#f59e0b',label:'Medium: требует внимания'},
        {color:'#22c55e',label:'Low: наблюдение'},
      ],
      diagnostics:[
        {label:'Показывает источник данных и качество импорта'},
      ],
    };
    const targetMap={
      dashboard:'dashboard-legend',
      registry:'registry-legend',
      gantt:'gantt-legend-extra',
      gantt2:'gantt2-legend',
      kanban:'kanban-legend',
      timeline:'timeline-legend-extra',
      podlozhka:'podlozhka-legend',
      employees:'employees-legend',
      summary:'summary-legend',
      metrics:'metrics-legend',
      insights:'insights-legend',
      diagnostics:'diagnostics-legend',
    };
    Object.entries(targetMap).forEach(([key,id])=>App.renderLegend(id,key===section?legendsBySection[key]||[]:[]) );
  },
  populateFilterDropdowns() { FiltersUI.populateDropdowns(); },
  renderSection(s) {
    if(App.syncGanttModeUi) App.syncGanttModeUi();
    if(s==='dashboard') DashboardView.render();
    else if(s==='registry') RegistryView.render();
    else if(s==='gantt') GanttView.render();
    else if(s==='gantt2') GanttV2.render();
    else if(s==='kanban') KanbanView.render();
    else if(s==='timeline') TimelineView.render();
    else if(s==='podlozhka') PodlozhkaView.render();
    else if(s==='employees') EmployeesView.render();
    else if(s==='summary') SummaryView.render();
    else if(s==='metrics') MetricsView.render();
    else if(s==='insights') InsightsView.render();
    else if(s==='diagnostics') DiagnosticsView.render();
    else if(s==='jira-pulse') JiraPulse.render();
    else if(s==='actions') ActionLayer.render();
    else if(s==='ai') AIView.render();
    else if(s==='ai-ceo') AICeoView.render();
    else if(s==='integrations') IntegrationsView.render();
    App.renderSectionLegends(s);
    if(typeof LLMAssistant!=='undefined'&&LLMAssistant.updateQuickPrompts){
      LLMAssistant.updateQuickPrompts();
    }
    HistoryManager.syncButtons();
    App.animateSection(s);
  },
  animateSection(section) {
    const root=document.getElementById(`section-${section}`);
    if(!root) return;
    const now=Date.now();
    if(App._lastAnimAt&&(now-App._lastAnimAt)<260) return;
    App._lastAnimAt=now;
    const targets=[...root.querySelectorAll('.kpi-card, .summary-card, .data-table-wrap, .insight-item, .kanban-card, .gantt-row, .gar-row, .timeline-section, .diag-card, .employee-card, .metrics-card, .metrics-person, .metrics-signal, .view-legend .legend-item-inline, .preset-btn, .preset-role-btn, .ai-block, .ceo-card, .ceo-feed-item')].slice(0,48);
    const bars=[...root.querySelectorAll('.mini-progress > span')].slice(0,32);
    targets.forEach((el,idx)=>{
      el.classList.remove('ui-animate-item');
      el.style.animationDelay=`${Math.min(idx*10,150)}ms`;
    });
    bars.forEach((bar,idx)=>{
      bar.classList.remove('progress-animated');
      bar.style.animationDelay=`${Math.min(idx*14,170)}ms`;
    });
    requestAnimationFrame(()=>{
      targets.forEach(el=>el.classList.add('ui-animate-item'));
      bars.forEach(bar=>bar.classList.add('progress-animated'));
    });
    clearTimeout(App._animCleanupT);
    App._animCleanupT=setTimeout(()=>{
      targets.forEach(el=>{ el.classList.remove('ui-animate-item'); el.style.animationDelay=''; });
      bars.forEach(el=>{ el.classList.remove('progress-animated'); el.style.animationDelay=''; });
    },760);
  },
  refreshAll() { App.renderSection(state.activeSection); HistoryManager.syncButtons(); },
  refreshCurrentSection() { App.renderSection(state.activeSection); },
  refreshDashboardIfActive() { if(state.activeSection==='dashboard') DashboardView.render(); },
  updateTopbarBadge() {
    const b=document.getElementById('topbar-row-count');
    if(state.rows.length){b.textContent=state.rows.length+' задач';b.classList.remove('hidden');}
    else b.classList.add('hidden');
  },
  bindFilesDropdown() {
    const wrap=document.getElementById('files-dropdown-wrap');
    const btn=document.getElementById('btn-files-dropdown');
    const menu=document.getElementById('files-dropdown-menu');
    if(!btn||!menu) return;
    btn.addEventListener('click',(e)=>{
      e.stopPropagation();
      menu.classList.toggle('hidden');
      btn.classList.toggle('active',!menu.classList.contains('hidden'));
    });
    document.addEventListener('click',(e)=>{
      if(!wrap.contains(e.target)){
        menu.classList.add('hidden');
        btn.classList.remove('active');
      }
    });
    menu.querySelectorAll('input[type=file]').forEach(inp=>{
      inp.addEventListener('change',()=>{
        menu.classList.add('hidden');
        btn.classList.remove('active');
      });
    });
    document.getElementById('btn-export-csv')?.addEventListener('click',()=>{
      menu.classList.add('hidden'); btn.classList.remove('active');
    });
    document.getElementById('btn-clear-storage')?.addEventListener('click',()=>{
      menu.classList.add('hidden'); btn.classList.remove('active');
    });
  },
  bindSimMode() {
    const btn=document.getElementById('btn-sim-mode');
    if(btn) btn.addEventListener('click',()=>SimMode.toggle());
  },
  bindInsightActions() {
    document.addEventListener('click',(e)=>{
      const btn=e.target.closest('.insight-action-btn');
      if(!btn) return;
      const action=btn.dataset.action;
      const rows=FilterEngine.getFiltered();
      if(action==='assign_120'){
        const targets=rows.filter(r=>r.isUnassigned&&r.scopeStatus==='Да');
        applyBulkAction(targets.map(r=>r.id),'assign_release',{release:'120'});
      } else if(action==='confirm_scope'){
        const targets=rows.filter(r=>r.scopeStatus==='Требует подтверждения'&&(r.hasRelease120||r.hasRelease121||r.hasRelease122||r.hasOvertime));
        applyBulkAction(targets.map(r=>r.id),'set_scope',{scope:'Да'});
      } else if(action==='clear_blockers'){
        const targets=rows.filter(r=>r.blockingDependency&&(r.hasRelease120||r.hasRelease121));
        applyBulkAction(targets.map(r=>r.id),'clear_blocker',{});
      }
    });
  },
};

// ============================================================
// WINDOW REFS + BOOTSTRAP
// ============================================================
window.App            = App;
window.LLMAssistant   = LLMAssistant;
window.HistoryManager = HistoryManager;
window.showToast      = showToast;
window.ThemeUI        = ThemeUI;
window.RegistryView   = RegistryView;
window.BulkEditPanel  = BulkEditPanel;
window.ActionLayer    = ActionLayer;

subscribe(reason => {
  if (!App) return;
  if (reason==='import-csv'||reason==='import-xlsx'||reason==='restore') {
    App.populateFilterDropdowns(); App.refreshAll(); App.updateTopbarBadge();
  } else if (reason) {
    App.refreshAll();
  }
  // Refresh alert bar when data changes
  if (reason && reason !== 'chat_filter' && reason !== 'chat_filter_clear') {
    try { refreshAlerts(); } catch(_) {}
  }
});

document.addEventListener('DOMContentLoaded', () => App.init());
