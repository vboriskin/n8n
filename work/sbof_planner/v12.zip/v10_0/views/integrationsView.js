'use strict';
/* ============================================================
   INTEGRATIONS VIEW — v10_0
   Orchestrates the Integrations tab: render + sync + settings.
   Read-only for data rows — all mutations go through applyUpdates().
   ============================================================ */

import { state, notify }             from '../state.js';
import { Storage }                   from '../dataStore.js';
import { loadSettings, saveSettings, getConnectionStatus } from '../integrations/integrationsStore.js';
import { syncAllRows, verifyJira, verifyBitbucket, verifyConfluence } from '../integrations/integrationsSync.js';
import {
  renderIntegrationsPage, renderIntegrationsEmpty,
  renderSettingsModal,
} from '../integrations/integrationsRenderer.js';

/* ── Apply sync updates back to state.rows ────────────────── */
function applyUpdates(updates) {
  if (!updates || !updates.length) return 0;
  let changed = 0;
  updates.forEach(upd => {
    const row = state.rows.find(r => r.id === upd.id);
    if (!row) return;
    const KEYS = ['jiraStatus','jiraAssignee','jiraUpdatedAt','prUrl','prStatus','prUpdatedAt','docUrl','docTitle'];
    KEYS.forEach(k => { if (k in upd && upd[k] !== undefined) row[k] = upd[k]; });
    row.updatedAt = new Date().toISOString();
    changed++;
  });
  return changed;
}

/* ── Apply cross-filter ───────────────────────────────────── */
function applyCrossFilter(crossKey) {
  const f = state.filters;
  const activeRows = state.rows.filter(r => !r.isDone);
  const inRelease  = activeRows.filter(r => r.hasRelease120 || r.hasRelease121 || r.hasRelease122);
  const sevenDaysAgo = Date.now() - 7 * 24 * 3600 * 1000;
  let ids = [];

  if (crossKey === 'no-jira-assignee') ids = inRelease.filter(r => r.jiraKey && !r.jiraAssignee).map(r => r.id);
  if (crossKey === 'no-pr')            ids = inRelease.filter(r => r.jiraKey && !r.prUrl).map(r => r.id);
  if (crossKey === 'no-doc')           ids = inRelease.filter(r => r.jiraKey && !r.docUrl).map(r => r.id);
  if (crossKey === 'stalled')          ids = activeRows.filter(r => {
    if (!r.jiraKey || !r.jiraUpdatedAt) return false;
    try { return new Date(r.jiraUpdatedAt).getTime() < sevenDaysAgo; } catch(_) { return false; }
  }).map(r => r.id);

  if (!ids.length) { window.showToast?.('Нет задач для этого фильтра', 'info'); return; }

  // Store filtered ids as a search note and go to registry
  // Use the search to highlight — simplest cross-section approach
  f.search = ''; f.team = ''; f.scope = ''; f.release = '';
  f.onlyBlocking = false; f.onlyRisky = false; f.onlyDone = false;
  window.App?.goTo?.('registry');
  window.notify?.('cross_filter');
  window.showToast?.(`Показано ${ids.length} задач`);
}

/* ── Settings modal binding ───────────────────────────────── */
function bindSettingsModal() {
  const modal = document.getElementById('int-settings-modal');
  if (!modal) return;

  // Tab switching
  modal.querySelectorAll('.int-stab').forEach(btn => {
    btn.addEventListener('click', () => {
      modal.querySelectorAll('.int-stab').forEach(b => b.classList.remove('active'));
      modal.querySelectorAll('.int-stab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      modal.querySelector(`[data-panel="${btn.dataset.stab}"]`)?.classList.add('active');
    });
  });

  // Close
  const close = () => modal.remove();
  modal.querySelector('#int-modal-close')?.addEventListener('click', close);
  modal.addEventListener('click', e => { if (e.target === modal) close(); });

  // ── Jira ──────────────────────────────────────────────────
  modal.querySelector('#int-jira-save')?.addEventListener('click', () => {
    const patch = { jiraBaseUrl: modal.querySelector('#int-jira-url')?.value?.trim() || '' };
    const tok = modal.querySelector('#int-jira-token')?.value?.trim();
    if (tok) patch.jiraToken = tok;
    saveSettings(patch);
    const serverPatch = { jiraBaseUrl: patch.jiraBaseUrl };
    if (tok) serverPatch.jiraToken = tok;
    fetch('/api/jira/config', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(serverPatch) }).catch(()=>{});
    window.showToast?.('Jira настройки сохранены');
    close();
  });

  modal.querySelector('#int-jira-verify')?.addEventListener('click', async () => {
    const res_el = modal.querySelector('#int-jira-verify-result');
    const url = modal.querySelector('#int-jira-url')?.value?.trim() || '';
    const tok = modal.querySelector('#int-jira-token')?.value?.trim();
    const serverPatch = { jiraBaseUrl: url };
    if (tok) serverPatch.jiraToken = tok;
    await fetch('/api/jira/config', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(serverPatch) }).catch(()=>{});
    saveSettings({ jiraBaseUrl: url, ...(tok ? { jiraToken: tok } : {}) });
    res_el?.classList.remove('hidden');
    res_el.textContent = '⏳ Проверяем...';
    const r = await verifyJira();
    res_el.className = r.ok ? 'int-verify-result int-verify-ok' : 'int-verify-result int-verify-err';
    res_el.textContent = r.ok ? `✓ Подключено (${r.who})` : `✗ Ошибка: ${r.error}`;
  });

  // ── Bitbucket ─────────────────────────────────────────────
  modal.querySelector('#int-bb-save')?.addEventListener('click', () => {
    const patch = { bitbucketBaseUrl: modal.querySelector('#int-bb-url')?.value?.trim() || '' };
    const tok = modal.querySelector('#int-bb-token')?.value?.trim();
    if (tok) patch.bitbucketToken = tok;
    saveSettings(patch);
    const serverPatch = { bitbucketBaseUrl: patch.bitbucketBaseUrl };
    if (tok) serverPatch.bitbucketToken = tok;
    fetch('/api/jira/config', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(serverPatch) }).catch(()=>{});
    window.showToast?.('Bitbucket настройки сохранены');
    close();
  });

  modal.querySelector('#int-bb-verify')?.addEventListener('click', async () => {
    const bbUrl = modal.querySelector('#int-bb-url')?.value?.trim() || '';
    const bbTok = modal.querySelector('#int-bb-token')?.value?.trim();
    const serverPatch = { bitbucketBaseUrl: bbUrl };
    if (bbTok) serverPatch.bitbucketToken = bbTok;
    await fetch('/api/jira/config', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(serverPatch) }).catch(()=>{});
    const res_el = modal.querySelector('#int-bb-verify-result');
    res_el?.classList.remove('hidden');
    res_el.textContent = '⏳ Проверяем...';
    const r = await verifyBitbucket();
    res_el.className = r.ok ? 'int-verify-result int-verify-ok' : 'int-verify-result int-verify-err';
    res_el.textContent = r.ok ? `✓ Подключено (${r.who || 'OK'})` : `✗ Ошибка: ${r.error}`;
  });

  // ── Confluence ────────────────────────────────────────────
  modal.querySelector('#int-cf-save')?.addEventListener('click', () => {
    const patch = { confluenceBaseUrl: modal.querySelector('#int-cf-url')?.value?.trim() || '' };
    const tok = modal.querySelector('#int-cf-token')?.value?.trim();
    if (tok) patch.confluenceToken = tok;
    saveSettings(patch);
    const serverPatch = { confluenceBaseUrl: patch.confluenceBaseUrl };
    if (tok) serverPatch.confluenceToken = tok;
    fetch('/api/jira/config', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(serverPatch) }).catch(()=>{});
    window.showToast?.('Confluence настройки сохранены');
    close();
  });

  modal.querySelector('#int-cf-verify')?.addEventListener('click', async () => {
    const cfUrl = modal.querySelector('#int-cf-url')?.value?.trim() || '';
    const cfTok = modal.querySelector('#int-cf-token')?.value?.trim();
    const serverPatch = { confluenceBaseUrl: cfUrl };
    if (cfTok) serverPatch.confluenceToken = cfTok;
    await fetch('/api/jira/config', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(serverPatch) }).catch(()=>{});
    const res_el = modal.querySelector('#int-cf-verify-result');
    res_el?.classList.remove('hidden');
    res_el.textContent = '⏳ Проверяем...';
    const r = await verifyConfluence();
    res_el.className = r.ok ? 'int-verify-result int-verify-ok' : 'int-verify-result int-verify-err';
    res_el.textContent = r.ok ? `✓ Подключено (${r.who || 'OK'})` : `✗ Ошибка: ${r.error}`;
  });
}

/* ── Open settings modal ──────────────────────────────────── */
function openSettingsModal(activeTab) {
  document.getElementById('int-settings-modal')?.remove();
  const settings = loadSettings();
  const html = renderSettingsModal(settings);
  document.body.insertAdjacentHTML('beforeend', html);
  // Activate requested tab
  if (activeTab && activeTab !== 'jira') {
    const modal = document.getElementById('int-settings-modal');
    modal?.querySelectorAll('.int-stab').forEach(b => b.classList.remove('active'));
    modal?.querySelectorAll('.int-stab-panel').forEach(p => p.classList.remove('active'));
    modal?.querySelector(`[data-stab="${activeTab}"]`)?.classList.add('active');
    modal?.querySelector(`[data-panel="${activeTab}"]`)?.classList.add('active');
  }
  bindSettingsModal();
}

/* ═══════════════════════════════════════════════════════════
   MAIN VIEW
   ═══════════════════════════════════════════════════════════ */
export const IntegrationsView = {
  _root: null,

  render() {
    const root = document.getElementById('section-integrations');
    if (!root) return;
    this._root = root;

    const rows = state.rows;
    const status   = getConnectionStatus();
    const settings = loadSettings();

    if (!rows || !rows.length) {
      root.innerHTML = `<div id="int-root" class="view-root">${renderIntegrationsEmpty()}</div>`;
    } else {
      root.innerHTML = `<div id="int-root" class="view-root">${renderIntegrationsPage(rows, status, settings)}</div>`;
    }
    this._bindEvents(root);
  },

  /* ── event delegation ──────────────────────────────────── */
  _bindEvents(root) {
    root.addEventListener('click', async e => {
      const el = e.target.closest('[data-int-action]');
      if (!el) return;
      const action = el.dataset.intAction;

      // Settings modal
      if (action === 'settings') {
        openSettingsModal(el.dataset.tab || 'jira');
        return;
      }

      // Filter: go to registry with integration filter
      if (action === 'filter') {
        const filterType = el.dataset.filter;
        this._applyIntFilter(filterType);
        return;
      }

      // Cross-source filter
      if (action === 'cross-filter') {
        applyCrossFilter(el.dataset.cross);
        return;
      }

      // Cross explain → chat
      if (action === 'cross-explain') {
        const msg = {
          'no-jira-assignee': 'Объясни риски задач в релизе без Jira Assignee',
          'no-pr':            'Объясни риски задач в релизе без Pull Request',
          'no-doc':           'Объясни риски задач без документации в Confluence',
          'stalled':          'Объясни что делать с задачами которые давно не обновлялись в Jira',
        }[el.dataset.cross] || 'Объясни эту проблему';
        try {
          const input = document.getElementById('assistant-input');
          if (input) { input.value = msg; input.dispatchEvent(new Event('input')); document.getElementById('assistant-btn-send')?.click(); }
          else document.getElementById('assistant-fab')?.click();
        } catch(_) {}
        return;
      }

      // Sync all
      if (e.target.id === 'int-sync-all-btn' || e.target.closest('#int-sync-all-btn')) {
        await this._syncAll();
        return;
      }
    });
  },

  /* ── Registry filter helper ───────────────────────────── */
  _applyIntFilter(type) {
    const f = state.filters;
    f.search = ''; f.team = ''; f.scope = ''; f.release = '';
    f.onlyBlocking = false; f.onlyRisky = false; f.onlyDone = false;
    if (type === 'jira')       f.search = 'jira:';        // registry search handles this
    if (type === 'bitbucket')  f.search = '';
    if (type === 'confluence') f.search = '';
    window.App?.goTo?.('registry');
    notify('int_filter');
    window.showToast?.('Переход в реестр');
  },

  /* ── Sync all rows ────────────────────────────────────── */
  async _syncAll() {
    const btn = document.getElementById('int-sync-all-btn');
    const progressEl = document.getElementById('int-sync-progress');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Синхронизация...'; }
    if (progressEl) { progressEl.classList.remove('hidden'); progressEl.textContent = 'Запрос данных...'; }

    try {
      const result = await syncAllRows(state.rows, {
        onProgress: (done, total) => {
          if (progressEl) progressEl.textContent = `Обработано ${done} / ${total} задач...`;
        },
      });

      if (result.updates.length) {
        const changed = applyUpdates(result.updates);
        Storage.save();
        notify('integrations_sync');
        window.showToast?.(`✓ Синхронизировано: ${changed} задач обновлено`);
        this.render(); // re-render with fresh data
      } else if (!result.synced) {
        window.showToast?.('Нет задач с Jira Key — нечего синхронизировать', 'info');
      } else {
        window.showToast?.('Данные актуальны', 'info');
      }
    } catch(e) {
      console.warn('[IntegrationsView] Sync error:', e);
      window.showToast?.(`Ошибка синхронизации: ${e.message}`, 'error');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = '↺ Обновить данные интеграций'; }
      if (progressEl) { progressEl.classList.add('hidden'); }
    }
  },
};

/* ── Expose settings modal globally ────────────────────────
   So the topbar "Интеграции" button can open it without
   requiring a full view render. ─────────────────────────── */
export function openIntegrationsSettings(tab) {
  openSettingsModal(tab || 'jira');
}
