'use strict';
/* ============================================================
   PORTFOLIO PULSE — v11 (read-only)
   Operational portfolio overview across multiple Jira project keys.
   MVP scope (per spec section 15):
     · Jira fetch + parse
     · participant cards ("В работе сейчас", "Сделал вчера", "Висят > N")
     · "Без исполнителя" card
     · basic insights
     · projectKey switcher (All + chips)
     · skeleton loading + per-PK error cards

   NOT in MVP (placeholders, can be added later):
     · Bitbucket commits / PR aggregation per participant
     · Confluence page edits aggregation
     · sprint/backlog/metrics deep tabs (sec. 7-10)

   No mutation, no API writes. UI never touches Jira directly —
   server proxy /api/integrations/portfolio-pulse does the work.
   ============================================================ */

import { Utils } from '../utils.js';
import { loadSettingsRaw } from './integrationsStore.js';

const esc  = (s) => Utils.escapeHtml(String(s ?? ''));
const trunc = (s, n) => Utils.truncate(String(s||''), n||60);

/* ── Time windows ────────────────────────────────────────── */

function _todayStart()    { const d = new Date(); d.setHours(0,0,0,0); return d.getTime(); }
function _yesterdayStart() { return _todayStart() - 24*3600*1000; }
function _twoDaysAgoStart(){ return _todayStart() - 48*3600*1000; }
function _hoursAgo(h)     { return Date.now() - h*3600*1000; }

function _ts(s) { if (!s) return 0; const t = Date.parse(s); return Number.isFinite(t) ? t : 0; }

/* ── Terminal-status heuristics (RU + EN) ────────────────── */

const TERMINAL_RX = /^(done|closed|resolved|complete|completed|cancelled|canceled|won['’]?t.?do|готово|закрыт|закрыто|выполнен|выполнено|решен|решено|снят|снято|отмен)/i;

function isTerminalStatus(name) {
  if (!name) return false;
  return TERMINAL_RX.test(String(name).trim());
}

/* ── User identity helpers ───────────────────────────────── */

function userKey(u) {
  if (!u) return '';
  return String(u.accountId || u.key || u.name || u.emailAddress || u.displayName || '').toLowerCase();
}
function userLabel(u) {
  if (!u) return '—';
  return u.displayName || u.name || u.emailAddress || 'Аноним';
}

/* ============================================================
   FETCHER — calls server endpoint
   ============================================================ */

export async function fetchPulseData({ projectKeys, signal } = {}) {
  const body = projectKeys && projectKeys.length ? { projectKeys } : {};
  const res  = await fetch('/api/integrations/portfolio-pulse', {
    method:  'POST',
    signal,
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
  return json;  // { reports: [{projectKey, issues, error?}], fetchedAt, projectKeys }
}

/* ============================================================
   ANALYSER — turns raw Jira issues into a pulse model
   Output:
     {
       fetchedAt, projectKeys[], errors[{pk,error}],
       participants: [{ key, label, projects[], issuesNow[], doneYesterday[],
                        doneDayBefore[], stale[], commentsRecent[],
                        loggedYesterdaySec, badges }],
       unassigned: [issues],
       insights: [{severity, msg, target?}],
       totals: { issuesByPk[pk]:n, terminal, active },
     }
   ============================================================ */

const STALE_DAYS_DEFAULT = 7;

export function analysePulse(rawReports, opts = {}) {
  const staleDays = opts.staleDays || STALE_DAYS_DEFAULT;
  const yStart = _yesterdayStart();
  const tStart = _todayStart();
  const dbStart = _twoDaysAgoStart();
  const win48  = _hoursAgo(48);

  const out = {
    fetchedAt: rawReports?.fetchedAt || new Date().toISOString(),
    projectKeys: rawReports?.projectKeys || [],
    errors: [],
    participants: [],   // sorted later
    unassigned: [],
    insights: [],
    totals: { issuesByPk: {}, terminal: 0, active: 0 },
  };

  const userMap = new Map();   // userKey → participant
  const ensureUser = (u, projectKey) => {
    const k = userKey(u);
    if (!k) return null;
    let p = userMap.get(k);
    if (!p) {
      p = {
        key: k, label: userLabel(u),
        avatar: u?.avatarUrls?.['24x24'] || u?.avatarUrls?.['32x32'] || '',
        projects: new Set(),
        issuesNow: [], doneYesterday: [], doneDayBefore: [], stale: [],
        commentsRecent: [], loggedYesterdaySec: 0,
        badges: { commits48h: 0, pr48h: 0, conf48h: 0 },
      };
      userMap.set(k, p);
    }
    if (projectKey) p.projects.add(projectKey);
    return p;
  };

  // Walk issues across all project reports
  for (const report of (rawReports?.reports || [])) {
    if (report.error) {
      out.errors.push({ projectKey: report.projectKey, error: report.error });
      continue;
    }
    const pk = report.projectKey;
    out.totals.issuesByPk[pk] = (report.issues || []).length;

    for (const issue of (report.issues || [])) {
      const f = issue.fields || {};
      const status   = f.status?.name || '';
      const terminal = isTerminalStatus(status);
      if (terminal) out.totals.terminal++; else out.totals.active++;

      const slim = _slimIssue(issue, pk);
      const assignee = f.assignee || null;

      // 6.5: unassigned card  (only active items)
      if (!assignee && !terminal) out.unassigned.push(slim);

      const user = assignee ? ensureUser(assignee, pk) : null;

      // 4.1 In progress now
      if (user && !terminal) user.issuesNow.push(slim);

      // 4.2 / 4.3 — walk changelog to detect "moved into terminal status" yesterday / day-before-yesterday
      const histories = issue.changelog?.histories || [];
      for (const h of histories) {
        const t = _ts(h.created);
        if (!t) continue;
        const movedToTerminal = (h.items || []).some(it =>
          it.field === 'status' && isTerminalStatus(it.toString || it.to || ''));
        if (!movedToTerminal) continue;
        const moverU = h.author && ensureUser(h.author, pk);
        if (!moverU) continue;
        if (t >= yStart && t < tStart) moverU.doneYesterday.push(slim);
        else if (t >= dbStart && t < yStart) moverU.doneDayBefore.push(slim);
      }

      // 4.4 Comments per author within 48h
      const comments = f.comment?.comments || [];
      for (const c of comments) {
        const t = _ts(c.created);
        if (!t || t < win48) continue;
        const author = c.author && ensureUser(c.author, pk);
        if (!author) continue;
        author.commentsRecent.push({ text: trunc(c.body || '', 140), at: c.created, issue: slim });
      }

      // logged-time yesterday (sum of worklog entries started yesterday)
      const wls = f.worklog?.worklogs || [];
      for (const wl of wls) {
        const t = _ts(wl.started);
        if (!t || t < yStart || t >= tStart) continue;
        const uu = wl.author && ensureUser(wl.author, pk);
        if (!uu) continue;
        uu.loggedYesterdaySec += Number(wl.timeSpentSeconds || 0);
      }

      // 4.6 Stale (active, no update for >= staleDays)
      if (user && !terminal) {
        const upd = _ts(f.updated);
        if (upd && (Date.now() - upd) >= staleDays * 24 * 3600 * 1000) {
          user.stale.push({ ...slim, daysIdle: Math.floor((Date.now() - upd) / (24*3600*1000)) });
        }
      }
    }
  }

  // Convert sets to arrays + sort participants by activity
  for (const p of userMap.values()) {
    p.projects = Array.from(p.projects);
    out.participants.push(p);
  }
  out.participants.sort((a, b) =>
    (b.issuesNow.length + b.doneYesterday.length) - (a.issuesNow.length + a.doneYesterday.length));

  // Sort unassigned by oldest update
  out.unassigned.sort((a, b) => _ts(a.updated) - _ts(b.updated));

  // ── Insights (basic MVP set) ─────────────────────────────
  for (const [pk, n] of Object.entries(out.totals.issuesByPk)) {
    if (!n) out.insights.push({ severity: 'warning', msg: `Пространство ${pk} пустое или недоступно`, target: pk });
  }
  if (out.unassigned.length) {
    out.insights.push({ severity: 'warning', msg: `${out.unassigned.length} активных задач без исполнителя` });
  }
  for (const p of out.participants) {
    if (p.issuesNow.length > 3) {
      out.insights.push({ severity: 'warning', msg: `${p.label}: WIP > 3 (${p.issuesNow.length})`, target: p.key });
    }
    if (p.issuesNow.length === 0 && p.doneYesterday.length === 0 && p.commentsRecent.length === 0) {
      out.insights.push({ severity: 'info', msg: `${p.label}: тишина за 48ч`, target: p.key });
    }
    if (p.stale.length) {
      out.insights.push({ severity: 'info', msg: `${p.label}: ${p.stale.length} зависших задач`, target: p.key });
    }
  }
  for (const e of out.errors) {
    out.insights.push({ severity: 'critical', msg: `Сбой проекта ${e.projectKey}: ${e.error}`, target: e.projectKey });
  }

  return out;
}

function _slimIssue(issue, pk) {
  const f = issue.fields || {};
  return {
    key:        issue.key,
    pk:         pk,
    summary:    f.summary || '',
    type:       f.issuetype?.name || '',
    priority:   f.priority?.name || '',
    status:     f.status?.name || '',
    statusCat:  f.status?.statusCategory?.key || '',
    assignee:   f.assignee?.displayName || '',
    parentKey:  f.parent?.key || '',
    parentSum:  f.parent?.fields?.summary || '',
    duedate:    f.duedate || '',
    updated:    f.updated || '',
  };
}

/* ============================================================
   RENDERER
   ============================================================ */

export function renderSkeleton() {
  return `
    <div class="pp-skeleton">
      <div class="pp-skel-line"></div>
      <div class="pp-skel-card"></div>
      <div class="pp-skel-card"></div>
      <div class="pp-skel-card"></div>
    </div>`;
}

export function renderEmpty(reason) {
  return `
    <div class="pp-empty">
      <div class="pp-empty-icon">📡</div>
      <div class="pp-empty-title">Нет данных Portfolio Pulse</div>
      <div class="pp-empty-sub">${esc(reason || 'Укажите ключи проектных пространств в настройках интеграций («⚙ Настройки → Интеграции → Jira»).')}</div>
    </div>`;
}

export function renderHeader(model, activePk) {
  const pks = model.projectKeys || [];
  const fetchedAt = model.fetchedAt ? new Date(model.fetchedAt).toLocaleString('ru') : '—';
  const errCount = (model.errors || []).length;
  return `
    <div class="pp-header">
      <div class="pp-header-row">
        <h3 class="pp-title">📡 Portfolio Pulse</h3>
        <div class="pp-header-meta">
          ${errCount ? `<span class="pp-err-pill" title="Ошибки в проектных пространствах">⚠ ${errCount} ошиб.</span>` : ''}
          <span class="pp-fetched">обновлено: ${esc(fetchedAt)}</span>
          <button class="int-btn int-btn-ghost int-btn-xs" id="pp-refresh-btn">↺ Обновить</button>
        </div>
      </div>
      <div class="pp-pk-chips">
        <button class="pp-pk-chip ${!activePk ? 'pp-pk-active' : ''}" data-pk="">Все</button>
        ${pks.map(pk => `<button class="pp-pk-chip ${activePk===pk?'pp-pk-active':''}" data-pk="${esc(pk)}">${esc(pk)}<span class="pp-pk-count">${model.totals?.issuesByPk?.[pk] || 0}</span></button>`).join('')}
      </div>
    </div>`;
}

function _badge(label, value, kind='neutral') {
  return `<span class="pp-badge pp-badge-${kind}" title="${esc(label)}">${esc(label)}: <b>${esc(String(value))}</b></span>`;
}

function _issueChip(it) {
  const tooltip = `${it.status || ''} · ${it.type || ''}${it.priority ? ' · '+it.priority : ''}${it.duedate ? ' · до ' + it.duedate : ''}`;
  const subtitle = it.parentKey ? `<span class="pp-issue-parent" title="Родитель: ${esc(it.parentKey)} ${esc(it.parentSum)}">↪ ${esc(it.parentKey)}</span>` : '';
  return `
    <div class="pp-issue" title="${esc(tooltip)}">
      <span class="pp-issue-pk" title="Project key">${esc(it.pk||'')}</span>
      <span class="pp-issue-key">${esc(it.key||'—')}</span>
      <span class="pp-issue-sum">${esc(trunc(it.summary, 80))}</span>
      ${subtitle}
      ${it.priority ? `<span class="pp-issue-prio pp-prio-${esc((it.priority||'').toLowerCase())}">${esc(it.priority)}</span>` : ''}
    </div>`;
}

function _groupByType(issues) {
  const groups = { story: [], task: [], bug: [], 'sub-task': [], other: [] };
  for (const it of issues) {
    const t = (it.type || '').toLowerCase();
    if (t.includes('bug') || t.includes('баг')) groups.bug.push(it);
    else if (t.includes('story') || t.includes('эпик') || t.includes('story')) groups.story.push(it);
    else if (t.includes('sub') || t.includes('подзадача')) groups['sub-task'].push(it);
    else if (t.includes('task') || t.includes('задача')) groups.task.push(it);
    else groups.other.push(it);
  }
  return groups;
}

function _renderGroup(label, items) {
  if (!items || !items.length) return '';
  return `
    <div class="pp-group">
      <div class="pp-group-title">${esc(label)} <span class="pp-group-count">${items.length}</span></div>
      <div class="pp-group-list">${items.map(_issueChip).join('')}</div>
    </div>`;
}

function _formatHrs(sec) {
  if (!sec) return '0h';
  const h = Math.round(sec / 3600 * 10) / 10;
  return h + 'h';
}

export function renderParticipantCard(p) {
  const groups = _groupByType(p.issuesNow);
  const hasNow   = p.issuesNow.length > 0;
  const hasYday  = p.doneYesterday.length > 0;
  const hasDby   = p.doneDayBefore.length > 0;
  const hasStale = p.stale.length > 0;
  const hasComm  = p.commentsRecent.length > 0;
  const projectChips = p.projects.map(pk => `<span class="pp-mini-pk" title="Project">${esc(pk)}</span>`).join('');

  const headerBadges = [
    p.loggedYesterdaySec ? _badge('logged вчера', _formatHrs(p.loggedYesterdaySec), 'ok') : '',
    p.badges?.commits48h ? _badge('commits 48ч', p.badges.commits48h, 'neutral') : '',
    p.badges?.pr48h      ? _badge('PR 48ч',      p.badges.pr48h,      'neutral') : '',
    p.badges?.conf48h    ? _badge('Confluence',  p.badges.conf48h,    'neutral') : '',
  ].filter(Boolean).join('');

  return `
    <div class="pp-card pp-card-user" data-user-key="${esc(p.key)}">
      <div class="pp-card-header">
        <div class="pp-card-id">
          ${p.avatar ? `<img class="pp-avatar" src="${esc(p.avatar)}" alt="" loading="lazy">` : '<span class="pp-avatar pp-avatar-fallback">👤</span>'}
          <div>
            <div class="pp-card-name">${esc(p.label)}</div>
            <div class="pp-card-projects">${projectChips}</div>
          </div>
        </div>
        <div class="pp-card-badges">${headerBadges}</div>
      </div>

      <details class="pp-section" ${hasNow ? 'open' : ''}>
        <summary>В работе сейчас <span class="pp-sect-count">${p.issuesNow.length}</span></summary>
        <div class="pp-sect-body">
          ${hasNow ? `${_renderGroup('Story',    groups.story)}
                     ${_renderGroup('Task',     groups.task)}
                     ${_renderGroup('Bug',      groups.bug)}
                     ${_renderGroup('Sub-task', groups['sub-task'])}
                     ${_renderGroup('Прочее',   groups.other)}` : '<div class="pp-empty-mini">— нет активных задач</div>'}
        </div>
      </details>

      <details class="pp-section" ${hasYday ? 'open' : ''}>
        <summary>Сделал вчера <span class="pp-sect-count">${p.doneYesterday.length}</span></summary>
        <div class="pp-sect-body">${hasYday ? p.doneYesterday.map(_issueChip).join('') : '<div class="pp-empty-mini">— нет</div>'}</div>
      </details>

      <details class="pp-section">
        <summary>Сделал позавчера <span class="pp-sect-count">${p.doneDayBefore.length}</span></summary>
        <div class="pp-sect-body">${hasDby ? p.doneDayBefore.map(_issueChip).join('') : '<div class="pp-empty-mini">— нет</div>'}</div>
      </details>

      ${hasComm ? `
      <details class="pp-section">
        <summary>Комментарии за 48ч <span class="pp-sect-count">${p.commentsRecent.length}</span></summary>
        <div class="pp-sect-body">
          ${p.commentsRecent.map(c => `
            <div class="pp-comment">
              <span class="pp-issue-pk">${esc(c.issue.pk||'')}</span>
              <span class="pp-issue-key">${esc(c.issue.key||'')}</span>
              <span class="pp-comment-text">${esc(trunc(c.text, 200))}</span>
              <span class="pp-comment-at" title="${esc(c.at||'')}">${esc((c.at||'').slice(11,16))}</span>
            </div>`).join('')}
        </div>
      </details>` : ''}

      <details class="pp-section pp-section-stale" ${hasStale ? 'open' : ''}>
        <summary>Висят &gt; 7 дней <span class="pp-sect-count">${p.stale.length}</span></summary>
        <div class="pp-sect-body">${hasStale
          ? p.stale.map(s => `
              <div class="pp-issue pp-issue-stale">
                <span class="pp-issue-pk">${esc(s.pk||'')}</span>
                <span class="pp-issue-key">${esc(s.key||'')}</span>
                <span class="pp-issue-sum">${esc(trunc(s.summary, 80))}</span>
                <span class="pp-issue-idle" title="Дней без обновления">${s.daysIdle}д</span>
              </div>`).join('')
          : '<div class="pp-empty-mini">— нет</div>'}</div>
      </details>
    </div>`;
}

export function renderUnassignedCard(model, activePk) {
  let items = model.unassigned || [];
  if (activePk) items = items.filter(it => it.pk === activePk);
  return `
    <div class="pp-card pp-card-unassigned">
      <div class="pp-card-header">
        <div class="pp-card-id">
          <span class="pp-avatar pp-avatar-empty" aria-hidden="true">∅</span>
          <div>
            <div class="pp-card-name">Без исполнителя</div>
            <div class="pp-card-projects"><span class="pp-mini-pk">${items.length} задач</span></div>
          </div>
        </div>
      </div>
      <div class="pp-card-body">
        ${items.length ? items.slice(0, 50).map(_issueChip).join('')
                       : '<div class="pp-empty-mini">— все задачи назначены</div>'}
        ${items.length > 50 ? `<div class="pp-more">…и ещё ${items.length - 50}</div>` : ''}
      </div>
    </div>`;
}

export function renderInsights(model) {
  if (!model.insights || !model.insights.length) {
    return `<div class="pp-insights"><div class="pp-empty-mini">✓ Сигналов нет — портфель в норме</div></div>`;
  }
  const items = model.insights.slice(0, 30).map(i => `
    <li class="pp-ins pp-ins-${esc(i.severity||'info')}">
      <span class="pp-ins-icon">${i.severity==='critical'?'🔴':i.severity==='warning'?'🟡':'🔵'}</span>
      <span class="pp-ins-msg">${esc(i.msg)}</span>
      ${i.target ? `<span class="pp-ins-target">${esc(i.target)}</span>` : ''}
    </li>`).join('');
  return `
    <div class="pp-insights">
      <div class="pp-insights-title">Insights</div>
      <ul class="pp-ins-list">${items}</ul>
    </div>`;
}

export function renderErrorCards(model) {
  if (!model.errors || !model.errors.length) return '';
  return `
    <div class="pp-errors">
      ${model.errors.map(e => `
        <div class="pp-err-card">
          <div class="pp-err-pk">⚠ ${esc(e.projectKey)}</div>
          <div class="pp-err-msg">${esc(e.error || 'Неизвестная ошибка')}</div>
        </div>`).join('')}
    </div>`;
}

/* Filter the model by active projectKey (returns a NEW shallow model) */
export function filterModel(model, activePk) {
  if (!activePk) return model;
  const inPk = (it) => it.pk === activePk;
  const participants = model.participants
    .map(p => ({
      ...p,
      issuesNow:      p.issuesNow.filter(inPk),
      doneYesterday:  p.doneYesterday.filter(inPk),
      doneDayBefore:  p.doneDayBefore.filter(inPk),
      stale:          p.stale.filter(inPk),
      commentsRecent: p.commentsRecent.filter(c => c.issue?.pk === activePk),
    }))
    .filter(p => p.issuesNow.length || p.doneYesterday.length || p.doneDayBefore.length || p.stale.length || p.commentsRecent.length);
  return { ...model, participants, unassigned: model.unassigned.filter(inPk) };
}

/* ============================================================
   ORCHESTRATOR (used by integrationsView)
   ============================================================ */

export const PortfolioPulse = {
  _model:     null,
  _activePk:  '',
  _container: null,
  _abort:     null,

  /** Returns project keys configured by the user, or [] if none. */
  getConfiguredKeys() {
    try {
      const cfg = loadSettingsRaw();
      return String(cfg.jiraProjectKeys || '').split(',').map(s => s.trim()).filter(Boolean);
    } catch (_) { return []; }
  },

  async render(container) {
    this._container = container;
    const pks = this.getConfiguredKeys();
    if (!pks.length) {
      container.innerHTML = renderEmpty(
        'Не указаны ключи Jira-пространств. Добавьте их в «⚙ Настройки → Интеграции → Jira → Ключи проектных пространств».');
      return;
    }
    container.innerHTML = renderSkeleton();
    try {
      if (this._abort) this._abort.abort();
      this._abort = new AbortController();
      const raw = await fetchPulseData({ projectKeys: pks, signal: this._abort.signal });
      this._model = analysePulse(raw);
      this._renderFull();
    } catch (e) {
      if (e?.name === 'AbortError') return;
      container.innerHTML = `<div class="pp-empty"><div class="pp-empty-icon">⚠</div>
        <div class="pp-empty-title">Не удалось получить данные</div>
        <div class="pp-empty-sub">${esc(e.message || 'Ошибка запроса')}</div></div>`;
    }
  },

  _renderFull() {
    if (!this._container || !this._model) return;
    const view = filterModel(this._model, this._activePk);
    const html = `
      ${renderHeader(this._model, this._activePk)}
      ${renderErrorCards(this._model)}
      ${renderInsights(view)}
      <div class="pp-cards">
        ${view.participants.map(renderParticipantCard).join('')}
        ${renderUnassignedCard(view, this._activePk)}
      </div>
    `;
    this._container.innerHTML = html;
    this._wire();
  },

  _wire() {
    const root = this._container;
    if (!root) return;
    root.querySelectorAll('.pp-pk-chip').forEach(c => {
      c.addEventListener('click', () => {
        this._activePk = c.dataset.pk || '';
        this._renderFull();
      });
    });
    root.querySelector('#pp-refresh-btn')?.addEventListener('click', () => this.render(root));
    // Insight "target" click — switch to that project
    root.querySelectorAll('.pp-ins-target').forEach(el => {
      el.addEventListener('click', () => {
        this._activePk = el.textContent.trim();
        this._renderFull();
      });
    });
  },
};

if (typeof window !== 'undefined') window.PortfolioPulse = PortfolioPulse;
