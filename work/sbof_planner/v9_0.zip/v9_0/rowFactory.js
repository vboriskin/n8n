'use strict';
/* ============================================================
   ROW FACTORY — v8_0 ES module
   ============================================================ */

import { Utils, nextId } from './utils.js';
import { RiskEngine } from './riskEngine.js';

export const RowFactory = {
  create(ov={}) {
    const now = new Date().toISOString();
    const row = {
      id: nextId(), sourceType:'', sourceSheet:'', team:'',
      category:'', epic:'',
      backend:'', frontend:'', analytics_estimate:'', testing_estimate:'', total_estimate:'',
      tasks:'', taskComment:'', teamDependency:'', risks:'',
      release120Raw:'', release121Raw:'', release122Raw:'', overtimeRaw:'',
      release120Types:[], release121Types:[], release122Types:[], overtimeTypes:[],
      hasRelease120:false, hasRelease121:false, hasRelease122:false, hasOvertime:false, isUnassigned:true,
      scopeStatus:'', role:'',
      blockingDependency:false, blockingDeadline:'',
      isDone:false, doneDate:'', backlogTypes:[], donePills:{},
      comment:'', dirty:true, riskFlags:[],
      workPeriodStart:'', workPeriodEnd:'', assignee:'', rowColor:'',
      createdAt:now, updatedAt:now,
    };
    Object.assign(row, ov);
    RowFactory.updateDerived(row);
    return row;
  },
  updateDerived(row) {
    // Keep work period consistent for timeline math.
    if (row.workPeriodStart && row.workPeriodEnd) {
      const s = new Date(row.workPeriodStart);
      const e = new Date(row.workPeriodEnd);
      if (!Number.isNaN(s.getTime()) && !Number.isNaN(e.getTime()) && s > e) {
        const tmp = row.workPeriodStart;
        row.workPeriodStart = row.workPeriodEnd;
        row.workPeriodEnd = tmp;
      }
    }
    row.hasRelease120 = !!(row.release120Types && row.release120Types.length);
    row.hasRelease121 = !!(row.release121Types && row.release121Types.length);
    row.hasRelease122 = !!(row.release122Types && row.release122Types.length);
    row.hasOvertime   = !!(row.overtimeTypes   && row.overtimeTypes.length);
    row.isUnassigned  = !row.hasRelease120 && !row.hasRelease121 && !row.hasRelease122 && !row.hasOvertime;
    row.release120Raw = (row.release120Types||[]).join(', ');
    row.release121Raw = (row.release121Types||[]).join(', ');
    row.release122Raw = (row.release122Types||[]).join(', ');
    row.overtimeRaw   = (row.overtimeTypes||[]).join(', ');
    RiskEngine.computeFlags(row);
    RiskEngine.computeRiskScore(row);
  },
};

export const EmployeeFactory = {
  create(ov={}) {
    const now = new Date().toISOString();
    const emp = {
      id: 'emp_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,7),
      fio: '',
      roles: '',
      teams: '',
      overtimeDays: [],
      weekdayReady: false,
      weekdayComment: '',
      sourceType: 'manual',
      createdAt: now,
      updatedAt: now,
    };
    Object.assign(emp, ov);
    EmployeeFactory.normalize(emp);
    return emp;
  },
  normalize(emp) {
    emp.fio = String(emp.fio || '').trim();
    emp.roles = String(emp.roles || '').split(/[|,]/).map(s=>s.trim()).filter(Boolean).join('|');
    emp.teams = String(emp.teams || '').split(/[|,]/).map(s=>s.trim()).filter(Boolean).join('|');
    if (!Array.isArray(emp.overtimeDays)) emp.overtimeDays = Utils.parseDateList(emp.overtimeDays);
    emp.overtimeDays = [...new Set(emp.overtimeDays.map(d=>Utils.parseDateish(d)||d).filter(Boolean))].sort();
    emp.weekdayReady = Utils.toBool(emp.weekdayReady,false);
    emp.weekdayComment = String(emp.weekdayComment || '').split(/[|,]/).map(s=>s.trim()).filter(Boolean).join('|');
    emp.updatedAt = new Date().toISOString();
  },
};
