// Static server + LLM proxy (Node built-ins only)
// Usage: node server.js [port]
'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = parseInt(process.argv[2], 10) || 8080;
const ROOT = __dirname;
const DEFAULT_GIGACHAT_BASE = process.env.GIGACHAT_API_BASE || 'https://gigachat.devices.sberbank.ru/api/v1';
const SERVER_ACCESS_TOKEN = process.env.GIGACHAT_ACCESS_TOKEN || '';
const MAX_BODY = 8 * 1024 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.csv': 'text/csv; charset=utf-8',
};

function writeJson(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

function readBody(req, limitBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limitBytes) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
    req.on('error', reject);
  });
}

function buildChatEndpoint(base) {
  const normalized = String(base || DEFAULT_GIGACHAT_BASE).replace(/\/+$/, '');
  if (normalized.endsWith('/chat/completions')) return normalized;
  if (normalized.endsWith('/v1')) return `${normalized}/chat/completions`;
  if (normalized.endsWith('/api')) return `${normalized}/v1/chat/completions`;
  return `${normalized}/chat/completions`;
}

function forwardSSEOrChunk(upstreamRes, clientRes) {
  clientRes.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  clientRes.write('event: meta\ndata: {"ok":true}\n\n');
  upstreamRes.on('data', (chunk) => {
    clientRes.write(chunk);
  });
  upstreamRes.on('end', () => {
    clientRes.write('data: [DONE]\n\n');
    clientRes.end();
  });
}

function proxyChat(req, res) {
  readBody(req, MAX_BODY).then((raw) => {
    const body = raw ? JSON.parse(raw) : {};
    const token = String(body.token || '').trim() || SERVER_ACCESS_TOKEN;
    const clientId = String(body.clientId || '').trim();
    const clientSecret = String(body.clientSecret || '').trim();

    if (clientId && clientSecret && !token) {
      // TODO: OAuth/token exchange from client credentials before chat call.
      writeJson(res, 501, { error: 'OAuth token exchange is not implemented yet (TODO).' });
      return;
    }
    if (!token) {
      writeJson(res, 400, { error: 'Missing access token. Provide token in settings or via server env GIGACHAT_ACCESS_TOKEN.' });
      return;
    }

    const endpoint = buildChatEndpoint(body.apiBaseUrl || DEFAULT_GIGACHAT_BASE);
    const endpointUrl = new URL(endpoint);
    const payload = {
      model: body.model || 'GigaChat-2',
      messages: Array.isArray(body.messages) ? body.messages : [],
      stream: body.stream !== false,
      temperature: Number.isFinite(Number(body.temperature)) ? Number(body.temperature) : 0.2,
      max_tokens: Number.isFinite(Number(body.max_tokens)) ? Number(body.max_tokens) : 900,
    };
    const payloadRaw = JSON.stringify(payload);

    const transport = endpointUrl.protocol === 'http:' ? http : https;
    const upstreamReq = transport.request({
      protocol: endpointUrl.protocol,
      hostname: endpointUrl.hostname,
      port: endpointUrl.port || (endpointUrl.protocol === 'http:' ? 80 : 443),
      path: endpointUrl.pathname + endpointUrl.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        Accept: 'text/event-stream, application/json',
        'Content-Length': Buffer.byteLength(payloadRaw),
      },
    }, (upstreamRes) => {
      const status = upstreamRes.statusCode || 500;
      const upstreamType = (upstreamRes.headers['content-type'] || '').toLowerCase();

      if (status >= 400) {
        const errChunks = [];
        upstreamRes.on('data', (chunk) => errChunks.push(chunk));
        upstreamRes.on('end', () => {
          const errText = Buffer.concat(errChunks).toString('utf-8');
          const parsed = (() => { try { return JSON.parse(errText); } catch (_) { return null; } })();
          writeJson(res, status, {
            error: 'GigaChat upstream error',
            status,
            details: parsed || errText || 'Unknown upstream error',
          });
        });
        return;
      }

      if (payload.stream) {
        if (upstreamType.includes('text/event-stream') || upstreamType.includes('stream') || upstreamType.includes('json')) {
          forwardSSEOrChunk(upstreamRes, res);
        } else {
          // Fallback: non-streaming body -> emit as single SSE chunk.
          const chunks = [];
          upstreamRes.on('data', (chunk) => chunks.push(chunk));
          upstreamRes.on('end', () => {
            const text = Buffer.concat(chunks).toString('utf-8');
            res.writeHead(200, {
              'Content-Type': 'text/event-stream; charset=utf-8',
              'Cache-Control': 'no-cache, no-transform',
              Connection: 'keep-alive',
            });
            res.write(`data: ${text}\n\n`);
            res.write('data: [DONE]\n\n');
            res.end();
          });
        }
      } else {
        res.writeHead(200, { 'Content-Type': upstreamType || 'application/json; charset=utf-8' });
        upstreamRes.pipe(res);
      }
    });

    req.on('close', () => {
      if (!res.writableEnded) upstreamReq.destroy(new Error('Client disconnected'));
    });

    upstreamReq.on('error', (err) => {
      if (res.writableEnded) return;
      writeJson(res, 502, { error: 'Proxy request failed', details: String(err && err.message ? err.message : err) });
    });

    upstreamReq.write(payloadRaw);
    upstreamReq.end();
  }).catch((err) => {
    writeJson(res, /Payload too large/.test(String(err)) ? 413 : 400, {
      error: 'Invalid request body',
      details: String(err && err.message ? err.message : err),
    });
  });
}

// ============================================================
// JIRA PULSE — config + proxy
// ============================================================
const JIRA_CONFIG_FILE = path.join(ROOT, 'jira_config.json');
const JIRA_DEFAULT_CONFIG = {
  jiraBaseUrl: '', jiraToken: '',
  areas: [],                       // [{ name, projectKey }]
  bitbucketBaseUrl: '', bitbucketToken: '', bitbucketProjectKeys: '',
  confluenceBaseUrl: '', confluenceToken: '',
  allowInsecureTls: false, staleDays: 3, noMovementDays: 2,
};

function jiraReadConfig() {
  try { return { ...JIRA_DEFAULT_CONFIG, ...JSON.parse(fs.readFileSync(JIRA_CONFIG_FILE, 'utf8')) }; }
  catch(_) { return { ...JIRA_DEFAULT_CONFIG }; }
}
function jiraWriteConfig(patch) {
  const next = { ...jiraReadConfig(), ...patch };
  fs.writeFileSync(JIRA_CONFIG_FILE, JSON.stringify(next, null, 2), 'utf8');
  return next;
}
function jiraSanitizeAreas(areas) {
  if (!Array.isArray(areas)) return [];
  const seen = new Set(), out = [];
  for (const a of areas) {
    const pk = String(a.projectKey||'').trim(), nm = String(a.name||pk||'').trim();
    if (!pk || seen.has(pk)) continue;
    seen.add(pk); out.push({ name:nm, projectKey:pk });
  }
  return out;
}
function jiraSanitizeConfig(cfg) {
  return {
    jiraBaseUrl: cfg.jiraBaseUrl||'', areas: jiraSanitizeAreas(cfg.areas),
    bitbucketBaseUrl: cfg.bitbucketBaseUrl||'', bitbucketProjectKeys: cfg.bitbucketProjectKeys||'',
    confluenceBaseUrl: cfg.confluenceBaseUrl||'', allowInsecureTls: !!cfg.allowInsecureTls,
    staleDays: cfg.staleDays??3, noMovementDays: cfg.noMovementDays??2,
    hasJiraToken: !!cfg.jiraToken, hasBitbucketToken: !!cfg.bitbucketToken, hasConfluenceToken: !!cfg.confluenceToken,
  };
}

function jiraForward({ targetUrl, method='GET', headers={}, body=null, allowInsecureTls=false, timeoutMs=25000 }) {
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(targetUrl); } catch(e) { return reject(new Error('Bad URL: '+targetUrl)); }
    const lib = parsed.protocol==='https:' ? https : http;
    const opts = {
      method, hostname: parsed.hostname,
      port: parsed.port||(parsed.protocol==='https:'?443:80),
      path: parsed.pathname+(parsed.search||''),
      headers: { Accept:'application/json', 'User-Agent':'sbof-planner/1.0', ...headers },
      rejectUnauthorized: !allowInsecureTls,
    };
    const r = lib.request(opts, (resp) => {
      const chunks = [];
      resp.on('data', c=>chunks.push(c));
      resp.on('end', ()=>resolve({ status:resp.statusCode||0, headers:resp.headers, text:Buffer.concat(chunks).toString('utf8') }));
    });
    r.setTimeout(timeoutMs, ()=>r.destroy(new Error('Timeout '+parsed.hostname)));
    r.on('error', reject);
    if (body!=null) {
      const pl = typeof body==='string'?body:JSON.stringify(body);
      r.setHeader('Content-Type','application/json'); r.setHeader('Content-Length',Buffer.byteLength(pl)); r.write(pl);
    }
    r.end();
  });
}
function jiraParseResp(resp, label) {
  if (resp.status<200||resp.status>=300) {
    let msg=`${label} ${resp.status}`;
    try { const j=JSON.parse(resp.text); if(j.errorMessages?.length) msg+=': '+j.errorMessages.join('; '); else if(j.message) msg+=': '+j.message; } catch(_){}
    const e=new Error(msg); e.status=resp.status; throw e;
  }
  if (!resp.text) return {};
  return JSON.parse(resp.text);
}
function jiraSleep(ms) { return new Promise(r=>setTimeout(r,ms)); }
async function jiraRequest(cfg, method, apiPath, body, maxRetries=4) {
  const target = cfg.jiraBaseUrl.replace(/\/+$/,'')+apiPath;
  let delay=2000;
  for (let i=0; i<=maxRetries; i++) {
    const resp = await jiraForward({ targetUrl:target, method, headers:{ Authorization:'Bearer '+cfg.jiraToken }, body:body??null, allowInsecureTls:cfg.allowInsecureTls });
    if (resp.status===429) {
      if (i===maxRetries) throw Object.assign(new Error('Jira 429 rate limit'), {status:429});
      const wait = parseInt(resp.headers['retry-after']||'0',10);
      await jiraSleep(wait>0?wait*1000:delay); delay=Math.min(delay*2,30000); continue;
    }
    return jiraParseResp(resp, 'Jira');
  }
}
async function jiraSearchAll(cfg, jql, fields, expand, hardCap=2000) {
  const out=[]; let startAt=0;
  while(true) {
    const data = await jiraRequest(cfg,'POST','/rest/api/2/search',{ jql, startAt, maxResults:100, fields, expand });
    const issues = data.issues||[];
    out.push(...issues);
    if (issues.length<100 || out.length>=(data.total||out.length) || startAt>hardCap) break;
    startAt+=issues.length;
  }
  return out;
}
function jiraPLimit(concurrency, tasks) {
  return new Promise((resolve) => {
    const results=new Array(tasks.length); let i=0, done=0, running=0;
    const next=()=>{
      while(running<concurrency&&i<tasks.length) {
        const idx=i++; running++;
        Promise.resolve().then(()=>tasks[idx]()).then(r=>{results[idx]=r;},e=>{results[idx]={__error:e.message};})
          .then(()=>{ running--; done++; if(done===tasks.length) resolve(results); else next(); });
      }
    };
    if(!tasks.length) resolve([]); else next();
  });
}
const JIRA_FIELDS=['summary','description','status','assignee','reporter','updated','created','priority','issuetype','labels','duedate','timetracking','timeoriginalestimate','aggregatetimespent','worklog','comment','parent','subtasks','resolution','resolutiondate'];

async function jiraBuildAreaReport(cfg, area) {
  let sprintIssues,recentIssues,inProgressIssues,backlogIssues;
  try {
    const pk=area.projectKey;
    [sprintIssues,recentIssues,inProgressIssues,backlogIssues] = await Promise.all([
      jiraSearchAll(cfg,`project="${pk}" AND sprint in openSprints()`,JIRA_FIELDS,['changelog']),
      jiraSearchAll(cfg,`project="${pk}" AND updated >= -3d`,JIRA_FIELDS,['changelog']),
      jiraSearchAll(cfg,`project="${pk}" AND statusCategory = "In Progress"`,JIRA_FIELDS,['changelog']),
      jiraSearchAll(cfg,`project="${pk}" AND statusCategory != Done AND (sprint is EMPTY OR sprint not in openSprints())`,JIRA_FIELDS,['changelog']),
    ]);
  } catch(e) {
    return { name:area.name, projectKey:area.projectKey, issues:[], sprintKeys:[], inProgressKeys:[], backlogKeys:[], devStatus:{}, error:e.message };
  }
  const byKey=new Map();
  for (const arr of [sprintIssues,recentIssues,inProgressIssues,backlogIssues]) for(const it of arr) byKey.set(it.key,it);
  return {
    name:area.name, projectKey:area.projectKey,
    issues:Array.from(byKey.values()),
    sprintKeys:sprintIssues.map(i=>i.key),
    inProgressKeys:inProgressIssues.map(i=>i.key),
    backlogKeys:backlogIssues.map(i=>i.key),
    devStatus:{}, error:null,
  };
}

async function jiraBuildReport(cfg) {
  const areas=jiraSanitizeAreas(cfg.areas);
  if (!cfg.jiraBaseUrl||!cfg.jiraToken) throw Object.assign(new Error('Jira URL или токен не заданы'),{status:400});
  if (!areas.length) throw Object.assign(new Error('Не задано ни одного пространства'),{status:400});
  const staleDays=Number(cfg.staleDays)||3, noMovementDays=Number(cfg.noMovementDays)||2;
  const areaReports = await jiraPLimit(2, areas.map(a=>()=>jiraBuildAreaReport(cfg,a)));
  const now=new Date(), yesterday=new Date(now); yesterday.setHours(0,0,0,0); yesterday.setDate(yesterday.getDate()-1);
  const today=new Date(now); today.setHours(0,0,0,0);
  const dayBefore=new Date(yesterday); dayBefore.setDate(dayBefore.getDate()-1);
  return {
    generatedAt:now.toISOString(),
    yesterdayRange:{ from:yesterday.toISOString(), to:today.toISOString() },
    dayBeforeYesterdayRange:{ from:dayBefore.toISOString(), to:yesterday.toISOString() },
    last48hRange:{ from:new Date(Date.now()-48*3600000).toISOString(), to:now.toISOString() },
    staleDays, noMovementDays, areas:areaReports, bitbucket:null, confluence:null,
  };
}

async function handleJiraApi(req, res, pathname) {
  try {
    if (pathname==='/api/jira/config' && req.method==='GET') {
      return writeJson(res, 200, jiraSanitizeConfig(jiraReadConfig()));
    }
    if (pathname==='/api/jira/config' && req.method==='POST') {
      const raw = await readBody(req, 512*1024);
      const body = raw ? JSON.parse(raw) : {};
      const patch = {};
      for (const k of ['jiraBaseUrl','bitbucketBaseUrl','bitbucketProjectKeys','confluenceBaseUrl']) {
        if (typeof body[k]==='string') patch[k]=body[k].trim();
      }
      if (Array.isArray(body.areas)) patch.areas=jiraSanitizeAreas(body.areas);
      if (typeof body.allowInsecureTls==='boolean') patch.allowInsecureTls=body.allowInsecureTls;
      if (typeof body.staleDays==='number') patch.staleDays=body.staleDays;
      if (typeof body.noMovementDays==='number') patch.noMovementDays=body.noMovementDays;
      if (typeof body.jiraToken==='string'&&body.jiraToken) patch.jiraToken=body.jiraToken;
      if (typeof body.bitbucketToken==='string'&&body.bitbucketToken) patch.bitbucketToken=body.bitbucketToken;
      if (typeof body.confluenceToken==='string'&&body.confluenceToken) patch.confluenceToken=body.confluenceToken;
      const next = jiraWriteConfig(patch);
      return writeJson(res, 200, jiraSanitizeConfig(next));
    }
    if (pathname==='/api/jira/verify' && req.method==='POST') {
      const cfg=jiraReadConfig();
      if (!cfg.jiraBaseUrl||!cfg.jiraToken) return writeJson(res,400,{ok:false,error:'Нет jiraBaseUrl или токена'});
      const me = await jiraRequest(cfg,'GET','/rest/api/2/myself',null);
      return writeJson(res,200,{ok:true,who:me.displayName||me.name||'?'});
    }
    if (pathname==='/api/jira/report' && req.method==='POST') {
      const cfg=jiraReadConfig();
      const report = await jiraBuildReport(cfg);
      return writeJson(res, 200, report);
    }
    writeJson(res, 404, { error: 'Неизвестный Jira API метод' });
  } catch(e) {
    const status = (e.status&&e.status>=400&&e.status<600)?e.status:500;
    writeJson(res, status, { error: e.message||String(e) });
  }
}

function serveStatic(req, res) {
  let urlPath = req.url.split('?')[0];
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.join(ROOT, urlPath);

  if (!path.resolve(filePath).startsWith(ROOT + path.sep) && path.resolve(filePath) !== ROOT) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Forbidden');
    return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(`Not Found: ${urlPath}`);
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Server Error');
      }
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  const pathname = req.url.split('?')[0];
  if (req.method === 'POST' && pathname === '/api/llm/chat') {
    proxyChat(req, res); return;
  }
  if (pathname.startsWith('/api/jira/')) {
    handleJiraApi(req, res, pathname); return;
  }
  serveStatic(req, res);
});

let currentPort = PORT;
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    const next = currentPort + 1;
    if (next <= PORT + 9) {
      currentPort = next;
      server.listen(currentPort, '127.0.0.1');
    } else {
      console.error(`Порты ${PORT}–${PORT + 9} заняты. Освободи порт или задай другой: node server.js 9090`);
      process.exit(1);
    }
  } else {
    throw err;
  }
});

server.listen(PORT, '127.0.0.1', () => {
  const actualPort = server.address().port;
  // Machine-readable marker so launch.js knows the real port.
  console.log(`LISTENING:${actualPort}`);
  console.log(`SBOF Planner — http://localhost:${actualPort}`);
  console.log('Ctrl+C to stop');
});
