# СБОФ Планировщик v8_0 — Architecture

## Overview

Q2 Plan Analyzer is a **vanilla JS, zero-dependency** sprint planning tool.  
It runs in the browser as ES modules, served by a lightweight Node.js HTTP server.  
No build step, no npm for the frontend — just `node server.js`.

## Tech Stack

| Layer | Tech |
|---|---|
| Browser JS | ES Modules (native `import`/`export`) |
| Rendering | Imperative DOM via `innerHTML` / `createElement` |
| State | Single mutable `state` object (centralized) |
| Persistence | `localStorage` (two keys: data + settings) |
| Server | Node.js `http` module (serves static files + Jira/LLM proxy API) |
| XLSX parsing | `libs/xlsx.full.min.js` (loaded as non-module `<script>`) |
| History | `modules/history.js` (sets `window.HistoryModule`) |
| CSV stream | `modules/csv-stream-exporter.js` (sets `window.CSVStreamExporter`) |

## Directory Layout

```
v8_0/
├── app.js                   # Main entry point — orchestrator, UI bindings, App object
├── index.html               # SPA shell — loads libs then <script type="module" src="app.js">
├── server.js                # Node.js static server + /api/jira/* and /api/llm/* proxies
├── styles.css               # All CSS (single file, no preprocessor)
├── package.json             # { "type": "module" } for server.js ESM
├── start.sh                 # Quick launch script
│
├── constants.js             # All compile-time constants (REGISTRY_COLS, RELEASE_WINDOWS, …)
├── state.js                 # Global mutable state + subscribe/notify pub-sub
├── dataStore.js             # localStorage I/O, CSV/XLSX import-export, bulk mutations
├── filters.js               # FilterEngine — filtering, sorting, dropdown value getters
├── riskEngine.js            # RiskEngine — computeFlags, computeRiskScore, computeAll
├── rowFactory.js            # RowFactory, EmployeeFactory — create & normalize rows
├── utils.js                 # Utils (escapeHtml, parseDateRange, …), nextId()
├── metricsEngine.js         # computeProgress, computeLoad, release metrics
├── insightEngine.js         # Insight signal generators (text analysis, pattern detection)
├── dependencyEngine.js      # Epic dependency graph helpers (cycle detection, traversal)
│
├── components/
│   ├── multiselect.js       # Multiselect dropdown component
│   └── tagInput.js          # Tag input component + color palette
│
├── views/
│   ├── renderHelpers.js     # Shared render utilities (RH.*) used across views
│   ├── dashboard.js         # DashboardView
│   ├── registry.js          # RegistryView (table, inline edit, col drag/resize/pin)
│   ├── gantt.js             # GanttView (detailed tasks) + GanttV2 (arrows/deps)
│   ├── kanban.js            # KanbanView
│   ├── timeline.js          # TimelineView + PodlozhkaView
│   ├── metrics.js           # SummaryView, MetricsView, InsightsView, DiagnosticsView
│   └── employees.js         # EmployeesView
│
├── modules/                 # Legacy non-module scripts (loaded before app.js)
│   ├── history.js           # Sets window.HistoryModule (undo/redo snapshots)
│   └── csv-stream-exporter.js # Sets window.CSVStreamExporter
│
├── libs/
│   └── xlsx.full.min.js     # SheetJS (loaded as non-module script, exposes window.XLSX)
│
├── testRunner.js            # Node.js test suite (no npm, uses require('assert'))
└── ARCHITECTURE.md          # This file
```

## Dependency Layers

```
constants.js          (no imports)
    ↓
state.js              (imports constants)
    ↓
utils.js              (imports state)
rowFactory.js         (imports state, utils)
riskEngine.js         (imports state)
filters.js            (imports state, constants)
dataStore.js          (imports state, constants, riskEngine, rowFactory, utils)
metricsEngine.js      (imports state)
insightEngine.js      (imports state, filters)
dependencyEngine.js   (imports state)
    ↓
components/           (import state, constants)
views/                (import state, filters, riskEngine, dataStore, components, constants)
    ↓
app.js                (imports everything above — orchestrator)
```

**Rule**: lower layers never import from higher layers. Cross-cutting calls (e.g. `dataStore` needing to trigger a UI refresh) use `window.X?.method()` optional chaining — `app.js` sets those refs after all modules load.

## State Management

Single source of truth: `state` object in `state.js`.

```js
import { state } from './state.js';
state.rows.push(newRow);          // mutate directly
notify('import-csv');             // broadcast to subscribers
```

```js
import { subscribe } from './state.js';
subscribe(reason => {             // in app.js
  App.refreshAll();
});
```

`notify(reason)` is **synchronous** — all listeners fire immediately, in order of registration.

## Data Flow

```
User action (click/input)
    → View event handler
    → Mutate state (state.rows, state.filters, …)
    → Storage.save() if persistent
    → notify(reason)  OR  App.refreshAll() directly
    → All subscribe() listeners fire
    → App.renderSection(state.activeSection)
    → View.render() re-draws DOM
```

## localStorage Schema

| Key | Content |
|---|---|
| `q2_plan_v3` | `{ rows[], employees[], savedAt, version:3 }` |
| `q2_settings_v3` | `{ colOrder, colWidths, colVisibility, pinnedCols, theme, ganttMode, epicDeps, … }` |
| `q2_llm_settings_v1` | LLM assistant settings (model, token, prompts) |
| `q2_llm_conv_v1` | LLM conversation history |
| `sbof_app_settings_v1` | Nav section visibility toggles |
| Legacy keys | `q2_plan_v2`, `q2_plan`, `q2_settings_v2`, `q2_settings` (read-only migration) |

## Breaking Circular Dependencies

Lower-layer modules (e.g. `dataStore.js`) sometimes need App-level functions like `showToast`, `HistoryManager.checkpoint`, `RegistryView.autoFitColWidths`. Importing `app.js` from a module would create a cycle.

**Solution**: `app.js` registers itself on `window` after initialization:

```js
// app.js — after all declarations
window.App             = App;
window.HistoryManager  = HistoryManager;
window.showToast       = showToast;
window.ThemeUI         = ThemeUI;
window.RegistryView    = RegistryView;
window.BulkEditPanel   = BulkEditPanel;
window.ActionLayer     = ActionLayer;
```

Lower layers call these with safe optional chaining:

```js
// dataStore.js
window.showToast?.('Импорт завершён', 'success');
window.HistoryManager?.checkpoint('импорт CSV');
```

## Non-Module Scripts (window globals)

`libs/xlsx.full.min.js` and `modules/history.js` are loaded as regular `<script>` tags **before** `app.js`. They expose `window.XLSX` and `window.HistoryModule` respectively. ES module code accesses them as `window.XLSX` (not bare `XLSX`) since module scope doesn't see non-module globals implicitly.

## Running

```bash
cd v8_0
node server.js          # starts on http://localhost:8080
```

## Testing

```bash
node testRunner.js      # runs domain logic tests (no browser needed)
```

Tests cover: RiskEngine scoring, FilterEngine filtering, dependency cycle detection, metrics computation. No npm required — uses Node.js built-in `assert`.
