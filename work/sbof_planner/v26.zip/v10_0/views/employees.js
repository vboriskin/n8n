'use strict';
/* ============================================================
   EMPLOYEES VIEW — v8_0 ES module
   ============================================================ */

import { state } from '../state.js';
import { FilterEngine } from '../filters.js';
import { Utils } from '../utils.js';
import { EmployeeFactory } from '../rowFactory.js';
import { Storage } from '../dataStore.js';
import { computeLoad } from '../metricsEngine.js';
import { RH } from './renderHelpers.js';
import { createTagInput } from '../components/tagInput.js';

export const EmployeesView = {
  _expanded: {},
  _cleanups: [],
  cleanup() {
    EmployeesView._cleanups.forEach(fn=>{ try{ fn(); } catch(e){} });
    EmployeesView._cleanups=[];
  },
  _splitTags(raw) {
    return String(raw||'').split(/[|,]/).map(s=>s.trim()).filter(Boolean);
  },
  getTasksForEmployee(fio) {
    const name=String(fio||'').trim();
    if (!name) return [];
    return state.rows.filter(row=>{
      const assignees=EmployeesView._splitTags(row.assignee);
      return assignees.includes(name);
    });
  },
  render() {
    EmployeesView.cleanup();
    const list=[...state.employees].sort((a,b)=>String(a.fio||'').localeCompare(String(b.fio||''),'ru'));
    const badge=document.getElementById('employees-count-badge');
    badge.textContent=`${list.length} сотрудников`;

    const taskLinks=list.reduce((acc,emp)=>acc+EmployeesView.getTasksForEmployee(emp.fio).length,0);
    const weekdayReady=list.filter(e=>e.weekdayReady).length;
    const withOtDays=list.filter(e=>Array.isArray(e.overtimeDays)&&e.overtimeDays.length).length;
    document.getElementById('employees-summary-cards').innerHTML=`
      <div class="kpi-card"><div class="kpi-label">Сотрудников</div><div class="kpi-value">${list.length}</div></div>
      <div class="kpi-card kpi-green"><div class="kpi-label">Готовы в будни</div><div class="kpi-value">${weekdayReady}</div></div>
      <div class="kpi-card kpi-red"><div class="kpi-label">С OT днями</div><div class="kpi-value">${withOtDays}</div></div>
      <div class="kpi-card kpi-blue"><div class="kpi-label">Связанных задач</div><div class="kpi-value">${taskLinks}</div></div>
    `;

    const wrap=document.getElementById('employees-table-wrap');
    if (!list.length) {
      wrap.innerHTML='<div class="empty-state"><div class="empty-icon">👥</div><div class="empty-title">Список сотрудников пуст</div><div class="empty-hint">Добавьте вручную или загрузите CSV/XLSX</div></div>';
      return;
    }

    const table=document.createElement('table');
    const load = computeLoad(state.rows);
    table.className='employees-table';
    table.innerHTML='<thead><tr><th>ФИО</th><th>Роль</th><th>Команда</th><th>Дни OT</th><th>Будни OT</th><th>Комментарий к будням</th><th>Нагрузка</th><th></th></tr></thead>';
    const tbody=document.createElement('tbody');

    list.forEach(emp=>{
      const tr=document.createElement('tr');

      // ФИО
      const fioTd=document.createElement('td');
      const fioInput=document.createElement('input');
      fioInput.className='cell-input';
      fioInput.type='text';
      fioInput.value=emp.fio||'';
      fioInput.placeholder='ФИО';
      fioInput.addEventListener('change',()=>{
        emp.fio=fioInput.value.trim();
        EmployeeFactory.normalize(emp);
        Storage.save();
        window.App?.populateFilterDropdowns();
        EmployeesView.render();
      });
      fioTd.appendChild(fioInput);
      tr.appendChild(fioTd);

      // Роль (теги)
      const rolesTd=document.createElement('td');
      const rolesInput=createTagInput(EmployeesView._splitTags(emp.roles),(tags)=>{
        emp.roles=tags.join('|');
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      },()=>FilterEngine.getRoles());
      if (rolesInput._cleanup) EmployeesView._cleanups.push(()=>rolesInput._cleanup());
      rolesTd.appendChild(rolesInput);
      tr.appendChild(rolesTd);

      // Команда (теги)
      const teamsTd=document.createElement('td');
      const teamsInput=createTagInput(EmployeesView._splitTags(emp.teams),(tags)=>{
        emp.teams=tags.join('|');
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      },()=>FilterEngine.getTeams());
      if (teamsInput._cleanup) EmployeesView._cleanups.push(()=>teamsInput._cleanup());
      teamsTd.appendChild(teamsInput);
      tr.appendChild(teamsTd);

      // Дни OT (дата + мульти)
      const daysTd=document.createElement('td');
      const daysWrap=document.createElement('div');
      daysWrap.className='employee-date-wrap';
      const listWrap=document.createElement('div');
      listWrap.className='employee-date-list';
      (emp.overtimeDays||[]).forEach(d=>{
        const chip=document.createElement('span');
        chip.className='employee-date-chip';
        chip.innerHTML=`${Utils.escapeHtml(d)} <button type="button">×</button>`;
        chip.querySelector('button').addEventListener('click',()=>{
          emp.overtimeDays=(emp.overtimeDays||[]).filter(x=>x!==d);
          EmployeeFactory.normalize(emp);
          Storage.save();
          EmployeesView.render();
        });
        listWrap.appendChild(chip);
      });
      const addWrap=document.createElement('div');
      addWrap.className='employee-date-add';
      const dayInput=document.createElement('input');
      dayInput.type='date';
      dayInput.className='cell-input';
      dayInput.style.maxWidth='150px';
      const addBtn=document.createElement('button');
      addBtn.className='employee-act-btn';
      addBtn.textContent='+';
      addBtn.addEventListener('click',()=>{
        if (!dayInput.value) return;
        emp.overtimeDays=[...(emp.overtimeDays||[]),dayInput.value];
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      });
      addWrap.appendChild(dayInput);
      addWrap.appendChild(addBtn);
      daysWrap.appendChild(listWrap);
      daysWrap.appendChild(addWrap);
      daysTd.appendChild(daysWrap);
      tr.appendChild(daysTd);

      // Будни OT (checkbox)
      const wdTd=document.createElement('td');
      const wdCb=document.createElement('input');
      wdCb.type='checkbox';
      wdCb.checked=!!emp.weekdayReady;
      wdCb.addEventListener('change',()=>{
        emp.weekdayReady=wdCb.checked;
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      });
      wdTd.appendChild(wdCb);
      tr.appendChild(wdTd);

      // Комментарий к будням
      const wdCommentTd=document.createElement('td');
      const commentInput=createTagInput(EmployeesView._splitTags(emp.weekdayComment),(tags)=>{
        emp.weekdayComment=tags.join('|');
        EmployeeFactory.normalize(emp);
        Storage.save();
        EmployeesView.render();
      });
      if (commentInput._cleanup) EmployeesView._cleanups.push(()=>commentInput._cleanup());
      wdCommentTd.appendChild(commentInput);
      tr.appendChild(wdCommentTd);

      // Нагрузка (load per release + drilldown)
      const tasksTd=document.createElement('td');
      const empLoad = load[emp.fio] || { total:0, r120:0, r121:0, r122:0, ot:0 };
      const empTasks=EmployeesView.getTasksForEmployee(emp.fio);
      const isOverloaded = empLoad.total >= 6;
      const loadHtml = `
        <div class="emp-load-wrap ${isOverloaded?'emp-overloaded':''}">
          <span class="emp-load-total" title="Всего задач">${empLoad.total}${isOverloaded?' ⚠️':''}</span>
          <div class="emp-load-breakdown">
            ${empLoad.r120?`<span class="emp-load-chip r120">1.20:${empLoad.r120}</span>`:''}
            ${empLoad.r121?`<span class="emp-load-chip r121">1.21:${empLoad.r121}</span>`:''}
            ${empLoad.r122?`<span class="emp-load-chip r122">1.22:${empLoad.r122}</span>`:''}
            ${empLoad.ot?`<span class="emp-load-chip ot">OT:${empLoad.ot}</span>`:''}
          </div>
        </div>`;
      const drillBtn=document.createElement('button');
      drillBtn.className='employee-act-btn';
      drillBtn.innerHTML=loadHtml+`<span style="font-size:10px;opacity:.7;margin-left:4px">▼ ${empTasks.length}</span>`;
      drillBtn.addEventListener('click',()=>{
        EmployeesView._expanded[emp.id]=!EmployeesView._expanded[emp.id];
        EmployeesView.render();
      });
      tasksTd.appendChild(drillBtn);
      tr.appendChild(tasksTd);

      // Actions
      const actTd=document.createElement('td');
      const delBtn=document.createElement('button');
      delBtn.className='employee-act-btn';
      delBtn.textContent='✕';
      delBtn.title='Удалить сотрудника';
      delBtn.addEventListener('click',()=>{
        if (!confirm(`Удалить сотрудника "${emp.fio||'без имени'}"?`)) return;
        state.employees=state.employees.filter(e=>e.id!==emp.id);
        Storage.save();
        window.App?.populateFilterDropdowns();
        EmployeesView.render();
      });
      actTd.appendChild(delBtn);
      tr.appendChild(actTd);

      tbody.appendChild(tr);

      if (EmployeesView._expanded[emp.id]) {
        const detailTr=document.createElement('tr');
        const td=document.createElement('td');
        td.colSpan=8;
        if (!empTasks.length) {
          td.innerHTML='<div class="text-muted text-sm" style="padding:10px 4px">В реестре нет задач с этим исполнителем.</div>';
        } else {
          td.innerHTML=`<div style="overflow:auto;padding:6px 0">
            <table class="data-table" style="width:100%">
              <thead><tr><th>Команда</th><th>Эпик</th><th>Задача</th><th>Релизы</th><th>Овертайм</th></tr></thead>
              <tbody>
                ${empTasks.map(r=>`<tr>
                  <td>${Utils.escapeHtml(r.team||'—')}</td>
                  <td>${Utils.escapeHtml(r.epic||'—')}</td>
                  <td><div class="tasks-cell">${RH.jiraTagsHtml(r.tasks||'')}</div></td>
                  <td>${RH.releaseChips(r)}</td>
                  <td>${r.hasOvertime?'<span class="chip chip-red">OT</span>':'<span class="chip chip-gray">Нет</span>'}</td>
                </tr>`).join('')}
              </tbody>
            </table>
          </div>`;
        }
        detailTr.appendChild(td);
        tbody.appendChild(detailTr);
      }
    });

    table.appendChild(tbody);
    wrap.innerHTML='';
    wrap.appendChild(table);
  },
  parseImportedRows(headers, matrixRows, sourceType) {
    const headerMap={};
    headers.forEach((h,idx)=>{
      const field=Utils.mapEmployeeHeader(Utils.normalizeHeader(h));
      if (field) headerMap[field]=idx;
    });
    if (headerMap.fio==null) return [];
    const get=(cells,key)=>{
      const idx=headerMap[key];
      return idx==null?'':String(cells[idx]||'').trim();
    };
    const imported=[];
    matrixRows.forEach(cells=>{
      if (!cells || cells.every(c=>!String(c||'').trim())) return;
      const fio=get(cells,'fio');
      if (!fio) return;
      imported.push(EmployeeFactory.create({
        fio,
        roles:get(cells,'roles'),
        teams:get(cells,'teams'),
        overtimeDays:Utils.parseDateList(get(cells,'overtimeDays')),
        weekdayReady:Utils.toBool(get(cells,'weekdayReady'),false),
        weekdayComment:get(cells,'weekdayComment'),
        sourceType,
      }));
    });
    return imported;
  },
  mergeImported(imported, sourceLabel) {
    if (!imported.length) { alert('Не найдено валидных строк сотрудников (нужна колонка ФИО).'); return; }
    const existingByFio=new Map();
    state.employees.forEach(emp=>{
      const key=String(emp.fio||'').trim().toLowerCase();
      if (key) existingByFio.set(key,emp);
    });
    let addCount=0, updateCount=0;
    imported.forEach(emp=>{
      const key=String(emp.fio||'').trim().toLowerCase();
      if (!key) return;
      const existing=existingByFio.get(key);
      if (existing) {
        existing.roles=emp.roles;
        existing.teams=emp.teams;
        existing.overtimeDays=emp.overtimeDays;
        existing.weekdayReady=emp.weekdayReady;
        existing.weekdayComment=emp.weekdayComment;
        existing.sourceType=emp.sourceType;
        EmployeeFactory.normalize(existing);
        updateCount++;
      } else {
        state.employees.push(emp);
        existingByFio.set(key,emp);
        addCount++;
      }
    });
    if (!addCount && !updateCount) { alert('Изменений по сотрудникам не найдено.'); return; }
    const ask=confirm(`${sourceLabel}: добавить ${addCount}, обновить ${updateCount}. Применить?`);
    if (!ask) return;
    Storage.save();
    window.App?.populateFilterDropdowns();
    if (state.activeSection==='employees') EmployeesView.render();
    window.showToast?.(`Сотрудники: +${addCount}, обновлено ${updateCount}`);
  },
  importCSV(text) {
    if (text.charCodeAt(0)===0xFEFF) text=text.slice(1);
    const rows=Utils.parseFullCSV(text);
    if (rows.length<2) { alert('CSV пустой'); return; }
    const headers=rows[0].map(h=>String(h||'').trim());
    const imported=EmployeesView.parseImportedRows(headers, rows.slice(1), 'csv');
    EmployeesView.mergeImported(imported, 'CSV');
  },
  importXLSX(buffer) {
    if (typeof window.XLSX==='undefined') { alert('Положите libs/xlsx.full.min.js рядом с index.html'); return; }
    const wb=window.XLSX.read(buffer,{type:'array'});
    const imported=[];
    wb.SheetNames.forEach(sheetName=>{
      const ws=wb.Sheets[sheetName];
      const raw=window.XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:false});
      if (!raw || raw.length<2) return;
      let headerIdx=0;
      for (let i=0;i<Math.min(6,raw.length);i++) {
        const mapped=raw[i].map(h=>Utils.mapEmployeeHeader(Utils.normalizeHeader(h)));
        if (mapped.includes('fio')) { headerIdx=i; break; }
      }
      const headers=(raw[headerIdx]||[]).map(h=>String(h||'').trim());
      const rows=raw.slice(headerIdx+1);
      imported.push(...EmployeesView.parseImportedRows(headers,rows,'xlsx:'+sheetName));
    });
    EmployeesView.mergeImported(imported, 'XLSX');
  },
};
