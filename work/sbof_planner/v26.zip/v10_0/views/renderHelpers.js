'use strict';
/* ============================================================
   RENDER HELPERS — v8_0 ES module
   ============================================================ */

import { Utils } from '../utils.js';
import { RISK_FLAGS, WT_CLS } from '../constants.js';

export const RH = {
  scopeChip(s) {
    if (!s) return '<span class="chip chip-gray">—</span>';
    const m={'Да':'chip chip-green','Нет':'chip chip-gray','Требует подтверждения':'chip chip-yellow'};
    return `<span class="${m[s]||'chip chip-gray'}">${s==='Требует подтверждения'?'Треб.':s}</span>`;
  },
  workTypeChips(types) {
    if (!types||!types.length) return '<span class="text-muted text-sm">—</span>';
    return types.map(t=>`<span class="wt-tag ${WT_CLS[t]||'wt-other'}">${t}</span>`).join('');
  },
  riskBadges(flags) {
    if (!flags||!flags.length) return '';
    return flags.map(f=>{
      const cls=f==='BLOCKING_NEAR_RELEASE'?'risk-badge risk-badge-danger':'risk-badge';
      return `<span class="${cls}" title="${RISK_FLAGS[f]||f}">⚠</span>`;
    }).join('');
  },
  dirtyBadge(d) { return d?'<span class="chip chip-dirty">✎</span>':''; },
  doneBadge(d) { return d?'<span class="chip chip-done">✅</span>':''; },
  jiraTagsHtml(raw) {
    const links=Utils.parseJiraLinks(raw);
    if (!links.length) return `<span class="tasks-cell-raw">${Utils.truncate(raw,40)}</span>`;
    return links.map(l=>{
      if (l.url) return `<a class="jira-tag" href="${l.url}" target="_blank" rel="noopener" title="${l.url}"><span class="jira-tag-icon">🔗</span>${l.key}</a>`;
      return `<span class="jira-tag" title="${l.key}">${l.key}</span>`;
    }).join('');
  },
  releaseChips(row) {
    const out=[];
    if (row.hasRelease120) out.push(`<span class="chip chip-indigo">1.20</span>`);
    if (row.hasRelease121) out.push(`<span class="chip chip-green">1.21</span>`);
    if (row.hasRelease122) out.push(`<span class="chip chip-yellow">1.22</span>`);
    if (row.hasOvertime) out.push(`<span class="chip chip-red">OT</span>`);
    return out.join('') || '<span class="chip chip-gray">—</span>';
  },
};
