'use strict';
/* ============================================================
   ONBOARDING UI — v11_0
   Handles: welcome overlay, demo loading, CEO micro-tour,
            setup flow, post-load insights, empty states.
   ============================================================ */

import { state }        from '../state.js';
import { Storage }      from '../dataStore.js';
import { RiskEngine }   from '../riskEngine.js';
import { loadDemoData } from './demoData.js';
import {
  startOnboarding, completeOnboarding, setOnboardingStep,
  setLastDatasetType, exitDemoMode, enterDemoMode,
  getOnboardingState, isDemoMode,
} from './onboarding.js';

/* ---- forward-declared refs filled by init() ---- */
let _goTo      = null; // (section:string) => void  — set by app.js
let _showToast = null; // (msg, type) => void
let _notify    = null; // (reason) => void

/* ================================================================
   PUBLIC API
   ================================================================ */

/** Call once from app.js, passing the App/Nav helpers. */
export function initOnboardingUI({ goTo, showToast, notify }) {
  _goTo      = goTo;
  _showToast = showToast;
  _notify    = notify;
}

/** Show full-screen welcome overlay. */
export function showWelcomeScreen() {
  const el = document.getElementById('ob-welcome');
  if (el) el.classList.remove('hidden');
}

/** Hide welcome overlay. */
export function hideWelcomeScreen() {
  const el = document.getElementById('ob-welcome');
  if (el) el.classList.add('hidden');
}

/** Load demo data then navigate to AI CEO and start micro-tour. */
export async function startDemoFlow() {
  startOnboarding('demo');
  setLastDatasetType('demo');
  hideWelcomeScreen();
  _showDemoLoading();
  await _delay(900);
  loadDemoData();
  Storage.save();
  _notify('demo-load');
  _hideDemoLoading();
  updateDemoBanner();
  _showToast('Демо-данные загружены — 22 задачи', 'success', 2800);
  _goTo('ai-ceo');
  await _delay(350);
  showCeoTour();
}

/** Start setup flow (open file upload instructions). */
export function startSetupFlow() {
  startOnboarding('setup');
  setLastDatasetType('user');
  completeOnboarding();
  hideWelcomeScreen();
  updateDemoBanner();
  _goTo('dashboard');
  _showToast('Загрузите свой файл через «Файлы → Импорт XLSX/CSV»', 'info', 5000);
  // Highlight the files button briefly
  const filesBtn = document.getElementById('btn-files-dropdown');
  if (filesBtn) {
    filesBtn.classList.add('ob-pulse');
    setTimeout(() => filesBtn.classList.remove('ob-pulse'), 3500);
  }
}

/* ---- CEO micro-tour ---- */
const CEO_TOUR_STEPS = [
  {
    selector: '#ceo-hero',
    title: '1 / 3 — Здоровье проекта',
    text: 'Шкала показывает общий статус: OK, AT RISK или CRITICAL. Каждая причина — кликабельна: нажмите чтобы сразу увидеть проблемные задачи в реестре.',
  },
  {
    selector: '#ceo-inc',
    title: '2 / 3 — Если ничего не делать',
    text: 'Прогноз на 14 дней вперёд: как риски вырастут сами собой без вмешательства. Помогает убедить команду действовать прямо сейчас.',
  },
  {
    selector: '#ceo-save',
    title: '3 / 3 — Спасти релиз',
    text: 'Три сценария с оценкой риска до/после. Нажмите «Посмотреть изменения» — увидите, что именно предлагается, без применения к данным.',
  },
];

/** Run 3-step micro-tour on CEO blocks. */
export function showCeoTour() {
  setOnboardingStep(0);
  _renderTourStep(0);
}

function _renderTourStep(idx) {
  _hideTourTooltip();
  if (idx >= CEO_TOUR_STEPS.length) {
    _endCeoTour();
    return;
  }
  setOnboardingStep(idx);
  const step = CEO_TOUR_STEPS[idx];
  const target = document.querySelector(step.selector);
  if (!target) { _renderTourStep(idx + 1); return; }

  target.scrollIntoView({ block: 'center', behavior: 'smooth' });
  requestAnimationFrame(() => requestAnimationFrame(() => {
    _positionTourTooltip(target, step, idx);
  }));
}

function _positionTourTooltip(target, step, idx) {
  let tooltip = document.getElementById('ob-tour-tooltip');
  if (!tooltip) {
    tooltip = document.createElement('div');
    tooltip.id = 'ob-tour-tooltip';
    tooltip.className = 'ob-tour-tooltip';
    document.body.appendChild(tooltip);
  }

  const isLast = idx === CEO_TOUR_STEPS.length - 1;
  tooltip.innerHTML = `
    <div class="ob-tour-title">${step.title}</div>
    <div class="ob-tour-text">${step.text}</div>
    <div class="ob-tour-actions">
      <span class="ob-tour-dots">${CEO_TOUR_STEPS.map((_,i) => `<span class="ob-tour-dot${i===idx?' active':''}"></span>`).join('')}</span>
      ${idx > 0 ? `<button class="ob-tour-btn ob-tour-prev" data-idx="${idx}">← Назад</button>` : ''}
      <button class="ob-tour-btn ob-tour-primary ob-tour-next" data-idx="${idx}">${isLast ? 'Готово ✓' : 'Далее →'}</button>
      <button class="ob-tour-btn ob-tour-skip">Пропустить</button>
    </div>`;

  // highlight ring
  let ring = document.getElementById('ob-tour-ring');
  if (!ring) {
    ring = document.createElement('div');
    ring.id = 'ob-tour-ring';
    ring.className = 'ob-tour-ring';
    document.body.appendChild(ring);
  }
  const r = target.getBoundingClientRect();
  const pad = 6;
  ring.style.cssText = `left:${r.left - pad}px;top:${r.top - pad + window.scrollY}px;width:${r.width + pad * 2}px;height:${r.height + pad * 2}px`;
  ring.classList.remove('hidden');

  // position tooltip
  const tipH = 180;
  let tipTop = r.bottom + window.scrollY + 12;
  if (tipTop + tipH > window.scrollY + window.innerHeight - 24) {
    tipTop = r.top + window.scrollY - tipH - 12;
  }
  tipTop = Math.max(window.scrollY + 8, tipTop);
  const tipLeft = Math.max(12, Math.min(r.left, window.innerWidth - 340 - 12));
  tooltip.style.cssText = `left:${tipLeft}px;top:${tipTop}px`;
  tooltip.classList.remove('hidden');

  // bind buttons
  tooltip.querySelector('.ob-tour-next')?.addEventListener('click', () => {
    if (isLast) _endCeoTour();
    else _renderTourStep(idx + 1);
  });
  tooltip.querySelector('.ob-tour-prev')?.addEventListener('click', () => _renderTourStep(idx - 1));
  tooltip.querySelector('.ob-tour-skip')?.addEventListener('click', () => _endCeoTour());
}

function _endCeoTour() {
  _hideTourTooltip();
  completeOnboarding();
  // show CTA to load own data
  showDemoCTA();
}

function _hideTourTooltip() {
  document.getElementById('ob-tour-tooltip')?.remove();
  const ring = document.getElementById('ob-tour-ring');
  if (ring) ring.classList.add('hidden');
}

/* ---- demo ↔ user banner ---- */
/** Update topbar demo / upload-own-data buttons based on current mode. */
export function updateDemoBanner() {
  const demo = isDemoMode();
  const demoBar = document.getElementById('ob-demo-bar');
  const btnLoad = document.getElementById('ob-btn-load-data');
  const btnBackToDemo = document.getElementById('ob-btn-back-demo');
  if (demoBar)       demoBar.classList.toggle('hidden', !demo);
  if (btnLoad)       btnLoad.classList.toggle('hidden', !demo);
  if (btnBackToDemo) btnBackToDemo.classList.toggle('hidden', demo || getOnboardingState().lastDatasetType !== 'demo');
}

/* ---- post-load insights ---- */
/** Show a brief insight toast after user loads own data. */
export function showPostLoadInsights(rows) {
  if (!rows || !rows.length) return;
  const blockers  = rows.filter(r => r.blockingDependency).length;
  const noRelease = rows.filter(r => r.isUnassigned).length;
  const risky     = rows.filter(r => (r.riskScore || 0) >= 50).length;
  const parts = [];
  if (blockers)  parts.push(`🚧 ${blockers} блокеров`);
  if (noRelease) parts.push(`📭 ${noRelease} без релиза`);
  if (risky)     parts.push(`⚠️ ${risky} высоко-рискованных`);
  if (parts.length) {
    _showToast('Загружено: ' + parts.join(' · '), 'warn', 5000);
  } else {
    _showToast(`Загружено ${rows.length} задач — данные выглядят чисто!`, 'success', 3500);
  }
  completeOnboarding();
  setLastDatasetType('user');
  updateDemoBanner();
}

/* ---- empty state ---- */
/** Inject empty-state placeholder into a container when no data present. */
export function showEmptyState(container) {
  if (!container) return;
  container.innerHTML = `
    <div class="ob-empty-state">
      <div class="ob-empty-icon">📋</div>
      <div class="ob-empty-title">Данные не загружены</div>
      <div class="ob-empty-sub">Загрузите свой план или посмотрите на демо-данных как работает аналитика</div>
      <div class="ob-empty-actions">
        <button class="ob-empty-btn ob-empty-btn-primary" id="ob-empty-demo">🎬 Посмотреть демо</button>
        <label class="ob-empty-btn ob-empty-btn-secondary">
          📂 Загрузить файл
          <input type="file" id="ob-empty-file-input" accept=".xlsx,.xls,.csv" class="input-hidden">
        </label>
      </div>
    </div>`;
  container.querySelector('#ob-empty-demo')?.addEventListener('click', startDemoFlow);
  container.querySelector('#ob-empty-file-input')?.addEventListener('change', (e) => {
    const input = document.getElementById('input-xlsx') || document.getElementById('input-csv');
    if (input && e.target.files[0]) {
      const dt = new DataTransfer();
      dt.items.add(e.target.files[0]);
      input.files = dt.files;
      input.dispatchEvent(new Event('change'));
    }
  });
}

/* ---- demo CTA (after tour) ---- */
/** Show "Ready for your own data?" toast/banner after tour finishes. */
export function showDemoCTA() {
  const cta = document.getElementById('ob-cta-bar');
  if (cta) {
    cta.classList.remove('hidden');
    cta.querySelector('#ob-cta-close')?.addEventListener('click', () => cta.classList.add('hidden'));
    cta.querySelector('#ob-cta-upload')?.addEventListener('click', () => {
      cta.classList.add('hidden');
      exitDemoMode();
      updateDemoBanner();
      _showToast('Загрузите свои данные через «Файлы → Импорт XLSX/CSV»', 'info', 5000);
      const filesBtn = document.getElementById('btn-files-dropdown');
      if (filesBtn) { filesBtn.classList.add('ob-pulse'); setTimeout(() => filesBtn.classList.remove('ob-pulse'), 3500); }
    });
  }
}

/* ---- demo loading overlay ---- */
function _showDemoLoading() {
  const el = document.getElementById('ob-loading');
  if (el) el.classList.remove('hidden');
}

function _hideDemoLoading() {
  const el = document.getElementById('ob-loading');
  if (el) el.classList.add('hidden');
}

/* ---- utils ---- */
function _delay(ms) { return new Promise(r => setTimeout(r, ms)); }

/* ================================================================
   BIND WELCOME OVERLAY BUTTONS (called from app.js)
   ================================================================ */
export function bindWelcomeButtons() {
  document.getElementById('ob-btn-demo')?.addEventListener('click', startDemoFlow);
  document.getElementById('ob-btn-setup')?.addEventListener('click', startSetupFlow);
  // 🎓 Full tour — close welcome, dismiss demo banner, kick the legacy 13-step Onboarding
  document.getElementById('ob-btn-tour')?.addEventListener('click', () => {
    hideWelcomeScreen();
    completeOnboarding();    // mark onboarding seen so welcome doesn't reopen
    setLastDatasetType('user');
    // Run after the welcome fade-out so the highlights have a target to point at
    setTimeout(() => {
      try {
        if (typeof window.Onboarding?.start === 'function') window.Onboarding.start();
        else if (typeof window.Onboarding?._start === 'function') window.Onboarding._start();
      } catch(_) {}
    }, 200);
  });
  document.getElementById('ob-welcome-close')?.addEventListener('click', () => {
    // User dismissed without choosing — treat as setup mode
    startSetupFlow();
  });
  // Topbar: re-enter demo
  document.getElementById('ob-btn-back-demo')?.addEventListener('click', async () => {
    enterDemoMode();
    await startDemoFlow();
  });
  // Topbar: load own data (shown in demo bar)
  document.getElementById('ob-btn-load-data')?.addEventListener('click', () => {
    exitDemoMode();
    updateDemoBanner();
    _showToast('Загрузите файл через «Файлы → Импорт XLSX/CSV»', 'info', 5000);
    const filesBtn = document.getElementById('btn-files-dropdown');
    if (filesBtn) { filesBtn.classList.add('ob-pulse'); setTimeout(() => filesBtn.classList.remove('ob-pulse'), 3500); }
  });
}
