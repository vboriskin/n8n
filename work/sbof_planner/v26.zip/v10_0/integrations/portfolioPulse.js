'use strict';
/* ============================================================
   PORTFOLIO PULSE — ORCHESTRATOR
   Wires the modular pieces together and manages tab/sub-tab UI.

   Public surface:
     PortfolioPulse.render(container)
     PortfolioPulse.refresh()
   ============================================================ */

import { loadSettingsRaw } from './integrationsStore.js';
import { fetchPulseData } from './portfolioPulseApi.js';
import { analysePulse, filterModelByPk } from './portfolioPulseModel.js';
import { buildInsights, filterInsightsByPk } from './portfolioPulseInsights.js';
import { buildMetrics } from './portfolioPulseMetrics.js';
import { buildBacklogModel, buildBacklogInsights } from './portfolioPulseBacklog.js';
import {
  renderTopHeader, renderMainTabs, renderErrorBanner,
  renderTeamsTab, renderSummaryTab, renderSprintsTab,
  renderInsightsTab, renderMetricsTab, renderBacklogTab,
  renderSkeleton, renderEmpty, renderError,
} from './portfolioPulseRenderer.js';
import { parseProjectKeys } from './portfolioPulseUtils.js';

export const PortfolioPulse = {
  _model: null,
  _insights: [],
  _metrics: null,
  _backlog: null,
  _backlogInsights: [],
  _activePk: '',
  _activeTab: 'teams',         // 'teams' | 'summary' | 'sprints' | 'insights' | 'metrics' | 'backlog'
  _activeBacklogSubtab: 'summary',
  _container: null,
  _abort: null,
  _reqId: 0,

  /* ── Configuration ────────────────────────────────── */
  _readConfig() {
    let cfg = {};
    try { cfg = loadSettingsRaw(); } catch(_) {}
    return {
      projectKeys: parseProjectKeys(cfg.jiraProjectKeys),
      staleDays:   Number(cfg.pulseStaleDays || 7),
      wipMax:      Number(cfg.pulseWipMax || 3),
    };
  },

  /* ── Public entrypoint ────────────────────────────── */
  async render(container) {
    this._container = container;
    const { projectKeys } = this._readConfig();

    if (!projectKeys.length) {
      container.innerHTML = renderEmpty();
      return;
    }
    await this._fetchAndRender();
  },

  async refresh() {
    if (this._container) await this._fetchAndRender();
  },

  /* ── Fetch + analyse + render ─────────────────────── */
  async _fetchAndRender() {
    const container = this._container;
    if (!container) return;
    const { projectKeys, staleDays, wipMax } = this._readConfig();
    const reqId = (this._reqId = (this._reqId || 0) + 1);

    container.innerHTML = renderSkeleton(`Запрашиваю ${projectKeys.length} проект${projectKeys.length===1?'':projectKeys.length<5?'а':'ов'} из Jira…`);
    container.querySelector('#pp-skel-cancel')?.addEventListener('click', () => {
      try { this._abort?.abort(); } catch(_) {}
      container.innerHTML = renderError('Запрос отменён', true);
      container.querySelector('#pp-retry-btn')?.addEventListener('click', () => this.refresh());
    });

    // Live progress hint
    let phaseIdx = 0;
    const phases = [
      `Запрашиваю ${projectKeys.length} проект${projectKeys.length===1?'':projectKeys.length<5?'а':'ов'} из Jira…`,
      'Идут JQL-запросы (sprint / updated / in-progress / backlog)…',
      'Тяну changelog, worklog и комментарии…',
      'Свожу участников за 48ч…',
      'Считаю инсайты и метрики…',
    ];
    const phaseTimer = setInterval(() => {
      phaseIdx = Math.min(phaseIdx + 1, phases.length - 1);
      const t = container.querySelector('#pp-skel-text');
      if (t) t.textContent = phases[phaseIdx];
    }, 4000);

    try {
      if (this._abort) this._abort.abort();
      this._abort = new AbortController();
      const raw = await fetchPulseData({ projectKeys, signal: this._abort.signal, timeoutMs: 90000 });
      if (reqId !== this._reqId) return;
      // Build all models once on fetch — re-renders are cheap
      this._model = analysePulse(raw, { staleDays });
      this._insights = buildInsights(this._model, { staleDays, wipMax });
      this._metrics = buildMetrics(this._model);
      this._backlog = buildBacklogModel(this._model);
      this._backlogInsights = buildBacklogInsights(this._backlog, this._model);
      this._renderFull();
    } catch (e) {
      if (reqId !== this._reqId) return;
      if (e?.name === 'AbortError') return;
      const isTimeout = e?.name === 'TimeoutError' || /timeout|abort/i.test(String(e?.message||''));
      const msg = isTimeout
        ? 'Запрос занял слишком много времени (>90с). Попробуйте сократить число projectKeys или повторите.'
        : (e?.message || 'Ошибка запроса');
      console.warn('[PortfolioPulse] fetch failed:', e);
      container.innerHTML = renderError(msg, true);
      container.querySelector('#pp-retry-btn')?.addEventListener('click', () => this.refresh());
    } finally {
      clearInterval(phaseTimer);
    }
  },

  /* ── Render top header + main tabs + active tab body ── */
  _renderFull() {
    if (!this._container || !this._model) return;
    const fetchedAtLabel = (() => {
      try { return new Date(this._model.fetchedAt).toLocaleString('ru'); } catch(_) { return '—'; }
    })();
    const html = `
      ${renderTopHeader(this._model, this._activePk, fetchedAtLabel)}
      ${renderErrorBanner(this._model)}
      ${renderMainTabs(this._activeTab)}
      <div class="pp-tab-body">${this._renderActiveTab()}</div>
    `;
    this._container.innerHTML = html;
    this._wire();
  },

  _renderActiveTab() {
    const m = filterModelByPk(this._model, this._activePk);
    const ins = filterInsightsByPk(this._insights, this._activePk);
    switch (this._activeTab) {
      case 'teams':    return renderTeamsTab(m, this._activePk);
      case 'summary':  return renderSummaryTab(m, this._activePk);
      case 'sprints':  return renderSprintsTab(m, this._activePk);
      case 'insights': return renderInsightsTab(ins, this._activePk);
      case 'metrics':  return renderMetricsTab(buildMetrics(m));
      case 'backlog': {
        const bl  = buildBacklogModel(m);
        const blI = buildBacklogInsights(bl, m);
        return renderBacklogTab(bl, blI, this._activePk, this._activeBacklogSubtab);
      }
      default:         return renderTeamsTab(m, this._activePk);
    }
  },

  _wire() {
    const root = this._container;
    if (!root) return;
    // Project-key chips
    root.querySelectorAll('.pp-pk-chip').forEach(c => {
      c.addEventListener('click', () => {
        this._activePk = c.dataset.pk || '';
        this._renderFull();
      });
    });
    // Main-tab switcher
    root.querySelectorAll('.pp-tab').forEach(b => {
      b.addEventListener('click', () => {
        this._activeTab = b.dataset.ppTab;
        this._renderFull();
      });
    });
    // Backlog sub-tabs
    root.querySelectorAll('.pp-subtab').forEach(b => {
      b.addEventListener('click', () => {
        this._activeBacklogSubtab = b.dataset.ppSubtab;
        this._renderFull();
      });
    });
    // Refresh
    root.querySelector('#pp-refresh-btn')?.addEventListener('click', () => this.refresh());
    // Insight target chip → switch to that PK
    root.querySelectorAll('.pp-ins-target').forEach(el => {
      el.addEventListener('click', () => {
        this._activePk = el.dataset.pk || el.textContent.trim();
        this._activeTab = 'teams';
        this._renderFull();
      });
    });
  },

  /** Currently configured project keys (for empty-state message). */
  getConfiguredKeys() {
    return this._readConfig().projectKeys;
  },
};

if (typeof window !== 'undefined') window.PortfolioPulse = PortfolioPulse;
