'use strict';
/* ============================================================
   PORTFOLIO PULSE — RENDERER
   Pure rendering — strings only, no side effects.
   ============================================================ */

import {
  esc, trunc, ts, daysAgo, hoursAgo,
  isTerminalStatus, isInitialStatus, statusBucket,
  typeBucket, typeBucketLabel, groupByBucket, formatHrs,
} from './portfolioPulseUtils.js';
import { renderDonut, renderBars, renderAgeHistogram } from './portfolioPulseMetrics.js';

/* ── Generic chips/issue-rows ──────────────────────────── */

export function renderIssueRow(it, opts = {}) {
  const tooltip = `${it.status || ''}${it.type ? ' · ' + it.type : ''}${it.priority ? ' · ' + it.priority : ''}${it.duedate ? ' · до '+it.duedate : ''}${it.description ? '\n— '+trunc(it.description, 200) : ''}`;
  const parent  = it.parentKey ? `<span class="pp-issue-parent" title="${esc(it.parentKey)}: ${esc(it.parentSum||'')}">↪ ${esc(it.parentKey)}</span>` : '';
  const prio    = it.priority ? `<span class="pp-issue-prio pp-prio-${esc((it.priority||'').toLowerCase())}">${esc(it.priority)}</span>` : '';
  const stat    = it.status ? `<span class="pp-issue-status pp-status-${statusBucket(it.status, it.statusCat)}" title="${esc(it.status)}">${esc(trunc(it.status, 12))}</span>` : '';
  const help    = `<span class="pp-issue-help" title="${esc(tooltip)}">?</span>`;
  return `<div class="pp-issue" data-key="${esc(it.key||'')}">
    <span class="pp-issue-pk">${esc(it.pk||'')}</span>
    <span class="pp-issue-key">${esc(it.key||'—')}</span>
    <span class="pp-issue-sum">${esc(trunc(it.summary, 80))}</span>
    ${parent}
    ${stat}
    ${prio}
    ${help}
  </div>`;
}

export function renderTypeGroup(label, items) {
  if (!items?.length) return '';
  return `<div class="pp-group">
    <div class="pp-group-title">${esc(label)} <span class="pp-group-count">${items.length}</span></div>
    <div class="pp-group-list">${items.map(i => renderIssueRow(i)).join('')}</div>
  </div>`;
}

export function renderGroupedByType(issues) {
  const g = groupByBucket(issues);
  return [
    renderTypeGroup('Story',    g.story),
    renderTypeGroup('Bug',      g.bug),
    renderTypeGroup('Task',     g.task),
    renderTypeGroup('Sub-task', g.subtask),
    renderTypeGroup('Прочее',   g.other),
  ].join('') || '<div class="pp-empty-mini">— нет</div>';
}

/* ── Header (project-keys chips + refresh) ─────────────── */

export function renderTopHeader(model, activePk, fetchedAtLabel) {
  const pks = model.projectKeys || [];
  const errCount = (model.errors||[]).length;
  return `<div class="pp-header">
    <div class="pp-header-row">
      <h3 class="pp-title">📡 Portfolio Pulse</h3>
      <div class="pp-header-meta">
        ${errCount ? `<span class="pp-err-pill" title="Сбойных пространств">⚠ ${errCount}</span>` : ''}
        <span class="pp-fetched">обновлено: ${esc(fetchedAtLabel)}</span>
        <button class="int-btn int-btn-ghost int-btn-xs" id="pp-refresh-btn">↺ Обновить</button>
      </div>
    </div>
    <div class="pp-pk-chips" data-role="pk-switcher">
      <button class="pp-pk-chip ${!activePk?'pp-pk-active':''}" data-pk="">Все</button>
      ${pks.map(pk => `<button class="pp-pk-chip ${activePk===pk?'pp-pk-active':''}" data-pk="${esc(pk)}">${esc(pk)}<span class="pp-pk-count">${(model.spaces[pk]?.issues||[]).length}</span></button>`).join('')}
    </div>
  </div>`;
}

export function renderMainTabs(active) {
  const tabs = [
    { id:'teams',    label:'Все команды' },
    { id:'summary',  label:'Сводка' },
    { id:'sprints',  label:'Спринты' },
    { id:'insights', label:'Инсайты' },
    { id:'metrics',  label:'Метрики' },
    { id:'backlog',  label:'Бэклог' },
  ];
  return `<div class="pp-tabs">${tabs.map(t =>
    `<button class="pp-tab ${active===t.id?'pp-tab-active':''}" data-pp-tab="${t.id}">${esc(t.label)}</button>`).join('')}</div>`;
}

/* ── Tab: ALL TEAMS (participant cards) ─────────────────── */

function _badge(label, value, kind='neutral') {
  return `<span class="pp-badge pp-badge-${kind}" title="${esc(label)}">${esc(label)}: <b>${esc(String(value))}</b></span>`;
}

export function renderParticipantCard(p) {
  const groups = groupByBucket(p.issuesNow);
  const projectChips = p.projects.map(pk => `<span class="pp-mini-pk">${esc(pk)}</span>`).join('');
  const headerBadges = [
    p.loggedYesterdaySec ? _badge('logged вчера', formatHrs(p.loggedYesterdaySec), 'ok') : '',
    p.badges?.commits48h ? _badge('commits 48ч',  p.badges.commits48h)   : '',
    p.badges?.pr48h      ? _badge('PR 48ч',       p.badges.pr48h)        : '',
    p.badges?.conf48h    ? _badge('Confluence',   p.badges.conf48h)      : '',
  ].filter(Boolean).join('');

  const sectionActions = (label, items, opts = {}) => `
    <details class="pp-section" ${opts.openIf && opts.openIf(items) ? 'open' : ''}>
      <summary>${esc(label)} <span class="pp-sect-count">${items.length}</span></summary>
      <div class="pp-sect-body">${items.length ? (opts.render ? opts.render(items) : items.map(renderIssueRow).join('')) : '<div class="pp-empty-mini">— нет</div>'}</div>
    </details>`;

  const renderTimeline = (items) => items.map(e => `
    <div class="pp-timeline-row">
      <span class="pp-timeline-icon">${e.kind==='closed'?'✅':e.kind==='transition'?'↪':e.kind==='comment'?'💬':e.kind==='worklog'?'⏱':'·'}</span>
      <div class="pp-timeline-body">
        <div class="pp-timeline-text">${esc(e.text||'')}</div>
        <div class="pp-timeline-issue">${renderIssueRow(e.issue)}</div>
      </div>
      <span class="pp-timeline-at" title="${esc(e.at||'')}">${esc((e.at||'').slice(11,16))}</span>
    </div>`).join('');

  const renderComments = (items) => items.map(c => `
    <div class="pp-comment">
      ${renderIssueRow(c.issue)}
      <div class="pp-comment-text">${esc(trunc(c.text||'', 240))}</div>
      <div class="pp-comment-at">${esc((c.at||'').slice(0,10))} ${esc((c.at||'').slice(11,16))}</div>
    </div>`).join('');

  return `<div class="pp-card pp-card-user" data-user-key="${esc(p.key)}">
    <div class="pp-card-header">
      <div class="pp-card-id">
        ${p.avatar ? `<img class="pp-avatar" src="${esc(p.avatar)}" alt="" loading="lazy">` : '<span class="pp-avatar pp-avatar-fallback">👤</span>'}
        <div>
          <div class="pp-card-name">${esc(p.label)}</div>
          <div class="pp-card-projects">${projectChips}</div>
        </div>
      </div>
      <div class="pp-card-badges">${headerBadges}</div>
    </div>
    ${sectionActions('В работе сейчас',     p.issuesNow,       { render: renderGroupedByType })}
    ${sectionActions('Что делал вчера',     p.timelineYesterday, { render: renderTimeline })}
    ${sectionActions('Сделано позавчера',   p.timelinePrev,      { render: renderTimeline })}
    ${sectionActions('Оставил комментарии', p.commentsRecent,    { render: renderComments })}
    ${sectionActions('Изменения в Confluence', p.confluenceEdits || [])}
    ${sectionActions(`Висят / stale`,        p.stale,            { openIf: it => it.length > 0 })}
  </div>`;
}

export function renderUnassignedBlock(model, activePk) {
  const entries = activePk
    ? [[activePk, model.unassignedByPk[activePk] || []]]
    : Object.entries(model.unassignedByPk).filter(([_, list]) => list.length);
  if (!entries.length || !entries.some(([_, l]) => l.length)) {
    return '<div class="pp-card pp-card-unassigned"><div class="pp-card-header">' +
      '<div class="pp-card-id"><span class="pp-avatar pp-avatar-empty">∅</span>' +
      '<div><div class="pp-card-name">Без исполнителя</div><div class="pp-card-projects"><span class="pp-mini-pk">все задачи назначены</span></div></div></div></div></div>';
  }
  const total = entries.reduce((s, [_, l]) => s + l.length, 0);
  const groups = entries.map(([pk, list]) => {
    const g = groupByBucket(list);
    return `<details class="pp-section" open>
      <summary>${esc(pk)} <span class="pp-sect-count">${list.length}</span></summary>
      <div class="pp-sect-body">${[
        renderTypeGroup('Story', g.story),
        renderTypeGroup('Bug',   g.bug),
        renderTypeGroup('Task',  g.task),
        renderTypeGroup('Sub-task', g.subtask),
        renderTypeGroup('Прочее',   g.other),
      ].join('') || '<div class="pp-empty-mini">— нет</div>'}</div>
    </details>`;
  }).join('');

  return `<div class="pp-card pp-card-unassigned">
    <div class="pp-card-header">
      <div class="pp-card-id">
        <span class="pp-avatar pp-avatar-empty">∅</span>
        <div>
          <div class="pp-card-name">Без исполнителя</div>
          <div class="pp-card-projects"><span class="pp-mini-pk">${total} задач</span></div>
        </div>
      </div>
    </div>
    ${groups}
  </div>`;
}

export function renderTeamsTab(model, activePk) {
  const cards = (model.participants || []).map(renderParticipantCard).join('');
  return `<div class="pp-cards">
    ${cards || '<div class="pp-empty-mini" style="text-align:center;padding:20px">— нет участников за окно 48ч</div>'}
    ${renderUnassignedBlock(model, activePk)}
  </div>`;
}

/* ── Tab: SUMMARY ─────────────────────────────────────── */

export function renderSummaryTab(model, activePk) {
  const s = model.summary;
  const todoToday = (activePk ? model.todoToday.filter(i => i.pk === activePk) : model.todoToday).slice(0, 50);
  const yest = (activePk ? model.yesterdayActivity.filter(a => a.issue?.pk === activePk) : model.yesterdayActivity).slice(0, 80);

  const sprintsLine = s.activeSprints.length
    ? s.activeSprints.map(a => `<span class="pp-mini-pk">${esc(a.pk)}: ${esc(a.name)}</span>`).join(' ')
    : '<span class="pp-empty-mini">— нет активных спринтов</span>';

  const stats = `
    <div class="pp-stat-grid">
      <div class="pp-stat"><div class="pp-stat-val">${s.totalIssues}</div><div class="pp-stat-label">Всего задач</div></div>
      <div class="pp-stat"><div class="pp-stat-val">${s.wip}</div><div class="pp-stat-label">В работе</div></div>
      <div class="pp-stat"><div class="pp-stat-val">${s.done}</div><div class="pp-stat-label">Done / Terminal</div></div>
      <div class="pp-stat"><div class="pp-stat-val">${s.notStarted}</div><div class="pp-stat-label">Не приступали</div></div>
      <div class="pp-stat"><div class="pp-stat-val">${s.unassigned}</div><div class="pp-stat-label">Без assignee</div></div>
      <div class="pp-stat"><div class="pp-stat-val">${s.blockers}</div><div class="pp-stat-label">Блокеры</div></div>
      <div class="pp-stat"><div class="pp-stat-val">${s.bugs}</div><div class="pp-stat-label">Bugs</div></div>
      <div class="pp-stat"><div class="pp-stat-val">${s.commits48h||0}</div><div class="pp-stat-label">Commits 48ч</div></div>
    </div>`;

  // Detail by bucket (8.4)
  const allIssues = Object.values(model.spaces).flatMap(sp => sp.issues || []);
  const byBucket = { story: { todo:0, wip:0, done:0 }, task: { todo:0, wip:0, done:0 }, bug: { todo:0, wip:0, done:0 }, subtask: { todo:0, wip:0, done:0 } };
  for (const it of allIssues) {
    const b = typeBucket(it);
    if (byBucket[b]) byBucket[b][statusBucket(it.status, it.statusCat)]++;
  }
  const detailRows = ['story','task','bug','subtask'].map(b => `
    <tr>
      <td class="pp-detail-bucket">${esc(typeBucketLabel(b))}</td>
      <td>${byBucket[b].done}</td>
      <td>${byBucket[b].wip}</td>
      <td>${byBucket[b].todo}</td>
    </tr>`).join('');

  return `<div class="pp-summary">
    <div class="pp-section-block">
      <div class="pp-section-block-title">Активные спринты</div>
      <div>${sprintsLine}</div>
    </div>
    ${stats}
    <div class="pp-section-block">
      <div class="pp-section-block-title">Детализация по типам</div>
      <table class="pp-detail-table">
        <thead><tr><th>Тип</th><th>Сделано</th><th>В работе</th><th>Не приступали</th></tr></thead>
        <tbody>${detailRows}</tbody>
      </table>
    </div>
    <div class="pp-section-block">
      <div class="pp-section-block-title">План на сегодня (фокус) <span class="pp-section-block-sub">${todoToday.length} задач</span></div>
      <div class="pp-group-list">${todoToday.map(renderIssueRow).join('') || '<div class="pp-empty-mini">— нет задач в фокусе</div>'}</div>
    </div>
    <div class="pp-section-block">
      <div class="pp-section-block-title">Что делали вчера <span class="pp-section-block-sub">${yest.length} активностей</span></div>
      <div class="pp-yesterday-list">${
        yest.map(a => `
          <div class="pp-timeline-row">
            <span class="pp-timeline-icon">${a.kind==='closed'?'✅':a.kind==='transition'?'↪':a.kind==='comment'?'💬':a.kind==='worklog'?'⏱':'·'}</span>
            <div class="pp-timeline-body">
              <div class="pp-timeline-text"><b>${esc(a.who||'')}</b>${a.text ? ' — '+esc(trunc(a.text, 140)) : ''}</div>
              <div>${renderIssueRow(a.issue)}</div>
            </div>
            <span class="pp-timeline-at">${esc((a.at||'').slice(11,16))}</span>
          </div>`).join('') || '<div class="pp-empty-mini">— нет активности</div>'
      }</div>
    </div>
  </div>`;
}

/* ── Tab: SPRINTS ──────────────────────────────────────── */

export function renderSprintsTab(model, activePk) {
  const pks = activePk ? [activePk] : model.projectKeys;
  if (!pks.length) return '<div class="pp-empty-mini">— нет проектов</div>';
  const sections = pks.map(pk => {
    const sp = model.spaces[pk];
    if (!sp) return `<div class="pp-card"><div class="pp-card-header"><div class="pp-card-name">${esc(pk)}</div></div><div class="pp-empty-mini" style="padding:12px">— нет данных</div></div>`;
    if (sp.hasError) return `<div class="pp-card pp-card-error"><div class="pp-card-header"><div class="pp-card-name">⚠ ${esc(pk)}</div></div><div class="pp-card-body"><div class="pp-err-msg">${esc(sp.errorMsg)}</div></div></div>`;

    const sprint = sp.sprintIssues || [];
    const stats = sp.stats || { byBucket:{}, byStatus:{} };
    const byBucketDetail = ['story','task','bug','subtask'].map(b => {
      const list = sprint.filter(i => typeBucket(i) === b);
      const done = list.filter(i => isTerminalStatus(i.status, i.statusCat)).length;
      const todo = list.filter(i => isInitialStatus(i.status, i.statusCat)).length;
      const wip  = list.length - done - todo;
      return `<tr><td>${esc(typeBucketLabel(b))}</td><td>${done}</td><td>${wip}</td><td>${todo}</td><td>${list.length}</td></tr>`;
    }).join('');

    const sprintName = sp.activeSprintName || '— активный спринт не определён';

    return `<div class="pp-card">
      <div class="pp-card-header">
        <div class="pp-card-id">
          <span class="pp-avatar pp-avatar-fallback">🏁</span>
          <div>
            <div class="pp-card-name">${esc(pk)} · ${esc(sprintName)}</div>
            <div class="pp-card-projects"><span class="pp-mini-pk">${sprint.length} задач</span></div>
          </div>
        </div>
      </div>
      <div class="pp-card-body">
        <div class="pp-section-block-title">Статистика по типам и статусам</div>
        <table class="pp-detail-table">
          <thead><tr><th>Тип</th><th>Сделано</th><th>В работе</th><th>Не приступали</th><th>Всего</th></tr></thead>
          <tbody>${byBucketDetail || '<tr><td colspan="5">—</td></tr>'}</tbody>
        </table>
      </div>
    </div>`;
  }).join('');

  return `<div class="pp-cards">${sections}</div>`;
}

/* ── Tab: INSIGHTS ─────────────────────────────────────── */

export function renderInsightsTab(insights, activePk) {
  if (!insights || !insights.length) {
    return `<div class="pp-empty"><div class="pp-empty-icon">✓</div>
      <div class="pp-empty-title">Сигналов нет</div>
      <div class="pp-empty-sub">Портфель ${activePk?'пространства '+activePk:''} в норме.</div></div>`;
  }
  return `<div class="pp-insights-grid">${insights.map(ins => `
    <div class="pp-ins-card pp-ins-${esc(ins.severity)}">
      <div class="pp-ins-card-head">
        <span class="pp-ins-icon">${ins.severity==='critical'?'🔴':ins.severity==='warning'?'🟡':'🔵'}</span>
        <span class="pp-ins-card-title">${esc(ins.title)}</span>
        ${ins.target ? `<span class="pp-ins-target" data-pk="${esc(ins.target)}">${esc(ins.target)}</span>` : ''}
      </div>
      <div class="pp-ins-card-exp">${esc(ins.explanation||'')}</div>
      ${ins.items && ins.items.length ? `
        <details class="pp-ins-items">
          <summary>Показать задачи (${ins.items.length})</summary>
          <div class="pp-ins-items-body">${ins.items.slice(0,40).map(renderIssueRow).join('')}${ins.items.length>40?`<div class="pp-more">…ещё ${ins.items.length-40}</div>`:''}</div>
        </details>` : ''}
    </div>`).join('')}</div>`;
}

/* ── Tab: METRICS ──────────────────────────────────────── */

export function renderMetricsTab(metrics) {
  return `<div class="pp-metrics-grid">
    ${renderDonut('Распределение типов',     metrics.donutTypes)}
    ${renderDonut('Распределение приоритетов', metrics.donutPriorities)}
    ${renderDonut('Распределение статусов',   metrics.donutStatuses)}
    ${renderBars('WIP по людям',              metrics.wipByPerson, { limit: 12 })}
    ${renderBars('WIP по пространствам',      metrics.wipBySpace,  { limit: 12 })}
    ${renderBars('WIP по типам задач',        metrics.wipByType)}
    ${renderBars('Логирование вчера (ч)',     metrics.loggedByPerson, { limit: 12, suffix:'ч' })}
    ${renderBars('Bugs по пространствам',     metrics.bugsBySpace)}
    ${renderBars('Без assignee по пространствам', metrics.unassignedBySpace)}
    ${renderBars('Stale-задачи по людям',     metrics.staleByPerson)}
    ${renderBars('Backlog size по пространствам', metrics.backlogBySpace)}
    ${renderAgeHistogram('Возраст задач (от created)', metrics.allIssues, 'created')}
  </div>`;
}

/* ── Tab: BACKLOG ──────────────────────────────────────── */

export function renderBacklogTab(bl, blInsights, activePk, subTab='summary') {
  const sub = (id, label) => `<button class="pp-subtab ${subTab===id?'pp-subtab-active':''}" data-pp-subtab="${id}">${esc(label)}</button>`;
  const tabs = `<div class="pp-subtabs">${sub('summary','Сводка')}${sub('metrics','Метрики')}${sub('boards','Дашборды')}${sub('insights','Инсайты')}</div>`;

  const totalsLine = `Всего: <b>${bl.total}</b> · ${Object.entries(bl.totalsByPk).map(([pk,n])=>`${esc(pk)}=${n}`).join(', ') || '—'}`;
  let body = '';

  if (subTab === 'summary') {
    body = `
      <div class="pp-section-block-title">Итого по бэклогу</div>
      <div>${totalsLine}</div>
      <div class="pp-stat-grid" style="margin-top:8px">
        <div class="pp-stat"><div class="pp-stat-val">${bl.total}</div><div class="pp-stat-label">Всего</div></div>
        <div class="pp-stat"><div class="pp-stat-val">${bl.older90d}</div><div class="pp-stat-label">Старше 90д</div></div>
        <div class="pp-stat"><div class="pp-stat-val">${bl.noAssignee}</div><div class="pp-stat-label">Без assignee</div></div>
        <div class="pp-stat"><div class="pp-stat-val">${bl.noDescription}</div><div class="pp-stat-label">Без description</div></div>
        <div class="pp-stat"><div class="pp-stat-val">${bl.bugs}</div><div class="pp-stat-label">Bugs</div></div>
        <div class="pp-stat"><div class="pp-stat-val">${bl.orphanSubs}</div><div class="pp-stat-label">Orphan sub-task</div></div>
        <div class="pp-stat"><div class="pp-stat-val">${bl.overdue}</div><div class="pp-stat-label">Просрочены</div></div>
        <div class="pp-stat"><div class="pp-stat-val">${bl.noPriority}</div><div class="pp-stat-label">Без приоритета</div></div>
      </div>
      <div class="pp-section-block">
        <div class="pp-section-block-title">Top oldest</div>
        ${bl.topOldest.slice(0,15).map(renderIssueRow).join('') || '<div class="pp-empty-mini">— нет</div>'}
      </div>
      <div class="pp-section-block">
        <div class="pp-section-block-title">Top high-priority</div>
        ${bl.topHighPriority.slice(0,15).map(renderIssueRow).join('') || '<div class="pp-empty-mini">— нет</div>'}
      </div>`;
  } else if (subTab === 'metrics') {
    const all = Object.values(bl.issuesByPk).flat();
    const donutTypes      = Object.create(null);
    const donutPriorities = Object.create(null);
    const donutStatuses   = Object.create(null);
    const byPk            = Object.create(null);
    for (const i of all) {
      donutTypes[i.type||'—'] = (donutTypes[i.type||'—']||0)+1;
      donutPriorities[i.priority||'—'] = (donutPriorities[i.priority||'—']||0)+1;
      donutStatuses[i.status||'—'] = (donutStatuses[i.status||'—']||0)+1;
      byPk[i.pk||'—'] = (byPk[i.pk||'—']||0)+1;
    }
    body = `<div class="pp-metrics-grid">
      ${renderAgeHistogram('Возраст задач в backlog',  all, 'created')}
      ${renderDonut('Приоритеты',  donutPriorities)}
      ${renderDonut('Статусы',     donutStatuses)}
      ${renderDonut('Типы',        donutTypes)}
      ${renderBars('По пространствам', byPk)}
    </div>`;
  } else if (subTab === 'boards') {
    body = `<div class="pp-cards">${
      Object.entries(bl.issuesByPk).map(([pk, list]) => {
        const oldest = list.slice().sort((a,b)=>ts(a.created)-ts(b.created))[0];
        const oldestAge = oldest ? Math.floor((Date.now()-ts(oldest.created))/(24*3600*1000)) : 0;
        const high = list.filter(i => /(blocker|highest|critical|high|критич|высок)/i.test(i.priority||'')).length;
        const bugs = list.filter(i => typeBucket(i)==='bug').length;
        const noA  = list.filter(i => !i.assignee).length;
        const noD  = list.filter(i => !i.description).length;
        return `<div class="pp-card">
          <div class="pp-card-header">
            <div class="pp-card-id"><span class="pp-avatar pp-avatar-fallback">📂</span>
            <div><div class="pp-card-name">${esc(pk)}</div><div class="pp-card-projects"><span class="pp-mini-pk">${list.length} в backlog</span></div></div></div>
          </div>
          <div class="pp-card-body">
            <div class="pp-stat-grid">
              <div class="pp-stat"><div class="pp-stat-val">${list.length}</div><div class="pp-stat-label">Всего</div></div>
              <div class="pp-stat"><div class="pp-stat-val">${oldestAge}д</div><div class="pp-stat-label">Самой старой</div></div>
              <div class="pp-stat"><div class="pp-stat-val">${high}</div><div class="pp-stat-label">High prio</div></div>
              <div class="pp-stat"><div class="pp-stat-val">${bugs}</div><div class="pp-stat-label">Bugs</div></div>
              <div class="pp-stat"><div class="pp-stat-val">${noA}</div><div class="pp-stat-label">Без assignee</div></div>
              <div class="pp-stat"><div class="pp-stat-val">${noD}</div><div class="pp-stat-label">Без description</div></div>
            </div>
          </div>
        </div>`;
      }).join('') || '<div class="pp-empty-mini" style="text-align:center;padding:14px">— backlog пуст</div>'
    }</div>`;
  } else if (subTab === 'insights') {
    body = renderInsightsTab(blInsights || [], activePk);
  }

  return `<div class="pp-backlog">${tabs}<div class="pp-backlog-body">${body}</div></div>`;
}

/* ── Top-level errors banner ───────────────────────────── */

export function renderErrorBanner(model) {
  if (!model.errors || !model.errors.length) return '';
  return `<div class="pp-errors">${model.errors.map(e => `
    <div class="pp-err-card">
      <div class="pp-err-pk">⚠ ${esc(e.projectKey)}</div>
      <div class="pp-err-msg">${esc(e.error||'')}</div>
    </div>`).join('')}</div>`;
}

/* ── Skeleton / empty / error states ───────────────────── */

export function renderSkeleton(message) {
  return `<div class="pp-skeleton">
    <div class="pp-skel-status">
      <span class="pp-skel-spinner" aria-hidden="true"></span>
      <span class="pp-skel-text" id="pp-skel-text">${esc(message||'Запрашиваю задачи из Jira…')}</span>
      <button class="int-btn int-btn-ghost int-btn-xs" id="pp-skel-cancel" type="button">✕ Отменить</button>
    </div>
    <div class="pp-skel-line"></div>
    <div class="pp-skel-card"></div>
    <div class="pp-skel-card"></div>
    <div class="pp-skel-card"></div>
  </div>`;
}

export function renderEmpty(reason) {
  return `<div class="pp-empty">
    <div class="pp-empty-icon">📡</div>
    <div class="pp-empty-title">Нет данных Portfolio Pulse</div>
    <div class="pp-empty-sub">${esc(reason || 'Укажите ключи проектных пространств: ⚙ Настройки → Интеграции → Jira → «Ключи проектных пространств».')}</div>
  </div>`;
}

export function renderError(message, retry=true) {
  return `<div class="pp-empty">
    <div class="pp-empty-icon">⚠</div>
    <div class="pp-empty-title">Не удалось получить данные</div>
    <div class="pp-empty-sub">${esc(message||'Ошибка запроса')}</div>
    ${retry ? `<div style="margin-top:14px"><button class="int-btn int-btn-primary" id="pp-retry-btn">↺ Повторить</button></div>` : ''}
  </div>`;
}
