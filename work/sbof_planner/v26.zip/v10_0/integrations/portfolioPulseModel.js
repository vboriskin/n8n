'use strict';
/* ============================================================
   PORTFOLIO PULSE — MODEL ANALYSER
   Turns raw Jira reports into a structured pulse model.
   ============================================================ */

import {
  isTerminalStatus, isInitialStatus, isWipActive, ts,
  todayStart, yesterdayStart, twoDaysAgoStart, hoursAgo, daysAgo,
  userKey, userLabel, userAvatar, slimIssue, typeBucket, statusBucket,
} from './portfolioPulseUtils.js';

const STALE_DAYS_DEFAULT = 7;

/**
 * @param  {object} rawReports - { reports: [{ projectKey, issues, error?, sprintKeys?, ... }], fetchedAt, projectKeys }
 * @param  {object} opts       - { staleDays: number }
 * @return {PulseModel}
 *
 * PulseModel = {
 *   fetchedAt, projectKeys[], errors[{pk, error}],
 *   participants[{ key, label, avatar, projects[],
 *                 issuesNow[], doneYesterday[], doneDayBefore[],
 *                 commentsRecent[], confluenceEdits[],
 *                 stale[], loggedYesterdaySec,
 *                 timelineYesterday[], timelinePrev[],
 *                 badges:{commits48h,pr48h,conf48h} }],
 *   unassignedByPk: { [pk]: issues[] },
 *   spaces: { [pk]: { issues[], sprintIssues[], backlogIssues[], wipIssues[],
 *                     activeSprintName, hasError, errorMsg } },
 *   summary: { totalIssues, wip, done, notStarted, unassigned, blockers,
 *              bugs, commits48h, pr48h, conf48h },
 * }
 */
export function analysePulse(rawReports, opts = {}) {
  const staleDays = opts.staleDays || STALE_DAYS_DEFAULT;
  const yStart  = yesterdayStart();
  const tStart  = todayStart();
  const dbStart = twoDaysAgoStart();
  const win48   = hoursAgo(48);

  const out = {
    fetchedAt:    rawReports?.fetchedAt || new Date().toISOString(),
    projectKeys:  rawReports?.projectKeys || [],
    errors:       [],
    participants: [],
    unassignedByPk: {},
    spaces:       {},
    summary: {
      totalIssues: 0, wip: 0, done: 0, notStarted: 0,
      unassigned: 0, blockers: 0, bugs: 0,
      commits48h: 0, pr48h: 0, conf48h: 0,
      activeSprints: [],
    },
    todoToday: [],          // 8.2 plan-for-today candidates
    yesterdayActivity: [],  // 8.3 what was done yesterday (transitions/worklog/comments)
  };

  const userMap = new Map();
  const ensureUser = (u, projectKey) => {
    const k = userKey(u);
    if (!k) return null;
    let p = userMap.get(k);
    if (!p) {
      p = {
        key: k, label: userLabel(u), avatar: userAvatar(u),
        projects: new Set(),
        issuesNow: [], doneYesterday: [], doneDayBefore: [], stale: [],
        commentsRecent: [], confluenceEdits: [],
        timelineYesterday: [],   // [{kind, issue, at, text?}]
        timelinePrev:      [],
        loggedYesterdaySec: 0, loggedDayBeforeSec: 0,
        badges: { commits48h: 0, pr48h: 0, conf48h: 0 },
      };
      userMap.set(k, p);
    }
    if (projectKey) p.projects.add(projectKey);
    return p;
  };

  // Walk per-project reports
  for (const report of (rawReports?.reports || [])) {
    if (report.error) {
      out.errors.push({ projectKey: report.projectKey, error: report.error });
      out.spaces[report.projectKey] = { hasError: true, errorMsg: report.error, issues: [], sprintIssues: [], backlogIssues: [], wipIssues: [], activeSprintName: '', activeSprintInfo: null };
      continue;
    }
    const pk = report.projectKey;
    const sprintKeys = new Set(report.sprintKeys || []);
    const inProgressKeys = new Set(report.inProgressKeys || []);
    const backlogKeys = new Set(report.backlogKeys || []);

    const space = {
      hasError: false, errorMsg: '',
      issues: [], sprintIssues: [], backlogIssues: [], wipIssues: [],
      activeSprintName: '', activeSprintInfo: null,
      stats: { byBucket: { story:0, task:0, bug:0, subtask:0, other:0 }, byStatus: { todo:0, wip:0, done:0 } },
    };
    out.spaces[pk] = space;
    out.unassignedByPk[pk] = [];

    for (const issue of (report.issues || [])) {
      const f = issue.fields || {};
      const status   = f.status?.name || '';
      const statusCat= f.status?.statusCategory?.key || '';
      const terminal = isTerminalStatus(status, statusCat);
      const initial  = isInitialStatus(status, statusCat);
      const slim = slimIssue(issue, pk);
      space.issues.push(slim);
      out.summary.totalIssues++;

      // Sprint / backlog / wip classification
      if (sprintKeys.has(issue.key)) space.sprintIssues.push(slim);
      if (backlogKeys.has(issue.key)) space.backlogIssues.push(slim);
      if (!terminal && isWipActive(issue)) space.wipIssues.push(slim);

      // Try to capture active sprint name from custom fields (Jira customfield_10010 typically)
      if (!space.activeSprintName) {
        for (const k of Object.keys(f)) {
          if (!k.startsWith('customfield_')) continue;
          const v = f[k];
          const arr = Array.isArray(v) ? v : (v ? [v] : []);
          for (const sp of arr) {
            const sName = sp?.name || (typeof sp === 'string' ? extractSprintName(sp) : '');
            const sState = sp?.state || (typeof sp === 'string' ? extractSprintState(sp) : '');
            if (sName && /active/i.test(sState || '')) {
              space.activeSprintName = sName;
              space.activeSprintInfo = sp;
              break;
            }
          }
          if (space.activeSprintName) break;
        }
      }

      // Stats
      space.stats.byBucket[typeBucket(slim)] += 1;
      const sb = statusBucket(status, statusCat);
      space.stats.byStatus[sb] += 1;

      // Summary aggregates
      if (terminal) out.summary.done++;
      else if (initial) out.summary.notStarted++;
      else out.summary.wip++;
      if (typeBucket(slim) === 'bug') out.summary.bugs++;
      if (f.priority?.name && /blocker|highest|критич/i.test(f.priority.name) && !terminal) out.summary.blockers++;

      const assignee = f.assignee || null;
      if (!assignee && !terminal) {
        out.unassignedByPk[pk].push(slim);
        out.summary.unassigned++;
      }

      const user = assignee ? ensureUser(assignee, pk) : null;

      // 3.1 In progress now
      if (user && !terminal) user.issuesNow.push(slim);

      // 3.6 Stale (active, not updated for >= staleDays)
      if (user && !terminal) {
        const upd = ts(f.updated);
        if (upd && (Date.now() - upd) >= staleDays * 24 * 3600 * 1000) {
          user.stale.push({ ...slim, daysIdle: Math.floor((Date.now() - upd) / (24*3600*1000)) });
        }
      }

      // Walk changelog: status transitions
      const histories = issue.changelog?.histories || [];
      for (const h of histories) {
        const tH = ts(h.created);
        if (!tH) continue;
        for (const it of (h.items || [])) {
          if (it.field !== 'status') continue;
          const toName = it.toString || it.to || '';
          const isTermTo = isTerminalStatus(toName);
          const moverU = h.author && ensureUser(h.author, pk);
          if (!moverU) continue;
          const event = { kind: isTermTo ? 'closed' : 'transition',
                          issue: slim, at: h.created, text: `Перевели в ${toName}` };
          if (tH >= yStart && tH < tStart) {
            moverU.timelineYesterday.push(event);
            if (isTermTo) moverU.doneYesterday.push(slim);
            out.yesterdayActivity.push({ kind: event.kind, issue: slim, at: h.created, who: moverU.label, text: event.text });
          } else if (tH >= dbStart && tH < yStart) {
            moverU.timelinePrev.push(event);
            if (isTermTo) moverU.doneDayBefore.push(slim);
          }
        }
      }

      // Walk comments: 48h window
      const comments = f.comment?.comments || [];
      for (const c of comments) {
        const tC = ts(c.created);
        if (!tC || tC < win48) continue;
        const author = c.author && ensureUser(c.author, pk);
        if (!author) continue;
        const evt = { kind: 'comment', issue: slim, at: c.created, text: String(c.body || '').slice(0, 220) };
        author.commentsRecent.push(evt);
        if (tC >= yStart && tC < tStart) {
          author.timelineYesterday.push(evt);
          out.yesterdayActivity.push({ kind: 'comment', issue: slim, at: c.created, who: author.label, text: evt.text });
        } else if (tC >= dbStart && tC < yStart) {
          author.timelinePrev.push(evt);
        }
      }

      // Walk worklog: yesterday/dayBefore aggregation
      const wls = f.worklog?.worklogs || [];
      for (const wl of wls) {
        const tW = ts(wl.started);
        if (!tW) continue;
        const author = wl.author && ensureUser(wl.author, pk);
        if (!author) continue;
        const sec = Number(wl.timeSpentSeconds || 0);
        if (tW >= yStart && tW < tStart) {
          author.loggedYesterdaySec += sec;
          author.timelineYesterday.push({ kind: 'worklog', issue: slim, at: wl.started, text: `Залогировано ${Math.round(sec/3600*10)/10}ч` });
          out.yesterdayActivity.push({ kind: 'worklog', issue: slim, at: wl.started, who: author.label, text: `${Math.round(sec/3600*10)/10}ч` });
        } else if (tW >= dbStart && tW < yStart) {
          author.loggedDayBeforeSec += sec;
        }
      }

      // 8.2 Plan for today: heuristic — assigned, in WIP/sprint, not terminal,
      // not just-updated yesterday (recently-active issues likely continue today).
      if (assignee && !terminal && (sprintKeys.has(issue.key) || isWipActive(issue))) {
        out.todoToday.push(slim);
      }
    }
  }

  // Convert sets to arrays + sort participants
  for (const p of userMap.values()) {
    p.projects = Array.from(p.projects);
    out.participants.push(p);
  }
  out.participants.sort((a, b) =>
    (b.issuesNow.length + b.doneYesterday.length + b.commentsRecent.length) -
    (a.issuesNow.length + a.doneYesterday.length + a.commentsRecent.length));

  // Sort unassigned per pk by oldest update
  for (const pk of Object.keys(out.unassignedByPk)) {
    out.unassignedByPk[pk].sort((a, b) => ts(a.updated) - ts(b.updated));
  }

  // Active sprint summary
  out.summary.activeSprints = Object.entries(out.spaces)
    .map(([pk, s]) => ({ pk, name: s.activeSprintName }))
    .filter(s => s.name);

  // Yesterday activity sorted desc
  out.yesterdayActivity.sort((a, b) => ts(b.at) - ts(a.at));

  return out;
}

/** Filter the model by an active projectKey. Returns a NEW shallow model. */
export function filterModelByPk(model, pk) {
  if (!pk) return model;
  const inPk = (it) => it && it.pk === pk;
  const participants = model.participants.map(p => ({
    ...p,
    issuesNow:        p.issuesNow.filter(inPk),
    doneYesterday:    p.doneYesterday.filter(inPk),
    doneDayBefore:    p.doneDayBefore.filter(inPk),
    stale:            p.stale.filter(inPk),
    commentsRecent:   p.commentsRecent.filter(c => inPk(c.issue)),
    confluenceEdits:  (p.confluenceEdits||[]).filter(c => inPk(c.issue)),
    timelineYesterday: p.timelineYesterday.filter(e => inPk(e.issue)),
    timelinePrev:     p.timelinePrev.filter(e => inPk(e.issue)),
  })).filter(p =>
    p.issuesNow.length + p.doneYesterday.length + p.doneDayBefore.length +
    p.stale.length + p.commentsRecent.length > 0);

  const unassignedByPk = { [pk]: model.unassignedByPk[pk] || [] };
  return {
    ...model, participants, unassignedByPk,
    yesterdayActivity: model.yesterdayActivity.filter(a => inPk(a.issue)),
    todoToday: model.todoToday.filter(inPk),
  };
}

/* ── Sprint name parsing from old Jira customfield_10010 string ── */
function extractSprintName(s) { const m = String(s).match(/name=([^,\]]+)/); return m ? m[1] : ''; }
function extractSprintState(s){ const m = String(s).match(/state=([^,\]]+)/); return m ? m[1] : ''; }
