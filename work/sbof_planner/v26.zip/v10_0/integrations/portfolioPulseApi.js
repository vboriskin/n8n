'use strict';
/* ============================================================
   PORTFOLIO PULSE — API LAYER
   Talks to /api/integrations/portfolio-pulse only. Server does
   the actual Jira / Bitbucket / Confluence aggregation.

   - Composes user signal with a timeout signal so request can't hang.
   - Surfaces server "errors" array unchanged (per-PK fallback).
   ============================================================ */

const ENDPOINT = '/api/integrations/portfolio-pulse';

export async function fetchPulseData({ projectKeys, signal, timeoutMs = 90000 } = {}) {
  const body = projectKeys && projectKeys.length ? { projectKeys } : {};

  // Compose abort signals: external + internal timeout
  const inner = new AbortController();
  let timer = null;
  if (timeoutMs > 0) timer = setTimeout(() => inner.abort(new DOMException('Timeout', 'TimeoutError')), timeoutMs);
  if (signal) {
    if (signal.aborted) inner.abort(signal.reason);
    else signal.addEventListener('abort', () => inner.abort(signal.reason));
  }

  try {
    const res = await fetch(ENDPOINT, {
      method:  'POST',
      signal:  inner.signal,
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}
