'use strict';
/* ============================================================
   STATE — v8_0 ES module
   ============================================================ */

import { REGISTRY_COLS, COL_TYPES } from './constants.js';

export const state = {
  rows: [],
  employees: [],
  filters: {
    search:'', team:'', scope:'', release:'', workType:'', role:'', assignee:'', tag:'',
    onlyBlocking:false, onlyRisky:false, onlyDone:false, preset:null,
  },
  activeSection: 'dashboard',
  diagnostics: {
    sources:[], sheets:[], rowsPerSheet:{}, detectedColumns:{}, missingColumns:{}, warnings:[],
    registryCount:0, csvImportCount:0, localStorageCount:0,
  },
  sort: { col:null, dir:'asc' },
  ganttMode: 'compact',
  ganttEpicsWell: 'none',
  epicDeps: {},
  gantt2Zoom: 1,
  gantt2ShowDeps: true,
  gantt2Team: '',
  lastClickedRowId: null,
  timelineMode: 'summary',
  podlozhkaGroup: 'team',
  podlozhkaMode: 'summary',
  summaryMode: 'brief',
  presetsCollapsed: false,
  theme: 'light',
  colVisibility: {},
  colOrder: REGISTRY_COLS.map(c => c.key),
  colWidths: {},
  colLabels: {},
  pinnedCols: [],
  rowHeight: 36,
  customCols: [],
  colTypes: {},
  sidebarCollapsed: false,
  _idCounter: 1,
  _dataVersion: 0,
  llm: {},
  simMode: false,
  bulkSelected: new Set(),
  actionLog: [],
};
REGISTRY_COLS.forEach(c => { state.colVisibility[c.key] = c.visible; });

export function getAllCols() {
  return [...REGISTRY_COLS, ...state.customCols].map(col => ({
    ...col,
    // `type` reflects the user-selected display type (controls renderer choice).
    type:        state.colTypes[col.key] || col.type || 'text',
    // `naturalType` is the column's underlying storage format (controls how to read/write).
    // E.g. release120Types is naturally 'multiselect' (array) — even if user picks 'tags'
    // for display, we must keep the array storage so gantt / dashboard / risk engine work.
    naturalType: col.type || 'text',
  }));
}

export function toBool(value, fallback=false) {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  if (typeof value === 'string') {
    const v = value.trim().toLowerCase();
    if (['true','1','yes','on','да'].includes(v)) return true;
    if (['false','0','no','off','нет',''].includes(v)) return false;
  }
  return !!fallback;
}

export function syncColumnSettings() {
  // Sanitize custom columns first (old localStorage could contain half-broken objects).
  const seenCustom = new Set();
  state.customCols = (Array.isArray(state.customCols) ? state.customCols : []).map((col, idx) => {
    if (!col || typeof col !== 'object') return null;
    const key = String(col.key || '').trim() || ('custom_' + idx);
    if (seenCustom.has(key)) return null;
    seenCustom.add(key);
    const widthRaw = Number.parseInt(col.width, 10);
    return {
      key,
      label: String(col.label || key).trim() || key,
      type: COL_TYPES.includes(col.type) ? col.type : 'text',
      visible: toBool(col.visible, true),
      width: Math.max(70, Math.min(420, Number.isFinite(widthRaw) ? widthRaw : 150)),
    };
  }).filter(Boolean);

  const all=[...REGISTRY_COLS, ...state.customCols];
  const allSet=new Set(all.map(c=>c.key));

  // Order: keep only existing keys, unique, then append missing.
  const orderRaw=Array.isArray(state.colOrder)?state.colOrder:[];
  const order=[];
  orderRaw.forEach(k=>{ if(allSet.has(k)&&!order.includes(k)) order.push(k); });
  all.forEach(col=>{ if(!order.includes(col.key)) order.push(col.key); });
  state.colOrder=order;

  // Visibility coercion: accept booleans and legacy "true"/"false" strings.
  const vis={};
  all.forEach(col=>{ vis[col.key]=toBool(state.colVisibility?.[col.key], col.visible!==false); });
  state.colVisibility=vis;

  // Widths with sane caps to avoid "everything moved away" UI.
  const widths={};
  all.forEach(col=>{
    const raw=state.colWidths?.[col.key];
    const n=Number.parseInt(raw,10);
    if (Number.isFinite(n)) widths[col.key]=Math.max(70,Math.min(420,n));
  });
  state.colWidths=widths;

  // Labels.
  const labels={};
  all.forEach(col=>{
    const v=state.colLabels?.[col.key];
    if (typeof v==='string' && v.trim()) labels[col.key]=v.trim();
  });
  state.colLabels=labels;

  // Type overrides.
  const types={};
  all.forEach(col=>{
    const t=state.colTypes?.[col.key];
    if (COL_TYPES.includes(t)) types[col.key]=t;
  });
  state.colTypes=types;

  // Pinned columns must exist and be visible.
  state.pinnedCols=[...new Set((Array.isArray(state.pinnedCols)?state.pinnedCols:[]).filter(key=>allSet.has(key)&&state.colVisibility[key]!==false))].slice(0,6);

  // Row height hard clamp.
  const rh=Number.parseInt(state.rowHeight,10);
  state.rowHeight=Math.max(28,Math.min(44,Number.isFinite(rh)?rh:36));

  // Sidebar collapsed flag could be stored as string in older snapshots.
  state.sidebarCollapsed=toBool(state.sidebarCollapsed,false);
  state.presetsCollapsed=toBool(state.presetsCollapsed,false);

  // Epic dependencies cleanup.
  const deps={};
  Object.entries(state.epicDeps||{}).forEach(([a,b])=>{
    const from=String(a||'').trim();
    const to=String(b||'').trim();
    if (!from||!to||from===to) return;
    deps[from]=to;
  });
  state.epicDeps=deps;
}

// Subscribe/notify mechanism for cross-module communication
const _listeners = [];
export function subscribe(fn) {
  _listeners.push(fn);
  return () => {
    const i = _listeners.indexOf(fn);
    if (i > -1) _listeners.splice(i, 1);
  };
}
export function notify(reason='') {
  _listeners.forEach(fn => { try { fn(reason); } catch(e) {} });
}
