'use strict';
/* ============================================================
   testRunner.js — v8_0 domain logic tests
   Run: node testRunner.js
   No npm required — uses Node.js built-in assert.
   ============================================================ */

const assert = require('assert');

let passed = 0, failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log('  ✓', name);
    passed++;
  } catch (e) {
    console.error('  ✗', name);
    console.error('    ', e.message);
    failed++;
  }
}

function group(label, fn) {
  console.log('\n' + label);
  fn();
}

// ============================================================
// Inline domain logic (mirrors v8_0 modules — no import needed)
// ============================================================

// ---- RiskEngine (mirrors riskEngine.js) ----
const RiskEngine = {
  computeFlags(row) {
    const flags = [];
    const inAny = row.hasRelease120 || row.hasRelease121 || row.hasRelease122 || row.hasOvertime;
    if (row.scopeStatus === 'Требует подтверждения' && inAny) flags.push('CONFIRMATION_IN_RELEASE');
    if (row.scopeStatus === 'Да' && row.isUnassigned) flags.push('IN_SCOPE_WITHOUT_RELEASE');
    if (row.blockingDependency && (row.hasRelease120 || row.hasRelease121)) flags.push('BLOCKING_NEAR_RELEASE');
    row.riskFlags = flags;
  },
  computeRiskScore(row) {
    let score = 0;
    if (row.blockingDependency) score += 30;
    if ((row.riskFlags || []).includes('IN_SCOPE_WITHOUT_RELEASE')) score += 25;
    if ((row.riskFlags || []).includes('CONFIRMATION_IN_RELEASE')) score += 20;
    if (row.hasRelease120) score += 15;
    if (row.scopeStatus === 'Требует подтверждения') score += 10;
    row.riskScore = Math.min(100, score);
    return row.riskScore;
  },
  computeAll(rows) {
    rows.forEach(r => { RiskEngine.computeFlags(r); RiskEngine.computeRiskScore(r); });
  },
};

function makeRow(overrides = {}) {
  return {
    id: 'r_' + Math.random().toString(36).slice(2),
    scopeStatus: '',
    blockingDependency: false,
    hasRelease120: false,
    hasRelease121: false,
    hasRelease122: false,
    hasOvertime: false,
    isUnassigned: true,
    riskFlags: [],
    riskScore: 0,
    isDone: false,
    release120Types: [],
    release121Types: [],
    release122Types: [],
    overtimeTypes: [],
    team: '',
    assignee: '',
    ...overrides,
  };
}

// ---- FilterEngine (mirrors filters.js core logic) ----
function applyFilters(rows, filters) {
  return rows.filter(r => {
    if (filters.search) {
      const q = filters.search.toLowerCase();
      const hay = `${r.epic} ${r.team} ${r.tasks} ${r.assignee} ${r.comment || ''}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    if (filters.team && r.team !== filters.team) return false;
    if (filters.scope && r.scopeStatus !== filters.scope) return false;
    if (filters.release) {
      if (filters.release === 'none') { if (!r.isUnassigned) return false; }
      else if (filters.release === '120') { if (!r.hasRelease120) return false; }
      else if (filters.release === '121') { if (!r.hasRelease121) return false; }
      else if (filters.release === '122') { if (!r.hasRelease122) return false; }
      else if (filters.release === 'overtime') { if (!r.hasOvertime) return false; }
    }
    if (filters.onlyBlocking && !r.blockingDependency) return false;
    if (filters.onlyRisky && !(r.riskFlags && r.riskFlags.length > 0)) return false;
    if (filters.onlyDone && !r.isDone) return false;
    return true;
  });
}

// ---- DependencyEngine (mirrors dependencyEngine.js) ----
function detectCycle(epicDeps, from, visited = new Set()) {
  if (visited.has(from)) return true;
  visited.add(from);
  const to = epicDeps[from];
  if (!to) return false;
  return detectCycle(epicDeps, to, visited);
}

function getTransitiveDeps(epicDeps, from) {
  const chain = [];
  let cur = from;
  const seen = new Set();
  while (epicDeps[cur] && !seen.has(cur)) {
    seen.add(cur);
    cur = epicDeps[cur];
    chain.push(cur);
  }
  return chain;
}

// ---- MetricsEngine (mirrors metricsEngine.js) ----
function computeProgress(rows) {
  const releases = ['120', '121', '122', 'ot'];
  const result = {};
  releases.forEach(rel => {
    const key = rel === 'ot' ? 'hasOvertime' : `hasRelease${rel}`;
    const inRel = rows.filter(r => r[key]);
    const done = inRel.filter(r => r.isDone).length;
    result[rel] = { total: inRel.length, done, pct: inRel.length ? Math.round(done / inRel.length * 100) : 0 };
  });
  const total = rows.length;
  const done = rows.filter(r => r.isDone).length;
  result.all = { total, done, pct: total ? Math.round(done / total * 100) : 0 };
  return result;
}

function computeLoad(rows) {
  const load = {};
  rows.forEach(r => {
    const assignees = String(r.assignee || '').split(/[|,]/).map(s => s.trim()).filter(Boolean);
    assignees.forEach(name => {
      if (!load[name]) load[name] = { total: 0, r120: 0, r121: 0, r122: 0, ot: 0 };
      load[name].total++;
      if (r.hasRelease120) load[name].r120++;
      if (r.hasRelease121) load[name].r121++;
      if (r.hasRelease122) load[name].r122++;
      if (r.hasOvertime) load[name].ot++;
    });
  });
  return load;
}

// ---- toBool (mirrors state.js) ----
function toBool(value, fallback = false) {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  if (typeof value === 'string') {
    const v = value.trim().toLowerCase();
    if (['true', '1', 'yes', 'on', 'да'].includes(v)) return true;
    if (['false', '0', 'no', 'off', 'нет', ''].includes(v)) return false;
  }
  return !!fallback;
}

// ============================================================
// Tests
// ============================================================

group('RiskEngine — computeFlags', () => {
  test('no flags on empty row', () => {
    const r = makeRow();
    RiskEngine.computeFlags(r);
    assert.deepStrictEqual(r.riskFlags, []);
  });

  test('BLOCKING_NEAR_RELEASE when blocker in 1.20', () => {
    const r = makeRow({ blockingDependency: true, hasRelease120: true, isUnassigned: false });
    RiskEngine.computeFlags(r);
    assert.ok(r.riskFlags.includes('BLOCKING_NEAR_RELEASE'));
  });

  test('BLOCKING_NEAR_RELEASE when blocker in 1.21', () => {
    const r = makeRow({ blockingDependency: true, hasRelease121: true, isUnassigned: false });
    RiskEngine.computeFlags(r);
    assert.ok(r.riskFlags.includes('BLOCKING_NEAR_RELEASE'));
  });

  test('no BLOCKING_NEAR_RELEASE for 1.22 blocker (not near)', () => {
    const r = makeRow({ blockingDependency: true, hasRelease122: true, isUnassigned: false });
    RiskEngine.computeFlags(r);
    assert.ok(!r.riskFlags.includes('BLOCKING_NEAR_RELEASE'));
  });

  test('IN_SCOPE_WITHOUT_RELEASE when scope=Да and unassigned', () => {
    const r = makeRow({ scopeStatus: 'Да', isUnassigned: true });
    RiskEngine.computeFlags(r);
    assert.ok(r.riskFlags.includes('IN_SCOPE_WITHOUT_RELEASE'));
  });

  test('no IN_SCOPE_WITHOUT_RELEASE when scope=Да but has release', () => {
    const r = makeRow({ scopeStatus: 'Да', isUnassigned: false, hasRelease120: true });
    RiskEngine.computeFlags(r);
    assert.ok(!r.riskFlags.includes('IN_SCOPE_WITHOUT_RELEASE'));
  });

  test('CONFIRMATION_IN_RELEASE when needs confirm and in release', () => {
    const r = makeRow({ scopeStatus: 'Требует подтверждения', hasRelease121: true, isUnassigned: false });
    RiskEngine.computeFlags(r);
    assert.ok(r.riskFlags.includes('CONFIRMATION_IN_RELEASE'));
  });

  test('no CONFIRMATION_IN_RELEASE when unassigned', () => {
    const r = makeRow({ scopeStatus: 'Требует подтверждения', isUnassigned: true });
    RiskEngine.computeFlags(r);
    assert.ok(!r.riskFlags.includes('CONFIRMATION_IN_RELEASE'));
  });

  test('multiple flags can coexist', () => {
    const r = makeRow({
      scopeStatus: 'Требует подтверждения',
      blockingDependency: true,
      hasRelease120: true,
      isUnassigned: false,
    });
    RiskEngine.computeFlags(r);
    assert.ok(r.riskFlags.includes('CONFIRMATION_IN_RELEASE'));
    assert.ok(r.riskFlags.includes('BLOCKING_NEAR_RELEASE'));
  });
});

group('RiskEngine — computeRiskScore', () => {
  test('score 0 for clean row', () => {
    const r = makeRow();
    RiskEngine.computeFlags(r);
    RiskEngine.computeRiskScore(r);
    assert.strictEqual(r.riskScore, 0);
  });

  test('blocking adds 30 points', () => {
    const r = makeRow({ blockingDependency: true, hasRelease122: true, isUnassigned: false });
    RiskEngine.computeFlags(r);
    RiskEngine.computeRiskScore(r);
    assert.ok(r.riskScore >= 30);
  });

  test('IN_SCOPE_WITHOUT_RELEASE adds 25 points', () => {
    const r = makeRow({ scopeStatus: 'Да', isUnassigned: true });
    RiskEngine.computeFlags(r);
    RiskEngine.computeRiskScore(r);
    assert.ok(r.riskScore >= 25);
  });

  test('score capped at 100', () => {
    const r = makeRow({
      blockingDependency: true,
      scopeStatus: 'Да',
      isUnassigned: true,
      hasRelease120: true,
    });
    RiskEngine.computeFlags(r);
    RiskEngine.computeRiskScore(r);
    assert.ok(r.riskScore <= 100);
  });

  test('hasRelease120 adds 15 to score', () => {
    const r = makeRow({ hasRelease120: true, isUnassigned: false, scopeStatus: 'Нет' });
    RiskEngine.computeFlags(r);
    const score = RiskEngine.computeRiskScore(r);
    assert.ok(score >= 15);
  });

  test('computeAll processes every row', () => {
    const rows = [
      makeRow({ blockingDependency: true, hasRelease120: true, isUnassigned: false }),
      makeRow({ scopeStatus: 'Да', isUnassigned: true }),
      makeRow(),
    ];
    RiskEngine.computeAll(rows);
    assert.ok(rows[0].riskScore > 0);
    assert.ok(rows[1].riskScore > 0);
    assert.strictEqual(rows[2].riskScore, 0);
  });
});

group('FilterEngine — applyFilters', () => {
  const rows = [
    makeRow({ team: 'Alpha', scopeStatus: 'Да', blockingDependency: true, hasRelease120: true, isUnassigned: false, epic: 'Оплата', assignee: 'Иван', riskFlags: ['BLOCKING_NEAR_RELEASE'] }),
    makeRow({ team: 'Beta',  scopeStatus: 'Нет', blockingDependency: false, isUnassigned: true, epic: 'Отчёты', assignee: 'Мария', riskFlags: [] }),
    makeRow({ team: 'Alpha', scopeStatus: 'Требует подтверждения', blockingDependency: false, hasRelease121: true, isUnassigned: false, epic: 'Интеграция', isDone: true, riskFlags: [] }),
  ];

  test('no filters returns all rows', () => {
    const result = applyFilters(rows, {});
    assert.strictEqual(result.length, 3);
  });

  test('filter by team', () => {
    const result = applyFilters(rows, { team: 'Alpha' });
    assert.strictEqual(result.length, 2);
    assert.ok(result.every(r => r.team === 'Alpha'));
  });

  test('filter by scope=Да', () => {
    const result = applyFilters(rows, { scope: 'Да' });
    assert.strictEqual(result.length, 1);
    assert.strictEqual(result[0].scopeStatus, 'Да');
  });

  test('onlyBlocking filter', () => {
    const result = applyFilters(rows, { onlyBlocking: true });
    assert.strictEqual(result.length, 1);
    assert.ok(result[0].blockingDependency);
  });

  test('onlyDone filter', () => {
    const result = applyFilters(rows, { onlyDone: true });
    assert.strictEqual(result.length, 1);
    assert.ok(result[0].isDone);
  });

  test('onlyRisky filter', () => {
    const result = applyFilters(rows, { onlyRisky: true });
    assert.strictEqual(result.length, 1);
    assert.ok(result[0].riskFlags.length > 0);
  });

  test('release=none returns unassigned rows', () => {
    const result = applyFilters(rows, { release: 'none' });
    assert.strictEqual(result.length, 1);
    assert.ok(result[0].isUnassigned);
  });

  test('release=120 returns rows with 1.20', () => {
    const result = applyFilters(rows, { release: '120' });
    assert.strictEqual(result.length, 1);
    assert.ok(result[0].hasRelease120);
  });

  test('search by epic text', () => {
    const result = applyFilters(rows, { search: 'оплата' });
    assert.strictEqual(result.length, 1);
    assert.strictEqual(result[0].epic, 'Оплата');
  });

  test('search is case-insensitive', () => {
    const result = applyFilters(rows, { search: 'ОТЧЁТЫ' });
    assert.strictEqual(result.length, 1);
  });

  test('combined filters AND together', () => {
    const result = applyFilters(rows, { team: 'Alpha', onlyBlocking: true });
    assert.strictEqual(result.length, 1);
  });

  test('no match returns empty array', () => {
    const result = applyFilters(rows, { team: 'Gamma' });
    assert.strictEqual(result.length, 0);
  });
});

group('DependencyEngine — cycle detection', () => {
  test('no cycle in simple chain A→B→C', () => {
    const deps = { A: 'B', B: 'C' };
    assert.strictEqual(detectCycle(deps, 'A'), false);
  });

  test('detects self-loop A→A', () => {
    const deps = { A: 'A' };
    assert.strictEqual(detectCycle(deps, 'A'), true);
  });

  test('detects cycle A→B→A', () => {
    const deps = { A: 'B', B: 'A' };
    assert.strictEqual(detectCycle(deps, 'A'), true);
  });

  test('detects cycle in longer chain A→B→C→A', () => {
    const deps = { A: 'B', B: 'C', C: 'A' };
    assert.strictEqual(detectCycle(deps, 'A'), true);
  });

  test('no cycle when chain ends at undefined', () => {
    const deps = { A: 'B' };
    assert.strictEqual(detectCycle(deps, 'A'), false);
  });

  test('getTransitiveDeps returns full chain', () => {
    const deps = { A: 'B', B: 'C' };
    const chain = getTransitiveDeps(deps, 'A');
    assert.deepStrictEqual(chain, ['B', 'C']);
  });

  test('getTransitiveDeps stops at cycle', () => {
    const deps = { A: 'B', B: 'C', C: 'A' };
    const chain = getTransitiveDeps(deps, 'A');
    assert.ok(chain.length < 10); // doesn't loop infinitely
  });

  test('getTransitiveDeps empty for node with no dep', () => {
    const chain = getTransitiveDeps({}, 'X');
    assert.deepStrictEqual(chain, []);
  });
});

group('MetricsEngine — computeProgress', () => {
  test('empty rows gives zero totals', () => {
    const prog = computeProgress([]);
    assert.strictEqual(prog.all.total, 0);
    assert.strictEqual(prog.all.done, 0);
    assert.strictEqual(prog.all.pct, 0);
  });

  test('counts total rows correctly', () => {
    const rows = [makeRow(), makeRow(), makeRow()];
    const prog = computeProgress(rows);
    assert.strictEqual(prog.all.total, 3);
  });

  test('counts done rows correctly', () => {
    const rows = [makeRow({ isDone: true }), makeRow(), makeRow({ isDone: true })];
    const prog = computeProgress(rows);
    assert.strictEqual(prog.all.done, 2);
    assert.strictEqual(prog.all.pct, 67);
  });

  test('release 1.20 progress isolated', () => {
    const rows = [
      makeRow({ hasRelease120: true, isDone: true }),
      makeRow({ hasRelease120: true, isDone: false }),
      makeRow({ hasRelease121: true, isDone: true }),
    ];
    const prog = computeProgress(rows);
    assert.strictEqual(prog['120'].total, 2);
    assert.strictEqual(prog['120'].done, 1);
    assert.strictEqual(prog['120'].pct, 50);
  });

  test('overtime (ot) uses hasOvertime key', () => {
    const rows = [
      makeRow({ hasOvertime: true, isDone: false }),
      makeRow({ hasOvertime: true, isDone: true }),
    ];
    const prog = computeProgress(rows);
    assert.strictEqual(prog.ot.total, 2);
    assert.strictEqual(prog.ot.done, 1);
  });

  test('100% pct when all done', () => {
    const rows = [makeRow({ hasRelease122: true, isDone: true }), makeRow({ hasRelease122: true, isDone: true })];
    const prog = computeProgress(rows);
    assert.strictEqual(prog['122'].pct, 100);
  });
});

group('MetricsEngine — computeLoad', () => {
  test('single assignee counted', () => {
    const rows = [makeRow({ assignee: 'Иван', hasRelease120: true })];
    const load = computeLoad(rows);
    assert.strictEqual(load['Иван'].total, 1);
    assert.strictEqual(load['Иван'].r120, 1);
  });

  test('pipe-separated assignees both counted', () => {
    const rows = [makeRow({ assignee: 'Иван|Мария', hasRelease121: true })];
    const load = computeLoad(rows);
    assert.strictEqual(load['Иван'].total, 1);
    assert.strictEqual(load['Мария'].total, 1);
    assert.strictEqual(load['Иван'].r121, 1);
  });

  test('comma-separated assignees both counted', () => {
    const rows = [makeRow({ assignee: 'Иван,Мария' })];
    const load = computeLoad(rows);
    assert.ok(load['Иван']);
    assert.ok(load['Мария']);
  });

  test('empty assignee ignored', () => {
    const rows = [makeRow({ assignee: '' })];
    const load = computeLoad(rows);
    assert.strictEqual(Object.keys(load).length, 0);
  });
});

group('toBool — state.js utility', () => {
  test('true stays true', () => assert.strictEqual(toBool(true), true));
  test('false stays false', () => assert.strictEqual(toBool(false), false));
  test('"true" string', () => assert.strictEqual(toBool('true'), true));
  test('"1" string', () => assert.strictEqual(toBool('1'), true));
  test('"да" string', () => assert.strictEqual(toBool('да'), true));
  test('"false" string', () => assert.strictEqual(toBool('false'), false));
  test('"0" string', () => assert.strictEqual(toBool('0'), false));
  test('"нет" string', () => assert.strictEqual(toBool('нет'), false));
  test('0 number is false', () => assert.strictEqual(toBool(0), false));
  test('1 number is true', () => assert.strictEqual(toBool(1), true));
  test('null uses fallback', () => assert.strictEqual(toBool(null, true), true));
  test('undefined uses fallback false', () => assert.strictEqual(toBool(undefined, false), false));
});

// ============================================================
// Summary
// ============================================================
console.log(`\n${'─'.repeat(40)}`);
console.log(`  Passed: ${passed}   Failed: ${failed}   Total: ${passed + failed}`);
console.log('─'.repeat(40));
if (failed > 0) process.exit(1);
