'use strict';
/* ============================================================
   INTEGRATIONS STORE — v10_0
   Manages API settings in localStorage.
   Tokens are NEVER logged, NEVER sent to LLM.
   ============================================================ */

export const INT_SETTINGS_KEY = 'q2_integrations_v1';

const DEFAULTS = {
  jiraBaseUrl:       '',
  // jiraToken: stored but never returned to UI in full

  bitbucketBaseUrl:  '',
  // bitbucketToken: stored but never returned to UI in full

  confluenceBaseUrl: '',
  // confluenceToken: stored but never returned to UI in full

  allowInsecureTls:  false, // global — applies to all integrations
  sinceDate:         '2025-01-01', // cut-off date for Jira / Confluence
  lastSync:          null,
};

/* Load raw settings (includes tokens — only for internal use) */
export function loadSettingsRaw() {
  try {
    return { ...DEFAULTS, ...JSON.parse(localStorage.getItem(INT_SETTINGS_KEY) || '{}') };
  } catch(_) {
    return { ...DEFAULTS };
  }
}

/* Load settings safe for UI (tokens masked as boolean) */
export function loadSettings() {
  const raw = loadSettingsRaw();
  return {
    jiraBaseUrl:       raw.jiraBaseUrl,
    hasJiraToken:      !!(raw.jiraToken),

    bitbucketBaseUrl:  raw.bitbucketBaseUrl,
    hasBitbucketToken: !!(raw.bitbucketToken),

    confluenceBaseUrl: raw.confluenceBaseUrl,
    hasConfluenceToken:!!(raw.confluenceToken),

    allowInsecureTls:  !!raw.allowInsecureTls,
    sinceDate:         raw.sinceDate || '2025-01-01',
    lastSync:          raw.lastSync,
  };
}

/* Save a patch — only accepts known keys, never logs tokens */
export function saveSettings(patch) {
  const raw = loadSettingsRaw();
  const ALLOWED_STRINGS = [
    'jiraBaseUrl', 'jiraToken',
    'bitbucketBaseUrl', 'bitbucketToken',
    'confluenceBaseUrl', 'confluenceToken',
    'sinceDate',
  ];
  const next = { ...raw };
  for (const k of ALLOWED_STRINGS) {
    if (k in patch && typeof patch[k] === 'string') next[k] = patch[k];
  }
  if ('allowInsecureTls' in patch) next.allowInsecureTls = !!patch.allowInsecureTls;
  if (patch.lastSync !== undefined) next.lastSync = patch.lastSync;
  localStorage.setItem(INT_SETTINGS_KEY, JSON.stringify(next));
  return loadSettings(); // return masked version
}

/* Check which services are configured */
export function getConnectionStatus() {
  const raw = loadSettingsRaw();
  return {
    jira:       { configured: !!(raw.jiraBaseUrl       && raw.jiraToken),       url: raw.jiraBaseUrl },
    bitbucket:  { configured: !!(raw.bitbucketBaseUrl  && raw.bitbucketToken),  url: raw.bitbucketBaseUrl },
    confluence: { configured: !!(raw.confluenceBaseUrl && raw.confluenceToken), url: raw.confluenceBaseUrl },
    lastSync:   raw.lastSync,
  };
}
