'use strict';
/**
 * Cross-platform launcher: starts server.js and opens the browser.
 * Works on macOS, Windows, and Linux.
 * Usage: node launch.js [port]
 */

const { spawn, exec } = require('child_process');
const path = require('path');
const http = require('http');

const PORT = Number(process.env.PORT || process.argv[2]) || 8080;

console.log('╔══════════════════════════════════════╗');
console.log('║   СБОФ Планирование v4.0             ║');
console.log('╚══════════════════════════════════════╝');
console.log('Остановка: Ctrl+C\n');

let actualPort = PORT;
let browserOpened = false;

// Start server.js with piped stdout so we can read the LISTENING:PORT marker.
const serverProc = spawn(
  process.execPath,
  [path.join(__dirname, 'server.js'), String(PORT)],
  { stdio: ['inherit', 'pipe', 'inherit'], cwd: __dirname }
);

// Forward server stdout to our stdout line-by-line, watching for the port marker.
const readline = require('readline');
const rl = readline.createInterface({ input: serverProc.stdout });
rl.on('line', (line) => {
  const m = line.match(/^LISTENING:(\d+)$/);
  if (m) {
    actualPort = Number(m[1]);
    const url = `http://127.0.0.1:${actualPort}`;
    console.log(`Адрес:     ${url}`);
    if (actualPort !== PORT) {
      console.log(`(порт ${PORT} занят, используем ${actualPort})`);
    }
    if (!browserOpened) { browserOpened = true; openBrowser(url); }
  } else {
    console.log(line);
  }
});

serverProc.on('error', (err) => {
  console.error('\nОшибка запуска сервера:', err.message);
  process.exit(1);
});

serverProc.on('exit', (code, signal) => {
  if (!signal) console.log(`\nСервер остановлен (код ${code}).`);
  process.exit(code || 0);
});

function openBrowser(url) {
  const cmd =
    process.platform === 'win32'  ? `start "" "${url}"` :
    process.platform === 'darwin' ? `open "${url}"`     :
                                    `xdg-open "${url}"`;
  exec(cmd, (err) => {
    if (err) console.warn('Не удалось открыть браузер автоматически.\nОткройте вручную:', url);
  });
}

function shutdown(sig) {
  serverProc.kill(sig);
}
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
