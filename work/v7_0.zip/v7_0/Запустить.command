#!/usr/bin/env bash
# Двойной клик в Finder — запускает приложение и открывает браузер.
# Если при первом запуске появится "Permission denied", выполните один раз в Терминале:
#   chmod +x "$(pwd)/Запустить.command"

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if ! command -v node &>/dev/null; then
  echo "❌  Node.js не найден."
  echo "    Скачайте и установите: https://nodejs.org"
  read -rp "Нажмите Enter для выхода..."
  exit 1
fi

NODE_VER=$(node -e "process.stdout.write(process.versions.node)")
echo "Node.js ${NODE_VER} найден."
exec node launch.js 8080
