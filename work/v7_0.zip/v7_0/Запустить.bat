@echo off
chcp 65001 >nul 2>&1
title СБОФ Планирование v4.0

cd /d "%~dp0"

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [ОШИБКА] Node.js не найден.
    echo  Скачайте и установите: https://nodejs.org
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node -e "process.stdout.write(process.versions.node)"') do set NODE_VER=%%v
echo  Node.js %NODE_VER% найден.
echo.

node launch.js 8080

echo.
echo  Сервер остановлен.
pause
