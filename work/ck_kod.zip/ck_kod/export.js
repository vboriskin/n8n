/* export.js — CSV / bundle export & bundle import */

const Export = (() => {

  /* ── CSV export ───────────────────────────────────────────────── */

  function rowsToCSV(rows) {
    if (!rows?.length) return '';
    const headers = Object.keys(rows[0]);
    const lines = [headers.map(Utils.escapeCSV).join(',')];
    for (const row of rows) {
      lines.push(headers.map(h => {
        const v = row[h];
        if (v instanceof Date) return Utils.escapeCSV(Utils.formatDate(v, true));
        return Utils.escapeCSV(v ?? '');
      }).join(','));
    }
    return lines.join('\n');
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
  }

  function exportTableToCSV(rows, filename = 'export.csv') {
    const csv = rowsToCSV(rows);
    const bom = '\uFEFF'; // UTF-8 BOM for Excel
    downloadBlob(new Blob([bom + csv], { type: 'text/csv;charset=utf-8' }), filename);
  }

  function exportAggregateToCSV(rows, name) {
    exportTableToCSV(rows, `aggregate_${name}.csv`);
  }

  /* ── Bundle export ────────────────────────────────────────────── */

  function serializeTable(entity, rows, schema, columns) {
    return {
      entity,
      columns,
      schema,
      rows: rows.map(row => {
        const out = {};
        for (const [k, v] of Object.entries(row)) {
          // Serialize Date to ISO string; private _fields skip
          if (k.startsWith('_')) continue;
          out[k] = v instanceof Date ? v.toISOString() : v;
        }
        return out;
      }),
    };
  }

  function exportBundle(appState) {
    const bundle = {
      version: BUNDLE_VERSION,
      exportedAt: new Date().toISOString(),
      filters: appState.filters || {},
      tables: {},
    };

    for (const [entity, tableData] of Object.entries(appState.tables || {})) {
      bundle.tables[entity] = serializeTable(
        entity,
        tableData.rows  || [],
        tableData.schema || {},
        tableData.columns || [],
      );
    }

    const json = JSON.stringify(bundle, null, 2);
    downloadBlob(
      new Blob([json], { type: 'application/json;charset=utf-8' }),
      `task_analytics_bundle_${_dateStamp()}.json`
    );
  }

  /* ── Bundle import ────────────────────────────────────────────── */

  function importBundle(json) {
    let bundle;
    try { bundle = JSON.parse(json); } catch { throw new Error('Невалидный JSON'); }

    if (!bundle.tables) throw new Error('Формат бандла не распознан');

    const result = {};
    for (const [entity, tdata] of Object.entries(bundle.tables)) {
      const schema = tdata.schema || {};
      const rows = (tdata.rows || []).map(row => {
        const out = {};
        for (const [k, v] of Object.entries(row)) {
          if (schema[k] === 'date' && v) out[k] = Utils.parseDate(v);
          else out[k] = v;
        }
        return out;
      });
      result[entity] = {
        entity,
        rows,
        schema,
        columns: tdata.columns || Object.keys(rows[0] || {}),
      };
    }

    return { tables: result, filters: bundle.filters || {}, exportedAt: bundle.exportedAt };
  }

  /* ── Import bundle from File ─────────────────────────────────── */

  async function importBundleFromFile(file) {
    return new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onload  = e => { try { res(importBundle(e.target.result)); } catch(err) { rej(err); } };
      fr.onerror = () => rej(new Error('Ошибка чтения файла'));
      fr.readAsText(file, 'UTF-8');
    });
  }

  /* ── Filtered rows export ────────────────────────────────────── */

  function exportFilteredTasks(tasks, filters) {
    const rows = tasks.map(t => {
      const out = {};
      for (const [k, v] of Object.entries(t)) {
        if (k.startsWith('_')) continue;
        out[k] = v instanceof Date ? Utils.formatDate(v, true) : v;
      }
      return out;
    });
    exportTableToCSV(rows, `tasks_filtered_${_dateStamp()}.csv`);
  }

  function _dateStamp() {
    return Utils.formatDateISO(new Date()).replace(/-/g,'');
  }

  return {
    rowsToCSV, exportTableToCSV, exportAggregateToCSV,
    exportBundle, importBundle, importBundleFromFile,
    exportFilteredTasks,
  };
})();
