/* app.js — main application: state, UI rendering, event handling */

/* ═══════════════════════════════════════════════════════════════
   STATE
   ═══════════════════════════════════════════════════════════════ */

const AppState = {
  tables:    {},       // { entity: { rows, schema, columns } }
  filters: {
    dateFrom:   '',
    dateTo:     '',
    snapshotDate: Utils.formatDateISO(new Date()),
    role:       [],
    login:      [],
    status:     [],
    taskId:     [],
    taskKey:    '',
    requestKey: '',
    isAutoAssigned: null,
    excludeErrorFromWIP: true,
  },
  ui: {
    activeTab: 'answers',
    rawDataEntity: ENTITIES.TASK,
    aggregateGrain: GRAIN.DAY,
    aggregateTable: 'taskDailySnapshot',
    filterPanelOpen: false,
    dirtyRows: {},      // entity -> Set of row indices
    editHistory: {},    // entity -> [{action, rowIdx, oldRow, newRow}]
    undoStack: {},
    redoStack: {},
    gridPage: {},
    gridSearch: {},
    gridSort:  {},
  },
  filterPresets: [],
  _computed: {
    metrics: null,
    answers: null,
    aggregates: null,
    insights: [],
  },
};

/* ═══════════════════════════════════════════════════════════════
   INIT
   ═══════════════════════════════════════════════════════════════ */

async function initApp() {
  renderTabs();
  bindGlobalEvents();
  bindImportEvents();
  bindFilterEvents();

  // Restore session
  const hasSess = await Storage.hasSession();
  if (hasSess) {
    const all = await Storage.loadAllTables();
    for (const [entity, rec] of Object.entries(all)) {
      if (!rec) continue;
      const rows = Storage.deserializeRows(rec.rows || [], rec.schema);
      AppState.tables[entity] = { rows, schema: rec.schema, columns: rec.columns || [] };
    }
    const savedFilters = Storage.loadMeta('filters');
    if (savedFilters) Object.assign(AppState.filters, savedFilters);
    refreshAll();
    setStatus(`Сессия восстановлена. Загружено сущностей: ${Object.keys(AppState.tables).length}.`);
  }

  renderTab(AppState.ui.activeTab);
}

/* ═══════════════════════════════════════════════════════════════
   TABS
   ═══════════════════════════════════════════════════════════════ */

function renderTabs() {
  const nav = Utils.qs('#tabNav');
  if (!nav) return;
  nav.innerHTML = TABS.map(t => `
    <button class="tab-btn ${t.id === AppState.ui.activeTab ? 'active':''}" data-tab="${t.id}">
      <span class="tab-icon">${t.icon}</span>
      <span>${t.label}</span>
    </button>`).join('');
  nav.querySelectorAll('.tab-btn').forEach(btn =>
    btn.addEventListener('click', () => activateTab(btn.dataset.tab))
  );
}

function activateTab(id) {
  AppState.ui.activeTab = id;
  document.querySelectorAll('.tab-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.tab === id)
  );
  renderTab(id);
}

function renderTab(id) {
  const main = Utils.qs('#appMain');
  if (!main) return;
  main.innerHTML = '<div class="tab-content" id="tabContent"></div>';
  const c = Utils.qs('#tabContent');

  const hasTables = Object.keys(AppState.tables).length > 0;

  switch (id) {
    case 'answers':    renderAnswers(c, hasTables);    break;
    case 'rawdata':    renderRawData(c);                break;
    case 'metrics':    renderMetrics(c, hasTables);     break;
    case 'dashboard':  renderDashboard(c, hasTables);  break;
    case 'insights':   renderInsights(c, hasTables);   break;
    case 'aggregates': renderAggregates(c, hasTables); break;
    default: c.innerHTML = '<p class="muted">Вкладка не найдена</p>';
  }
}

/* ═══════════════════════════════════════════════════════════════
   COMPUTED — refresh all metrics
   ═══════════════════════════════════════════════════════════════ */

function refreshAll() {
  const tables = getPlainTables();
  if (!Object.keys(tables).length) return;
  try {
    AppState._computed.metrics    = Metrics.computeMetrics(tables, AppState.filters);
    AppState._computed.answers    = Metrics.computeAnswers(tables, AppState.filters);
    AppState._computed.aggregates = Metrics.computeAggregates(tables, AppState.ui.aggregateGrain, AppState.filters);
    AppState._computed.insights   = Insights.generate(tables, AppState.filters);
  } catch(e) {
    console.warn('refreshAll error:', e);
  }
  updateStatusDataInfo();
}

function getPlainTables() {
  const out = {};
  for (const [e, t] of Object.entries(AppState.tables)) {
    out[e] = t.rows;
  }
  return out;
}

/* ═══════════════════════════════════════════════════════════════
   ANSWERS TAB
   ═══════════════════════════════════════════════════════════════ */

function renderAnswers(container, hasTables) {
  if (!hasTables) { container.innerHTML = _emptyState('Загрузите файлы для отображения аналитики.'); return; }
  const a = AppState._computed.answers;
  if (!a) { container.innerHTML = _emptyState('Нет данных для расчёта.'); return; }
  const { q1, q2, q3, snapshotDate, dateFrom, dateTo } = a;

  container.innerHTML = `
    <div class="answers-page">
      <div class="answers-period-bar">
        <span class="period-label">Период: <b>${_fmtPeriod(dateFrom, dateTo)}</b></span>
        <span class="period-label">Срез: <b>${Utils.formatDate(snapshotDate)}</b></span>
        <label class="toggle-row">
          <input type="checkbox" id="chkExcludeError" ${AppState.filters.excludeErrorFromWIP ? 'checked':''}>
          <span>Исключать ERROR из In Progress</span>
        </label>
      </div>

      <section class="answers-section">
        <h2 class="section-title"><span class="q-badge">Q1</span> Создание задач</h2>
        <div class="kpi-row">
          ${kpiCard('Создано за период', q1.createdInPeriod, '#6366f1')}
          ${kpiCard('Существует на дату', q1.existsOnDate, '#3b82f6')}
          ${kpiCard('Не в работе на дату', q1.notStartedOnDate, '#f59e0b')}
          ${kpiCard('Мин. дата создания', q1.minCreated ? Utils.formatDate(q1.minCreated) : '—', '#22c55e', false)}
          ${kpiCard('Макс. дата создания', q1.maxCreated ? Utils.formatDate(q1.maxCreated) : '—', '#22c55e', false)}
        </div>
        ${breakdownTables({ 'По ролям': q1.byRole, 'По типам задач': q1.byTaskType, 'По логинам': q1.byLogin, 'По статусам': q1.byStatus })}
      </section>

      <section class="answers-section">
        <h2 class="section-title"><span class="q-badge q2">Q2</span> Назначение в работу</h2>
        <div class="kpi-row">
          ${kpiCard('Назначено за период', q2.assignedInPeriod, '#6366f1')}
          ${kpiCard('Назначено на дату', q2.assignedOnDate, '#3b82f6')}
          ${kpiCard('В работе на дату', q2.inProgressOnDate, '#22c55e')}
        </div>
        ${breakdownTables({ 'По ролям': q2.byRole, 'По типам задач': q2.byTaskType })}
      </section>

      <section class="answers-section">
        <h2 class="section-title"><span class="q-badge q3">Q3</span> Закрытие задач</h2>
        <div class="kpi-row">
          ${kpiCard('Закрыто за период', q3.closedInPeriod, '#6366f1')}
          ${kpiCard('Закрыто на дату', q3.closedOnDate, '#3b82f6')}
          ${kpiCard('Closure rate', Utils.formatPct(q3.closureRate), '#22c55e', false)}
        </div>
        ${breakdownTables({ 'По ролям': q3.byRole, 'По типам задач': q3.byTaskType })}
      </section>

      <section class="answers-section info-section">
        <h2 class="section-title">ℹ Логика состояния задачи на дату</h2>
        <div class="info-block">
          <p>Состояние задачи на дату <b>D</b> определяется по следующему приоритету:</p>
          <ol>
            <li><b>Closed</b> — если <code>CloseDateTime ≤ D</code></li>
            <li><b>Error</b> — если есть запись в TaskError с <code>pxCreateDateTime ≤ D</code> и задача не закрыта</li>
            <li><b>Deferred</b> — если существует запись TaskDeferment, где <code>pxCreateDateTime ≤ D &lt; EndDateTime</code> (или EndDateTime пустой)</li>
            <li><b>InProgress</b> — есть назначение в LoginRequest с <code>pxCreateDateTime ≤ D</code></li>
            <li><b>NotStarted</b> — задача создана, но назначений ещё не было</li>
          </ol>
          <p><b>Автоназначение</b>: если первая запись в TaskDeferment по TaskKey имеет Comment = <em>"Назначение ЦК КОД"</em>, задача считается автоназначенной.</p>
        </div>
      </section>
    </div>`;

  Utils.qs('#chkExcludeError')?.addEventListener('change', e => {
    AppState.filters.excludeErrorFromWIP = e.target.checked;
    saveFilters();
    refreshAll();
    renderTab('answers');
  });
}

function kpiCard(label, value, color = '#6366f1', isNumber = true) {
  return `
    <div class="kpi-card" style="--accent:${color}">
      <div class="kpi-value">${isNumber ? Utils.formatNum(typeof value === 'number' ? value : parseFloat(value)||0) : value}</div>
      <div class="kpi-label">${label}</div>
    </div>`;
}

function breakdownTables(groups) {
  let html = '<div class="breakdown-row">';
  for (const [title, data] of Object.entries(groups)) {
    const entries = Utils.sortBy(
      Object.entries(data || {}).map(([k,v]) => ({k,v})),
      'v', true
    ).slice(0, 10);
    if (!entries.length) continue;
    html += `
      <div class="breakdown-card">
        <h4>${title}</h4>
        <table class="mini-table">
          ${entries.map(({k,v}) => `
            <tr>
              <td>${Utils.escapeHtml(k)}</td>
              <td class="num">${Utils.formatNum(v)}</td>
              <td class="bar-cell"><div class="mini-bar" style="width:${Math.round(v/entries[0].v*100)}%"></div></td>
            </tr>`).join('')}
        </table>
      </div>`;
  }
  return html + '</div>';
}

function _fmtPeriod(from, to) {
  if (!from && !to) return 'весь период';
  if (from && to) return `${Utils.formatDate(from)} — ${Utils.formatDate(to)}`;
  if (from) return `с ${Utils.formatDate(from)}`;
  return `до ${Utils.formatDate(to)}`;
}

/* ═══════════════════════════════════════════════════════════════
   RAW DATA TAB — editable grid
   ═══════════════════════════════════════════════════════════════ */

function renderRawData(container) {
  const entity = AppState.ui.rawDataEntity;
  const tableData = AppState.tables[entity];

  const entitySelector = Object.keys(ENTITIES).map(k => {
    const ent = ENTITIES[k];
    const cnt = AppState.tables[ent]?.rows?.length || 0;
    return `<option value="${ent}" ${ent === entity ? 'selected':''}>${ENTITY_LABELS[ent]||ent} (${cnt})</option>`;
  }).join('');

  container.innerHTML = `
    <div class="rawdata-page">
      <div class="rawdata-toolbar">
        <select id="entitySelect" class="select-sm">${entitySelector}</select>
        <input type="text" id="gridSearch" class="input-sm" placeholder="Поиск..." value="${AppState.ui.gridSearch[entity]||''}">
        <button class="btn btn-sm btn-ghost" id="btnAddRow">+ Строка</button>
        <button class="btn btn-sm btn-ghost" id="btnUndoEdit" title="Отменить">↩ Undo</button>
        <button class="btn btn-sm btn-ghost" id="btnRedoEdit" title="Повторить">↪ Redo</button>
        <button class="btn btn-sm btn-ghost" id="btnRestoreOriginal" title="Восстановить исходные данные">↺ Сброс</button>
        <button class="btn btn-sm btn-primary" id="btnExportTable">↓ CSV</button>
        <span class="dirty-indicator ${_hasDirty(entity) ? 'visible':''}" id="dirtyIndicator">● Есть изменения</span>
      </div>
      <div id="gridContainer" class="grid-container"></div>
      <div class="grid-pagination" id="gridPagination"></div>
    </div>`;

  if (!tableData?.rows?.length) {
    Utils.qs('#gridContainer').innerHTML = _emptyState(`Нет данных для "${ENTITY_LABELS[entity]||entity}". Загрузите файл.`);
  } else {
    renderGrid(entity, tableData);
  }

  // Entity switch
  Utils.qs('#entitySelect').addEventListener('change', e => {
    AppState.ui.rawDataEntity = e.target.value;
    AppState.ui.gridPage[e.target.value] = 0;
    renderTab('rawdata');
  });

  // Search
  Utils.qs('#gridSearch').addEventListener('input', Utils.debounce(e => {
    AppState.ui.gridSearch[entity] = e.target.value;
    AppState.ui.gridPage[entity] = 0;
    renderGrid(entity, AppState.tables[entity]);
  }, 200));

  Utils.qs('#btnAddRow')?.addEventListener('click', () => addGridRow(entity));
  Utils.qs('#btnUndoEdit')?.addEventListener('click', () => undoEdit(entity));
  Utils.qs('#btnRedoEdit')?.addEventListener('click', () => redoEdit(entity));
  Utils.qs('#btnRestoreOriginal')?.addEventListener('click', () => restoreOriginal(entity));
  Utils.qs('#btnExportTable')?.addEventListener('click', () => {
    if (tableData) Export.exportTableToCSV(tableData.rows, `${entity}.csv`);
  });
}

function renderGrid(entity, tableData) {
  const gc = Utils.qs('#gridContainer');
  if (!gc || !tableData) return;

  const columns = tableData.columns || Object.keys(tableData.rows[0] || {});
  const search  = (AppState.ui.gridSearch[entity] || '').toLowerCase();
  const sort    = AppState.ui.gridSort[entity] || { col: null, dir: 1 };
  const dirty   = AppState.ui.dirtyRows[entity] || new Set();

  let rows = tableData.rows;

  // search filter
  if (search) {
    rows = rows.filter(row =>
      columns.some(c => Utils.normalize(String(row[c]??'')).includes(search))
    );
  }

  // sort
  if (sort.col) {
    rows = Utils.sortBy(rows, r => r[sort.col], sort.dir === -1);
  }

  const total = rows.length;
  const page  = AppState.ui.gridPage[entity] || 0;
  const pages = Math.ceil(total / PAGE_SIZE);
  const slice = rows.slice(page * PAGE_SIZE, (page+1) * PAGE_SIZE);

  // Build table
  let html = `<table class="data-grid" id="dataGrid">
    <thead><tr>
      <th style="width:36px">#</th>`;
  for (const col of columns) {
    const asc = sort.col === col && sort.dir === 1;
    const dsc = sort.col === col && sort.dir === -1;
    html += `<th class="sortable ${asc?'sort-asc':dsc?'sort-desc':''}" data-col="${Utils.escapeHtml(col)}">${Utils.escapeHtml(col)}</th>`;
  }
  html += `<th style="width:48px">Del</th></tr></thead><tbody>`;

  slice.forEach((row, localIdx) => {
    const globalIdx = page * PAGE_SIZE + localIdx;
    const isDirty = dirty.has(globalIdx);
    html += `<tr class="${isDirty?'dirty-row':''}" data-ridx="${globalIdx}">
      <td class="row-num">${globalIdx+1}</td>`;
    for (const col of columns) {
      const val = row[col];
      const display = val instanceof Date ? Utils.formatDate(val, true) : (val ?? '');
      html += `<td class="editable" data-col="${Utils.escapeHtml(col)}" data-ridx="${globalIdx}" contenteditable="true">${Utils.escapeHtml(String(display))}</td>`;
    }
    html += `<td><button class="btn-del-row" data-ridx="${globalIdx}" title="Удалить строку">✕</button></td></tr>`;
  });

  html += '</tbody></table>';
  gc.innerHTML = html;

  // Sort headers
  gc.querySelectorAll('th.sortable').forEach(th => {
    th.addEventListener('click', () => {
      const col = th.dataset.col;
      const cur = AppState.ui.gridSort[entity] || {};
      AppState.ui.gridSort[entity] = {
        col,
        dir: cur.col === col ? -cur.dir : 1,
      };
      renderGrid(entity, AppState.tables[entity]);
    });
  });

  // Editable cells
  gc.querySelectorAll('td.editable').forEach(td => {
    td.addEventListener('blur', e => {
      const col   = td.dataset.col;
      const ridx  = parseInt(td.dataset.ridx);
      const oldVal = AppState.tables[entity].rows[ridx]?.[col];
      const newVal = td.innerText.trim();
      const oldStr = oldVal instanceof Date ? Utils.formatDate(oldVal,true) : String(oldVal??'');
      if (newVal === oldStr) return;
      recordEdit(entity, ridx, col, oldVal, newVal);
      AppState.tables[entity].rows[ridx][col] = newVal;
      _markDirty(entity, ridx);
      debouncedSave(entity);
    });

    // Copy/paste handling
    td.addEventListener('keydown', e => {
      if (e.key === 'Tab') {
        e.preventDefault();
        const next = td.closest('tr').querySelector(`td[data-ridx="${td.dataset.ridx}"]:not([data-col="${td.dataset.col}"])`) ||
                     td.closest('tr').nextElementSibling?.querySelector('td.editable');
        next?.focus();
      }
    });
  });

  // Delete rows
  gc.querySelectorAll('.btn-del-row').forEach(btn => {
    btn.addEventListener('click', () => deleteGridRow(entity, parseInt(btn.dataset.ridx)));
  });

  // Pagination
  const pag = Utils.qs('#gridPagination');
  if (pag) {
    pag.innerHTML = `
      <span class="page-info">${total} строк · страница ${page+1} / ${Math.max(1,pages)}</span>
      <button class="btn btn-sm btn-ghost" ${page===0?'disabled':''} id="btnPrevPage">‹ Пред</button>
      <button class="btn btn-sm btn-ghost" ${page>=pages-1?'disabled':''} id="btnNextPage">След ›</button>`;
    pag.querySelector('#btnPrevPage')?.addEventListener('click', () => {
      AppState.ui.gridPage[entity] = Math.max(0, page-1);
      renderGrid(entity, AppState.tables[entity]);
    });
    pag.querySelector('#btnNextPage')?.addEventListener('click', () => {
      AppState.ui.gridPage[entity] = Math.min(pages-1, page+1);
      renderGrid(entity, AppState.tables[entity]);
    });
  }
}

/* ── Grid edit operations ─────────────────────────────────────── */

function recordEdit(entity, ridx, col, oldVal, newVal) {
  if (!AppState.ui.undoStack[entity]) AppState.ui.undoStack[entity] = [];
  AppState.ui.undoStack[entity].push({ ridx, col, oldVal, newVal });
  if (AppState.ui.undoStack[entity].length > MAX_UNDO) AppState.ui.undoStack[entity].shift();
  AppState.ui.redoStack[entity] = []; // clear redo on new edit
}

function undoEdit(entity) {
  const stack = AppState.ui.undoStack[entity] || [];
  if (!stack.length) return;
  const { ridx, col, oldVal } = stack.pop();
  if (!AppState.ui.redoStack[entity]) AppState.ui.redoStack[entity] = [];
  const curVal = AppState.tables[entity].rows[ridx]?.[col];
  AppState.ui.redoStack[entity].push({ ridx, col, oldVal: curVal, newVal: oldVal });
  if (AppState.tables[entity].rows[ridx]) AppState.tables[entity].rows[ridx][col] = oldVal;
  debouncedSave(entity);
  renderGrid(entity, AppState.tables[entity]);
}

function redoEdit(entity) {
  const stack = AppState.ui.redoStack[entity] || [];
  if (!stack.length) return;
  const { ridx, col, newVal } = stack.pop();
  if (AppState.tables[entity].rows[ridx]) AppState.tables[entity].rows[ridx][col] = newVal;
  debouncedSave(entity);
  renderGrid(entity, AppState.tables[entity]);
}

function addGridRow(entity) {
  const td = AppState.tables[entity];
  if (!td) return;
  const cols = td.columns || [];
  const newRow = {};
  cols.forEach(c => newRow[c] = '');
  td.rows.push(newRow);
  const lastPage = Math.ceil(td.rows.length / PAGE_SIZE) - 1;
  AppState.ui.gridPage[entity] = lastPage;
  debouncedSave(entity);
  renderGrid(entity, td);
}

function deleteGridRow(entity, ridx) {
  const td = AppState.tables[entity];
  if (!td || ridx >= td.rows.length) return;
  const old = td.rows[ridx];
  recordEdit(entity, ridx, '__DELETE__', old, null);
  td.rows.splice(ridx, 1);
  debouncedSave(entity);
  renderGrid(entity, td);
}

function restoreOriginal(entity) {
  const saved = Storage.loadMeta(`original_${entity}`);
  if (!saved) { setStatus('Нет сохранённой исходной копии.'); return; }
  const td = AppState.tables[entity];
  if (!td) return;
  td.rows = Storage.deserializeRows(saved.rows, td.schema);
  AppState.ui.dirtyRows[entity] = new Set();
  AppState.ui.undoStack[entity] = [];
  AppState.ui.redoStack[entity] = [];
  debouncedSave(entity);
  renderGrid(entity, td);
}

function _markDirty(entity, ridx) {
  if (!AppState.ui.dirtyRows[entity]) AppState.ui.dirtyRows[entity] = new Set();
  AppState.ui.dirtyRows[entity].add(ridx);
  const ind = Utils.qs('#dirtyIndicator');
  if (ind) ind.classList.add('visible');
}

function _hasDirty(entity) {
  return (AppState.ui.dirtyRows[entity]?.size || 0) > 0;
}

const debouncedSave = Utils.debounce(async entity => {
  const td = AppState.tables[entity];
  if (!td) return;
  await Storage.saveTable(entity, Storage.serializeRows(td.rows), td.schema, td.columns);
  refreshAll();
}, 800);

/* ═══════════════════════════════════════════════════════════════
   METRICS TAB
   ═══════════════════════════════════════════════════════════════ */

function renderMetrics(container, hasTables) {
  if (!hasTables) { container.innerHTML = _emptyState('Загрузите файлы.'); return; }
  const m = AppState._computed.metrics;
  if (!m) { container.innerHTML = _emptyState('Нет данных.'); return; }

  const cards = [
    { label: 'Создано',           value: m.total,           color: '#6366f1' },
    { label: 'Назначено',         value: m.assigned,        color: '#3b82f6' },
    { label: 'В работе',          value: m.inProgress,      color: '#22c55e' },
    { label: 'Отложено',          value: m.deferred,        color: '#f59e0b' },
    { label: 'Ошибки',            value: m.errCount,        color: '#ef4444' },
    { label: 'Закрыто',           value: m.closed,          color: '#10b981' },
    { label: 'Не начато',         value: m.notStarted,      color: '#6b7280' },
    { label: 'Авто-назначений',   value: m.autoCount,       color: '#8b5cf6' },
    { label: 'Доля авто (%)',     value: m.autoShare,       color: '#8b5cf6', unit:'%' },
    { label: 'Closure rate (%)',  value: m.closureRate,     color: '#22c55e', unit:'%' },
    { label: 'Assignment rate (%)', value: m.assignmentRate, color: '#3b82f6', unit:'%' },
    { label: 'Error rate (%)',    value: m.errorRate,       color: '#ef4444', unit:'%' },
    { label: 'Deferment rate (%)', value: m.defermentRate,  color: '#f59e0b', unit:'%' },
    { label: 'Ср. время до назначения', value: m.avgCreateToAssign, color: '#6366f1', fmt: 'dur' },
    { label: 'Медиана до назначения',   value: m.medCreateToAssign, color: '#6366f1', fmt: 'dur' },
    { label: 'Ср. время до закрытия',   value: m.avgCreateToClose,  color: '#22c55e', fmt: 'dur' },
    { label: 'Медиана до закрытия',     value: m.medCreateToClose,  color: '#22c55e', fmt: 'dur' },
    { label: 'Ср. время в отложении',   value: m.avgDeferredDuration, color: '#f59e0b', fmt: 'dur' },
    { label: 'Переназначений всего',    value: m.reassignTotal,   color: '#ec4899' },
    { label: 'Reassignment rate (%)',   value: m.reassignRate,    color: '#ec4899', unit:'%' },
  ];

  function fmtVal(c) {
    if (c.fmt === 'dur') return Utils.formatDuration(c.value);
    if (c.unit === '%')  return `${Utils.formatNum(c.value, 1)}%`;
    return Utils.formatNum(c.value);
  }

  container.innerHTML = `
    <div class="metrics-page">
      <div class="metrics-grid">
        ${cards.map(c => `
          <div class="metric-card" style="--accent:${c.color}">
            <div class="metric-value" style="color:${c.color}">${fmtVal(c)}</div>
            <div class="metric-label">${c.label}</div>
          </div>`).join('')}
      </div>

      <div class="metrics-section-row">
        <div class="section-card">
          <h3>Aging buckets</h3>
          <table class="mini-table">
            <thead><tr><th>Возраст</th><th>Кол-во</th><th>%</th></tr></thead>
            <tbody>
              ${m.agingBuckets.map(b => `
                <tr>
                  <td>${b.label}</td>
                  <td class="num">${Utils.formatNum(b.count)}</td>
                  <td class="num">${Utils.formatPct(Utils.pct(b.count, m.total))}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>

        <div class="section-card">
          <h3>Авто vs Ручные</h3>
          <table class="mini-table">
            <thead><tr><th></th><th>Авто</th><th>Ручные</th></tr></thead>
            <tbody>
              <tr><td>Кол-во</td><td>${m.autoMetrics.count}</td><td>${m.manualMetrics.count}</td></tr>
              <tr><td>Closure rate</td><td>${m.autoMetrics.closureRate}%</td><td>${m.manualMetrics.closureRate}%</td></tr>
              <tr><td>Ошибки</td><td>${m.autoMetrics.errored}</td><td>${m.manualMetrics.errored}</td></tr>
              <tr><td>Откладывания</td><td>${m.autoMetrics.deferred}</td><td>${m.manualMetrics.deferred}</td></tr>
            </tbody>
          </table>
        </div>

        <div class="section-card">
          <h3>По ролям (топ-10)</h3>
          ${_simpleBarTable(m.byRole)}
        </div>

        <div class="section-card">
          <h3>По типам задач (топ-10)</h3>
          ${_simpleBarTable(m.byTaskType)}
        </div>
      </div>
    </div>`;
}

function _simpleBarTable(countObj) {
  const entries = Utils.sortBy(
    Object.entries(countObj||{}).map(([k,v])=>({k,v})), 'v', true
  ).slice(0,10);
  if (!entries.length) return '<p class="muted">Нет данных</p>';
  const max = entries[0].v;
  return `<table class="mini-table">
    ${entries.map(({k,v}) => `
      <tr>
        <td>${Utils.escapeHtml(k)}</td>
        <td class="num">${v}</td>
        <td class="bar-cell"><div class="mini-bar" style="width:${Math.round(v/max*100)}%"></div></td>
      </tr>`).join('')}
  </table>`;
}

/* ═══════════════════════════════════════════════════════════════
   DASHBOARD TAB
   ═══════════════════════════════════════════════════════════════ */

function renderDashboard(container, hasTables) {
  if (!hasTables) { container.innerHTML = _emptyState('Загрузите файлы.'); return; }

  container.innerHTML = `
    <div class="dashboard-page">
      <div class="dash-row">
        <div class="dash-card wide"><h3>Динамика: создано / назначено / закрыто</h3><canvas id="cLine" class="chart-canvas" height="200"></canvas></div>
        <div class="dash-card"><h3>Воронка</h3><canvas id="cFunnel" class="chart-canvas" height="200"></canvas></div>
      </div>
      <div class="dash-row">
        <div class="dash-card"><h3>Состояния на дату (donut)</h3><canvas id="cDonutState" class="chart-canvas" height="220"></canvas></div>
        <div class="dash-card"><h3>Авто vs Ручные (donut)</h3><canvas id="cDonutAuto" class="chart-canvas" height="220"></canvas></div>
        <div class="dash-card"><h3>По ролям</h3><canvas id="cBarRole" class="chart-canvas" height="220"></canvas></div>
      </div>
      <div class="dash-row">
        <div class="dash-card wide"><h3>Heatmap: создание задач (день × час)</h3><canvas id="cHeatmap" class="chart-canvas" height="180"></canvas></div>
        <div class="dash-card"><h3>Типы задач</h3><canvas id="cBarType" class="chart-canvas" height="180"></canvas></div>
      </div>
      <div class="dash-row">
        <div class="dash-card"><h3>Aging</h3><canvas id="cAging" class="chart-canvas" height="200"></canvas></div>
        <div class="dash-card wide"><h3>Накопительный тренд (backlog)</h3><canvas id="cBacklog" class="chart-canvas" height="200"></canvas></div>
      </div>
    </div>`;

  requestAnimationFrame(() => drawAllCharts());
}

function drawAllCharts() {
  const m    = AppState._computed.metrics;
  const aggs = AppState._computed.aggregates;
  if (!m || !aggs) return;

  // Line: trend
  const trend = aggs.taskDailySnapshot.slice(-60); // last 60 periods
  _drawOnCanvas('cLine', canvas => Charts.drawLine(canvas, {
    labels: trend.map(r => r.date),
    series: [
      { name: 'Создано',   color: '#6366f1', values: trend.map(r => r.created  || 0) },
      { name: 'Назначено', color: '#3b82f6', values: trend.map(r => r.assigned || 0) },
      { name: 'Закрыто',   color: '#22c55e', values: trend.map(r => r.closed   || 0) },
    ],
  }, { title: '' }));

  // Funnel
  _drawOnCanvas('cFunnel', canvas => Charts.drawFunnel(canvas, [
    { label: 'Создано',   value: m.total,      color: '#6366f1' },
    { label: 'Назначено', value: m.assigned,   color: '#3b82f6' },
    { label: 'В работе',  value: m.inProgress, color: '#22c55e' },
    { label: 'Закрыто',   value: m.closed,     color: '#10b981' },
  ]));

  // Donut states
  _drawOnCanvas('cDonutState', canvas => Charts.drawDonut(canvas, [
    { label: 'В работе',  value: m.inProgress, color: '#3b82f6' },
    { label: 'Отложено',  value: m.deferred,   color: '#f59e0b' },
    { label: 'Ошибки',    value: m.errCount,   color: '#ef4444' },
    { label: 'Не начато', value: m.notStarted, color: '#6b7280' },
    { label: 'Закрыто',   value: m.closed,     color: '#22c55e' },
  ].filter(d => d.value > 0)));

  // Donut auto vs manual
  _drawOnCanvas('cDonutAuto', canvas => Charts.drawDonut(canvas, [
    { label: 'Авто',    value: m.autoCount,            color: '#8b5cf6' },
    { label: 'Ручные',  value: m.total - m.autoCount,  color: '#6366f1' },
  ].filter(d => d.value > 0)));

  // Bar by role
  const topRoles = Utils.sortBy(Object.entries(m.byRole).map(([k,v])=>({k,v})), 'v', true).slice(0,8);
  _drawOnCanvas('cBarRole', canvas => Charts.drawBar(canvas, {
    labels: topRoles.map(r => r.k),
    series: [{ name: 'Задач', color: '#6366f1', values: topRoles.map(r => r.v) }],
  }, { horizontal: true }));

  // Bar by task type
  const topTypes = Utils.sortBy(Object.entries(m.byTaskType).map(([k,v])=>({k,v})), 'v', true).slice(0,8);
  _drawOnCanvas('cBarType', canvas => Charts.drawBar(canvas, {
    labels: topTypes.map(r => r.k),
    series: [{ name: 'Задач', color: '#f59e0b', values: topTypes.map(r => r.v) }],
  }, { horizontal: true }));

  // Heatmap
  const heatTasks = m._tasks;
  const heatmap = Metrics.computeHeatmapData(heatTasks, 'pxCreateDateTime');
  _drawOnCanvas('cHeatmap', canvas => Charts.drawHeatmap(canvas, heatmap));

  // Aging
  _drawOnCanvas('cAging', canvas => Charts.drawBar(canvas, {
    labels: m.agingBuckets.map(b => b.label),
    series: [{ name: 'Задач', color: '#f97316', values: m.agingBuckets.map(b => b.count) }],
  }));

  // Backlog
  const backlog = aggs.backlogByDay.slice(-60);
  _drawOnCanvas('cBacklog', canvas => Charts.drawLine(canvas, {
    labels: backlog.map(r => r.date),
    series: [
      { name: 'Создано (накопл.)', color: '#6366f1', values: backlog.map(r => r.cumCreated) },
      { name: 'Закрыто (накопл.)', color: '#22c55e', values: backlog.map(r => r.cumClosed)  },
      { name: 'Backlog',           color: '#f59e0b', values: backlog.map(r => r.backlog)    },
    ],
  }));
}

function _drawOnCanvas(id, drawFn) {
  const canvas = Utils.qs(`#${id}`);
  if (!canvas) return;
  // Wait for DOM to settle
  requestAnimationFrame(() => { try { drawFn(canvas); } catch(e) { console.warn(id, e); } });
}

/* ═══════════════════════════════════════════════════════════════
   INSIGHTS TAB
   ═══════════════════════════════════════════════════════════════ */

function renderInsights(container, hasTables) {
  if (!hasTables) { container.innerHTML = _emptyState('Загрузите файлы.'); return; }
  const ins = AppState._computed.insights;
  if (!ins.length) {
    container.innerHTML = _emptyState('Нет инсайтов. Недостаточно данных или все метрики в норме.');
    return;
  }

  const svgIcon = s => s === 'high' ? '🔴' : s === 'medium' ? '🟡' : '🟢';

  container.innerHTML = `
    <div class="insights-page">
      <div class="insights-list">
        ${ins.map((ins,i) => `
          <div class="insight-card severity-${ins.severity}" data-iidx="${i}">
            <div class="insight-header">
              <span class="insight-icon">${svgIcon(ins.severity)}</span>
              <div>
                <div class="insight-title">${Utils.escapeHtml(ins.title)}</div>
                <div class="insight-meta">Уверенность: <b>${ins.confidence}</b> · Показатель: <b>${Utils.escapeHtml(String(ins.value))}</b></div>
              </div>
            </div>
            <p class="insight-body">${Utils.escapeHtml(ins.body)}</p>
            ${ins.tasks.length ? `<button class="btn btn-sm btn-ghost insight-detail-btn" data-iidx="${i}">Показать задачи (${ins.tasks.length})</button>` : ''}
          </div>`).join('')}
      </div>
    </div>`;

  container.querySelectorAll('.insight-detail-btn').forEach(btn => {
    btn.addEventListener('click', () => showInsightDetail(ins[parseInt(btn.dataset.iidx)]));
  });
}

function showInsightDetail(insight) {
  const modal = Utils.qs('#insightModal');
  Utils.qs('#insightModalTitle').textContent = insight.title;
  const rows = insight.tasks.slice(0, 200);
  const cols = rows.length ? Object.keys(rows[0]).filter(k => !k.startsWith('_')).slice(0, 12) : [];
  Utils.qs('#insightModalBody').innerHTML = rows.length ? `
    <p class="muted">Показано ${rows.length} из ${insight.tasks.length} задач.</p>
    <div style="overflow:auto">
    <table class="data-grid">
      <thead><tr>${cols.map(c => `<th>${Utils.escapeHtml(c)}</th>`).join('')}</tr></thead>
      <tbody>
        ${rows.map(r => `<tr>${cols.map(c => {
          const v = r[c];
          return `<td>${Utils.escapeHtml(v instanceof Date ? Utils.formatDate(v,true) : String(v??''))}</td>`;
        }).join('')}</tr>`).join('')}
      </tbody>
    </table></div>` : '<p class="muted">Нет задач для отображения.</p>';
  Utils.show(modal);
}

/* ═══════════════════════════════════════════════════════════════
   AGGREGATES TAB
   ═══════════════════════════════════════════════════════════════ */

function renderAggregates(container, hasTables) {
  if (!hasTables) { container.innerHTML = _emptyState('Загрузите файлы.'); return; }
  const aggs = AppState._computed.aggregates;
  if (!aggs) { container.innerHTML = _emptyState('Нет данных.'); return; }

  const aggTables = [
    { key: 'taskDailySnapshot',  label: 'Снапшот по дням' },
    { key: 'closureByDay',       label: 'Closure по дням' },
    { key: 'backlogByDay',       label: 'Backlog по дням' },
    { key: 'workloadByRole',     label: 'Нагрузка по ролям' },
    { key: 'defermentByReason',  label: 'Откладывания по причинам' },
    { key: 'errorByReason',      label: 'Ошибки по причинам' },
    { key: 'reassignmentSummary','label': 'Переназначения' },
    { key: 'funnelByDay',        label: 'Воронка по дням' },
  ];

  const cur = AppState.ui.aggregateTable;
  const grain = AppState.ui.aggregateGrain;

  container.innerHTML = `
    <div class="aggregates-page">
      <div class="agg-toolbar">
        <select id="aggTableSelect" class="select-sm">
          ${aggTables.map(t => `<option value="${t.key}" ${t.key===cur?'selected':''}>${t.label}</option>`).join('')}
        </select>
        <span>Зерно:</span>
        ${Object.values(GRAIN).map(g => `
          <label class="grain-label ${g===grain?'active':''}">
            <input type="radio" name="grain" value="${g}" ${g===grain?'checked':''}>
            ${g === GRAIN.DAY ? 'День' : g === GRAIN.WEEK ? 'Неделя' : 'Месяц'}
          </label>`).join('')}
        <button class="btn btn-sm btn-primary" id="btnExportAgg">↓ CSV</button>
      </div>
      <div id="aggTableContainer"></div>
    </div>`;

  renderAggTable(aggs[cur] || []);

  Utils.qs('#aggTableSelect').addEventListener('change', e => {
    AppState.ui.aggregateTable = e.target.value;
    renderAggTable(aggs[e.target.value] || []);
  });

  container.querySelectorAll('input[name="grain"]').forEach(r => {
    r.addEventListener('change', () => {
      AppState.ui.aggregateGrain = r.value;
      const tables = getPlainTables();
      AppState._computed.aggregates = Metrics.computeAggregates(tables, r.value, AppState.filters);
      renderTab('aggregates');
    });
  });

  Utils.qs('#btnExportAgg')?.addEventListener('click', () => {
    const key = AppState.ui.aggregateTable;
    Export.exportAggregateToCSV(aggs[key] || [], key);
  });
}

function renderAggTable(rows) {
  const c = Utils.qs('#aggTableContainer');
  if (!c) return;
  if (!rows.length) { c.innerHTML = _emptyState('Нет данных для этого агрегата.'); return; }
  const cols = Object.keys(rows[0]);
  c.innerHTML = `
    <div style="overflow:auto">
    <table class="data-grid">
      <thead><tr>${cols.map(col => `<th>${Utils.escapeHtml(col)}</th>`).join('')}</tr></thead>
      <tbody>
        ${rows.map(r => `<tr>${cols.map(c => {
          const v = r[c];
          const s = v instanceof Date ? Utils.formatDate(v,true) : (typeof v === 'number' ? Utils.formatNum(v,1) : String(v??''));
          return `<td>${Utils.escapeHtml(s)}</td>`;
        }).join('')}</tr>`).join('')}
      </tbody>
    </table></div>`;
}

/* ═══════════════════════════════════════════════════════════════
   FILTER PANEL
   ═══════════════════════════════════════════════════════════════ */

function bindFilterEvents() {
  Utils.qs('#filterDateFrom')?.addEventListener('change', e => {
    AppState.filters.dateFrom = e.target.value;
    applyAndRefresh();
  });
  Utils.qs('#filterDateTo')?.addEventListener('change', e => {
    AppState.filters.dateTo = e.target.value;
    applyAndRefresh();
  });
  Utils.qs('#filterSnapshotDate')?.addEventListener('change', e => {
    AppState.filters.snapshotDate = e.target.value;
    applyAndRefresh();
  });
  Utils.qs('#btnClearFilters')?.addEventListener('click', () => {
    AppState.filters.dateFrom = '';
    AppState.filters.dateTo = '';
    AppState.filters.role = [];
    AppState.filters.login = [];
    AppState.filters.status = [];
    AppState.filters.taskId = [];
    AppState.filters.isAutoAssigned = null;
    syncFilterUI();
    applyAndRefresh();
  });
  Utils.qs('#btnFilterMore')?.addEventListener('click', () => {
    AppState.ui.filterPanelOpen = !AppState.ui.filterPanelOpen;
    const ext = Utils.qs('#filterExtended');
    Utils.toggle(ext, AppState.ui.filterPanelOpen);
    if (AppState.ui.filterPanelOpen) buildExtendedFilters();
  });

  syncFilterUI();
}

function syncFilterUI() {
  const f = AppState.filters;
  const el_from = Utils.qs('#filterDateFrom');
  const el_to   = Utils.qs('#filterDateTo');
  const el_snap = Utils.qs('#filterSnapshotDate');
  if (el_from) el_from.value = f.dateFrom || '';
  if (el_to)   el_to.value   = f.dateTo   || '';
  if (el_snap) el_snap.value = f.snapshotDate || Utils.formatDateISO(new Date());
  renderFilterChips();
}

function renderFilterChips() {
  const chips = Utils.qs('#filterChips');
  if (!chips) return;
  const f = AppState.filters;
  const items = [];
  if (f.dateFrom)           items.push({ label: `С ${f.dateFrom}`,         key: 'dateFrom' });
  if (f.dateTo)             items.push({ label: `По ${f.dateTo}`,           key: 'dateTo' });
  if (f.role?.length)       items.push({ label: `Роль: ${f.role.join(',')}`, key: 'role' });
  if (f.login?.length)      items.push({ label: `Логин: ${f.login.join(',')}`, key: 'login' });
  if (f.status?.length)     items.push({ label: `Статус: ${f.status.join(',')}`, key: 'status' });
  if (f.taskId?.length)     items.push({ label: `Тип: ${f.taskId.join(',')}`, key: 'taskId' });
  if (f.isAutoAssigned !== null && f.isAutoAssigned !== undefined) {
    items.push({ label: `Авто: ${f.isAutoAssigned ? 'да':'нет'}`, key: 'isAutoAssigned' });
  }
  chips.innerHTML = items.map(i =>
    `<span class="filter-chip" data-key="${i.key}">${Utils.escapeHtml(i.label)} ✕</span>`
  ).join('');
  chips.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const key = chip.dataset.key;
      if (Array.isArray(AppState.filters[key])) AppState.filters[key] = [];
      else AppState.filters[key] = key === 'isAutoAssigned' ? null : '';
      syncFilterUI();
      applyAndRefresh();
    });
  });
}

function buildExtendedFilters() {
  const fg = Utils.qs('#filterGrid');
  if (!fg) return;
  const opts = Metrics.getFilterOptions(getPlainTables());
  fg.innerHTML = [
    { key: 'role',   label: 'Роль',          values: opts.role },
    { key: 'status', label: 'Статус',        values: opts.status },
    { key: 'taskId', label: 'Тип задачи',    values: opts.taskId },
    { key: 'login',  label: 'Логин',         values: opts.login.slice(0,30) },
  ].map(f => `
    <div class="ext-filter-group">
      <label>${f.label}</label>
      <div class="ext-filter-options">
        ${f.values.map(v => `
          <label class="ext-filter-opt">
            <input type="checkbox" data-key="${f.key}" value="${Utils.escapeHtml(v)}"
              ${(AppState.filters[f.key]||[]).includes(v) ? 'checked':''}>
            ${Utils.escapeHtml(v)}
          </label>`).join('')}
      </div>
    </div>`).join('');

  // isAutoAssigned toggle
  fg.innerHTML += `
    <div class="ext-filter-group">
      <label>Автоназначение</label>
      <div class="ext-filter-options">
        <label class="ext-filter-opt">
          <input type="radio" name="autoAsgn" value="" ${AppState.filters.isAutoAssigned===null?'checked':''}> Все
        </label>
        <label class="ext-filter-opt">
          <input type="radio" name="autoAsgn" value="true" ${AppState.filters.isAutoAssigned===true?'checked':''}> Только авто
        </label>
        <label class="ext-filter-opt">
          <input type="radio" name="autoAsgn" value="false" ${AppState.filters.isAutoAssigned===false?'checked':''}> Только ручные
        </label>
      </div>
    </div>`;

  fg.querySelectorAll('input[type=checkbox]').forEach(cb => {
    cb.addEventListener('change', () => {
      const key = cb.dataset.key;
      const val = cb.value;
      if (!Array.isArray(AppState.filters[key])) AppState.filters[key] = [];
      if (cb.checked) AppState.filters[key].push(val);
      else AppState.filters[key] = AppState.filters[key].filter(x => x !== val);
      applyAndRefresh();
    });
  });

  fg.querySelectorAll('input[name=autoAsgn]').forEach(r => {
    r.addEventListener('change', () => {
      AppState.filters.isAutoAssigned = r.value === '' ? null : r.value === 'true';
      applyAndRefresh();
    });
  });
}

function applyAndRefresh() {
  saveFilters();
  refreshAll();
  renderFilterChips();
  renderTab(AppState.ui.activeTab);
}

function saveFilters() {
  Storage.saveMeta('filters', AppState.filters);
}

/* ═══════════════════════════════════════════════════════════════
   IMPORT / FILE HANDLING
   ═══════════════════════════════════════════════════════════════ */

let _pendingFiles = [];

function bindImportEvents() {
  const modal    = Utils.qs('#importModal');
  const dropzone = Utils.qs('#dropzone');
  const fileInput= Utils.qs('#fileInput');

  Utils.qs('#btnImport')?.addEventListener('click', () => {
    _pendingFiles = [];
    Utils.qs('#fileList').innerHTML = '';
    Utils.qs('#btnApplyImport').disabled = true;
    Utils.show(modal);
  });

  Utils.qs('#btnCloseImport')?.addEventListener('click', () => Utils.hide(modal));
  Utils.qs('#btnCancelImport')?.addEventListener('click', () => Utils.hide(modal));

  dropzone.addEventListener('click', () => fileInput.click());
  dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('drag-over'); });
  dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
  dropzone.addEventListener('drop', e => {
    e.preventDefault(); dropzone.classList.remove('drag-over');
    handleFiles([...e.dataTransfer.files]);
  });

  fileInput.addEventListener('change', e => handleFiles([...e.target.files]));

  Utils.qs('#btnApplyImport')?.addEventListener('click', applyImport);

  // Bundle import
  Utils.qs('#btnExportBundle')?.addEventListener('click', () => {
    if (!Object.keys(AppState.tables).length) { setStatus('Нет данных для экспорта.'); return; }
    Export.exportBundle(AppState);
  });

  // Bundle import via file input
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      Utils.hide(Utils.qs('#importModal'));
      Utils.hide(Utils.qs('#mappingModal'));
      Utils.hide(Utils.qs('#insightModal'));
    }
  });

  // Modal overlays close on outside click
  [Utils.qs('#importModal'), Utils.qs('#mappingModal'), Utils.qs('#insightModal')].forEach(m => {
    if (!m) return;
    m.addEventListener('click', e => { if (e.target === m) Utils.hide(m); });
  });

  Utils.qs('#btnCloseInsightModal')?.addEventListener('click', () => Utils.hide(Utils.qs('#insightModal')));
  Utils.qs('#btnCloseMappingModal')?.addEventListener('click', () => Utils.hide(Utils.qs('#mappingModal')));

  Utils.qs('#btnClearSession')?.addEventListener('click', async () => {
    if (!confirm('Очистить всю текущую сессию?')) return;
    await Storage.clearAll();
    AppState.tables = {};
    AppState._computed = { metrics: null, answers: null, aggregates: null, insights: [] };
    renderTab(AppState.ui.activeTab);
    setStatus('Сессия очищена.');
  });
}

async function handleFiles(files) {
  const delim = Utils.qs('#csvDelimiter')?.value || 'auto';
  const list  = Utils.qs('#fileList');
  list.innerHTML = '<div class="file-item loading">Парсинг файлов...</div>';

  const parsed = [];
  for (const file of files) {
    try {
      const sheets = await Parser.parseFile(file, delim);
      for (const sheet of sheets) {
        sheet._file = file.name;
        parsed.push(sheet);
      }
    } catch(e) {
      list.innerHTML += `<div class="file-item error">❌ ${Utils.escapeHtml(file.name)}: ${Utils.escapeHtml(e.message)}</div>`;
    }
  }

  _pendingFiles = parsed;
  list.innerHTML = '';
  for (const sheet of parsed) {
    list.innerHTML += `
      <div class="file-item">
        <div class="file-item-name">📄 ${Utils.escapeHtml(sheet.filename)} ${sheet.sheet !== sheet.filename ? `[${sheet.sheet}]` : ''}</div>
        <div class="file-item-meta">
          ${sheet.rows.length} строк, ${sheet.columns.length} колонок
          <span class="entity-tag">${sheet.entity || '?'}</span>
          <select class="entity-select-inline" data-pidx="${parsed.indexOf(sheet)}">
            <option value="">— выбрать сущность —</option>
            ${Object.values(ENTITIES).map(e =>
              `<option value="${e}" ${e === sheet.entity ? 'selected':''}>${ENTITY_LABELS[e]||e}</option>`
            ).join('')}
          </select>
        </div>
        ${sheet.issues.map(i => `<div class="file-issue ${i.level}">⚠ ${Utils.escapeHtml(i.msg)}</div>`).join('')}
        <div class="preview-table">${buildPreviewHTML(sheet)}</div>
      </div>`;
  }

  // Allow entity override
  list.querySelectorAll('.entity-select-inline').forEach(sel => {
    sel.addEventListener('change', e => {
      _pendingFiles[parseInt(sel.dataset.pidx)].entity = e.target.value || null;
    });
  });

  const btn = Utils.qs('#btnApplyImport');
  if (btn) btn.disabled = parsed.length === 0;
}

function buildPreviewHTML(sheet) {
  const rows = sheet.rows.slice(0, 5);
  const cols = sheet.columns.slice(0, 8);
  if (!rows.length) return '<p class="muted">Пусто</p>';
  return `<table class="preview-mini">
    <thead><tr>${cols.map(c => `<th>${Utils.escapeHtml(c)}</th>`).join('')}</tr></thead>
    <tbody>${rows.map(r => `<tr>${cols.map(c => {
      const v = r[c]; const s = v instanceof Date ? Utils.formatDate(v,true) : String(v??'');
      return `<td>${Utils.escapeHtml(Utils.truncate(s,20))}</td>`;
    }).join('')}</tr>`).join('')}</tbody>
  </table>`;
}

async function applyImport() {
  const toLoad = _pendingFiles.filter(s => s.entity);
  if (!toLoad.length) { setStatus('Не выбрана ни одна сущность.'); return; }

  for (const sheet of toLoad) {
    const entity = sheet.entity;
    AppState.tables[entity] = {
      rows:    sheet.rows,
      schema:  sheet.schema,
      columns: sheet.columns,
    };
    // Save original for restore
    Storage.saveMeta(`original_${entity}`, { rows: Storage.serializeRows(sheet.rows) });
    await Storage.saveTable(entity, Storage.serializeRows(sheet.rows), sheet.schema, sheet.columns);
  }

  Utils.hide(Utils.qs('#importModal'));
  refreshAll();
  renderTab(AppState.ui.activeTab);
  updateStatusDataInfo();
  setStatus(`Загружено: ${toLoad.map(s => s.entity).join(', ')}.`);
}

/* ═══════════════════════════════════════════════════════════════
   GLOBAL EVENTS
   ═══════════════════════════════════════════════════════════════ */

function bindGlobalEvents() {
  // Bundle import via drag-drop on the main area
  document.body.addEventListener('dragover', e => e.preventDefault());
  document.body.addEventListener('drop', async e => {
    e.preventDefault();
    const files = [...e.dataTransfer.files];
    const jsonFile = files.find(f => f.name.endsWith('.json'));
    if (jsonFile) {
      try {
        const result = await Export.importBundleFromFile(jsonFile);
        for (const [entity, tdata] of Object.entries(result.tables)) {
          AppState.tables[entity] = tdata;
          await Storage.saveTable(entity, Storage.serializeRows(tdata.rows), tdata.schema, tdata.columns);
        }
        if (result.filters) Object.assign(AppState.filters, result.filters);
        refreshAll();
        renderTab(AppState.ui.activeTab);
        setStatus(`Бандл загружен. Сущностей: ${Object.keys(result.tables).length}.`);
      } catch(err) {
        setStatus(`Ошибка импорта бандла: ${err.message}`);
      }
    }
  });
}

/* ═══════════════════════════════════════════════════════════════
   STATUS / HELPERS
   ═══════════════════════════════════════════════════════════════ */

function setStatus(msg) {
  const el = Utils.qs('#statusText');
  if (el) el.textContent = msg;
}

function updateStatusDataInfo() {
  const el = Utils.qs('#statusDataInfo');
  if (!el) return;
  const m = AppState._computed.metrics;
  if (!m) { el.textContent = ''; return; }
  el.textContent = `Задач: ${Utils.formatNum(m.total)} · Закрыто: ${m.closureRate}% · Авто: ${m.autoShare}%`;
}

function _emptyState(msg) {
  return `<div class="empty-state">
    <div class="empty-state-icon">◎</div>
    <p>${Utils.escapeHtml(msg)}</p>
  </div>`;
}

/* ═══════════════════════════════════════════════════════════════
   BOOT
   ═══════════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', initApp);
