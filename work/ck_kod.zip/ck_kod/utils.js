/* utils.js — pure utility functions, no side-effects */

const Utils = (() => {

  /* ── Date helpers ─────────────────────────────────────────────── */

  const RU_MONTHS = {
    'янв':1,'фев':2,'мар':3,'апр':4,'май':5,'июн':6,
    'июл':7,'авг':8,'сен':9,'окт':10,'ноя':11,'дек':12,
    'january':1,'february':2,'march':3,'april':4,'may':5,'june':6,
    'july':7,'august':8,'september':9,'october':10,'november':11,'december':12,
  };

  function parseDate(value) {
    if (value == null || value === '') return null;
    if (value instanceof Date) return isNaN(value.getTime()) ? null : value;

    // Excel serial number
    if (typeof value === 'number') {
      if (value > 40000 && value < 100000) {
        const d = new Date((value - 25569) * 86400 * 1000);
        return isNaN(d.getTime()) ? null : d;
      }
      return null;
    }

    const s = String(value).trim();
    if (!s) return null;

    // ISO-like: 2024-01-15T10:30:00
    let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?/);
    if (m) {
      return new Date(
        +m[1], +m[2]-1, +m[3],
        m[4]?+m[4]:0, m[5]?+m[5]:0, m[6]?+m[6]:0
      );
    }

    // DD.MM.YYYY or DD/MM/YYYY
    m = s.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?/);
    if (m) {
      return new Date(
        +m[3], +m[2]-1, +m[1],
        m[4]?+m[4]:0, m[5]?+m[5]:0, m[6]?+m[6]:0
      );
    }

    // Try native Date parse as fallback
    const d = new Date(s);
    return isNaN(d.getTime()) ? null : d;
  }

  function formatDate(date, withTime = false) {
    if (!date) return '—';
    const d = date instanceof Date ? date : parseDate(date);
    if (!d) return String(date);
    const dd   = String(d.getDate()).padStart(2,'0');
    const mm   = String(d.getMonth()+1).padStart(2,'0');
    const yyyy = d.getFullYear();
    if (!withTime) return `${dd}.${mm}.${yyyy}`;
    const hh = String(d.getHours()).padStart(2,'0');
    const mi = String(d.getMinutes()).padStart(2,'0');
    return `${dd}.${mm}.${yyyy} ${hh}:${mi}`;
  }

  function formatDateISO(date) {
    if (!date) return null;
    const d = date instanceof Date ? date : parseDate(date);
    if (!d) return null;
    return d.toISOString().slice(0,10);
  }

  function startOfDay(date) {
    const d = new Date(date);
    d.setHours(0,0,0,0);
    return d;
  }

  function addDays(date, n) {
    const d = new Date(date);
    d.setDate(d.getDate() + n);
    return d;
  }

  function daysBetween(a, b) {
    const da = startOfDay(a), db = startOfDay(b);
    return Math.round((db - da) / 86400000);
  }

  function weekKey(date) {
    const d = new Date(date);
    d.setHours(0,0,0,0);
    d.setDate(d.getDate() - d.getDay() + 1); // Monday
    return formatDateISO(d);
  }

  function monthKey(date) {
    const d = parseDate(date) || new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
  }

  function grainKey(date, grain) {
    const d = parseDate(date) || new Date(date);
    if (grain === GRAIN.MONTH) return monthKey(d);
    if (grain === GRAIN.WEEK)  return weekKey(d);
    return formatDateISO(d);
  }

  function dateRange(from, to) {
    const days = [];
    let cur = startOfDay(new Date(from));
    const end = startOfDay(new Date(to));
    while (cur <= end) {
      days.push(new Date(cur));
      cur = addDays(cur, 1);
    }
    return days;
  }

  /* ── Number helpers ───────────────────────────────────────────── */

  function safeDivide(a, b, fallback = 0) {
    if (!b || isNaN(b)) return fallback;
    return a / b;
  }

  function pct(a, b) {
    return b ? Math.round(safeDivide(a, b) * 1000) / 10 : 0;
  }

  function formatPct(val) {
    return `${Math.round(val * 10) / 10}%`;
  }

  function formatNum(n, decimals = 0) {
    if (n == null || isNaN(n)) return '—';
    return Number(n).toLocaleString('ru-RU', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
  }

  function formatDuration(hours) {
    if (hours == null || isNaN(hours)) return '—';
    if (hours < 1)   return `${Math.round(hours * 60)} мин`;
    if (hours < 24)  return `${hours.toFixed(1)} ч`;
    const days = hours / 24;
    if (days < 30)   return `${days.toFixed(1)} д`;
    return `${(days/30).toFixed(1)} мес`;
  }

  function median(arr) {
    if (!arr.length) return null;
    const sorted = [...arr].sort((a,b) => a-b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 === 0
      ? (sorted[mid-1] + sorted[mid]) / 2
      : sorted[mid];
  }

  function mean(arr) {
    if (!arr.length) return null;
    return arr.reduce((s,v) => s+v, 0) / arr.length;
  }

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  /* ── Array / object helpers ───────────────────────────────────── */

  function groupBy(arr, keyFn) {
    const map = new Map();
    for (const item of arr) {
      const k = typeof keyFn === 'function' ? keyFn(item) : item[keyFn];
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(item);
    }
    return map;
  }

  function groupByObj(arr, keyFn) {
    const obj = {};
    for (const item of arr) {
      const k = typeof keyFn === 'function' ? keyFn(item) : item[keyFn];
      if (!obj[k]) obj[k] = [];
      obj[k].push(item);
    }
    return obj;
  }

  function sortBy(arr, keyFn, desc = false) {
    return [...arr].sort((a, b) => {
      const ka = typeof keyFn === 'function' ? keyFn(a) : a[keyFn];
      const kb = typeof keyFn === 'function' ? keyFn(b) : b[keyFn];
      if (ka == null) return 1;
      if (kb == null) return -1;
      const cmp = ka < kb ? -1 : ka > kb ? 1 : 0;
      return desc ? -cmp : cmp;
    });
  }

  function unique(arr) {
    return [...new Set(arr)];
  }

  function uniqueBy(arr, keyFn) {
    const seen = new Set();
    return arr.filter(item => {
      const k = typeof keyFn === 'function' ? keyFn(item) : item[keyFn];
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  function countBy(arr, keyFn) {
    const obj = {};
    for (const item of arr) {
      const k = typeof keyFn === 'function' ? keyFn(item) : item[keyFn];
      obj[k] = (obj[k] || 0) + 1;
    }
    return obj;
  }

  function topN(obj, n = 10) {
    return Object.entries(obj)
      .sort(([,a],[,b]) => b - a)
      .slice(0, n)
      .map(([k,v]) => ({key: k, count: v}));
  }

  function deepClone(obj) {
    if (obj == null || typeof obj !== 'object') return obj;
    try { return JSON.parse(JSON.stringify(obj)); }
    catch { return obj; }
  }

  /* ── String helpers ───────────────────────────────────────────── */

  function normalize(s) {
    return String(s || '').trim().toLowerCase();
  }

  function escapeHtml(s) {
    return String(s ?? '')
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;');
  }

  function escapeCSV(v) {
    const s = String(v ?? '');
    if (s.includes(',') || s.includes('"') || s.includes('\n'))
      return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function truncate(s, n = 40) {
    s = String(s ?? '');
    return s.length > n ? s.slice(0, n) + '…' : s;
  }

  /* ── DOM helpers ──────────────────────────────────────────────── */

  function el(tag, attrs = {}, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class')          e.className = v;
      else if (k === 'innerHTML') e.innerHTML = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
      else                        e.setAttribute(k, v);
    }
    for (const child of children) {
      if (child == null) continue;
      if (typeof child === 'string') e.appendChild(document.createTextNode(child));
      else if (child instanceof Node) e.appendChild(child);
    }
    return e;
  }

  function qs(sel, root = document) { return root.querySelector(sel); }
  function qsa(sel, root = document) { return [...root.querySelectorAll(sel)]; }

  function show(el) { el && el.classList.remove('hidden'); }
  function hide(el) { el && el.classList.add('hidden'); }
  function toggle(el, force) { el && el.classList.toggle('hidden', force !== undefined ? !force : undefined); }

  function debounce(fn, ms = 200) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  }

  function generateId() {
    return Math.random().toString(36).slice(2);
  }

  /* ── Export ───────────────────────────────────────────────────── */
  return {
    parseDate, formatDate, formatDateISO, startOfDay, addDays,
    daysBetween, weekKey, monthKey, grainKey, dateRange,
    safeDivide, pct, formatPct, formatNum, formatDuration,
    median, mean, clamp,
    groupBy, groupByObj, sortBy, unique, uniqueBy, countBy, topN, deepClone,
    normalize, escapeHtml, escapeCSV, truncate,
    el, qs, qsa, show, hide, toggle, debounce, generateId,
  };
})();
