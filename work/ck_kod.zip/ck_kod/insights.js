/* insights.js — auto-generated analytical insights */

const Insights = (() => {

  const SEVERITY = { HIGH: 'high', MEDIUM: 'medium', LOW: 'low' };

  /* ─── helper ─────────────────────────────────────────────────── */
  function insight(id, severity, title, body, value, tasks = []) {
    return { id, severity, title, body, value, tasks, confidence: _conf(tasks.length) };
  }

  function _conf(n) {
    if (n >= 100) return 'высокая';
    if (n >= 20)  return 'средняя';
    return 'низкая';
  }

  /* ─── main ───────────────────────────────────────────────────── */
  function generate(tables, filters = {}) {
    const result = Metrics.computeMetrics(tables, filters);
    const tasks = result._tasks;
    if (!tasks.length) return [];

    const ins = [];

    // 1. Backlog growth — roles with most not-started
    const notStartedByRole = Utils.countBy(
      tasks.filter(t => {
        const cd = t.CloseDateTime;
        return !cd && !t._firstAssignDate;
      }),
      t => t.Role || '(нет)'
    );
    const topRoleBacklog = Utils.sortBy(
      Object.entries(notStartedByRole).map(([role, count]) => ({role, count})),
      'count', true
    )[0];
    if (topRoleBacklog) {
      ins.push(insight(
        'role_backlog', SEVERITY.HIGH,
        `Высокий backlog у роли "${topRoleBacklog.role}"`,
        `У роли "${topRoleBacklog.role}" наибольшее количество задач, ещё не взятых в работу.`,
        topRoleBacklog.count,
        tasks.filter(t => (t.Role||'(нет)') === topRoleBacklog.role && !t._firstAssignDate)
      ));
    }

    // 2. High deferment rate by task type
    const byType = Utils.groupByObj(tasks, t => t.TaskID || t.TaskType || '(нет)');
    const deferRates = Object.entries(byType)
      .filter(([,arr]) => arr.length >= 3)
      .map(([type, arr]) => ({
        type,
        count: arr.length,
        deferred: arr.filter(t => t._firstDeferDate).length,
        rate: Utils.pct(arr.filter(t => t._firstDeferDate).length, arr.length),
      }))
      .filter(d => d.rate > 20);
    const topDefer = Utils.sortBy(deferRates, 'rate', true)[0];
    if (topDefer) {
      ins.push(insight(
        'type_deferment', SEVERITY.MEDIUM,
        `Тип задачи "${topDefer.type}" часто откладывается`,
        `Среди задач типа "${topDefer.type}" ${topDefer.rate}% были отложены хотя бы раз.`,
        `${topDefer.rate}%`,
        tasks.filter(t => (t.TaskID||'(нет)') === topDefer.type && t._firstDeferDate)
      ));
    }

    // 3. High error rate by task type
    const errRates = Object.entries(byType)
      .filter(([,arr]) => arr.length >= 3)
      .map(([type, arr]) => ({
        type,
        rate: Utils.pct(arr.filter(t => t._firstErrorDate).length, arr.length),
      }))
      .filter(d => d.rate > 15);
    const topErr = Utils.sortBy(errRates, 'rate', true)[0];
    if (topErr) {
      ins.push(insight(
        'type_error', SEVERITY.HIGH,
        `Тип задачи "${topErr.type}" имеет высокий error rate`,
        `У задач типа "${topErr.type}" уровень ошибок составляет ${topErr.rate}%.`,
        `${topErr.rate}%`,
        tasks.filter(t => (t.TaskID||'(нет)') === topErr.type && t._firstErrorDate)
      ));
    }

    // 4. Slow assignment (long time to first assign)
    const slowAsgn = tasks.filter(t => t._createToAssignHours != null && t._createToAssignHours > 72);
    if (slowAsgn.length > tasks.length * 0.1) {
      ins.push(insight(
        'slow_assign', SEVERITY.MEDIUM,
        'Много задач с длительным временем назначения',
        `${slowAsgn.length} задач (${Utils.pct(slowAsgn.length, tasks.length)}%) ждали назначения более 3 суток.`,
        `${slowAsgn.length} задач`,
        slowAsgn
      ));
    }

    // 5. Slow closure
    const slowClose = tasks.filter(t => t._createToCloseHours != null && t._createToCloseHours > 720);
    if (slowClose.length > tasks.length * 0.1) {
      ins.push(insight(
        'slow_close', SEVERITY.MEDIUM,
        'Много задач с длительным временем закрытия',
        `${slowClose.length} задач закрывались дольше 30 дней.`,
        `${slowClose.length} задач`,
        slowClose
      ));
    }

    // 6. Auto assignment — compare closure rates
    const autoTasks   = tasks.filter(t => t._isAutoAssigned);
    const manualTasks = tasks.filter(t => !t._isAutoAssigned);
    if (autoTasks.length > 5 && manualTasks.length > 5) {
      const autoCR   = Utils.pct(autoTasks.filter(t => t.CloseDateTime).length, autoTasks.length);
      const manualCR = Utils.pct(manualTasks.filter(t => t.CloseDateTime).length, manualTasks.length);
      const diff = autoCR - manualCR;
      if (Math.abs(diff) > 5) {
        ins.push(insight(
          'auto_vs_manual_closure', diff > 0 ? SEVERITY.LOW : SEVERITY.MEDIUM,
          diff > 0
            ? 'Автоназначенные задачи закрываются чаще'
            : 'Ручные задачи закрываются чаще автоназначенных',
          `Closure rate: авто ${autoCR}% vs ручные ${manualCR}% (разница ${Math.abs(diff).toFixed(1)}%).`,
          `Δ ${diff > 0 ? '+' : ''}${diff.toFixed(1)}%`,
          diff > 0 ? autoTasks.filter(t => t.CloseDateTime) : manualTasks.filter(t => t.CloseDateTime)
        ));
      }

      const autoER   = Utils.pct(autoTasks.filter(t => t._firstErrorDate).length, autoTasks.length);
      const manualER = Utils.pct(manualTasks.filter(t => t._firstErrorDate).length, manualTasks.length);
      const errDiff = autoER - manualER;
      if (Math.abs(errDiff) > 5) {
        ins.push(insight(
          'auto_vs_manual_error', errDiff > 0 ? SEVERITY.MEDIUM : SEVERITY.LOW,
          errDiff > 0
            ? 'Автоназначенные задачи чаще уходят в ошибку'
            : 'Автоназначенные задачи реже уходят в ошибку',
          `Error rate: авто ${autoER}% vs ручные ${manualER}%.`,
          `Δ ${errDiff > 0 ? '+' : ''}${errDiff.toFixed(1)}%`,
          []
        ));
      }
    }

    // 7. High reassignment rate
    const highReasgn = tasks.filter(t => t._reassignCount > 2);
    if (highReasgn.length > tasks.length * 0.05) {
      ins.push(insight(
        'high_reassign', SEVERITY.MEDIUM,
        'Высокий уровень переназначений',
        `${highReasgn.length} задач (${Utils.pct(highReasgn.length, tasks.length)}%) переназначались более 2 раз.`,
        `${highReasgn.length} задач`,
        highReasgn
      ));
    }

    // 8. Peak creation hours
    const heatmap = Metrics.computeHeatmapData(tasks, 'pxCreateDateTime');
    const hourTotals = Array.from({length:24}, (_,h) => ({
      hour: h,
      count: heatmap.reduce((s, day) => s + day[h], 0),
    }));
    const peakHour = Utils.sortBy(hourTotals, 'count', true)[0];
    if (peakHour?.count > 0) {
      ins.push(insight(
        'peak_hour', SEVERITY.LOW,
        `Пик создания задач в ${peakHour.hour}:00`,
        `Больше всего задач создаётся в ${peakHour.hour}:00 — ${peakHour.count} задач.`,
        `${peakHour.count} задач`,
        []
      ));
    }

    // 9. Low closure rate
    if (result.closureRate < 30 && tasks.length > 10) {
      ins.push(insight(
        'low_closure', SEVERITY.HIGH,
        'Низкий closure rate',
        `Только ${result.closureRate}% задач закрыты. Возможно накапливается незавершённая работа.`,
        `${result.closureRate}%`,
        tasks.filter(t => !t.CloseDateTime)
      ));
    }

    // 10. Aging: many old tasks
    const aged = tasks.filter(t => t._agingDays != null && t._agingDays > 30 && !t.CloseDateTime);
    if (aged.length > tasks.length * 0.15) {
      ins.push(insight(
        'aging_tasks', SEVERITY.HIGH,
        'Много задач старше 30 дней',
        `${aged.length} незакрытых задач старше 30 дней (${Utils.pct(aged.length, tasks.length)}% от всех).`,
        `${aged.length} задач`,
        aged
      ));
    }

    return Utils.sortBy(ins, i => i.severity === SEVERITY.HIGH ? 0 : i.severity === SEVERITY.MEDIUM ? 1 : 2);
  }

  return { generate, SEVERITY };
})();
