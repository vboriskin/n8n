/* metrics.js — normalization, state computation, all business metrics */

const Metrics = (() => {

  /* ──────────────────────────────────────────────────────────────
     1. AUTO-ASSIGNMENT DETECTION
     ────────────────────────────────────────────────────────────── */

  function computeAutoAssignment(taskDeferments) {
    const result = new Map(); // TaskKey -> boolean
    if (!taskDeferments?.length) return result;

    // Group by TaskKey, find earliest record per TaskKey
    const grouped = Utils.groupBy(taskDeferments, r => r.TaskKey || r.taskkey || '');
    for (const [taskKey, records] of grouped) {
      if (!taskKey) continue;
      const sorted = Utils.sortBy(records, r => r.pxCreateDateTime);
      const earliest = sorted[0];
      const comment = String(earliest.Comment || earliest.comment || '').trim();
      result.set(String(taskKey), comment === AUTO_ASSIGN_COMMENT);
    }
    return result;
  }

  /* ──────────────────────────────────────────────────────────────
     2. SNAPSHOT STATE ON DATE D
     Priority: Closed > Error > Deferred > InProgress > NotStarted
     ────────────────────────────────────────────────────────────── */

  function computeTaskStateOnDate(taskKey, date, {
    task, loginRequests, taskDeferments, taskErrors, excludeError = true,
  }) {
    const D = date instanceof Date ? date : Utils.parseDate(date);
    if (!D || !task) return COMPUTED_STATUS.NOT_STARTED;

    const created = task.pxCreateDateTime;
    if (created && created > D) return null; // not yet created

    // 1. Closed
    const closeDate = task.CloseDateTime;
    if (closeDate && closeDate <= D) return COMPUTED_STATUS.CLOSED;

    // 2. Error — any TaskError for this task with pxCreateDateTime <= D
    if (excludeError && taskErrors?.length) {
      const errs = taskErrors.filter(e =>
        String(e.TaskKey || '') === String(taskKey) &&
        e.pxCreateDateTime && e.pxCreateDateTime <= D
      );
      if (errs.length) {
        // Still in error if task not closed before D
        return COMPUTED_STATUS.ERROR;
      }
    }

    // 3. Deferred — active deferment interval containing D
    if (taskDeferments?.length) {
      const defs = taskDeferments.filter(d =>
        String(d.TaskKey || d.taskKey || '') === String(taskKey) &&
        d.pxCreateDateTime && d.pxCreateDateTime <= D
      );
      for (const d of defs) {
        const endDate = d.EndDateTime;
        if (!endDate || endDate > D) {
          return COMPUTED_STATUS.DEFERRED;
        }
      }
    }

    // 4. InProgress — at least one LoginRequest record <= D
    if (loginRequests?.length) {
      const assigned = loginRequests.filter(lr =>
        String(lr.RequestKey || lr.TaskKey || '') === String(task.RequestKey || taskKey) &&
        lr.pxCreateDateTime && lr.pxCreateDateTime <= D
      );
      if (assigned.length) return COMPUTED_STATUS.IN_PROGRESS;
    }

    // 5. NotStarted
    return COMPUTED_STATUS.NOT_STARTED;
  }

  /* ──────────────────────────────────────────────────────────────
     3. NORMALIZATION — build enriched task objects
     ────────────────────────────────────────────────────────────── */

  function normalizeTasks(tables) {
    const tasks          = tables[ENTITIES.TASK]          || [];
    const loginRequests  = tables[ENTITIES.LOGIN_REQUEST] || [];
    const taskDeferments = tables[ENTITIES.TASK_DEFERMENT]|| [];
    const taskErrors     = tables[ENTITIES.TASK_ERROR]    || [];
    const assigns        = tables[ENTITIES.ASSIGN]        || [];

    const autoAssignMap = computeAutoAssignment(taskDeferments);

    // Index LoginRequests by RequestKey
    const lrByReq = Utils.groupByObj(loginRequests, lr =>
      String(lr.RequestKey || lr.TaskKey || '')
    );

    // Index deferments by TaskKey
    const defByTask = Utils.groupByObj(taskDeferments, d =>
      String(d.TaskKey || d.taskKey || '')
    );

    // Index errors by TaskKey
    const errByTask = Utils.groupByObj(taskErrors, e => String(e.TaskKey || ''));

    // Index assigns by DealID / TaskKey
    const assignByTask = Utils.groupByObj(assigns, a =>
      String(a.TaskKey || a.DealID || a.RequestKey || '')
    );

    const normalized = tasks.map(task => {
      const taskKey   = String(task.TaskKey || '');
      const reqKey    = String(task.RequestKey || '');

      const myLR   = lrByReq[reqKey] || lrByReq[taskKey] || [];
      const myDefs = defByTask[taskKey] || [];
      const myErrs = errByTask[taskKey] || [];
      const myAsgn = assignByTask[taskKey] || assignByTask[reqKey] || [];

      // First assignment date
      const sortedLR = Utils.sortBy(myLR, r => r.pxCreateDateTime);
      const firstAssignDate = sortedLR[0]?.pxCreateDateTime || null;

      // First deferment date
      const sortedDefs = Utils.sortBy(myDefs, d => d.pxCreateDateTime);
      const firstDeferDate = sortedDefs[0]?.pxCreateDateTime || null;

      // First error date
      const sortedErrs = Utils.sortBy(myErrs, e => e.pxCreateDateTime);
      const firstErrorDate = sortedErrs[0]?.pxCreateDateTime || null;

      // Auto assignment flag
      const isAutoAssigned = autoAssignMap.get(taskKey) || false;

      // Aging (from creation to today)
      const now = new Date();
      const created = task.pxCreateDateTime;
      const agingDays = created ? Utils.daysBetween(created, now) : null;

      // Duration create → assign
      const createToAssignHours = (created && firstAssignDate)
        ? (firstAssignDate - created) / 3600000 : null;

      // Duration create → close
      const closeDate = task.CloseDateTime;
      const createToCloseHours = (created && closeDate)
        ? (closeDate - created) / 3600000 : null;

      // Total deferred duration
      let totalDeferredHours = 0;
      for (const d of myDefs) {
        const start = d.pxCreateDateTime;
        const end   = d.EndDateTime || closeDate || now;
        if (start && end && end >= start) {
          totalDeferredHours += (end - start) / 3600000;
        }
      }

      // Reassignment count
      const reassignCount = myAsgn.length;

      return {
        ...task,
        TaskKey: taskKey,
        RequestKey: reqKey,
        _firstAssignDate:     firstAssignDate,
        _firstDeferDate:      firstDeferDate,
        _firstErrorDate:      firstErrorDate,
        _isAutoAssigned:      isAutoAssigned,
        _agingDays:           agingDays,
        _createToAssignHours: createToAssignHours,
        _createToCloseHours:  createToCloseHours,
        _totalDeferredHours:  totalDeferredHours,
        _reassignCount:       reassignCount,
        _loginRequests:       myLR,
        _deferments:          myDefs,
        _errors:              myErrs,
        _assigns:             myAsgn,
      };
    });

    return { normalized, lrByReq, defByTask, errByTask };
  }

  /* ──────────────────────────────────────────────────────────────
     4. FILTER APPLICATION
     ────────────────────────────────────────────────────────────── */

  function applyFilters(tasks, filters) {
    let result = tasks;

    if (filters.dateFrom) {
      const from = Utils.parseDate(filters.dateFrom);
      if (from) result = result.filter(t => t.pxCreateDateTime && t.pxCreateDateTime >= from);
    }
    if (filters.dateTo) {
      const to = Utils.parseDate(filters.dateTo);
      if (to) {
        const end = new Date(to); end.setHours(23,59,59,999);
        result = result.filter(t => t.pxCreateDateTime && t.pxCreateDateTime <= end);
      }
    }
    if (filters.role?.length)     result = result.filter(t => filters.role.includes(String(t.Role || '')));
    if (filters.login?.length)    result = result.filter(t => filters.login.includes(String(t.Login || '')));
    if (filters.status?.length)   result = result.filter(t => filters.status.includes(String(t.Status || '')));
    if (filters.taskId?.length)   result = result.filter(t => filters.taskId.includes(String(t.TaskID || '')));
    if (filters.taskKey)          result = result.filter(t => String(t.TaskKey||'').includes(filters.taskKey));
    if (filters.requestKey)       result = result.filter(t => String(t.RequestKey||'').includes(filters.requestKey));
    if (filters.isAutoAssigned !== undefined && filters.isAutoAssigned !== null) {
      result = result.filter(t => t._isAutoAssigned === filters.isAutoAssigned);
    }

    return result;
  }

  /* ──────────────────────────────────────────────────────────────
     5. CORE METRICS COMPUTATION
     ────────────────────────────────────────────────────────────── */

  function computeMetrics(tables, filters = {}) {
    const { normalized } = normalizeTasks(tables);
    const filtered = applyFilters(normalized, filters);
    const now = new Date();
    const snapshotDate = filters.snapshotDate ? Utils.parseDate(filters.snapshotDate) : now;
    const excludeError = filters.excludeErrorFromWIP !== false;

    // ── Counts ──────────────────────────────────────────────────
    const total       = filtered.length;
    const created     = total;
    const assigned    = filtered.filter(t => !!t._firstAssignDate).length;
    const closed      = filtered.filter(t => {
      const cd = t.CloseDateTime;
      return cd && cd <= snapshotDate;
    }).length;

    // State on snapshot date
    let inProgress = 0, deferred = 0, errCount = 0, notStarted = 0;
    for (const t of filtered) {
      const state = computeTaskStateOnDate(t.TaskKey, snapshotDate, {
        task: t,
        loginRequests:  t._loginRequests,
        taskDeferments: t._deferments,
        taskErrors:     t._errors,
        excludeError,
      });
      if (state === COMPUTED_STATUS.IN_PROGRESS)  inProgress++;
      else if (state === COMPUTED_STATUS.DEFERRED) deferred++;
      else if (state === COMPUTED_STATUS.ERROR)    errCount++;
      else if (state === COMPUTED_STATUS.NOT_STARTED) notStarted++;
    }

    // ── Auto assignment ──────────────────────────────────────────
    const autoCount   = filtered.filter(t => t._isAutoAssigned).length;
    const autoShare   = Utils.pct(autoCount, total);

    // ── Rates ───────────────────────────────────────────────────
    const closureRate    = Utils.pct(closed, total);
    const assignmentRate = Utils.pct(assigned, total);
    const errorRate      = Utils.pct(errCount, total);
    const defermentRate  = Utils.pct(deferred, total);

    // ── Timing metrics ───────────────────────────────────────────
    const c2aVals = filtered.map(t => t._createToAssignHours).filter(v => v != null && v >= 0);
    const c2cVals = filtered.map(t => t._createToCloseHours).filter(v => v != null && v >= 0);
    const defVals = filtered.map(t => t._totalDeferredHours).filter(v => v > 0);

    const avgCreateToAssign    = Utils.mean(c2aVals);
    const medCreateToAssign    = Utils.median(c2aVals);
    const avgCreateToClose     = Utils.mean(c2cVals);
    const medCreateToClose     = Utils.median(c2cVals);
    const avgDeferredDuration  = Utils.mean(defVals);

    // ── Reassignments ────────────────────────────────────────────
    const reassignTotal = filtered.reduce((s,t) => s + t._reassignCount, 0);
    const reassignRate  = Utils.pct(filtered.filter(t => t._reassignCount > 0).length, total);

    // ── Breakdowns ───────────────────────────────────────────────
    const byRole     = Utils.countBy(filtered, t => t.Role     || '(нет)');
    const byTaskType = Utils.countBy(filtered, t => t.TaskID   || t.TaskType || '(нет)');
    const byLogin    = Utils.countBy(filtered, t => t.Login    || '(нет)');
    const byStatus   = Utils.countBy(filtered, t => t.Status   || '(нет)');

    // ── Aging buckets ─────────────────────────────────────────────
    const agingBuckets = AGING_BUCKETS.map(b => ({
      ...b,
      count: filtered.filter(t => {
        const d = t._agingDays;
        return d != null && d >= b.min && d < b.max;
      }).length,
    }));

    // ── Auto vs manual comparison ────────────────────────────────
    const autoTasks   = filtered.filter(t => t._isAutoAssigned);
    const manualTasks = filtered.filter(t => !t._isAutoAssigned);

    const autoMetrics = {
      count:       autoTasks.length,
      closed:      autoTasks.filter(t => t.CloseDateTime && t.CloseDateTime <= snapshotDate).length,
      errored:     autoTasks.filter(t => t._firstErrorDate).length,
      deferred:    autoTasks.filter(t => t._firstDeferDate).length,
      closureRate: Utils.pct(autoTasks.filter(t => t.CloseDateTime).length, autoTasks.length),
    };
    const manualMetrics = {
      count:       manualTasks.length,
      closed:      manualTasks.filter(t => t.CloseDateTime && t.CloseDateTime <= snapshotDate).length,
      errored:     manualTasks.filter(t => t._firstErrorDate).length,
      deferred:    manualTasks.filter(t => t._firstDeferDate).length,
      closureRate: Utils.pct(manualTasks.filter(t => t.CloseDateTime).length, manualTasks.length),
    };

    return {
      total, created, assigned, closed, inProgress, deferred,
      errCount, notStarted, autoCount, autoShare,
      closureRate, assignmentRate, errorRate, defermentRate,
      avgCreateToAssign, medCreateToAssign,
      avgCreateToClose, medCreateToClose, avgDeferredDuration,
      reassignTotal, reassignRate,
      byRole, byTaskType, byLogin, byStatus,
      agingBuckets, autoMetrics, manualMetrics,
      _tasks: filtered,
      _snapshotDate: snapshotDate,
    };
  }

  /* ──────────────────────────────────────────────────────────────
     6. ANSWERS TO 3 MAIN QUESTIONS
     ────────────────────────────────────────────────────────────── */

  function computeAnswers(tables, filters = {}) {
    const { normalized } = normalizeTasks(tables);
    const now = new Date();
    const snapshotDate = filters.snapshotDate ? Utils.parseDate(filters.snapshotDate) : now;
    const dateFrom = filters.dateFrom ? Utils.parseDate(filters.dateFrom) : null;
    const dateTo   = filters.dateTo   ? Utils.parseDate(filters.dateTo)   : null;
    const excludeError = filters.excludeErrorFromWIP !== false;

    const inPeriod = t => {
      const cd = t.pxCreateDateTime;
      if (!cd) return false;
      if (dateFrom && cd < dateFrom) return false;
      if (dateTo) { const end = new Date(dateTo); end.setHours(23,59,59,999); if (cd > end) return false; }
      return true;
    };

    // Q1: Created
    const createdInPeriod = normalized.filter(inPeriod);
    const existsOnDate    = normalized.filter(t => t.pxCreateDateTime && t.pxCreateDateTime <= snapshotDate);

    const notStartedOnDate = existsOnDate.filter(t => {
      if (t.CloseDateTime && t.CloseDateTime <= snapshotDate) return false;
      if (t._firstAssignDate && t._firstAssignDate <= snapshotDate) return false;
      return true;
    });

    // Q2: Assigned / InProgress
    const assignedInPeriod = normalized.filter(t => {
      const adate = t._firstAssignDate;
      if (!adate) return false;
      if (dateFrom && adate < dateFrom) return false;
      if (dateTo) { const end = new Date(dateTo); end.setHours(23,59,59,999); if (adate > end) return false; }
      return true;
    });

    const assignedOnDate = normalized.filter(t =>
      t._firstAssignDate && t._firstAssignDate <= snapshotDate
    );

    const inProgressOnDate = existsOnDate.filter(t => {
      const state = computeTaskStateOnDate(t.TaskKey, snapshotDate, {
        task: t, loginRequests: t._loginRequests,
        taskDeferments: t._deferments, taskErrors: t._errors, excludeError,
      });
      return state === COMPUTED_STATUS.IN_PROGRESS;
    });

    // Q3: Closed
    const closedInPeriod = normalized.filter(t => {
      const cd = t.CloseDateTime;
      if (!cd) return false;
      if (dateFrom && cd < dateFrom) return false;
      if (dateTo) { const end = new Date(dateTo); end.setHours(23,59,59,999); if (cd > end) return false; }
      return true;
    });
    const closedOnDate = normalized.filter(t => t.CloseDateTime && t.CloseDateTime <= snapshotDate);

    const closureRate = Utils.pct(closedOnDate.length, existsOnDate.length);

    // Min/max created date
    const allCreated = normalized.map(t => t.pxCreateDateTime).filter(Boolean).sort((a,b) => a-b);
    const minCreated = allCreated[0] || null;
    const maxCreated = allCreated[allCreated.length-1] || null;

    return {
      q1: {
        createdInPeriod: createdInPeriod.length,
        existsOnDate: existsOnDate.length,
        notStartedOnDate: notStartedOnDate.length,
        minCreated, maxCreated,
        byRole:     Utils.countBy(createdInPeriod, t => t.Role    || '(нет)'),
        byTaskType: Utils.countBy(createdInPeriod, t => t.TaskID  || '(нет)'),
        byLogin:    Utils.countBy(createdInPeriod, t => t.Login   || '(нет)'),
        byStatus:   Utils.countBy(createdInPeriod, t => t.Status  || '(нет)'),
        tasks: createdInPeriod,
      },
      q2: {
        assignedInPeriod: assignedInPeriod.length,
        assignedOnDate: assignedOnDate.length,
        inProgressOnDate: inProgressOnDate.length,
        byRole:     Utils.countBy(inProgressOnDate, t => t.Role   || '(нет)'),
        byTaskType: Utils.countBy(inProgressOnDate, t => t.TaskID || '(нет)'),
        tasks: inProgressOnDate,
      },
      q3: {
        closedInPeriod: closedInPeriod.length,
        closedOnDate: closedOnDate.length,
        closureRate,
        byRole:     Utils.countBy(closedInPeriod, t => t.Role    || '(нет)'),
        byTaskType: Utils.countBy(closedInPeriod, t => t.TaskID  || '(нет)'),
        tasks: closedInPeriod,
      },
      snapshotDate, dateFrom, dateTo,
    };
  }

  /* ──────────────────────────────────────────────────────────────
     7. AGGREGATES BY GRAIN
     ────────────────────────────────────────────────────────────── */

  function computeAggregates(tables, grain = GRAIN.DAY, filters = {}) {
    const { normalized } = normalizeTasks(tables);
    const tasks = applyFilters(normalized, filters);
    const taskDeferments = tables[ENTITIES.TASK_DEFERMENT] || [];
    const taskErrors     = tables[ENTITIES.TASK_ERROR]     || [];
    const assigns        = tables[ENTITIES.ASSIGN]         || [];

    // task_daily_snapshot
    const taskByDay = {};
    const addToDay = (date, key, val = 1) => {
      if (!date) return;
      const dk = Utils.grainKey(date, grain);
      if (!taskByDay[dk]) taskByDay[dk] = {};
      taskByDay[dk][key] = (taskByDay[dk][key] || 0) + val;
    };
    for (const t of tasks) {
      addToDay(t.pxCreateDateTime,  'created');
      addToDay(t._firstAssignDate,  'assigned');
      addToDay(t.CloseDateTime,     'closed');
      addToDay(t._firstDeferDate,   'deferred');
      addToDay(t._firstErrorDate,   'errored');
    }
    const taskDailySnapshot = Utils.sortBy(
      Object.entries(taskByDay).map(([date, counts]) => ({ date, ...counts })),
      'date'
    );

    // closure_by_day
    const closureByDay = taskDailySnapshot.map(row => ({
      date: row.date,
      created: row.created || 0,
      closed:  row.closed  || 0,
      rate:    Utils.pct(row.closed || 0, row.created || 0),
    }));

    // backlog_by_day — cumulative created - cumulative closed
    let cumCreated = 0, cumClosed = 0;
    const backlogByDay = taskDailySnapshot.map(row => {
      cumCreated += row.created || 0;
      cumClosed  += row.closed  || 0;
      return { date: row.date, cumCreated, cumClosed, backlog: cumCreated - cumClosed };
    });

    // workload_by_role
    const roleByDay = {};
    for (const t of tasks) {
      const dk = t.pxCreateDateTime ? Utils.grainKey(t.pxCreateDateTime, grain) : null;
      if (!dk) continue;
      const role = t.Role || '(нет)';
      if (!roleByDay[dk]) roleByDay[dk] = {};
      roleByDay[dk][role] = (roleByDay[dk][role] || 0) + 1;
    }
    const workloadByRole = Utils.sortBy(
      Object.entries(roleByDay).map(([date, roles]) => ({ date, ...roles })),
      'date'
    );

    // deferment_by_reason
    const deferByReason = Utils.countBy(taskDeferments, d => d.Reason || d.reason || '(нет)');
    const defermentByReason = Utils.sortBy(
      Object.entries(deferByReason).map(([reason, count]) => ({ reason, count })),
      'count', true
    );

    // error_by_reason
    const errByReason = Utils.countBy(taskErrors, e => e.Reason || e.reason || '(нет)');
    const errorByReason = Utils.sortBy(
      Object.entries(errByReason).map(([reason, count]) => ({ reason, count })),
      'count', true
    );

    // reassignment_summary
    const reassignByDate = {};
    for (const a of assigns) {
      const dk = a.pxCreateDateTime ? Utils.grainKey(a.pxCreateDateTime, grain) : null;
      if (dk) reassignByDate[dk] = (reassignByDate[dk] || 0) + 1;
    }
    const reassignmentSummary = Utils.sortBy(
      Object.entries(reassignByDate).map(([date, count]) => ({ date, count })),
      'date'
    );

    // auto_assignment_summary
    const autoTasks   = tasks.filter(t => t._isAutoAssigned);
    const manualTasks = tasks.filter(t => !t._isAutoAssigned);

    const autoAssignmentSummary = {
      autoCount:   autoTasks.length,
      manualCount: manualTasks.length,
      autoClosureRate:   Utils.pct(autoTasks.filter(t => t.CloseDateTime).length, autoTasks.length),
      manualClosureRate: Utils.pct(manualTasks.filter(t => t.CloseDateTime).length, manualTasks.length),
      autoErrorRate:     Utils.pct(autoTasks.filter(t => t._firstErrorDate).length, autoTasks.length),
      manualErrorRate:   Utils.pct(manualTasks.filter(t => t._firstErrorDate).length, manualTasks.length),
    };

    // funnel_by_day
    const funnelByDay = taskDailySnapshot.map(row => ({
      date:     row.date,
      created:  row.created  || 0,
      assigned: row.assigned || 0,
      closed:   row.closed   || 0,
      deferred: row.deferred || 0,
      errored:  row.errored  || 0,
    }));

    return {
      taskDailySnapshot,
      closureByDay,
      backlogByDay,
      workloadByRole,
      defermentByReason,
      errorByReason,
      reassignmentSummary,
      autoAssignmentSummary,
      funnelByDay,
    };
  }

  /* ──────────────────────────────────────────────────────────────
     8. TREND DATA (for charts)
     ────────────────────────────────────────────────────────────── */

  function computeTrendData(tables, grain = GRAIN.DAY, filters = {}) {
    const aggs = computeAggregates(tables, grain, filters);
    return aggs;
  }

  /* ──────────────────────────────────────────────────────────────
     9. HEATMAP DATA (weekday × hour)
     ────────────────────────────────────────────────────────────── */

  function computeHeatmapData(tasks, dateField = 'pxCreateDateTime') {
    // 7 weekdays × 24 hours
    const grid = Array.from({length:7}, () => new Array(24).fill(0));
    for (const t of tasks) {
      const d = t[dateField];
      if (!d) continue;
      const day  = d.getDay();   // 0=Sun ... 6=Sat
      const hour = d.getHours();
      grid[day][hour]++;
    }
    return grid;
  }

  /* ──────────────────────────────────────────────────────────────
     10. FILTER OPTIONS (unique values per field for filter UI)
     ────────────────────────────────────────────────────────────── */

  function getFilterOptions(tables) {
    const tasks = tables[ENTITIES.TASK] || [];
    const lrs   = tables[ENTITIES.LOGIN_REQUEST] || [];
    const asgns = tables[ENTITIES.ASSIGN] || [];

    const vals = field => Utils.unique(tasks.map(t => String(t[field] || '')).filter(Boolean)).sort();
    const lrVals = field => Utils.unique(lrs.map(r => String(r[field] || '')).filter(Boolean)).sort();

    return {
      role:       vals('Role'),
      login:      vals('Login'),
      status:     vals('Status'),
      taskId:     vals('TaskID'),
      requestKey: vals('RequestKey').slice(0, 100),
      loginFrom:  Utils.unique(asgns.map(a => a.LoginFrom || '').filter(Boolean)).sort(),
      loginTo:    Utils.unique(asgns.map(a => a.LoginTo   || '').filter(Boolean)).sort(),
      reassigner: Utils.unique(asgns.map(a => a.Reassigner|| '').filter(Boolean)).sort(),
    };
  }

  return {
    computeAutoAssignment,
    computeTaskStateOnDate,
    normalizeTasks,
    applyFilters,
    computeMetrics,
    computeAnswers,
    computeAggregates,
    computeTrendData,
    computeHeatmapData,
    getFilterOptions,
  };
})();
