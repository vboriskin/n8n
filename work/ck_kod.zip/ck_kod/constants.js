/* constants.js — all static configuration */

const ENTITIES = {
  TASK: 'Task',
  LOGIN_REQUEST: 'LoginRequest',
  ASSIGN: 'Assign',
  TASK_DEFERMENT: 'TaskDeferment',
  TASK_ERROR: 'TaskError',
  TASK_DIRECTORY: 'TaskDirectory',
  DEFERMENT_REASON_DIRECTORY: 'DefermentReasonDirectory',
};

const ENTITY_LABELS = {
  Task: 'Задачи',
  LoginRequest: 'Назначения в работу',
  Assign: 'Переназначения',
  TaskDeferment: 'Откладывания',
  TaskError: 'Ошибки',
  TaskDirectory: 'Справочник задач',
  DefermentReasonDirectory: 'Справочник причин',
};

const TASK_STATUS = {
  CLOSED: 'Closed',
  DEFERRED: 'Deferred',
  ERROR: 'ERROR',
  IN_PROGRESS: 'InProgress',
  TODO: 'ToDo',
  NOT_STARTED: 'NotStarted',
};

const COMPUTED_STATUS = {
  CLOSED: 'Closed',
  ERROR: 'Error',
  DEFERRED: 'Deferred',
  IN_PROGRESS: 'InProgress',
  NOT_STARTED: 'NotStarted',
};

const AUTO_ASSIGN_COMMENT = 'Назначение ЦК КОД';

const STATUS_COLORS = {
  Closed:     '#22c55e',
  Error:      '#ef4444',
  ERROR:      '#ef4444',
  Deferred:   '#f59e0b',
  InProgress: '#3b82f6',
  NotStarted: '#6b7280',
  ToDo:       '#94a3b8',
};

/* Patterns used to auto-detect entity from filename (lowercase match) */
const ENTITY_FILENAME_PATTERNS = {
  Task:                      ['task'],
  LoginRequest:              ['loginrequest', 'login_request', 'loginrq'],
  Assign:                    ['assign', 'reassign'],
  TaskDeferment:             ['deferment', 'defer', 'отложен'],
  TaskError:                 ['taskerror', 'task_error'],
  TaskDirectory:             ['taskdirectory', 'task_directory', 'tasktype', 'task_type', 'taskcatalog'],
  DefermentReasonDirectory:  ['defermentreason', 'defreason', 'reasondir'],
};

/* Distinct column names used to score entity match */
const ENTITY_COLUMN_SIGNATURES = {
  Task:                     ['TaskKey', 'TaskID', 'CloseDateTime', 'RequestKey'],
  LoginRequest:             ['IsActive', 'RequestKey', 'Login', 'Role'],
  Assign:                   ['LoginFrom', 'LoginTo', 'Reassigner', 'DealID'],
  TaskDeferment:            ['EndDateTime', 'Deadline', 'Expired'],
  TaskError:                ['TaskKey'],
  TaskDirectory:            ['TaskID', 'Description'],
  DefermentReasonDirectory: ['ReasonCode', 'ReasonDescription'],
};

const CSV_DELIMITERS = {
  auto:      'auto',
  comma:     ',',
  semicolon: ';',
  tab:       '\t',
  pipe:      '|',
};

const GRAIN = { DAY: 'day', WEEK: 'week', MONTH: 'month' };

const AGING_BUCKETS = [
  { label: '0–1 д',   min: 0,   max: 1   },
  { label: '1–3 д',   min: 1,   max: 3   },
  { label: '3–7 д',   min: 3,   max: 7   },
  { label: '7–14 д',  min: 7,   max: 14  },
  { label: '14–30 д', min: 14,  max: 30  },
  { label: '30+ д',   min: 30,  max: Infinity },
];

const TABS = [
  { id: 'answers',    label: 'Ответы',       icon: '◎' },
  { id: 'rawdata',    label: 'Данные',        icon: '⊞' },
  { id: 'metrics',    label: 'Метрики',       icon: '⊡' },
  { id: 'dashboard',  label: 'Дашборд',       icon: '⊟' },
  { id: 'insights',   label: 'Инсайты',       icon: '◈' },
  { id: 'aggregates', label: 'Агрегаты',      icon: '⊕' },
];

const CHART_COLORS = [
  '#6366f1','#22c55e','#f59e0b','#ef4444','#3b82f6',
  '#8b5cf6','#ec4899','#14b8a6','#f97316','#06b6d4',
];

const CHART_PALETTE = {
  primary: '#6366f1',
  success: '#22c55e',
  warning: '#f59e0b',
  danger:  '#ef4444',
  info:    '#3b82f6',
  muted:   '#94a3b8',
  grid:    '#e5e7eb',
  text:    '#1f2937',
  bg:      '#ffffff',
};

const MAX_UNDO = 50;
const PAGE_SIZE = 100;
const BUNDLE_VERSION = '1.0';
const STORAGE_KEY = 'task_analytics_session';
