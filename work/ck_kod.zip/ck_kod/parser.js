/* parser.js — CSV / XLSX parsing, entity detection, column mapping */

const Parser = (() => {

  /* ── CSV ──────────────────────────────────────────────────────── */

  function detectDelimiter(text) {
    const sample = text.slice(0, 4096);
    const counts = {
      ',': (sample.match(/,/g) || []).length,
      ';': (sample.match(/;/g) || []).length,
      '\t': (sample.match(/\t/g) || []).length,
      '|': (sample.match(/\|/g) || []).length,
    };
    return Object.entries(counts).sort(([,a],[,b]) => b-a)[0][0];
  }

  function parseCSVLine(line, delimiter) {
    const cells = [];
    let cur = '', inQuote = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuote && line[i+1] === '"') { cur += '"'; i++; }
        else inQuote = !inQuote;
      } else if (ch === delimiter && !inQuote) {
        cells.push(cur); cur = '';
      } else {
        cur += ch;
      }
    }
    cells.push(cur);
    return cells.map(c => c.trim());
  }

  function parseCSV(text, delimiter = 'auto') {
    const delim = delimiter === 'auto' ? detectDelimiter(text) : delimiter;
    const lines = text.replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n');
    const nonEmpty = lines.filter(l => l.trim());
    if (!nonEmpty.length) return [];

    const headers = parseCSVLine(nonEmpty[0], delim);
    const rows = [];
    for (let i = 1; i < nonEmpty.length; i++) {
      const cells = parseCSVLine(nonEmpty[i], delim);
      const row = {};
      headers.forEach((h, idx) => {
        row[h.trim()] = cells[idx] !== undefined ? cells[idx] : '';
      });
      rows.push(row);
    }
    return rows;
  }

  /* ── XLSX ─────────────────────────────────────────────────────── */

  function parseXLSX(buffer) {
    if (typeof XLSX === 'undefined') {
      throw new Error('xlsx.full.min.js не подключен. Смотри README.');
    }
    const wb = XLSX.read(new Uint8Array(buffer), { type: 'array', cellDates: false });
    const result = {};
    for (const name of wb.SheetNames) {
      const ws = wb.Sheets[name];
      const rows = XLSX.utils.sheet_to_json(ws, { defval: '', raw: true });
      result[name] = rows;
    }
    return result;
  }

  /* ── Entity detection ─────────────────────────────────────────── */

  function detectEntityFromFilename(filename) {
    const low = Utils.normalize(filename).replace(/[_\-\s\.]/g,'');
    for (const [entity, patterns] of Object.entries(ENTITY_FILENAME_PATTERNS)) {
      for (const p of patterns) {
        if (low.includes(p.replace(/[_\-\s]/g,''))) return entity;
      }
    }
    return null;
  }

  function detectEntityFromColumns(columns) {
    const colSet = new Set(columns.map(c => Utils.normalize(c)));
    let bestEntity = null, bestScore = 0;
    for (const [entity, sigs] of Object.entries(ENTITY_COLUMN_SIGNATURES)) {
      const score = sigs.filter(s => colSet.has(Utils.normalize(s))).length;
      if (score > bestScore) { bestScore = score; bestEntity = entity; }
    }
    return bestScore >= 1 ? bestEntity : null;
  }

  function detectEntity(filename, columns) {
    return detectEntityFromFilename(filename)
        || detectEntityFromColumns(columns)
        || null;
  }

  /* ── Type inference ───────────────────────────────────────────── */

  function inferColumnType(values) {
    let dateCount = 0, numCount = 0, total = 0;
    for (const v of values) {
      if (v == null || v === '') continue;
      total++;
      if (Utils.parseDate(v)) dateCount++;
      else if (!isNaN(Number(v))) numCount++;
    }
    if (!total) return 'string';
    if (dateCount / total > 0.6) return 'date';
    if (numCount / total > 0.8) return 'number';
    return 'string';
  }

  function inferSchema(rows, sampleSize = 200) {
    if (!rows.length) return {};
    const sample = rows.slice(0, sampleSize);
    const schema = {};
    for (const key of Object.keys(sample[0])) {
      const vals = sample.map(r => r[key]);
      schema[key] = inferColumnType(vals);
    }
    return schema;
  }

  /* ── Post-processing ──────────────────────────────────────────── */

  function coerceRow(row, schema) {
    const out = {};
    for (const [k, type] of Object.entries(schema)) {
      const v = row[k];
      if (v == null || v === '') { out[k] = null; continue; }
      if (type === 'date') {
        out[k] = Utils.parseDate(v) || null;
      } else if (type === 'number') {
        const n = Number(v);
        out[k] = isNaN(n) ? v : n;
      } else {
        out[k] = String(v).trim();
      }
    }
    return out;
  }

  function coerceRows(rows, schema) {
    return rows.map(r => coerceRow(r, schema));
  }

  /* ── Validate after import ────────────────────────────────────── */

  function validateTable(rows, entity) {
    const issues = [];
    if (!rows.length) { issues.push({ level: 'warning', msg: 'Таблица пустая' }); return issues; }

    const required = {
      Task:         ['pxCreateDateTime'],
      LoginRequest: ['pxCreateDateTime'],
      TaskDeferment:['pxCreateDateTime'],
      TaskError:    ['pxCreateDateTime'],
      Assign:       ['pxCreateDateTime'],
    };
    const req = required[entity] || [];
    const cols = Object.keys(rows[0]);
    for (const r of req) {
      if (!cols.includes(r)) {
        issues.push({ level: 'warning', msg: `Отсутствует колонка ${r}` });
      }
    }

    // Check for duplicate TaskKey
    if (entity === ENTITIES.TASK && cols.includes('TaskKey')) {
      const keys = rows.map(r => r['TaskKey']).filter(Boolean);
      const uniq = new Set(keys);
      if (uniq.size < keys.length) {
        issues.push({ level: 'info', msg: `Дублирование TaskKey: ${keys.length - uniq.size} строк` });
      }
    }

    return issues;
  }

  /* ── Main entry point ─────────────────────────────────────────── */

  async function parseFile(file, csvDelimiter = 'auto') {
    const name = file.name;
    const ext  = name.split('.').pop().toLowerCase();

    let sheetRows = {}; // { sheetName: rows[] }

    if (ext === 'csv') {
      const text = await readAsText(file);
      sheetRows[name] = parseCSV(text, csvDelimiter);
    } else if (ext === 'xlsx' || ext === 'xls') {
      const buffer = await readAsArrayBuffer(file);
      sheetRows = parseXLSX(buffer);
    } else {
      throw new Error(`Неподдерживаемый формат: .${ext}`);
    }

    const result = [];
    for (const [sheet, rows] of Object.entries(sheetRows)) {
      if (!rows.length) continue;
      const cols   = Object.keys(rows[0]);
      const entity = detectEntity(name.replace(/\.[^.]+$/, ''), cols)
                  || detectEntity(sheet, cols);
      const schema = inferSchema(rows);
      const coerced = coerceRows(rows, schema);
      const issues  = validateTable(coerced, entity);
      result.push({ filename: name, sheet, entity, columns: cols, schema, rows: coerced, issues, rawRows: rows });
    }
    return result;
  }

  function readAsText(file) {
    return new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onload  = e => res(e.target.result);
      fr.onerror = rej;
      fr.readAsText(file, 'UTF-8');
    });
  }

  function readAsArrayBuffer(file) {
    return new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onload  = e => res(e.target.result);
      fr.onerror = rej;
      fr.readAsArrayBuffer(file);
    });
  }

  return {
    parseFile, parseCSV, parseXLSX,
    detectEntity, detectEntityFromFilename, detectEntityFromColumns,
    inferSchema, coerceRows, validateTable,
  };
})();
