/* charts.js — lightweight Canvas/SVG chart renderer */

const Charts = (() => {
  const P = CHART_PALETTE;

  /* ── helpers ─────────────────────────────────────────────────── */
  function dpr() { return window.devicePixelRatio || 1; }

  function setupCanvas(canvas, w, h) {
    const r = dpr();
    canvas.width  = w * r;
    canvas.height = h * r;
    canvas.style.width  = w + 'px';
    canvas.style.height = h + 'px';
    const ctx = canvas.getContext('2d');
    ctx.scale(r, r);
    ctx.clearRect(0, 0, w, h);
    return ctx;
  }

  function nice(v) {
    if (v >= 1e6) return (v/1e6).toFixed(1) + 'M';
    if (v >= 1e3) return (v/1e3).toFixed(1) + 'K';
    return String(Math.round(v));
  }

  function niceMax(max) {
    if (!max) return 10;
    const exp = Math.pow(10, Math.floor(Math.log10(max)));
    const step = Math.ceil(max / exp) * exp;
    return step || 10;
  }

  /* ── Line Chart ──────────────────────────────────────────────── */
  function drawLine(canvas, data, opts = {}) {
    /*
      data: { labels: string[], series: [{name, color, values: number[]}] }
      opts: { title, yLabel, smooth }
    */
    const W = canvas.offsetWidth || 600, H = canvas.offsetHeight || 280;
    const ctx = setupCanvas(canvas, W, H);
    const PAD = { top: 36, right: 20, bottom: 48, left: 52 };
    const cw = W - PAD.left - PAD.right;
    const ch = H - PAD.top  - PAD.bottom;

    if (!data?.labels?.length) { _empty(ctx, W, H); return; }

    const allVals = data.series.flatMap(s => s.values);
    const maxV = niceMax(Math.max(...allVals, 1));
    const labels = data.labels;
    const n = labels.length;

    // grid
    ctx.strokeStyle = P.grid; ctx.lineWidth = 1;
    const yTicks = 5;
    for (let i = 0; i <= yTicks; i++) {
      const y = PAD.top + ch - (i / yTicks) * ch;
      ctx.beginPath(); ctx.moveTo(PAD.left, y); ctx.lineTo(PAD.left + cw, y); ctx.stroke();
      ctx.fillStyle = '#6b7280'; ctx.font = '11px system-ui';
      ctx.textAlign = 'right';
      ctx.fillText(nice(maxV * i / yTicks), PAD.left - 6, y + 4);
    }

    // x labels (show ~8 evenly)
    const step = Math.max(1, Math.ceil(n / 8));
    ctx.fillStyle = '#6b7280'; ctx.font = '11px system-ui'; ctx.textAlign = 'center';
    for (let i = 0; i < n; i += step) {
      const x = PAD.left + (n > 1 ? i / (n-1) : 0.5) * cw;
      ctx.fillText(labels[i], x, H - PAD.bottom + 16);
    }

    // title
    if (opts.title) {
      ctx.fillStyle = P.text; ctx.font = 'bold 13px system-ui'; ctx.textAlign = 'center';
      ctx.fillText(opts.title, W/2, 18);
    }

    // series
    for (const s of data.series) {
      const vals = s.values;
      const color = s.color || P.primary;

      ctx.strokeStyle = color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const x = PAD.left + (n > 1 ? i/(n-1) : 0.5) * cw;
        const y = PAD.top + ch - (vals[i] / maxV) * ch;
        i === 0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
      }
      ctx.stroke();

      // area
      ctx.save();
      ctx.globalAlpha = 0.08;
      ctx.fillStyle = color;
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const x = PAD.left + (n > 1 ? i/(n-1) : 0.5) * cw;
        const y = PAD.top + ch - (vals[i] / maxV) * ch;
        i === 0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
      }
      ctx.lineTo(PAD.left + cw, PAD.top + ch);
      ctx.lineTo(PAD.left, PAD.top + ch);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }

    // legend
    let lx = PAD.left;
    for (const s of data.series) {
      ctx.fillStyle = s.color || P.primary;
      ctx.fillRect(lx, H - 16, 12, 8);
      ctx.fillStyle = '#6b7280'; ctx.font = '11px system-ui'; ctx.textAlign = 'left';
      ctx.fillText(s.name, lx + 16, H - 8);
      lx += ctx.measureText(s.name).width + 32;
    }
  }

  /* ── Bar Chart ────────────────────────────────────────────────── */
  function drawBar(canvas, data, opts = {}) {
    /*
      data: { labels: string[], series: [{name, color, values: number[]}] }
      opts: { title, horizontal, stacked }
    */
    const W = canvas.offsetWidth || 600, H = canvas.offsetHeight || 280;
    const ctx = setupCanvas(canvas, W, H);
    if (!data?.labels?.length) { _empty(ctx, W, H); return; }

    if (opts.horizontal) { _drawBarH(ctx, data, W, H, opts); return; }

    const PAD = { top: 36, right: 20, bottom: 64, left: 52 };
    const cw = W - PAD.left - PAD.right;
    const ch = H - PAD.top  - PAD.bottom;
    const labels = data.labels;
    const n = labels.length;
    const nseries = data.series.length;

    const allVals = opts.stacked
      ? labels.map((_,i) => data.series.reduce((s,sr) => s + (sr.values[i]||0), 0))
      : data.series.flatMap(s => s.values);
    const maxV = niceMax(Math.max(...allVals, 1));

    // grid
    ctx.strokeStyle = P.grid; ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      const y = PAD.top + ch - (i/5)*ch;
      ctx.beginPath(); ctx.moveTo(PAD.left, y); ctx.lineTo(PAD.left+cw, y); ctx.stroke();
      ctx.fillStyle = '#6b7280'; ctx.font = '11px system-ui'; ctx.textAlign = 'right';
      ctx.fillText(nice(maxV*i/5), PAD.left-6, y+4);
    }
    if (opts.title) {
      ctx.fillStyle = P.text; ctx.font = 'bold 13px system-ui'; ctx.textAlign = 'center';
      ctx.fillText(opts.title, W/2, 18);
    }

    const groupW = cw / n;
    const barW   = opts.stacked ? groupW * 0.7 : (groupW * 0.8) / nseries;

    for (let i = 0; i < n; i++) {
      const gx = PAD.left + i * groupW + groupW * 0.1;
      let stackBase = 0;
      for (let s = 0; s < nseries; s++) {
        const val   = data.series[s].values[i] || 0;
        const color = data.series[s].color || CHART_COLORS[s % CHART_COLORS.length];
        let x, barH, y;
        if (opts.stacked) {
          barH = (val / maxV) * ch;
          y    = PAD.top + ch - barH - (stackBase/maxV)*ch;
          x    = gx + (groupW * 0.7 - groupW * 0.7) / 2;
          x    = gx;
          stackBase += val;
        } else {
          x    = gx + s * barW;
          barH = (val / maxV) * ch;
          y    = PAD.top + ch - barH;
        }
        ctx.fillStyle = color;
        ctx.fillRect(x, y, opts.stacked ? groupW*0.7 : barW - 1, barH);
      }

      // x label
      ctx.fillStyle = '#6b7280'; ctx.font = '11px system-ui'; ctx.textAlign = 'center';
      ctx.save(); ctx.translate(gx + groupW*0.5, H - PAD.bottom + 8);
      const lbl = String(labels[i]);
      if (lbl.length > 12 && n > 6) {
        ctx.rotate(-Math.PI/4); ctx.textAlign = 'right';
      }
      ctx.fillText(Utils.truncate(lbl, 16), 0, 0);
      ctx.restore();
    }

    // legend
    let lx = PAD.left;
    for (let s = 0; s < nseries; s++) {
      const color = data.series[s].color || CHART_COLORS[s % CHART_COLORS.length];
      ctx.fillStyle = color; ctx.fillRect(lx, H-16, 12, 8);
      ctx.fillStyle = '#6b7280'; ctx.font = '11px system-ui'; ctx.textAlign = 'left';
      ctx.fillText(data.series[s].name, lx+16, H-8);
      lx += ctx.measureText(data.series[s].name).width + 32;
    }
  }

  function _drawBarH(ctx, data, W, H, opts) {
    const PAD = { top: 24, right: 60, bottom: 24, left: 140 };
    const cw = W - PAD.left - PAD.right;
    const ch = H - PAD.top  - PAD.bottom;
    const labels = data.labels;
    const n = labels.length;
    const vals = data.series[0]?.values || [];
    const maxV = niceMax(Math.max(...vals, 1));
    const barH = Math.min((ch / n) * 0.7, 28);
    const gap  = (ch / n) * 0.3;

    if (opts.title) {
      ctx.fillStyle = P.text; ctx.font = 'bold 13px system-ui'; ctx.textAlign = 'center';
      ctx.fillText(opts.title, W/2, 16);
    }

    for (let i = 0; i < n; i++) {
      const y   = PAD.top + i * (barH + gap);
      const val = vals[i] || 0;
      const bw  = (val / maxV) * cw;
      const color = data.series[0].color || CHART_COLORS[i % CHART_COLORS.length];

      ctx.fillStyle = color;
      ctx.beginPath();
      _roundRect(ctx, PAD.left, y, Math.max(bw,2), barH, 3);
      ctx.fill();

      // label left
      ctx.fillStyle = P.text; ctx.font = '11px system-ui'; ctx.textAlign = 'right';
      ctx.fillText(Utils.truncate(String(labels[i]), 20), PAD.left - 6, y + barH/2 + 4);

      // value right
      ctx.fillStyle = '#6b7280'; ctx.textAlign = 'left';
      ctx.fillText(nice(val), PAD.left + bw + 4, y + barH/2 + 4);
    }
  }

  function _roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x+r, y);
    ctx.lineTo(x+w-r, y); ctx.arcTo(x+w,y, x+w,y+r, r);
    ctx.lineTo(x+w, y+h-r); ctx.arcTo(x+w,y+h, x+w-r,y+h, r);
    ctx.lineTo(x+r, y+h); ctx.arcTo(x,y+h, x,y+h-r, r);
    ctx.lineTo(x, y+r); ctx.arcTo(x,y, x+r,y, r);
    ctx.closePath();
  }

  /* ── Donut Chart ─────────────────────────────────────────────── */
  function drawDonut(canvas, data, opts = {}) {
    /*
      data: [{label, value, color}]
      opts: { title, centerText }
    */
    const W = canvas.offsetWidth || 300, H = canvas.offsetHeight || 260;
    const ctx = setupCanvas(canvas, W, H);
    if (!data?.length) { _empty(ctx, W, H); return; }

    const total = data.reduce((s,d) => s + (d.value||0), 0);
    if (!total) { _empty(ctx, W, H); return; }

    const R = Math.min(W, H) * 0.35;
    const cx = W / 2, cy = H * 0.46;
    const innerR = R * 0.55;
    let angle = -Math.PI / 2;

    if (opts.title) {
      ctx.fillStyle = P.text; ctx.font = 'bold 13px system-ui'; ctx.textAlign = 'center';
      ctx.fillText(opts.title, cx, 16);
    }

    for (let i = 0; i < data.length; i++) {
      const slice = (data[i].value / total) * 2 * Math.PI;
      const color = data[i].color || CHART_COLORS[i % CHART_COLORS.length];
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, R, angle, angle + slice);
      ctx.arc(cx, cy, innerR, angle + slice, angle, true);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.fill();
      angle += slice;
    }

    // center text
    const center = opts.centerText || String(total);
    ctx.fillStyle = P.text;
    ctx.font = `bold ${Math.floor(R*0.35)}px system-ui`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(center, cx, cy);
    ctx.textBaseline = 'alphabetic';

    // legend
    const legendY = cy + R + 16;
    let lx = 12, ly = legendY;
    const lineH = 20;
    for (let i = 0; i < data.length; i++) {
      const color = data[i].color || CHART_COLORS[i % CHART_COLORS.length];
      const lbl = `${data[i].label}: ${Utils.formatPct(Utils.pct(data[i].value, total))}`;
      const tw = ctx.measureText(lbl).width + 24;
      if (lx + tw > W - 12 && lx > 12) { lx = 12; ly += lineH; }
      ctx.fillStyle = color; ctx.fillRect(lx, ly-10, 12, 10);
      ctx.fillStyle = '#6b7280'; ctx.font = '11px system-ui'; ctx.textAlign = 'left';
      ctx.fillText(lbl, lx + 16, ly);
      lx += tw + 8;
    }
  }

  /* ── Heatmap ─────────────────────────────────────────────────── */
  function drawHeatmap(canvas, grid, opts = {}) {
    /*
      grid: number[7][24]  — weekday × hour
      opts: { title, colorFn }
    */
    const W = canvas.offsetWidth || 620, H = canvas.offsetHeight || 200;
    const ctx = setupCanvas(canvas, W, H);
    const DAYS  = ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];
    const PAD   = { top: 32, right: 12, bottom: 20, left: 28 };
    const cw = W - PAD.left - PAD.right;
    const ch = H - PAD.top  - PAD.bottom;
    const cellW = cw / 24;
    const cellH = ch / 7;
    const maxV  = Math.max(...grid.flat(), 1);

    if (opts.title) {
      ctx.fillStyle = P.text; ctx.font = 'bold 13px system-ui'; ctx.textAlign = 'center';
      ctx.fillText(opts.title, W/2, 16);
    }

    for (let day = 0; day < 7; day++) {
      for (let hr = 0; hr < 24; hr++) {
        const val   = grid[day][hr];
        const alpha = val / maxV;
        const x = PAD.left + hr * cellW;
        const y = PAD.top  + day * cellH;
        ctx.fillStyle = `rgba(99,102,241,${alpha.toFixed(2)})`;
        ctx.fillRect(x+1, y+1, cellW-2, cellH-2);
      }
    }

    // axes
    ctx.fillStyle = '#6b7280'; ctx.font = '10px system-ui'; ctx.textAlign = 'right';
    for (let d = 0; d < 7; d++) {
      ctx.fillText(DAYS[d], PAD.left-4, PAD.top + d*cellH + cellH/2 + 4);
    }
    ctx.textAlign = 'center';
    for (let h = 0; h < 24; h += 3) {
      ctx.fillText(h + ':00', PAD.left + h*cellW + cellW*1.5, PAD.top - 6);
    }
  }

  /* ── Sparkline ───────────────────────────────────────────────── */
  function drawSparkline(canvas, values, color = P.primary) {
    const W = canvas.offsetWidth || 80, H = canvas.offsetHeight || 28;
    const ctx = setupCanvas(canvas, W, H);
    if (!values?.length) return;
    const max = Math.max(...values, 1);
    const n = values.length;
    ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const x = (i / Math.max(n-1,1)) * W;
      const y = H - (values[i] / max) * H * 0.85;
      i === 0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
    }
    ctx.stroke();
  }

  /* ── Funnel ──────────────────────────────────────────────────── */
  function drawFunnel(canvas, steps, opts = {}) {
    /*
      steps: [{label, value, color}]
    */
    const W = canvas.offsetWidth || 500, H = canvas.offsetHeight || 260;
    const ctx = setupCanvas(canvas, W, H);
    if (!steps?.length) { _empty(ctx, W, H); return; }

    if (opts.title) {
      ctx.fillStyle = P.text; ctx.font = 'bold 13px system-ui'; ctx.textAlign = 'center';
      ctx.fillText(opts.title, W/2, 18);
    }

    const n    = steps.length;
    const maxV = steps[0].value || 1;
    const stepH = (H - 36) / n;
    const maxW = W * 0.7;
    const cx   = W / 2;

    for (let i = 0; i < n; i++) {
      const ratio = steps[i].value / maxV;
      const nextRatio = i < n-1 ? steps[i+1].value / maxV : ratio * 0.8;
      const color = steps[i].color || CHART_COLORS[i % CHART_COLORS.length];
      const y1 = 30 + i * stepH;
      const y2 = y1 + stepH - 2;
      const w1 = maxW * ratio;
      const w2 = maxW * nextRatio;

      ctx.beginPath();
      ctx.moveTo(cx - w1/2, y1);
      ctx.lineTo(cx + w1/2, y1);
      ctx.lineTo(cx + w2/2, y2);
      ctx.lineTo(cx - w2/2, y2);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.85;
      ctx.fill();
      ctx.globalAlpha = 1;

      // Label
      ctx.fillStyle = P.text; ctx.font = 'bold 12px system-ui'; ctx.textAlign = 'center';
      ctx.fillText(`${steps[i].label}: ${Utils.formatNum(steps[i].value)}`, cx, y1 + stepH/2 + 4);
    }
  }

  /* ── empty state ─────────────────────────────────────────────── */
  function _empty(ctx, W, H) {
    ctx.fillStyle = '#e5e7eb';
    ctx.font = '13px system-ui'; ctx.textAlign = 'center';
    ctx.fillText('Нет данных', W/2, H/2);
  }

  /* ── Public resize helper ─────────────────────────────────────── */
  function autoResize(canvas, drawFn) {
    const ro = new ResizeObserver(() => drawFn());
    ro.observe(canvas);
    drawFn();
    return ro;
  }

  return { drawLine, drawBar, drawDonut, drawHeatmap, drawSparkline, drawFunnel, autoResize };
})();
