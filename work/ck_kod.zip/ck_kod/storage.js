/* storage.js — session persistence via localStorage / IndexedDB */

const Storage = (() => {

  const LS_KEY  = STORAGE_KEY;
  const DB_NAME = 'task_analytics';
  const DB_VER  = 1;
  let   _db     = null;

  /* ── IndexedDB init ───────────────────────────────────────────── */

  function openDB() {
    if (_db) return Promise.resolve(_db);
    return new Promise((res, rej) => {
      const req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = e => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('tables')) {
          db.createObjectStore('tables', { keyPath: 'entity' });
        }
        if (!db.objectStoreNames.contains('meta')) {
          db.createObjectStore('meta', { keyPath: 'key' });
        }
      };
      req.onsuccess = e => { _db = e.target.result; res(_db); };
      req.onerror   = e => rej(e.target.error);
    });
  }

  function dbPut(storeName, record) {
    return openDB().then(db => new Promise((res, rej) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).put(record).onsuccess = e => res(e.target.result);
      tx.onerror = e => rej(e.target.error);
    }));
  }

  function dbGet(storeName, key) {
    return openDB().then(db => new Promise((res, rej) => {
      const tx = db.transaction(storeName, 'readonly');
      tx.objectStore(storeName).get(key).onsuccess = e => res(e.target.result);
      tx.onerror = e => rej(e.target.error);
    }));
  }

  function dbGetAll(storeName) {
    return openDB().then(db => new Promise((res, rej) => {
      const tx = db.transaction(storeName, 'readonly');
      tx.objectStore(storeName).getAll().onsuccess = e => res(e.target.result);
      tx.onerror = e => rej(e.target.error);
    }));
  }

  function dbDelete(storeName, key) {
    return openDB().then(db => new Promise((res, rej) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).delete(key).onsuccess = () => res();
      tx.onerror = e => rej(e.target.error);
    }));
  }

  function dbClear(storeName) {
    return openDB().then(db => new Promise((res, rej) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).clear().onsuccess = () => res();
      tx.onerror = e => rej(e.target.error);
    }));
  }

  /* ── Public API ───────────────────────────────────────────────── */

  async function saveTable(entity, rows, schema, columns) {
    try {
      await dbPut('tables', { entity, rows, schema, columns, savedAt: new Date().toISOString() });
    } catch(e) {
      console.warn('Storage.saveTable failed', e);
    }
  }

  async function loadTable(entity) {
    try {
      return await dbGet('tables', entity);
    } catch(e) {
      console.warn('Storage.loadTable failed', e);
      return null;
    }
  }

  async function loadAllTables() {
    try {
      const all = await dbGetAll('tables');
      const result = {};
      for (const rec of all) { result[rec.entity] = rec; }
      return result;
    } catch(e) {
      console.warn('Storage.loadAllTables failed', e);
      return {};
    }
  }

  async function clearTables() {
    try { await dbClear('tables'); } catch(e) { console.warn(e); }
  }

  function saveMeta(key, value) {
    try {
      const data = JSON.stringify(value);
      localStorage.setItem(`${LS_KEY}:${key}`, data);
    } catch(e) { console.warn('Storage.saveMeta failed', e); }
  }

  function loadMeta(key, fallback = null) {
    try {
      const raw = localStorage.getItem(`${LS_KEY}:${key}`);
      if (raw == null) return fallback;
      return JSON.parse(raw);
    } catch { return fallback; }
  }

  function clearMeta() {
    const toRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k.startsWith(`${LS_KEY}:`)) toRemove.push(k);
    }
    toRemove.forEach(k => localStorage.removeItem(k));
  }

  async function clearAll() {
    await clearTables();
    clearMeta();
  }

  async function hasSession() {
    try {
      const all = await loadAllTables();
      return Object.keys(all).length > 0;
    } catch { return false; }
  }

  /* Serialize rows with Date objects to JSON-safe form */
  function serializeRows(rows) {
    return rows.map(row => {
      const out = {};
      for (const [k, v] of Object.entries(row)) {
        out[k] = v instanceof Date ? v.toISOString() : v;
      }
      return out;
    });
  }

  /* Deserialize rows, restoring Date columns by schema */
  function deserializeRows(rows, schema) {
    if (!schema) return rows;
    return rows.map(row => {
      const out = {};
      for (const [k, v] of Object.entries(row)) {
        if (schema[k] === 'date' && v) out[k] = Utils.parseDate(v);
        else out[k] = v;
      }
      return out;
    });
  }

  return {
    saveTable, loadTable, loadAllTables, clearTables,
    saveMeta, loadMeta, clearMeta, clearAll, hasSession,
    serializeRows, deserializeRows,
  };
})();
